# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import logging
import re
from abc import ABC, ABCMeta
from typing import Any, Callable, Dict, Tuple, Type, TypeVar

from lark.exceptions import LarkError
from typing_extensions import Self

from .inline_eval import InlineEval

_PASCAL_CASE_REGEX = re.compile(r"^[A-Z]+[a-z]*(?:\d*(?:[A-Z]+[a-z]*)?)*$")
_CAMEL_BOUNDARY_REGEX = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)


def pascal_to_upper_snake(name: str) -> str:
    """
    Convert a camel case string to an upper snake case string.

    Parameters:
        name: The camel case string to convert.

    Returns:
        The upper snake case string.

    Raises:
        ValueError: If the name is not in PascalCase format
    """

    if not _PASCAL_CASE_REGEX.match(name):
        raise ValueError(f"{name} is not in PascalCase format!")

    name = _CAMEL_BOUNDARY_REGEX.sub("_", name)
    return name.upper()


class Spec(ABC):
    """
    The base class for all specifications.
    """

    def __init__(self) -> None:
        super().__init__()

        if not dc.is_dataclass(self):
            raise ValueError("Spec classes must be dataclasses.")

    @classmethod
    def load_from_dict(cls, cfg: Dict[str, Any]) -> Self:
        result: Dict[str, Any] = {}
        for key in dc.fields(cls):
            try:
                result[key.name] = cfg[key.name]
            except KeyError as ke:
                raise ValueError(f"Missing key {key.name} in config") from ke
        return cls(**result)


_Spec = TypeVar("_Spec", bound=Spec, covariant=True)

# The states for this decorator are stored in the closure.
REGISTRY_FOR_CLASSES: Dict[Tuple[Type, str], Tuple[Type, Type]] = {}

_T = TypeVar("_T", bound=Type)


def factorise(base_spec_class: Type[_Spec], /) -> Any:
    """
    A decorator that automatically modifies a class to accept a specification in its constructor,
    along with a factory method for creating instances of the class with the specified name.
    This decorator is intended solely for use with abstract classes.

    Every specified class accompanies a `Spec` dataclass that defines the specification for the class.

    After `factorise` is applied to a class, the class will have a `spec` attribute that is initialized with the given specification.

    Subclasses should inherit from the decorated class and put a `spec_class` attribute in the class definition,
    which should be a subclass of the `base_spec_class` given in the decorator.

    See examples below for more details.

    Examples:
        >>> @dc.dataclass
        ... class FooSpec:
        ...     a: int = 10

        >>> @factorise(FooSpec)
        ... class Foo:
        ...     pass

        >>> Foo(FooSpec()).spec
        FooSpec(a=10)

        Subclasses of the decorated class (`Foo` in the example above) should put a `spec_class` attribute
        in the class definition, which should be a subclass of the `base_spec_class`
        given in the decorator. The decorator ensures that the spec class is a subclass of the base spec class.

        >>> @dc.dataclass
        ... class BarSpec(FooSpec):
        ...     b: float = 666.666

        >>> class Bar(Foo, spec_class=BarSpec):
        ...     pass

        >>> Bar(BarSpec(a=20, b=30.0)).spec
        BarSpec(a=20, b=30.0)

        After decorating the class, the class will have a `factory` method
        that can be used to create instances of the class,
        and a `registered_classes` method that returns a list of available class names.

        >>> Foo.factory("BAR", a=20, b=22.2).spec
        BarSpec(a=20, b=22.2)

        >>> Foo.registered_classes()
        ['BAR']

        If we want to register more classes, we can do so by subclassing the `Foo` class in the same way.

        >>> @dc.dataclass
        ... class BazSpec(BarSpec):
        ...     c: str = "baz"

        >>> class Baz(Foo, spec_class=BazSpec):
        ...     pass

        >>> Foo.registered_classes()
        ['BAR', 'BAZ']

        >>> Foo.factory("BAZ", a=20, b=22.2, c="hello").spec
        BazSpec(a=20, b=22.2, c='hello')

    Parameters:
        base_spec_class: The base specification class for the class to decorate.

    Returns:
        A decorator that decorates the class with its specification class.

    Raises:
        TypeError: If the class is not abstract.
        KeyError: If the class with the same name is already registered.

    TODO:
        Perhaps allow use of ``factorise`` on objects, not just classes.
    """

    def decorator(base_class: _T, /) -> _T:
        LOGGER.info(f"Factorising {base_class} with {base_spec_class}")

        # The base class must be abstract to use the `factorise` method.
        if not isinstance(base_class, ABCMeta):
            raise TypeError(
                f"{base_class} is not abstract! "
                "You cannot use the `factorise` method on a class that does not define subclasses."
            )

        specify(base_spec_class)(base_class)

        _set_factory(base_class)

        return base_class

    return decorator


def specify(base_spec_class: Type[_Spec], /) -> Any:
    def decorator(base_class: _T) -> _T:
        LOGGER.info(f"Specifying {base_class} with {base_spec_class}")

        _set_init(base_class, base_spec_class)
        _set_init_subc(base_class, base_spec_class)
        return base_class

    return decorator


def _set_init(base_class, base_spec_class):
    def __init__(self, spec: _Spec, /, *args, **kwargs) -> None:
        if not isinstance(spec, base_spec_class):
            raise TypeError(f"{spec} should be an instance of {base_spec_class}")

        super(base_class, self).__init__(*args, **kwargs)
        self.__spec = spec

    @property
    def spec(self) -> _Spec:
        """
        The getter for spec attribute.
        This is used as a readonly attribute for all the subclasses.

        The superclass must be `@specify`-ed for this to work.
        """

        return self.__spec

    base_class.__init__ = __init__
    base_class.spec = spec


def _set_init_subc(base_class, base_spec_class):
    @classmethod
    def __init_subclass__(
        cls,
        spec_class: type[_Spec],
        class_name: Callable[[str], str] | str = pascal_to_upper_snake,
        **kwargs,
    ) -> None:
        """
        The `__init_subclass__` method is called when the class is subclassed.
        Here, it registers the subclass with the factory method,
        with keys being computed from the class name.

        Parameters:
            spec_class: The specification class for the subclass.
            class_name:
                The key for the new subclass accessed from the factory,
                or the function to rewrite the ``cls.__name__`` attribute into the key.

                By default, it converts the ``__name__`` from PascalCase to UPPER_SNAKE_CASE.
        """

        super(base_class, cls).__init_subclass__(**kwargs)

        # The given spec class should be a subclass of the base spec class.
        if not issubclass(spec_class, base_spec_class):
            raise TypeError(f"{spec_class} should be a subclass of {base_spec_class}")

        # The spec class should be a dataclass.
        if not dc.is_dataclass(spec_class):
            raise ValueError("Spec classes must be dataclasses.")

        # If the class has name `PascalCase`, the registered name would be `PASCAL_CASE`.
        if callable(class_name):
            reg_name = class_name(cls.__name__)
        elif isinstance(class_name, str):
            reg_name = class_name
        else:
            raise TypeError(f"Invalid type for name: {type(class_name)=}")

        REGISTRY_FOR_CLASSES[base_class, reg_name] = spec_class, cls

    base_class.__init_subclass__ = __init_subclass__


_INLINE_EVAL = InlineEval()


def _set_factory(base_class):
    @classmethod
    def factory(cls, name: str, **kwargs: Any):
        """
        Factory method to create instances of the class with the given name.
        The name always would be in UPPER_SNAKE_CASE format, corresponding to the class name `UpperSnakeCase` originally.

        Parameters:
            name:
                The name of the class to create an instance of.
                The name can also be an inline evaluation string.
            **kwargs: The keyword arguments to pass to the class constructor

        Example:
            >>> Foo.factory("BAR", a=20, b=22.2)
            Bar(a=20, b=22.2)

            >>> Foo.factory("BAR(a=20)", b=22.2)
            Bar(a=20, b=22.2)

        Returns:
            An instance of the class with the given name.
        """

        try:
            n, kw = _INLINE_EVAL(name)
        except LarkError as le:
            raise KeyError(f"Invalid name {name}! Must be a valid class name or an inline evaluation string.") from le
        return cls._factory(n, **{**kw, **kwargs})

    @classmethod
    def _factory(cls, name: str, **kwargs: Any):
        try:
            spec, klass = REGISTRY_FOR_CLASSES[base_class, name]
        except KeyError as ke:
            raise KeyError(f"Class {name} is not registered! Registered: {cls.registered_classes()}") from ke
        return klass(spec(**kwargs))

    @classmethod
    def registered_classes(cls):
        """
        Examples:
            >>> Foo.registered_classes()
            ['BAR', 'BAZ']

        Returns:
            A list of available class names registered with the factory method.
        """

        return [name for klass, name in REGISTRY_FOR_CLASSES.keys() if klass == base_class]

    base_class.factory = factory
    base_class._factory = _factory
    base_class.registered_classes = registered_classes
