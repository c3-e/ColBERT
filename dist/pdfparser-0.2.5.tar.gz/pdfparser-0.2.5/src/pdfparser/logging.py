# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from logging import CRITICAL, DEBUG, ERROR, INFO, WARNING, Handler
from typing import Any, Callable

from pdfparser import utils


class C3LogHandler(Handler):
    """
    C3 logging handler.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._logger = utils.c3_ctx().log()

    def emit(self, record):
        return self._c3_logging(record)

    @property
    def _c3_logging(self) -> Callable[[str], Any]:
        try:
            return {
                DEBUG: self._logger.debug,
                INFO: self._logger.info,
                WARNING: self._logger.warn,
                ERROR: self._logger.error,
                CRITICAL: self._logger.critical,
            }[self.level]
        except KeyError:
            raise ValueError("Unsupported log level: %s" % self.level)
