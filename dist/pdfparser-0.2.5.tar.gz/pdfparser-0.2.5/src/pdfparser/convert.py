# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import re
import warnings
from pathlib import Path
from types import FunctionType
from typing import NamedTuple, Type

import jinja2

from .decltype import LayoutModule

HIDDEN_METHOD = re.compile(r"_\w+")

TEMPL_STRING = (Path(__file__).parent / "convert.j2").read_text()
ENV = jinja2.Environment()
TMPL = ENV.from_string(TEMPL_STRING)


class C3TypeAndImpl(NamedTuple):
    c3typ: str
    impl: str


def convert(klass: Type[LayoutModule], c3env: str) -> str:
    warnings.warn("Experimental feature", FutureWarning)

    if not issubclass(klass, LayoutModule):
        raise TypeError("klass must be a subclass of LayoutModule")

    c3typ = klass.C3_TYPE_CLASS

    if c3typ is None:
        raise ValueError(f"{klass} is not a remote class. `remote` must be set to a valid C3 path.")

    static_fields = [f for f in dc.fields(klass) if f.name != "C3_TYPE_CLASS"]

    dynamic_fields = [f for f in dir(klass) if not HIDDEN_METHOD.match(f)]
    for f in dynamic_fields:
        if f in static_fields:
            continue

        if f == "C3_TYPE_CLASS":
            continue

        if not isinstance(getattr(klass, f), (FunctionType, property)):
            raise TypeError(f"{f} is not a method or property")

    members = []
    for member in static_fields:
        members.append({"name": member.name, "type": member.type.__name__})

    functions = []
    for function in dynamic_fields:
        # Convert properties into methods.
        if isinstance(getattr(klass, function), property):
            functions.append(
                {
                    "name": function,
                    "is_property": True,
                    "output": getattr(klass, function).fget.__annotations__["return"].__name__,
                }
            )
            continue

        if isinstance(getattr(klass, function), FunctionType):
            functions.append(
                {
                    "name": function,
                    "is_property": False,
                    "output": getattr(klass, function).__annotations__["return"].__name__,
                }
            )
        functions.append({"name": function})

    c3file = TMPL.render(
        c3typ=c3typ,
        members=members,
        functions=functions,
        c3env=c3env,
    )
    return C3TypeAndImpl(c3file, "")


if __name__ == "__main__":

    @dc.dataclass
    class TestLayout(LayoutModule, remote="c3.a.b.c.d"):
        pass

    print(convert(TestLayout, "c3"))
