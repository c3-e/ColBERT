# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import Dict, Iterator, List, MutableMapping

from .graphs import Graph


@dc.dataclass(frozen=True)
class GraphDict(MutableMapping[str, Graph]):
    mapping: Dict[str, Graph]

    def __post_init__(self):
        lengths = set()

        for key, value in self.mapping.items():
            if not isinstance(value, Graph):
                raise ValueError(f"Value for key {key} must be a Graph object.")
            lengths.add(len(value))

        if len(lengths) > 1:
            raise ValueError("All graphs must have the same number of rows.")

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GraphDict):
            return NotImplemented

        return self.mapping == other.mapping

    def __iter__(self) -> Iterator[str]:
        return iter(self.mapping)

    def __len__(self) -> int:
        return len(self.mapping)

    def __getitem__(self, key: str) -> Graph:
        return self.mapping[key]

    def __setitem__(self, key: str, value: Graph):
        if len(self.mapping) and len(value) != self.num_rows:
            raise ValueError(
                "The graph must have the same number of rows as the context."
                f"Got {len(value)} rows, expected {self.num_rows}."
            )

        self.mapping[key] = value

    def __delitem__(self, key: str):
        del self.mapping[key]

    @property
    def num_rows(self) -> int | None:
        if not self.mapping:
            return None

        return len(next(iter(self.mapping.values())))

    @classmethod
    def empty(cls) -> GraphDict:
        return cls({})

    def take(self, indices: List[int], /) -> GraphDict:
        return GraphDict({key: value.take(indices) for key, value in self.mapping.items()})
