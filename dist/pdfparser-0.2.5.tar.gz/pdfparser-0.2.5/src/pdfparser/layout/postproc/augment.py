# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from typing import no_type_check

from pdfparser.core import BoundingBox
from pdfparser.providers.plumber import pdfplumber_extract_font_size

from .api import LayoutParserOutput, LayoutPostProc


@no_type_check
@LayoutPostProc.register
def plumber_add_font_size(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    A heuristic to determine the hierarchy of headers in a document.
    """

    pages = sorted(output.pages.unique().tolist())

    if max(pages) > len(pages):
        raise ValueError("Pages must be 0-indexed and contiguous")

    result = []
    for item in output.data.to_records(with_ids=True):
        if item["klass"] not in ["PLAIN", "LIST"]:
            result.append(-1)
            continue

        font_size = pdfplumber_extract_font_size(
            file=output.document.fname,
            page=item["page"],
            bbox=BoundingBox(x_1=item["x_1"], x_2=item["x_2"], y_1=item["y_1"], y_2=item["y_2"]),
        )
        result.append(font_size.average)

    return output.with_column("font_size", result)
