# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import re
from copy import deepcopy
from dataclasses import dataclass, field
from typing import List, Tuple

from .api import TextChunker, TextChunkerSpec


@dataclass(frozen=True)
class LongChainSpec(TextChunkerSpec):
    """
    The text chunker spec class.
    """

    split_length: int = 500  # The maximum token length of a chunk
    split_overlap: int = 100  # The overlapping token length of the sliding window
    add_page_number: bool = field(default=True)  # Add page number for the chunk


class LongChain(TextChunker, spec_class=LongChainSpec):
    """
    Text chunker written by Long Chen.
    This chunker uses the NLTK sentence tokenizer to split text into chunks while respecting sentence boundaries.
    """

    def __init__(self, spec: LongChainSpec):
        super().__init__(spec)
        import nltk

        self.nltk_data = nltk.load("nltk:tokenizers/punkt_tab/english.pickle")

    def chunk(self, text: str) -> List[str]:
        """
        Chunks text while respecting sentence boundaries.
        Args:
            text: text to chunk.
        Returns:
            Split text chunks.
        """

        # split text passage into list of sentences, ensuring that chunks respect sentence boundaries.
        sentences = self.split_sentences(text)

        word_count_slice = 0
        cur_page = 1
        list_splits = []
        current_slice: List[str] = []
        pages_list = []

        # iterate through text sentences and form chunks. Current chunk is tracked through current_slice.
        for sen in sentences:
            word_count_sen = len(sen.split())

            # once a chunk has reached its desired size, create overlap for the next chunk and handle page numbering.
            if word_count_slice + word_count_sen > self.spec.split_length:
                # save the current chunk.
                if current_slice:
                    list_splits.append(current_slice)
                    pages_list.append(cur_page)

                # create overlap as required, for use in the start of the next chunk. Set curent_slice to the overlap
                # if overlap is used, clear current_slice if no overlap is used.
                if self.spec.split_overlap:
                    processed_sents, current_slice, word_count_slice = get_overlap_from_slice(
                        current_slice, self.spec.split_overlap, self.spec.split_length
                    )
                else:
                    processed_sents = current_slice
                    current_slice = []
                    word_count_slice = 0

                # deal with page numbering.
                if self.spec.add_page_number:
                    num_page_breaks = count_processed_page_breaks(
                        sentences=processed_sents,
                        overlapping_sents=current_slice,
                        current_sent=sen,
                        split_overlap=self.spec.split_overlap,
                    )
                    cur_page += num_page_breaks

            # add to the current chunk and increment word count.
            current_slice.append(sen)
            word_count_slice += word_count_sen

        if current_slice:
            list_splits.append(current_slice)
            pages_list.append(cur_page)

        text_splits: List[str] = []
        for sl in list_splits:
            txt = "".join(sl)
            if len(txt) > 0:
                text_splits.append(txt)

        return text_splits

    def split_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences using the NLTK sentence tokenizer. Sentences are defined by the presence of
        stop characters, such ), }, ], ., * etc. Ensures that chunks respect sentence boundaries.
        """

        period_context_fmt = r"""
                %(SentEndChars)s             # a potential sentence ending
                \s*                          # match potential whitespace (is originally in lookahead assertion)
                (?=(?P<after_tok>
                    %(NonWord)s              # either other punctuation
                    |
                    (?P<next_tok>\S+)        # or some other token - original version: \s+(?P<next_tok>\S+)
                ))"""
        re_period_context = re.compile(
            period_context_fmt
            % {
                "NonWord": self.nltk_data._lang_vars._re_non_word_chars,
                "SentEndChars": self.nltk_data._lang_vars._re_sent_end_chars + r"[\)\]}]*",
            },
            re.UNICODE | re.VERBOSE,
        )
        self.nltk_data._lang_vars._re_period_context = re_period_context

        return self.nltk_data.tokenize(text)


def get_overlap_from_slice(
    current_slice: List[str], split_overlap: int, split_length: int
) -> Tuple[List[str], list, int]:
    """
    Forms the overlaps from a slice of text. Iterates through the slice of text in reverse and adds sentences
    to the overlap as long as the overlap has a word count < the split overlap and a sentence length < the
    split length.
    """

    overlap = []
    word_count_overlap = 0
    current_slice_copy = deepcopy(current_slice)
    for idx, s in reversed(list(enumerate(current_slice))[1:]):
        if word_count_overlap >= split_overlap or (sen_len := len(s.split())) >= split_length:
            break

        overlap.append(s)
        word_count_overlap += sen_len
        current_slice_copy.pop(idx)
    processed_sents = current_slice_copy  # current chunk minus overlap.
    next_slice = list(reversed(overlap))  # overlap for the next slice.
    word_count_slice = word_count_overlap

    return processed_sents, next_slice, word_count_slice


def count_processed_page_breaks(
    sentences: List[str], overlapping_sents: List[str], current_sent, split_overlap: int
) -> int:
    """
    Count the total number of page breaks in input sentences, overlapping sentences and the current sentence.
    Used to assign page numbers to chunks.
    """

    num_page_breaks = sum(sent.count("\f") for sent in sentences)
    if sentences and sentences[0].startswith("\f"):
        num_page_breaks -= 1

    if split_overlap and overlapping_sents:
        if overlapping_sents[0].startswith("\f"):
            num_page_breaks += 1
    else:
        if current_sent.startswith("\f"):
            num_page_breaks += 1

    return num_page_breaks
