# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import base64
import dataclasses as dc
from typing import Dict, List

import cv2
import requests
from numpy.typing import NDArray

from pdfparser.specs import Spec, specify


@dc.dataclass(frozen=True)
class OpenaiProviderSpec(Spec):
    """
    Spec for verbaliser that does nothing and returns an empty string.
    """

    api_key: str
    """
    The API key to use.
    """

    endpoint: str
    """
    The endpoint to use.
    For example, "{url}/openai/deployments/{model}/chat/completions?api-version={api_version}"
    """

    max_tokens: int = 100
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a table assistant."
    """
    The system prompt to use for the API.
    """


@specify(OpenaiProviderSpec)
class OpenaiProvider:
    def __call__(self, messages: List[Dict[str, str | Dict]], /) -> str:
        """
        Call the OpenAI API with the given messages and return the response.

        TODO:
            Automatically infer types of content based on the messages.

            Or, alternatively, group into VLM / LLM.

        Parameters:
            messages: The messages to send to the API.

        Returns:
            The response from the API.
        """

        headers = {"Content-Type": "application/json", "api-key": self.spec.api_key}

        for msg in messages:
            if not isinstance(msg, dict):
                raise TypeError("Message must be a dictionary.")

            if "type" not in msg:
                raise ValueError("Message must have a 'type' field.")

        data = {
            "messages": [
                {"role": "system", "content": self.spec.system_prompt},
                {"role": "user", "content": messages},
            ],
            "max_tokens": self.spec.max_tokens,
        }

        resp = requests.post(self.spec.endpoint, headers=headers, json=data)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]


@dc.dataclass(frozen=True)
class OpenaiVLMSpec(Spec):
    api_key: str
    endpoint: str
    max_tokens: int = 100
    system_prompt: str = "You are a table recognizer."


@specify(OpenaiVLMSpec)
class OpenaiVLM:
    def __call__(self, text: str, img: NDArray) -> str:
        succ, png = cv2.imencode(".png", img)

        assert succ, "Failed to encode image."
        b64_img = base64.b64encode(png).decode("utf-8")

        img_encode_text = f"data:image/jpeg;base64,{b64_img}"
        messages = [
            {"type": "text", "text": text},
            {"type": "image_url", "image_url": {"url": img_encode_text}},
        ]
        return self.provider(messages)

    @property
    def provider(self):
        return OpenaiProvider(
            OpenaiProviderSpec(
                api_key=self.spec.api_key,
                endpoint=self.spec.endpoint,
                max_tokens=self.spec.max_tokens,
                system_prompt=self.spec.system_prompt,
            )
        )
