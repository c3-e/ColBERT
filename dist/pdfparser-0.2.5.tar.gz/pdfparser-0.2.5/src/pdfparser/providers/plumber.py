# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING, Callable, NamedTuple, TypeVar

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from pdfplumber.page import Page
    from pdfplumber.pdf import PDF

    from pdfparser import BoundingBox

T = TypeVar("T")


@lru_cache(4)
def pdfplumber_file(file: str) -> PDF:
    import pdfplumber

    return pdfplumber.open(file)


@lru_cache(4096)
def pdfplumber_page(file: str, page: int):
    pdf = pdfplumber_file(file)
    return pdf.pages[page]


def pdfplumber_read_pdf(file: str, page: int, callback: Callable[[Page], T], bbox: BoundingBox | None = None) -> T:
    pass

    if not callable(callback):
        raise ValueError("callback must be a callable function")

    pdf_page = pdfplumber_page(file, page)

    if bbox is not None:
        pdf_page = pdf_page.crop(tuple(bbox), relative=False, strict=True)

    return callback(pdf_page)


class FontSize(NamedTuple):
    minimum: float
    maximum: float
    average: float

    quantile_1: float
    quantile_3: float


def pdfplumber_extract_font_size(file: str, page: int, bbox: BoundingBox | None = None):
    chars = pdfplumber_read_pdf(file, page, callback=lambda page: page.chars, bbox=bbox)

    if len(chars) == 0:
        raise ValueError("No characters found.")

    chars_df = pd.DataFrame.from_records(chars)

    # On the same page, but +1 because page numbers are 1-indexed
    chars_df = chars_df[chars_df["page_number"] == page + 1]

    # Get only the items within the bounding box.
    if bbox is not None:
        filt_exp = (
            (chars_df["x0"] >= bbox.x_1)
            & (chars_df["x1"] <= bbox.x_2)
            & (chars_df["top"] >= bbox.y_1)
            & (chars_df["bottom"] <= bbox.y_2)
        )
        chars_df = chars_df[filt_exp]

    size = np.array(chars_df["size"])

    return FontSize(
        minimum=size.min(),
        maximum=size.max(),
        average=size.mean(),
        quantile_1=np.quantile(size, 0.25),
        quantile_3=np.quantile(size, 0.75),
    )
