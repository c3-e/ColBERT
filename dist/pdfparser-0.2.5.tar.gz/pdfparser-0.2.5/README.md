<center>
<img src="assets/pdf.png" alt="" class="center" width="25%"></img>
<br>
<h1> C3 AI PDF parsing library </h1>
</center>

### Original Authors

C3 AI Data Science

### What is in this library?

This library contains the next generation C3 AI pdf parsing implementation that features text, table, and image parsing to perform tasks over all 3 modalities of data downstream.

This implementation is build to be somewhat modular so that each component can be upgraded over time and dynamic enough that it can scale through multi-processing and GPU-computing.

While mostly following the original's architecture, the rewrite is built with readability and modilarity in mind, such that each element can be updated individually and extensions can be added without affecting business logic.

### Setup instructions

We use `Makefile`s because it is battle-tested and reliable, as well as well understood.
Be sure that your python version is `3.9.*`!

#### Installing dependencies

Platfrom dependencies:

1. Ensure you have CUDA 12! Download [here](https://developer.nvidia.com/cuda-12-1-0-download-archive)
2. Ensure you have clang compiler installed.
3. You also need to have [PDM](https://pdm-project.org/en/latest/) installed in your environment.

Python dependencies install (on 3.9):

```bash
make install
```

You could also install directly with pip (not recommended)

```bash
pip install -e .[extras] # extras install the groups: ml (machine learning dependencies), service (web dependencies), and parsers (parsing pdf requirements).

# Other optional dependencies gropus you can install (with the syntax `pip install pdfparser[group]`): test (pytest), types (type checking), formatting (for clean looking code), demo (for jupyter notebooks / progress bars), docs (for website building).
```

This creates a new virtual environment located at the `.venv` folder in the current directory.

#### Testing

```bash
make test PYTEST_FLAGS="--cov" # Or any flags you like
```

#### Website building

```bash
make build-docs
```

#### Website building + serving

```bash
invoke build-docs
```
