# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path

import pytest
import torch

from pdfparser.document import Document


def vgt_gen_no_grid():
    from pdfparser.layout.vgt.gen import VGTGridInputGenerator

    return VGTGridInputGenerator("bert-base-uncased", False)


def vgt_gen_with_grid():
    from pdfparser.layout.vgt.gen import VGTGridInputGenerator

    return VGTGridInputGenerator("bert-base-uncased", True)


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


@pytest.mark.parametrize("vgt_gen", [vgt_gen_no_grid(), vgt_gen_with_grid()])
@torch.no_grad()
def test_vgt_gen(vgt_gen, document):
    from pdfparser.document import CropWithBbox

    assert vgt_gen.tokenizer is not None

    pages = vgt_gen.return_subword_grid_per_page(document)
    assert len(pages) > 0
    assert len(pages[0]) > 0
    assert isinstance(pages[0][0], CropWithBbox)


@pytest.fixture
def original_xywh():
    return (0, 0, 100, 100), (100, 100, 200, 100)


def test_readjust_bbox_coords_null(original_xywh):
    from pdfparser.layout.vgt.gen import readjust_bbox_coords

    # Does nothing because every token is of the same length.
    tokens = ["1", "2"]

    result = readjust_bbox_coords(original_xywh, tokens)

    assert result == list(original_xywh)


def test_readjust_bbox_coords(original_xywh):
    from pdfparser.layout.vgt.gen import readjust_bbox_coords

    tokens = ["1", ["2", "3"]]

    result = readjust_bbox_coords(original_xywh, tokens)

    assert result == [(0, 0, 100, 100), (100, 100, 100, 100), (200, 100, 100, 100)]


def test_readjust_bbox_coords_fail(original_xywh):
    from pdfparser.layout.vgt.gen import readjust_bbox_coords

    tokens = ["1", "2", "3"]

    with pytest.raises(AssertionError):
        readjust_bbox_coords(original_xywh, tokens)


@pytest.mark.parametrize("vgt_gen", [vgt_gen_no_grid(), vgt_gen_with_grid()])
def test_vgt_grid_dict(vgt_gen, original_xywh):
    from pdfparser.core import BoundingBox
    from pdfparser.document import CropWithBbox
    from pdfparser.layout.vgt.gen import create_grid_dict_per_page

    page_data = [
        CropWithBbox(data="1", bbox=BoundingBox(0, 0, 100, 110)),
        CropWithBbox(data="23", bbox=BoundingBox(100, 100, 200, 120)),
    ]

    result = create_grid_dict_per_page(vgt_gen.tokenizer, page_data)

    assert "input_ids" in result
    assert "bbox_subword_list" in result
    assert "texts" in result
    assert "bbox_texts_list" in result

    assert len(result["input_ids"]) == 2
    assert len(result["bbox_subword_list"]) == 2
    assert len(result["texts"]) == 2
    assert len(result["bbox_texts_list"]) == 2
