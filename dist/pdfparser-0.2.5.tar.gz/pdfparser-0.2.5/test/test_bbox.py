# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


from pathlib import Path

import pytest

from pdfparser import BoundingBox, DocBboxes, Document, ParsedMetadata


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


# Test BoundingBox area methods
def test_boundingbox_area():
    box1 = BoundingBox(1.0, 1.0, 2.0, 2.0)
    box2 = BoundingBox(1.5, 1.5, 2.0, 2.0)
    assert box1.intersection_over(box2, strategy="union") == 0.25
    assert BoundingBox.within(box1, box2) == 0
    assert box2.intersection_over(box1, strategy="left") == 1

    assert BoundingBox.contains_point(box1, (1.5, 1.5))
    assert not BoundingBox.contains_point(box1, (2.5, 2.5))
    assert (2.5, 2.5) not in box1
    assert (1.5, 1.5) in box1


def test_bbox_as_grid_numpy():
    import numpy as np

    # Test case 1: Simple bounding box within the page
    bbox = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    world = BoundingBox(0, 0, 100, 100)
    expected_output = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]
    )
    output = bbox.numpy_grid(world=world, grid_step=10)
    assert np.array_equal(output, expected_output), f"Test case 1 failed: {output}"

    # Test case 2: Bounding box touching the right boundary
    bbox = BoundingBox(x_1=80, y_1=80, x_2=100, y_2=100)
    world = BoundingBox(0, 0, 100, 100)
    expected_output = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
        ]
    )
    output = bbox.numpy_grid(world=world, grid_step=10)
    assert np.array_equal(output, expected_output), f"Test case 2 failed: {output}"


def test_bbox_merge():
    # Test case 1: Union of two overlapping bounding boxes
    box1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    box2 = BoundingBox(x_1=30, y_1=30, x_2=70, y_2=70)
    expected_output = BoundingBox(x_1=10, y_1=10, x_2=70, y_2=70)
    result = box1.merge(box2, strategy="union")
    assert result == expected_output, f"Union test case 1 failed: {result}"

    # Test case 2: Intersection of two overlapping bounding boxes
    expected_output = BoundingBox(x_1=30, y_1=30, x_2=50, y_2=50)
    result = box1.merge(box2, strategy="intersection")
    assert result == expected_output, f"Intersection test case 2 failed: {result}"

    # Test case 3: Union of two non-overlapping bounding boxes
    box3 = BoundingBox(x_1=60, y_1=60, x_2=80, y_2=80)
    expected_output = BoundingBox(x_1=10, y_1=10, x_2=80, y_2=80)
    result = box1.merge(box3, strategy="union")
    assert result == expected_output, f"Union test case 3 failed: {result}"

    # Test case 4: Intersection of two non-overlapping bounding boxes
    with pytest.raises(ValueError):
        result = box1.merge(box3, strategy="intersection")

    # Test case 5: Union of a bounding box with itself
    expected_output = box1
    result = box1.merge(box1, strategy="union")
    assert result == expected_output, f"Union test case 5 failed: {result}"

    # Test case 6: Intersection of a bounding box with itself
    expected_output = box1
    result = box1.merge(box1, strategy="intersection")
    assert result == expected_output, f"Intersection test case 6 failed: {result}"


@pytest.fixture(scope="function")
def doc_bboxes(document):
    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Figure", 0.9),
                ParsedMetadata.flat_init(0, 0, 100, 101),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Caption", 0.9),
            ],
        ],
        document=document,
    )
    return p


def test_doc_bboxes_init(doc_bboxes):
    assert doc_bboxes.num_bboxes == 4
