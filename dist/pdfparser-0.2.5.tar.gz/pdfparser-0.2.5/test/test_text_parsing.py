# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path

import pytest

from pdfparser import (
    BoundingBox,
    DocBboxes,
    Document,
    LayoutParserOutput,
    ParsedMetadata,
    TextExtractor,
    TextParser,
    TextParserSpec,
)


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


def collect(doc_bbox: DocBboxes):
    return LayoutParserOutput.init_with_mapping(
        doc_bbox,
        {"table": "TABLE", "Figure": "FIGURE", "Caption": "PLAIN", "": "IDK", "Text": "PLAIN"},
    )


def test_pdf_plumber_ext(document):
    parsed = DocBboxes.init(
        [
            [
                ParsedMetadata.canon_init(BoundingBox(0, 0, 100, 100), klass="Text"),
            ],
        ],
        document=document,
    )

    pdfplumber_ext = TextExtractor.factory("DEFAULT")
    collected = collect(parsed)
    result = pdfplumber_ext.run(collected, collected)
    assert len(result)


def test_pdf_plumber_merge_ext(document):
    parsed = DocBboxes.init(
        [
            [
                ParsedMetadata.canon_init(BoundingBox(0, 0, 100, 100), klass="Text"),
            ],
        ],
        document=document,
    )

    pdfplumber_ext = TextExtractor.factory("MERGE")
    collected = collect(parsed)
    result = pdfplumber_ext.run(collected, collected)
    assert len(result) == 1


def test_parse(document):
    parsed = DocBboxes.init(
        [
            [
                ParsedMetadata.canon_init(BoundingBox(0, 0, 100, 100), klass="Text"),
            ],
        ],
        document=document,
    )

    parser = TextParser(TextParserSpec("DEFAULT", "LONG_CHAIN"))
    result = parser(collect(parsed))
    assert len(result)
