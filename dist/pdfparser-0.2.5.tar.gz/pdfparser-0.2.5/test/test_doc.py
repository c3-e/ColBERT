# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path

import numpy as np
import pytest

from pdfparser import BoundingBox, Content, CroppingStrategy, Document


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


def test_document_init(fname):
    doc = Document(fname)

    assert doc.fname == str(fname)


def test_document_load_array(fname):
    doc = Document(fname)

    arrays = np.array(doc)
    assert all(isinstance(arr, np.ndarray) for arr in arrays)


def test_document_load_image_list(fname):
    doc = Document(fname)

    arrays = doc.page_contents
    assert all(isinstance(arr, Content) for arr in arrays)
    assert all(isinstance(np.array(arr), np.ndarray) for arr in arrays)

    assert np.array(arrays).ndim == 4


def test_doc_read_text(fname):
    doc = Document(fname)
    result = doc.page_contents[0].crop_text(BoundingBox(0, 0, 200, 200))
    assert isinstance(result, str)


def test_doc_read_table(fname):
    doc = Document(fname, cropping=CroppingStrategy(table="PLUMBER_TEXT"))
    result = doc.page_contents[0].crop_table(BoundingBox(0, 0, 200, 200))
    assert isinstance(result, str)


def test_document_view(fname):
    doc = Document(fname)
    assert len(doc.view(3)) == 1
