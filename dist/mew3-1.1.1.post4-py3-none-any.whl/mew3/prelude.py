# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc

from typing_extensions import Any, Dict, List, Tuple

from mew3.decltype import Chain, DuplicateAndMerge, ExecPipe, Filter, Mark, Range, Tag


@dc.dataclass(frozen=True)
class TextParserCfg:
    contextual: Tuple[str, ...] = "HEADER", "PLAIN", "LIST"
    """
    The classes to consider (aka kept after filtering) when parsing text. Default to consider headers, plain text, and lists
    """

    parse: Tuple[str, ...] = "HEADER", "PLAIN", "LIST"
    """
    The classes to parse. Default to parse headers, plain text, and lists.
    """

    ext_typ: str = "DEFAULT"
    """
    The type of text extractor to use. Default to using the default text extractor.
    """

    chunker_typ: str = "LONG_CHAIN"
    """
    The type of text chunker to use. Default to using the long chain chunker.
    """

    ext_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the text extractor. See individual text extractor classes for details.
    """

    chunker_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the text chunker. See individual text chunker classes for details.
    """


@dc.dataclass(frozen=True)
class ImageParserCfg:
    """
    The image parser specification class.
    """

    contextual: Tuple[str, ...] = "FIGURE", "PLAIN"
    """
    The classes to consider (aka kept after filtering) when parsing images. Default to consider both figures and plain text.
    """

    parse: Tuple[str, ...] = ("FIGURE",)
    """
    The classes to parse. Default to parse only figures.
    """

    caption_finder_typ: str = "LOCALITY"
    """
    The type of caption finder to use. Default to using the locality-based caption finder,
    because layout parsers are availalbe for all documents.
    """

    caption_finder_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "search_bbox_with_offsets": [1, -1, 2, -2, 3, -3],
            "current_bbox_typ": ["FIGURE"],
            "target_bbox_type": "CAPTION",
            "bbox_types_to_search_for": ["CAPTION", "PLAIN", "HEADER"],
        }
    )
    """
    The keyword arguments for the caption finder. See individual caption finder classes for details.
    """

    verbal_typ: str = "NULL"
    """
    The type of verbalizer to use. Default to using the NULL verbalizer (no verbalization).
    """

    verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the verbalizer. See individual verbalizer classes for details.
    """


@dc.dataclass(frozen=True)
class TableParserCfg:
    contextual: Tuple[str, ...] = "TABLE", "HEADER", "PLAIN"
    """
    The classes to consider (aka kept after filtering) when parsing tables. Default to consider tables, headers, and plain text.
    """
    parse: Tuple[str, ...] = ("TABLE",)
    """
    The classes to parse. Default to parse only tables.
    """

    content_parser_typ: str = "DEFAULT"
    """
    The type of content parser to use.
    """

    content_parser_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the content parser.
    """

    title_finder_typ: str = "LOCALITY"
    """
    The type of title finder to use.
    """

    title_finder_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "current_bbox_typ": ["TABLE"],
            "search_bbox_with_offsets": [-1, 1, -2, 2, -3, 3],
            "target_bbox_type": "HEADER",
            "bbox_types_to_search_for": ["HEADER", "CAPTION", "PLAIN"],
        }
    )

    chunker_typ: str = "LONG_CHAIN"
    """
    The type of chunker to use.
    """

    chunker_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the chunker. See individual chunker classes for details.
    """


@dc.dataclass(frozen=True)
class LayoutParserCfg:
    """
    A specification for a layout parser.
    """

    layout_model_typ: str = "VGT"
    """
    The type of layout model to use. Default to vgt layout model because it has been the most mature.
    """

    layout_model_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments to pass to the layout model.
    See individual layout model for the list of supported keyword arguments.
    """

    post_process: List[str] = dc.field(
        default_factory=lambda: [
            "JUPYTER_DEBUG(title='Model Output')",
            "FILTER_DOC",
            "JUPYTER_DEBUG(title='Filtered Bounding Boxes')",
            "UNION_BOX",
            "JUPYTER_DEBUG(title='Unioned Bounding Boxes')",
            "NO_OVERLAP",
            "JUPYTER_DEBUG(title='Non-overlapping Bounding Boxes')",
            "ORDER_BY_GRID(grid_step=128)",
            "JUPYTER_DEBUG(title='Ordered Bounding Boxes')",
            "TO_MARKDOWN_CLASS",
        ]
    )
    """
    The list of post-processing steps to apply to the layout model output.
    """


def layout_parser_pipeline(spec: LayoutParserCfg):
    """
    The overall flow for parsing layout is as follows:

    1. Parse the layout of the document using the layout model.
    2. Post-process the layout using the post-processing pipeline.
    """

    from mew3.layout import LayoutModel

    return Chain(
        [
            LayoutModel.factory(spec.layout_model_typ, **spec.layout_model_kwargs),
            ExecPipe(spec.post_process),
        ],
        stage_names=["layout-parser", "post-process"],
    )


def image_parser_pipeline(cfg: ImageParserCfg, /):
    from mew3.component import CaptionFinder, ImageVerbal
    from mew3.component.image import image_extract

    return ExecPipe(
        [
            Tag(column="parser", tag="IMAGE"),
            Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
            Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
            CaptionFinder.factory(cfg.caption_finder_typ, **cfg.caption_finder_kwargs),
            image_extract,
            ImageVerbal.factory(cfg.verbal_typ, **cfg.verbal_kwargs),
            "ALIAS(source='verbalization', target='description_for_vectorstore')",
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
        ]
    )


def table_parser_pipeline(cfg: TableParserCfg, /):
    from mew3.component import CaptionFinder, TableContent, TextChunker, csv_extract, save_csv_c3

    return ExecPipe(
        [
            "TAG(column='parser', tag='TABLE')",
            Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
            CaptionFinder.factory(cfg.title_finder_typ, **cfg.title_finder_kwargs),
            'RENAME(source="caption", target="title")',
            {"kind": "FILTER", "kwargs": {"column": "markdown_class", "function": lambda key: key in cfg.parse}},
            TableContent.factory(cfg.content_parser_typ, **cfg.content_parser_kwargs),
            "ALIAS(source='text', target='description_for_vectorstore')",
            TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            csv_extract,
            save_csv_c3,
        ]
    )


def text_parser_pipeline(cfg: TextParserCfg, /):
    """
    The overall flow for parsing text components is as follows:

    1. Extract text from the document using the extractor.
    2. Chunk the extracted text using the chunker.

    The extractor and chunker are specified in the spec.
    """

    from mew3.component import TextChunker, TextExtractor

    return ExecPipe(
        execs=[
            Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
            TextExtractor.factory(cfg.ext_typ, **cfg.ext_kwargs),
            TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            Tag(column="parser", tag="TEXT"),
            "ALIAS(source='text', target='description_for_vectorstore')",
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
        ]
    )


def document_parser_pipeline(
    *,
    layout_parser_spec: LayoutParserCfg = LayoutParserCfg(),
    text_parser_spec: TextParserCfg | None = TextParserCfg(),
    table_parser_spec: TableParserCfg | None = TableParserCfg(),
    image_parser_spec: ImageParserCfg | None = ImageParserCfg(),
):
    parsers = {}

    if text_parser_spec is not None:
        parsers["text"] = text_parser_pipeline(text_parser_spec)

    if table_parser_spec is not None:
        parsers["table"] = table_parser_pipeline(table_parser_spec)

    if image_parser_spec is not None:
        parsers["image"] = image_parser_pipeline(image_parser_spec)

    return Chain(
        [
            layout_parser_pipeline(layout_parser_spec),
            Range("global_idx"),
            DuplicateAndMerge(parsers),
        ],
        stage_names=["layout", "global_index", "parsers"],
    )
