# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from enum import Enum

from .openai import OpenaiProvider


class GenaiCoreProviderModels(Enum):
    """Available GenaiCore model providers."""

    AZURE_OPENAI = "GenaiCore.Llm.AzureOpenAi.Model"
    VERTEX_AI = "GenaiCore.Llm.VertexAi.Model"
    BEDROCK = "GenaiCore.Llm.Bedrock.Model"
    MIS = "GenaiCore.Llm.Mis.Model"


@dc.dataclass(frozen=True)
class ModelMixin:
    model: str
    """
    The model to use for the API. E.g. "gpt-4o", "gemini-1.5-flash", etc.
    """

    genai_core_model: str = GenaiCoreProviderModels.AZURE_OPENAI.value
    """
    This parameter will be evaled by c3.type().
    Options:
        - GenaiCore.Llm.AzureOpenAi.Model
        - GenaiCore.Llm.VertexAi.Model
        - GenaiCore.Llm.Bedrock.Model
    """

    default_options: dict = dc.field(
        default_factory=lambda: {
            "temperature": 0,
            "max_tokens": 4096,
            "returnJson": True,
        }
    )
    """
    Default options for the model. `returnJson` should be set to True.
    """

    @property
    def genai_core_auth(self):
        return self.genai_core_model.rsplit(".", 1)[0] + ".Auth"

    genai_core_auth_name: str = "default"
    """
    The name of the authentication to use. Default to "default".
    """

    def __post_init__(self):
        valid_models = [model.value for model in GenaiCoreProviderModels]
        if self.genai_core_model not in valid_models:
            raise ValueError(
                f"Invalid genai_core_model: {self.genai_core_model}. " f"Must be one of: {', '.join(valid_models)}"
            )


@dc.dataclass(frozen=True)
class LiteLLM(OpenaiProvider, ModelMixin):
    """
    Spec for verbalizer that does nothing and returns an empty string.
    """

    def call(self, message, **options):
        # Litellm imports really slowly.
        # Don't do top levle imports
        from litellm import completion

        return completion(model=self.model, messages=message, **options, api_key=self.api_key, api_base=self.endpoint)
