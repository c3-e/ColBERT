# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc

from mew3.ctx import c3

from .litellm import ModelMixin
from .openai import OpenaiLikeLLM


@dc.dataclass(frozen=True)
class C3GenaiCoreLLM(OpenaiLikeLLM, ModelMixin):
    """
    C3's GenaiCore LLM provider. Need to create authentication before using it.
    See the example below for openai. See genaiPlatform's tutorial notebook for more LLM's.

    ```py
    openai_auth_dict = {
        "apiKey": settings.api_key, # your api key
        "azureEndpoint": settings.endpoint, # your api endpoint (e.g. the full url)
    }

    openai_auth = c3_ctx().GenaiCore.Llm.AzureOpenAi.Auth(name="default", **openai_auth_dict)
    openai_auth.setConfig()
    openai_auth.setSecret()
    ```
    """

    def call(self, messages, **options):
        CompletionClient = c3().GenaiCore.Llm.Completion.Client
        GenaiCoreModel = c3().type(self.genai_core_model)

        # NOTE: `auth` input should take arg name="default" by default. Then no need to specify!
        client = CompletionClient(
            model=GenaiCoreModel(
                model=self.model,
                auth=c3().type(self.genai_core_auth)(name=self.genai_core_auth_name),
                defaultOptions=self.default_options,
            )
        )

        openai_response = client.completion(messages=messages, options=options)
        return openai_response
