# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from . import ctx, integrations, logging, providers, settings
from .component import (
    CaptionFinder,
    GetSurroundingText,
    GetSurroundingTextSpec,
    ImageVerbal,
    TableContent,
    TextChunker,
    TextExtractor,
)
from .core import BoundingBox, DocBboxes, Graph, GraphDict, Graphrame, NotUniqueError, ParsedMetadata, UniqueIds
from .croppers import ImageCropper, TableCropper, TextCropper
from .ctx import get_cfg, get_cfg_keys, set_c3, set_cfg
from .decltype import (
    Delta,
    DeltaKind,
    LayoutExec,
    LayoutExecutor,
    LayoutMod,
    LayoutModule,
    LayoutModuleRenderer,
    LayoutProc,
    LayoutProcessor,
    LayoutProd,
    LayoutProducer,
)
from .doc_parser import DocumentParser, DocumentParserOutput
from .document import Content, Document, PageDoc
from .integrations import SourceFileParser, VLMParser
from .layout import DOCLAYNET_LABELS, DocLayNetClass, LayoutModel, LayoutModelSpec, MarkdownClass
from .reader import CropWithBbox, GridGen, PageCnt
from .specs import Spec, UnparsableError, signature_parse
from .ui_debugger import C3UiDebugger, UiDebugger
from .version import __version__


def _repr_svg_():
    from .logo import Logo

    return Logo()._repr_svg_()
