# Copyright 2009-2025 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import io
import json
import logging
import uuid
from functools import wraps
from typing import Any, Dict, List, Tuple

import numpy as np

import mew3
from mew3.ctx import c3
from mew3.decltype import Chain, ExecPipe, Filter, Mark, Range, Rename, Tag
from mew3.document import PageDoc
from mew3.layout import LayoutModel

_LOG = logging.getLogger(__name__)


def require_field(*required_keys):
    """
    Specify which columns are required in __call__().
    """

    def decorator(func):
        @wraps(func)
        def wrapper(self, **kwargs):
            for key in required_keys:
                if key not in kwargs:
                    raise ValueError(f"Missing required argument: {key}")
            return func(self, **kwargs)

        return wrapper

    return decorator


class SourceFileInputParser:
    """
    Convert input document path into mew3 Document object.
    """

    def __init__(self, document_spec: Dict[str, Any]):
        """
        Initialize the SourceFileInputParser with the given specification.

        Args:
            document_spec: The specification for the document parser.
        """
        self.document_spec = document_spec

    @require_field("document")
    def __call__(self, **kwargs):
        document = kwargs["document"]

        doc = mew3.Document(document, cropping=self.document_spec["cropping"])
        return {"document": doc}


class SourceFileLayoutParser:
    """
    A class that handles layout parsing functionality.
    """

    @dc.dataclass(frozen=True)
    class LayoutParserCfg:
        """
        A specification for a layout parser.
        """

        layout_model_typ: str = "VGT"
        """
        The type of layout model to use. Default to vgt layout model because it has been the most mature.
        """

        layout_model_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
        """
        The keyword arguments to pass to the layout model.
        See individual layout model for the list of supported keyword arguments.
        """

        post_process: List[str] = dc.field(
            default_factory=lambda: [
                "FILTER_DOC",
                "UNION_BOX",
                "NO_OVERLAP",
                "ORDER_BY_GRID(grid_step=32)",
                "TO_MARKDOWN_CLASS",
                "MERGE_LIST",
                "MERGE_MANY_THING_BY_COLUMN",
                "RESOLVE_CLASS_CONFLICT(iou_threshold=0.85)",
                "REMOVE_CONTAINED_BOXES(containment_threshold=0.9)",
                "MERGE_TEXT_UNDER_HEADER",
            ]
        )
        """
        The list of post-processing steps to apply to the layout model output.
        """

    def layout_parser_pipeline(self):
        """
        The overall flow for parsing layout is as follows:

        1. Parse the layout of the document using the layout model.
        2. Post-process the layout using the post-processing pipeline.
        """
        return Chain(
            [
                LayoutModel.factory(self.config.layout_model_typ, **self.config.layout_model_kwargs),
                ExecPipe(self.config.post_process),
                Range("global_idx"),
            ]
        )

    def __init__(self, layout_parser_spec: Dict[str, Any]):
        """
        Initialize the SourceFileLayoutParser with the given specification.

        Args:
            layout_parser_spec: The specification for the layout parser.
        """

        self.config = self.LayoutParserCfg(**layout_parser_spec)

        self.layout_parser = self.layout_parser_pipeline()

    @require_field("document")
    def __call__(self, **kwargs):
        """
        Process the document through the layout parser pipeline.

        Args:
            document: The document to parse.

        Returns:
            The layout bounding boxes extracted from the document.
        """

        document = kwargs["document"]

        layout_bboxes = self.layout_parser(document)

        return {"layout_bboxes": layout_bboxes, "document": document}


class SourceFileComponentParser:
    """
    A class that handles component parsing functionality.
    """

    @dc.dataclass(frozen=True)
    class TextParserCfg:
        contextual: Tuple[str, ...] = "HEADER", "PLAIN", "LIST", "CAPTION"
        """
        The classes to consider (aka kept after filtering) when parsing text. Default to consider headers, plain text, and lists
        """

        parse: Tuple[str, ...] = "HEADER", "PLAIN", "LIST", "CAPTION"
        """
        The classes to parse. Default to parse headers, plain text, and lists.
        """

        ext_typ: str = "DEFAULT"
        """
        The type of text extractor to use. Default to using the default text extractor.
        """

        ext_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
        """
        The keyword arguments for the text extractor. See individual text extractor classes for details.
        """

        get_parent_header_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {
                "do_hierarchy_detection": True,
                "extract_header_for_type": ["PLAIN", "LIST"],
                "header_parent_types": ["HEADER"],
                "enable_cross_page_search": True,
            }
        )
        """
        The keyword arguments for the GetParentHeader component. See GetParentHeaderSpec for details.
        """

    @dc.dataclass(frozen=True)
    class ImageParserCfg:
        """
        The image parser specification class.
        """

        contextual: Tuple[str, ...] = ("FIGURE", "TABLE", "PLAIN", "HEADER", "CAPTION", "LIST", "IDK")
        """
        The classes to consider (aka kept after filtering) when parsing images. Default to consider both figures and plain text.
        """

        parse: Tuple[str, ...] = ("FIGURE",)
        """
        The classes to parse. Default to parse only figures.
        """

        get_surrounding_text_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {
                "current_bbox_typ": "FIGURE",
                "extract_bbox_with_offsets": [-3, -2, -1, 1, 2, 3],
                "extract_bbox_with_type": ["CAPTION", "PLAIN", "HEADER", "LIST"],
                "enable_cross_page_search": False,
            }
        )
        """
        The keyword arguments for the get_surrounding_text component. See GetSurroundingTextSpec for details.
        """

        caption_finder_typ: str = "LOCALITY"
        """
        The type of caption finder to use. Default to using the locality-based caption finder,
        because layout parsers are availalbe for all documents.
        """

        caption_finder_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {
                "search_bbox_with_offsets": [1, -1, 2, -2, 3, -3],
                "current_bbox_typ": ["FIGURE"],
                "target_bbox_type": "CAPTION",
                "bbox_types_to_search_for": ["CAPTION", "PLAIN", "HEADER"],
                "enable_cross_page_search": False,
            }
        )
        """
        The keyword arguments for the caption finder. See individual caption finder classes for details.
        """

        verbal_typ: str = "OPENAI"
        """
        The type of verbalizer to use. Can also use NULL (just output empty string).
        """

        verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
        """
        The keyword arguments for the verbalizer. See individual verbalizer classes for details.
        """

    @dc.dataclass(frozen=True)
    class TableParserCfg:
        contextual: Tuple[str, ...] = ("FIGURE", "TABLE", "PLAIN", "HEADER", "CAPTION", "LIST", "IDK")
        """
        The classes to consider (aka kept after filtering) when parsing tables. Default to consider tables, headers, and plain text.
        """
        parse: Tuple[str, ...] = ("TABLE",)
        """
        The classes to parse. Default to parse only tables.
        """

        content_parser_typ: str = "DEFAULT"
        """
        The type of content parser to use. 'DEFAUT' means using cropping_strategy for documents, which can be 'PLUMBER', 'OPENAI', 'GROUNDED_LLM', etc.
        """

        content_parser_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
        """
        The keyword arguments for the content parser.
        """

        get_surrounding_text_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {
                "current_bbox_typ": "TABLE",
                "extract_bbox_with_offsets": [-3, -2, -1, 1, 2, 3],
                "extract_bbox_with_type": ["CAPTION", "PLAIN", "HEADER", "LIST"],
                "enable_cross_page_search": False,
            }
        )
        """
        The keyword arguments for the get_surrounding_text component. See GetSurroundingTextSpec for details.
        """

        title_finder_typ: str = "LOCALITY"
        """
        The type of title finder to use.
        """

        title_finder_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {
                "current_bbox_typ": ["TABLE"],
                "search_bbox_with_offsets": [-1, 1, -2, 2, -3, 3],
                "target_bbox_type": "HEADER",
                "bbox_types_to_search_for": ["HEADER", "CAPTION", "PLAIN"],
                "enable_cross_page_search": False,
            }
        )

        verbal_typ: str = "OPENAI"
        """
        The type of verbalizer to use. Can also use NULL (just output empty string).
        """

        verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
        """
        The keyword arguments for the verbalizer. See individual verbalizer classes for details.
        """

    def text_parser_pipeline(self, cfg):
        """
        Create a text parser pipeline with the given configuration.

        Args:
            cfg: The configuration for the text parser.

        Returns:
            A pipeline for parsing text components.
        """
        from mew3.component import GetParentHeader, TextExtractor

        return ExecPipe(
            execs=[
                Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
                TextExtractor.factory(cfg.ext_typ, **cfg.ext_kwargs),
                GetParentHeader(**cfg.get_parent_header_kwargs),
                Filter(column="markdown_class", function=lambda key: key in cfg.parse),
                Tag(column="parser", tag="TEXT"),
            ]
        )

    def image_parser_pipeline(self, cfg):
        """
        Create an image parser pipeline with the given configuration.

        Args:
            cfg: The configuration for the image parser.

        Returns:
            A pipeline for parsing image components.
        """
        from mew3.component import CaptionFinder, GetSurroundingText, ImageVerbal
        from mew3.component.image import image_extract, save_image_c3

        return ExecPipe(
            [
                Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
                GetSurroundingText(**cfg.get_surrounding_text_kwargs),
                CaptionFinder.factory(cfg.caption_finder_typ, **cfg.caption_finder_kwargs),
                Filter(column="markdown_class", function=lambda key: key in cfg.parse),
                image_extract,
                ImageVerbal.factory(cfg.verbal_typ, **cfg.verbal_kwargs),
                save_image_c3,
                Tag(column="parser", tag="IMAGE"),
            ]
        )

    def table_parser_pipeline(self, cfg):
        """
        Create a table parser pipeline with the given configuration.

        Args:
            cfg: The configuration for the table parser.

        Returns:
            A pipeline for parsing table components.
        """
        from mew3.component import (
            CaptionFinder,
            GetSurroundingText,
            TableContent,
            TableVerbal,
            csv_extract,
            save_csv_c3,
            save_table_image_c3,
            table_image_extract,
        )

        return ExecPipe(
            [
                Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
                GetSurroundingText(**cfg.get_surrounding_text_kwargs),
                CaptionFinder.factory(cfg.title_finder_typ, **cfg.title_finder_kwargs),
                Rename(source="caption", target="title"),
                Filter(column="markdown_class", function=lambda key: key in cfg.parse),
                TableContent.factory(cfg.content_parser_typ, **cfg.content_parser_kwargs),
                table_image_extract,
                csv_extract,
                TableVerbal.factory(cfg.verbal_typ, **cfg.verbal_kwargs),
                save_table_image_c3,
                save_csv_c3,
                Tag(column="parser", tag="TABLE"),
            ]
        )

    def __init__(self, component_parser_spec: Dict[str, Any] = None):
        """
        Initialize the SourceFileComponentParser with the given specifications.
        spec is {} -> use default configs.
        spec is None -> do not parse this component.

        Args:
            text_parser_spec: The specification for the text parser.
            image_parser_spec: The specification for the image parser.
            table_parser_spec: The specification for the table parser.
        """

        self.text_parser_spec = component_parser_spec["text_parser_spec"]
        self.image_parser_spec = component_parser_spec["image_parser_spec"]
        self.table_parser_spec = component_parser_spec["table_parser_spec"]

        self.text_parser = None
        self.image_parser = None
        self.table_parser = None

        if self.text_parser_spec is not None:
            self.text_parser = self.text_parser_pipeline(self.TextParserCfg(**self.text_parser_spec))

        if self.image_parser_spec is not None:
            self.image_parser = self.image_parser_pipeline(self.ImageParserCfg(**self.image_parser_spec))

        if self.table_parser_spec is not None:
            self.table_parser = self.table_parser_pipeline(self.TableParserCfg(**self.table_parser_spec))

    @require_field("layout_bboxes", "document")
    def __call__(self, **kwargs):
        """
        Process the layout bounding boxes through the component parsers.

        Args:
            layout_bboxes: The layout bounding boxes to parse.

        Returns:
            A list of components extracted from the layout bounding boxes.
        """

        layout_bboxes = kwargs["layout_bboxes"]
        document = kwargs["document"]

        text_bboxes = None
        image_bboxes = None
        table_bboxes = None

        if self.text_parser is not None:
            text_bboxes = self.text_parser(layout_bboxes)

        if self.image_parser is not None:
            image_bboxes = self.image_parser(layout_bboxes)

        if self.table_parser is not None:
            table_bboxes = self.table_parser(layout_bboxes)

        return {
            "text_bboxes": text_bboxes,
            "image_bboxes": image_bboxes,
            "table_bboxes": table_bboxes,
            "document": document,
        }


class SourceFileComponentChunker:
    """
    A class that handles component chunking functionality.
    """

    @dc.dataclass(frozen=True)
    class TextChunkerCfg:
        chunker_typ: str = "LONG_CHAIN"
        """
        The type of text chunker to use. Default to using the long chain chunker.
        """

        chunker_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {"column_to_chunk": "text", "split_overlap": 100, "split_length": 500}
        )
        """
        The keyword arguments for the text chunker. See individual text chunker classes for details.
        """

    @dc.dataclass(frozen=True)
    class ImageChunkerCfg:
        pass

    @dc.dataclass(frozen=True)
    class TableChunkerCfg:
        chunker_typ: str = "LONG_CHAIN"
        """
        The type of chunker to use.
        """

        chunker_kwargs: Dict[str, Any] = dc.field(
            default_factory=lambda: {"column_to_chunk": "verbalization", "split_overlap": 100, "split_length": 500}
        )
        """
        The keyword arguments for the chunker. See individual chunker classes for details.
        """

    def text_chunker_pipeline(self, cfg):
        from mew3.component import TextChunker

        return ExecPipe(
            execs=[
                TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            ]
        )

    def image_chunker_pipeline(self, cfg):
        return lambda x: x

    def table_chunker_pipeline(self, cfg):
        from mew3.component import TextChunker

        return ExecPipe(
            [
                TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            ]
        )

    def __init__(self, component_chunker_spec: Dict[str, Any] = None):
        """
        Initialize the SourceFileComponentParser with the given specifications.
        spec is {} -> use default configs.
        spec is None -> do not parse this component.

        Args:
            text_chunker_spec: The specification for the text chunker.
            image_chunker_spec: The specification for the image chunker.
            table_chunker_spec: The specification for the table chunker.
        """
        self.text_chunker_spec = component_chunker_spec["text_chunker_spec"]
        self.image_chunker_spec = component_chunker_spec["image_chunker_spec"]
        self.table_chunker_spec = component_chunker_spec["table_chunker_spec"]

        self.text_chunker = None
        self.image_chunker = None
        self.table_chunker = None

        if self.text_chunker_spec is not None:
            self.text_chunker = self.text_chunker_pipeline(self.TextChunkerCfg(**self.text_chunker_spec))

        if self.image_chunker_spec is not None:
            self.image_chunker = self.image_chunker_pipeline(self.ImageChunkerCfg(**self.image_chunker_spec))

        if self.table_chunker_spec is not None:
            self.table_chunker = self.table_chunker_pipeline(self.TableChunkerCfg(**self.table_chunker_spec))

    @require_field("text_bboxes", "image_bboxes", "table_bboxes", "document")
    def __call__(self, **kwargs):
        """
        Process the layout bounding boxes through the component parsers.

        Args:
            *_bboxes: The corresponding bounding boxes to parse.

        Returns:
            A list of components extracted from the layout bounding boxes.
        """

        text_bboxes = kwargs["text_bboxes"]
        image_bboxes = kwargs["image_bboxes"]
        table_bboxes = kwargs["table_bboxes"]
        document = kwargs["document"]

        list_components = []

        if self.text_chunker is not None:
            text_bboxes = self.text_chunker(text_bboxes)
            list_components.extend(text_bboxes.to_records(with_ids=True))

        if self.image_chunker is not None:
            image_bboxes = self.image_chunker(image_bboxes)
            list_components.extend(image_bboxes.to_records(with_ids=True))

        if self.table_chunker is not None:
            table_bboxes = self.table_chunker(table_bboxes)
            list_components.extend(table_bboxes.to_records(with_ids=True))

        return {"list_components": list_components, "document": document}


class SourceFileOutputParser:
    """
    A class that handles output parsing functionality.
    """

    def get_document_info_from_doc(self, document: PageDoc, pipeline_spec: dict = {}):
        """
        For full_specs to be populated, the component parsers should be called.
        """

        info = {
            "file_info": {
                "filename": document.fname,
                "fname": document.name,
                "filetype": document.type,
                "rel_scale": document.rel_scale,
                "dpi": document.dpi,
            },
            "full_specs": pipeline_spec,
            "cropping_strategy": {
                "text_crop": {"class": str(document.text_cropper.__class__), "spec": str(document.text_cropper.spec)},
                "image_crop": {
                    "class": str(document.image_cropper.__class__),
                    "spec": str(document.image_cropper.spec),
                },
                "table_crop": {
                    "class": str(document.table_cropper.__class__),
                    "spec": str(document.table_cropper.spec),
                },
                "page_cnt": str(document.page_cnt),
                "grid_gen": str(document.grid_gen),
            },
        }

        return info

    def __init__(self):
        pass

    @require_field("list_components", "document", "pipeline_spec")
    def __call__(self, **kwargs):
        """
        Process the components into output chunks.

        Args:
            document: The document being processed.
            layout_bboxes: The layout bounding boxes.
            list_components: The list of components to process.
            pipeline_spec: The pipeline specification.

        Returns:
            A list of output chunks.
        """

        list_components = kwargs["list_components"]
        document = kwargs["document"]
        pipeline_spec = kwargs["pipeline_spec"]

        document_info = self.get_document_info_from_doc(document, pipeline_spec)

        buffer = io.StringIO()
        json.dump(document_info, buffer, indent=4)
        buffer.seek(0)

        unique_id = str(uuid.uuid4())
        remote_json_path = (
            f"mew3_parsed/document_info/"
            f"{document_info['file_info']['fname'].split('.')[0]}"
            f"_info__uniqueid_{unique_id}.json"
        )
        c3().FileSystem.uploadFile(srcFile=buffer, dstPath=remote_json_path)

        for item in list_components:
            item["text"] = item.get("text", "")
            item["chunked"] = item.get("chunked", [])

            if item["parser"] == "TEXT":
                item["description_for_vectorstore"] = [
                    (
                        f"Parent Header Text: {item['parent_text']}; Text: {piece}"
                        if item.get("parent_text", "") != ""
                        else f"Text: {piece}"
                    )
                    for piece in item["chunked"]
                ]

            elif item["parser"] == "TABLE":
                item["surrounding_text"] = item.get("surrounding_text", "")
                item["title"] = item.get("title", "")
                item["verbalization"] = item.get("verbalization", "")
                item["csv"] = item.get("csv", "")
                item["csv_url_c3"] = item.get("csv_url_c3", "")
                item["table_image_url_c3"] = item.get("table_image_url_c3", "")
                item["description_for_vectorstore"] = [
                    f"Title: {item['title']}; Text: {piece}" for piece in item["chunked"]
                ]

            elif item["parser"] == "IMAGE":
                item["surrounding_text"] = item.get("surrounding_text", "")
                item["caption"] = item.get("caption", "")
                item["verbalization"] = item.get("verbalization", "")
                item["image_url_c3"] = item.get("image_url_c3", "")
                item[
                    "description_for_vectorstore"
                ] = f"Caption: {item['caption']}; Verbalization: {item['verbalization']}"

            rel_scale = document.rel_scale
            doc_shape = np.shape(document.page_contents[item["page"]])

            item["scaled_x_1"] = item["x_1"] * rel_scale
            item["scaled_y_1"] = item["y_1"] * rel_scale
            item["scaled_x_2"] = item["x_2"] * rel_scale
            item["scaled_y_2"] = item["y_2"] * rel_scale
            item["doc_height_px"] = doc_shape[0]
            item["doc_width_px"] = doc_shape[1]
            item["document_info_url_c3"] = remote_json_path

            # NOTE: avoid trouble when converting to OutputChunk
            if "image" in item:
                del item["image"]
            if "table_image" in item:
                del item["table_image"]

        # sort by page, then by y_1, then by x_1
        list_components = sorted(list_components, key=lambda x: (x["page"], x["scaled_y_1"], x["scaled_x_1"]))

        return {"list_components": list_components, "document": document}
