# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from typing import Literal

from . import settings


def running_in() -> Literal["jupyter", "ipython", "terminal"]:
    """
    Code adapted from [here](https://stackoverflow.com/questions/47211324/check-if-module-is-running-in-jupyter-or-not)
    """

    try:
        ipy_str = str(type(get_ipython()))  # type: ignore
        if "zmqshell" in ipy_str:
            return "jupyter"
        if "terminal" in ipy_str:
            return "ipython"
    except NameError:
        pass

    return "terminal"


def c3():
    """
    Getter for the c3 global object.
    """
    if c3_not_set():
        raise RuntimeError("c3 is not available, maybe setting it with `mew3.set_c3(c3)`?")
    return settings.c3


def c3_not_set():
    return settings.c3 is None


def c3_is_set():
    return not c3_not_set()


def set_c3(c3):
    settings.c3 = c3


def set_cfg(key, val):
    setattr(settings, key, val)


def get_cfg(key):
    return getattr(settings, key)


def get_cfg_keys():
    return settings.KEYS
