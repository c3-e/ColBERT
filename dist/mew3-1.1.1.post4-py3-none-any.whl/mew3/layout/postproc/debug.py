# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import collections
import dataclasses as dc
import itertools
from typing import List, no_type_check

from mew3.core import DocBboxes
from mew3.ctx import running_in
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.document import Content, PageDoc

from ..api import LayoutParserOutput


@LayoutExec.register()
def print(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    Print the output of the layout parser.
    """
    from rich import print

    print(output)
    return output


@dc.dataclass(frozen=True)
class EchoSpec(LayoutExecSpec):
    """
    A specification for an echo post-processor.
    """

    message: str
    """
    The message to echo.
    """


class Echo(LayoutExec, spec_class=EchoSpec):
    """
    An echo post-processor. Prints the message to the console.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        print(self.spec.message)
        return output


@dc.dataclass(frozen=True)
class ScaleBboxSpec(LayoutExecSpec):
    """
    A specification for a rescale post-processor.
    """

    scale: float
    """
    The scale factor to apply to the bounding boxes.
    """


class ScaleBbox(LayoutExec, spec_class=ScaleBboxSpec):
    """
    Scale the bounding boxes by a factor.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        output["x_1"] *= self.spec.scale
        output["x_2"] *= self.spec.scale
        output["y_1"] *= self.spec.scale
        output["y_2"] *= self.spec.scale

        return output


@dc.dataclass(frozen=True)
class JupyterDebugSpec(LayoutExecSpec):
    """
    A specification for a debug post-processor.
    """

    title: str
    """
    The title of the debug plot.
    """

    color_key: str = "klass"
    """
    The key to use for the bounding box class.
    """


class JupyterDebug(LayoutExec, spec_class=JupyterDebugSpec):
    """
    A debug post-processor that plots the bounding boxes on the page.

    Note:
        Only works in Jupyter notebooks, and does nothing if not in a Jupyter notebook.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        _debug_layout_impl(
            document=output.document, bounding_boxes=output, title=self.spec.title, key=self.spec.color_key
        )
        return output


def _debug_layout_impl(document: PageDoc, bounding_boxes: LayoutParserOutput, title: str, key: str) -> None:
    if running_in() != "jupyter":
        return

    import matplotlib.pyplot as plt
    import numpy as np
    import seaborn as sns
    from matplotlib.patches import Patch

    sns.set_theme()

    palette = sns.color_palette("Paired", 8)

    counter = itertools.count()
    color_map = collections.defaultdict(lambda: palette[next(counter) % len(palette)])

    # Plot the bounding boxes on the page, overlayed on the image, with the label, subtle.
    def plot_page(bboxes, img: Content):
        _, ax = plt.subplots()
        ax.imshow(img)

        for bbox in bboxes:
            # Detectron's output is normalized, but we need to scale it back to the original image size.
            x0, y0, x1, y1 = bbox.bbox * document.rel_scale
            color = color_map[bbox[key]]
            rect = plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color)
            ax.add_patch(rect)
            ax.text(
                x0, y0, str(np.round(float(bbox.score), 3)), color=color, fontsize=12
            )  # Set fontsize to 8 for smaller labels

        plt.axis("off")  # Optional: Turn off axis
        plt.title(title)
        plt.legend(
            handles=[Patch(facecolor=color_map[klass], label=klass) for klass in color_map.keys()], prop={"size": 12}
        )
        plt.show()

    def plot_multi_page(bboxes_list: DocBboxes, imgs: List[Content]):
        for idx, page_bboxes in enumerate(bboxes_list.to_list_of_list(filter_empty=False)):
            img = imgs[idx]
            plot_page(page_bboxes, img)

    plot_multi_page(bounding_boxes, document.page_contents)


@dc.dataclass(frozen=True)
class VerifyClassSpec(LayoutExecSpec):
    """
    Verify that the class of each bbox is in the list of valid classes.
    """

    valid_classes: list[str]


class VerifyClass(LayoutExec, spec_class=VerifyClassSpec):
    """
    TODO:
        Add tests for this post-processor.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        output.validate_classes(self.spec.valid_classes)
        return output
