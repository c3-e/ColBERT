# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import logging
from itertools import groupby

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.specs import factorize

_LOG = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class ResolveClassConflictSpec(LayoutExecSpec):
    iou_threshold: float = 0.9
    """
    IoU threashold to resolve bbox klass conflict
    """

    def delta_columns(self):
        return ".x_1", ".x_2", ".y_1", ".y_2", ".score", ".klass", ".markdown_class"


@factorize(ResolveClassConflictSpec)
class ResolveClassConflict(LayoutExec, spec_class=ResolveClassConflictSpec):
    """
    Sometimes an element has two almost identical bounding boxes.
    This function removes the duplicates.
    The box with the highest VGT score is kept.
    The bbox is augmented to be the union of the two bboxes.
    NOTE: Only use for markdown_class!
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        curr_document = output.document

        flat = output.to_records(with_ids=True)

        # ALERT: work around. directly for loop has bug. Group records by page
        boxes_by_page = [
            [box for box in group if box["markdown_class"] != "IDK"]
            for _, group in groupby(flat, key=lambda x: x["page"])
        ]

        result = []
        for page_idx, boxes_on_page in enumerate(boxes_by_page):
            processed_page = self._merge_page_boxes(boxes_on_page)
            result.extend(processed_page)

        cleaned_records = LayoutParserOutput.from_records(result, curr_document)
        return cleaned_records

    def _merge_page_boxes(self, boxes_on_page):
        """
        Merge overlapping boxes within a single page.
        """
        if not boxes_on_page:
            return []

        boxes = boxes_on_page.copy()
        i = 0
        while i < len(boxes):
            merged = False
            j = i + 1
            while j < len(boxes):
                if self._compute_iou(boxes[i], boxes[j]) > self.spec.iou_threshold:
                    # Merge boxes and remove the lower scoring one
                    merged_box = self._merge_boxes(boxes[i], boxes[j])
                    boxes[i] = merged_box
                    boxes.pop(j)
                    merged = True
                else:
                    j += 1

            # Only increment i if no merges happened in this iteration
            if not merged:
                i += 1

        return boxes

    def _compute_iou(self, box1, box2):
        """
        Compute IoU between two bounding boxes.
        """

        x1, y1, x2, y2 = box1["x_1"], box1["y_1"], box1["x_2"], box1["y_2"]
        x1_, y1_, x2_, y2_ = box2["x_1"], box2["y_1"], box2["x_2"], box2["y_2"]

        # Compute intersection
        inter_x1 = max(x1, x1_)
        inter_y1 = max(y1, y1_)
        inter_x2 = min(x2, x2_)
        inter_y2 = min(y2, y2_)

        inter_area = max(0, inter_x2 - inter_x1) * max(0, inter_y2 - inter_y1)

        # Compute union
        area1 = (x2 - x1) * (y2 - y1)
        area2 = (x2_ - x1_) * (y2_ - y1_)
        union_area = area1 + area2 - inter_area

        iou = inter_area / union_area if union_area > 0 else 0

        return iou

    def _merge_boxes(self, box1, box2):
        """
        Use the box with the highest score as the new box,
        and merge the other box region into it.
        """

        new_box = box1.copy() if box1["score"] > box2["score"] else box2.copy()

        new_x1 = min(box1["x_1"], box2["x_1"])
        new_y1 = min(box1["y_1"], box2["y_1"])
        new_x2 = max(box1["x_2"], box2["x_2"])
        new_y2 = max(box1["y_2"], box2["y_2"])

        new_box["x_1"] = new_x1
        new_box["y_1"] = new_y1
        new_box["x_2"] = new_x2
        new_box["y_2"] = new_y2

        return new_box


@dc.dataclass(frozen=True)
class RemoveContainedBoxesSpec(LayoutExecSpec):
    containment_threshold: float = 0.95
    """
    Threshold for considering a box as contained within another.
    A value of 0.98 means 98% of the smaller box must be contained within the larger box.
    """

    def delta_columns(self):
        return ".x_1", ".x_2", ".y_1", ".y_2", ".score", ".klass", ".markdown_class"


@factorize(RemoveContainedBoxesSpec)
class RemoveContainedBoxes(LayoutExec, spec_class=RemoveContainedBoxesSpec):
    """
    Removes bounding boxes that are completely contained within larger boxes.
    When a smaller box is contained within a larger one, the smaller box is removed.
    This helps eliminate redundant nested detections.
    NOTE: Only use for markdown_class!
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        curr_document = output.document
        flat = output.to_records(with_ids=True)

        boxes_by_page = [
            [box for box in group if box["markdown_class"] != "IDK"]
            for _, group in groupby(flat, key=lambda x: x["page"])
        ]

        result = []
        for page_idx, boxes_on_page in enumerate(boxes_by_page):
            processed_page = self._remove_contained_boxes(boxes_on_page)
            result.extend(processed_page)

        cleaned_records = LayoutParserOutput.from_records(result, curr_document)
        return cleaned_records

    def _remove_contained_boxes(self, boxes_on_page):
        """
        Remove boxes that are contained within larger boxes on a single page.
        """
        if not boxes_on_page:
            return []

        boxes = boxes_on_page.copy()
        i = 0
        while i < len(boxes):
            j = i + 1
            while j < len(boxes):
                # Check containment in both directions
                containment_ratio_i_in_j = self._compute_containment(boxes[i], boxes[j])
                containment_ratio_j_in_i = self._compute_containment(boxes[j], boxes[i])

                if containment_ratio_i_in_j > self.spec.containment_threshold:
                    # Box i is contained in box j, remove box i
                    boxes.pop(i)
                    j = i + 1  # Reset j since we removed i
                    continue
                elif containment_ratio_j_in_i > self.spec.containment_threshold:
                    # Box j is contained in box i, remove box j
                    boxes.pop(j)
                    continue
                j += 1
            i += 1

        return boxes

    def _compute_containment(self, smaller_box, larger_box):
        """
        Compute the ratio of overlap between the smaller box and the larger box.
        Returns the ratio of the intersection area to the smaller box area.
        """
        # Calculate intersection
        inter_x1 = max(smaller_box["x_1"], larger_box["x_1"])
        inter_y1 = max(smaller_box["y_1"], larger_box["y_1"])
        inter_x2 = min(smaller_box["x_2"], larger_box["x_2"])
        inter_y2 = min(smaller_box["y_2"], larger_box["y_2"])

        if inter_x2 <= inter_x1 or inter_y2 <= inter_y1:
            return 0.0

        # Calculate areas
        intersection_area = (inter_x2 - inter_x1) * (inter_y2 - inter_y1)
        smaller_box_area = (smaller_box["x_2"] - smaller_box["x_1"]) * (smaller_box["y_2"] - smaller_box["y_1"])

        # Return the ratio of intersection area to smaller box area
        return intersection_area / smaller_box_area if smaller_box_area > 0 else 0.0
