# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import logging
from copy import deepcopy
from functools import reduce
from typing import List, no_type_check

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.core import ParsedMetadata
from mew3.decltype import LayoutExec, LayoutExecSpec

_LOG = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class ListCombinerSpec(LayoutExecSpec):
    cross_page: bool = True
    """
    Combine lists across page boundaries.
    """


class ListCombiner(LayoutExec, spec_class=ListCombinerSpec):
    """
    The combiner of lists. Must be used after the key "markdown_class" is set, by "TO_MARKDOWN_CLASS" adddon.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        list_start_idx = None
        global_index = 0
        for page_bboxes in output:
            # Reset the list start index if we are not combining lists across pages.
            if not self.spec.cross_page:
                list_start_idx = None

            for bbox in page_bboxes:
                markdown_class = bbox["markdown_class"]
                if markdown_class != "LIST":
                    list_start_idx = None
                elif list_start_idx is None:
                    list_start_idx = global_index
                else:
                    output.rels["parent"].link(list_start_idx, global_index)
                global_index += 1
        return output


@no_type_check
@LayoutExec.register([".markdown_class"])
def merge_list(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    An alternative implementation of ListCombiner.
    Must be used after the key "markdown_class" is set, by "TO_MARKDOWN_CLASS" adddon.
    """

    list_bboxes: List[ParsedMetadata] = []
    result: List[ParsedMetadata] = []

    for page_bboxes in output:
        page_result = []
        assert not list_bboxes
        for bbox in page_bboxes:
            markdown_class = bbox["markdown_class"]
            if markdown_class == "LIST":
                list_bboxes.append(bbox.detach())
                continue

            _clear_list_into_result(page_result, list_bboxes)
            page_result.append(bbox.detach())
        else:
            _clear_list_into_result(page_result, list_bboxes)

        result.append(page_result)

    output = LayoutParserOutput.init(result + list_bboxes, document=output.document)
    return output


@no_type_check
@LayoutExec.register(delta_columns=[".font_size"])
def bbox_size_header_hierarchy(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    A heuristic to determine the hierarchy of headers in a document.
    """

    is_header = output.klasses == "HEADER"
    font_sizes = output.font_size[is_header]

    header_indices = [i for i, is_h in enumerate(is_header) if is_h]

    for idx in header_indices:
        # Find the nearest header above the current header.
        for prev in range(idx - 1, -1, -1):
            if is_header[prev] and font_sizes[prev] > font_sizes[idx]:
                output.rels["parent"].link(prev, idx)
                break
    return output


@no_type_check
@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", ".klass"])
def merge_many_things_by_column(output: LayoutParserOutput) -> LayoutParserOutput:
    list_bboxes: List[ParsedMetadata] = []
    result = []

    for page_bboxes in output:
        page_result = []
        assert not list_bboxes
        prev_grid_col = -1
        for bbox in page_bboxes:
            # FIXME: Make 32 configurable.
            grid_column = bbox.x_1 // 32
            if bbox.klass in ["PLAIN", "HEADER", "LIST", "IDK"] and grid_column == prev_grid_col:
                list_bboxes.append(bbox.detach())
                continue
            if len(list_bboxes):
                _clear_list_into_result(page_result, list_bboxes)
            prev_grid_col = grid_column
            page_result.append(bbox.detach())
        else:
            if len(list_bboxes):
                _clear_list_into_result(page_result, list_bboxes)
        result.append(page_result)
    output = LayoutParserOutput.init(result + list_bboxes, document=output.document)
    return output


def _clear_list_into_result(page_result: List[ParsedMetadata], list_bboxes: List[ParsedMetadata], /) -> None:
    if not len(list_bboxes):
        return

    lbb = [p.bbox for p in list_bboxes]
    merged_bbox = reduce(lambda left, right: left.merge(right, strategy="union"), lbb[1:], lbb[0])

    # NOTE:
    #   Just use the first bbox's metadata.
    first_item = deepcopy(list_bboxes[0])
    first_item.x_1 = merged_bbox.x_1
    first_item.y_1 = merged_bbox.y_1
    first_item.x_2 = merged_bbox.x_2
    first_item.y_2 = merged_bbox.y_2
    first_item.score = max([bbox.score for bbox in list_bboxes])

    page_result.append(first_item)
    list_bboxes.clear()


@no_type_check
@LayoutExec.register([".markdown_class"])
def merge_text_under_header(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    For a given HEADER, merge all PLAIN below until the next HEADER, or until bottom of page.
    Must be used after the key "markdown_class" is set, by "TO_MARKDOWN_CLASS" adddon.
    For now, DO NOT allow cross-page merging. Add this functionality later as configurable if needed.
    """

    result: List[ParsedMetadata] = []
    current_plain_texts: List[ParsedMetadata] = []

    for page_bboxes in output:
        page_result = []

        for bbox in page_bboxes:
            if bbox["markdown_class"] == "HEADER":
                # If we find a header, merge any accumulated plain texts
                if current_plain_texts:
                    page_result.append(_merge_plain_texts(current_plain_texts))
                    current_plain_texts.clear()
                # Add the header
                page_result.append(bbox.detach())

            # add other boxtyp as configurable if needed later
            elif bbox["markdown_class"] in ["PLAIN"]:
                current_plain_texts.append(bbox.detach())

            # For any other type, merge accumulated plain texts first
            else:
                if current_plain_texts:
                    page_result.append(_merge_plain_texts(current_plain_texts))
                    current_plain_texts.clear()
                # Add the other type
                page_result.append(bbox.detach())

        # Handle any remaining plain texts at end of page
        if current_plain_texts:
            page_result.append(_merge_plain_texts(current_plain_texts))
            current_plain_texts.clear()

        result.append(page_result)

    output = LayoutParserOutput.init(result, document=output.document)
    return output


def _merge_plain_texts(plain_texts: List[ParsedMetadata]) -> ParsedMetadata:
    """
    Helper function to merge multiple plain text boxes into one.
    """

    if not plain_texts:
        return None

    bboxes = [p.bbox for p in plain_texts]
    merged_bbox = reduce(lambda left, right: left.merge(right, strategy="union"), bboxes[1:], bboxes[0])

    # Use metadata from first PLAIN box
    merged = deepcopy(plain_texts[0])
    merged.x_1 = merged_bbox.x_1
    merged.y_1 = merged_bbox.y_1
    merged.x_2 = merged_bbox.x_2
    merged.y_2 = merged_bbox.y_2
    merged.score = max(bbox.score for bbox in plain_texts)
    return merged
