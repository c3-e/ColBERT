# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import functools
import json

import alive_progress as ap

from mew3 import settings
from mew3.core import DocBboxes
from mew3.document import PageDoc

from .api import LayoutModel, LayoutModelSpec
from .outputs import DOCLAYNET_LABELS

_TO_DOCLAYNET = {
    "title": "Title",
    "document_index": "Picture",
    "section_header": "Section-header",
    "page_header": "Page-header",
    "page_footer": "Page-footer",
    "list_item": "List-item",
    "caption": "Caption",
    "footnote": "Footnote",
    "formula": "Formula",
    "text": "Text",
    "picture": "Picture",
    "table": "Table",
    "checkbox_selected": "Picture",
    "checkbox_unselected": "Picture",
    "code": "Text",
}
for val in _TO_DOCLAYNET.values():
    assert val in DOCLAYNET_LABELS, f"DocLayNetClass should have {val} class"


@dc.dataclass(frozen=True)
class DoclingSpec(LayoutModelSpec):
    def delta_columns(self):
        return "+x_1", "+y_1", "+x_2", "+y_2", "+klass", "+score", "+page"


class Docling(LayoutModel, spec_class=DoclingSpec):
    """
    The layout model backed by the library docling.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._doc_conv = get_docling()

    def produce(self, doc: PageDoc) -> DocBboxes:
        out = self._doc_conv.convert(doc.fname)
        json_out = json.loads(out.model_dump_json())

        records = []

        assembled = json_out["assembled"]
        bodies = assembled["body"]
        pages = json_out["pages"]

        if settings.debug_mode:
            bodies = ap.alive_it(bodies, title="Processing", length=len(bodies))

        for rec in bodies:
            bbox = rec["cluster"]["bbox"]

            page_number = rec["page_no"]
            page_width = pages[page_number]["size"]["width"]
            page_height = pages[page_number]["size"]["height"]

            found_bbox = {
                "x_1": bbox["l"],
                "y_1": bbox["t"],
                "x_2": bbox["r"],
                "y_2": bbox["b"],
                "klass": _TO_DOCLAYNET.get(rec["label"], "Picture"),
                "score": rec["cluster"]["confidence"],
                "page": page_number,
            }

            assert found_bbox["x_1"] <= found_bbox["x_2"], "Invalid bounding box coordinates"
            assert found_bbox["y_1"] <= found_bbox["y_2"], "Invalid bounding box coordinates"

            # Entire box is outside the page.
            if any(
                [
                    found_bbox["x_1"] > page_width,
                    found_bbox["y_1"] > page_height,
                    found_bbox["x_2"] < 0,
                    found_bbox["y_2"] < 0,
                ]
            ):
                continue

            # Crop it to be inside the page.
            found_bbox["x_1"] = max(found_bbox["x_1"], 0)
            found_bbox["y_1"] = max(found_bbox["y_1"], 0)
            found_bbox["x_2"] = min(found_bbox["x_2"], page_width)
            found_bbox["y_2"] = min(found_bbox["y_2"], page_height)

            records.append(found_bbox)

        return DocBboxes.from_records(records, document=doc)


@functools.cache
def get_docling():
    from docling.backend.pypdfium2_backend import PyPdfiumDocumentBackend
    from docling.datamodel.base_models import InputFormat
    from docling.document_converter import DocumentConverter, PdfFormatOption, WordFormatOption
    from docling.pipeline.simple_pipeline import SimplePipeline
    from docling.pipeline.standard_pdf_pipeline import StandardPdfPipeline

    return DocumentConverter(  # all of the below is optional, has internal defaults.
        allowed_formats=[
            InputFormat.PDF,
            InputFormat.IMAGE,
            InputFormat.DOCX,
            InputFormat.HTML,
            InputFormat.PPTX,
            InputFormat.ASCIIDOC,
            InputFormat.CSV,
            InputFormat.MD,
        ],  # whitelist formats, non-matching files are ignored.
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_cls=StandardPdfPipeline, backend=PyPdfiumDocumentBackend),
            InputFormat.DOCX: WordFormatOption(pipeline_cls=SimplePipeline),  # , backend=MsWordDocumentBackend
        },
    )
