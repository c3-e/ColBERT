# Copyright 2009-2025 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


import dataclasses as dc
import logging

from mew3.core import BoundingBox
from mew3.core import DocBboxes as LayoutParserOutput

from .api import TextExtractor, TextExtractorSpec

_LOG = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class DefaultSpec(TextExtractorSpec):
    pass


class Default(TextExtractor, spec_class=DefaultSpec):
    """
    PDF Plumber text extractor takes in a PDF document and bounding boxes,
    and extract text from those regions using the pdfplumber library.

    This must be used in conjunction with a layout parser that extracts bounding boxes.
    """

    def execute(self, out: LayoutParserOutput) -> LayoutParserOutput:
        """
        Extracts text from a page using the default cropping strategy.

        Args:
            document: The PDF document.
            bounding_boxes: The bounding boxes of texts on each page.

        Returns:
            A list cropped text boxes.
        """

        # Note: this was causing duplicate components with the same global_idx that was interfering
        #   with the caption indexing for images and tables.
        # out["global_idx"] = list(range(out.num_rows))
        out["text"] = [
            out.document.pages[page].crop_text(
                BoundingBox(x_1=bbox["x_1"], x_2=bbox["x_2"], y_1=bbox["y_1"], y_2=bbox["y_2"])
            )
            for page, bbox in zip(out["page"], out.to_records())
        ]
        return out


# @dc.dataclass(frozen=True)
# class MergeSpec(DefaultSpec):
#     pass


# class Merge(Default, spec_class=MergeSpec):
#     """
#     Merges the text components extracted by the pdfplumber text extractor, and then merge them by page.
#     """

#     def execute(self, parsed: DocBboxes) -> List[RawTextComponent]:
#         super_parsed = super().execute(parsed)
#         by_page: Dict[int, List[RawTextComponent]] = defaultdict(list)

#         for parsed in super_parsed:
#             by_page[parsed.page].append(parsed)

#         def merge_bbox(bboxes: List[BoundingBox]) -> BoundingBox:
#             """
#             Merge a list of bounding boxes into a single bounding box.
#             """
#             assert bboxes
#             return reduce(lambda bbox1, bbox2: bbox1.merge(bbox2, strategy="union"), bboxes[1:], bboxes[0])

#         # Join the components on each page.
#         return [
#             RawTextComponent(
#                 text="\n".join(comp.text for comp in parsed_by_page),
#                 page=page,
#                 bbox=merge_bbox([comp.bbox for comp in parsed_by_page]),
#             )
#             for page, parsed_by_page in by_page.items()
#         ]
