# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from mew3.ctx import c3_not_set
from mew3.providers import C3GenaiCoreLLM, OpenaiProvider, vlm

from .api import TableVerbal, TableVerbalSpec


@dc.dataclass(frozen=True)
class OpenaiSpec(TableVerbalSpec):
    model: str = "gpt-4o"
    """
    Necessary is using GenaiCore LLM.
    """

    genai_core_model: str = "GenaiCore.Llm.AzureOpenAi.Model"
    """
    This parameter will be evaled by c3.type().
    """

    default_options: dict = dc.field(
        default_factory=lambda: {
            "temperature": 0,
            "max_tokens": 4096,
            "returnJson": True,
        }
    )
    """
    Default options for the model. `returnJson` must be True (implicitly set).
    """

    genai_core_auth_name: str = "default"
    """
    The name of the authentication to use. Default to "default".
    """

    max_tokens: int = 4096
    """
    The maximum number of tokens to generate for the remote model.
    Used by non-GenaiCore LLM.
    """

    system_prompt: str = "You are a good table verbalizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = """
    Given the table, provide a brief description of its contents. Also, highlight important values and keywords.
    The following extracted information from the table and its page can assist with your verbalization:
    
    {title_prompt}

    {context_awareness_prompt}

    {table_content_prompt}

    Your output:"""

    """
    The user prompt to use for the table verbalization.
    """

    def delta_columns(self):
        return ("+verbalization",)


class Openai(TableVerbal, spec_class=OpenaiSpec):
    """
    Use LLM for table verbalization.
    Input: table image, title, content text, surrounding text (optional). Output: verbalization.
    """

    def _call(self, box: dict):
        if "title" in box:
            title_prompt = f"=== Table Title ===\n\n{box['title']}"
        else:
            title_prompt = ""

        if "surrounding_text" in box:
            context_awareness_prompt = f"=== Parsed text surrounding the table ===\n\n{box['surrounding_text']}"
        else:
            context_awareness_prompt = ""

        if "text" in box:
            table_content_prompt = f"=== Parsed Table Content (e.g. from pdfplumber) ===\n\n{box['text']}"
        else:
            table_content_prompt = ""

        prompt = self.spec.user_text_prompt.format(
            title_prompt=title_prompt,
            table_content_prompt=table_content_prompt,
            context_awareness_prompt=context_awareness_prompt,
        )

        if "table_image" in box:
            return self.vlm(prompt, box["table_image"])
        else:
            return self.vlm(prompt)

    @property
    def vlm(self):
        if c3_not_set():
            return vlm(
                OpenaiProvider(
                    max_tokens=self.spec.max_tokens,
                    system_prompt=self.spec.system_prompt,
                )
            )

        else:
            return vlm(
                C3GenaiCoreLLM(
                    model=self.spec.model,
                    genai_core_model=self.spec.genai_core_model,
                    genai_core_auth_name=self.spec.genai_core_auth_name,
                    default_options=self.spec.default_options,
                    max_tokens=self.spec.max_tokens,
                    system_prompt=self.spec.system_prompt,
                )
            )
