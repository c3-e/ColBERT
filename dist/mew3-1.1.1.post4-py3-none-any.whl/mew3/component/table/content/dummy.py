# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import logging
from dataclasses import dataclass, field
from typing import Any, Dict

from mew3.document import PageDoc

from .api import TableContent, TableContentSpec

_LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class DummySpec(TableContentSpec):
    kwargs: Dict[str, Any] = field(default_factory=dict)


class Dummy(TableContent, spec_class=DummySpec):
    def _call(self, document: PageDoc, box: dict) -> str:
        return ""
