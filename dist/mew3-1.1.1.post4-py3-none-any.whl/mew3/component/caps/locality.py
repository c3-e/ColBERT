# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import logging
from dataclasses import dataclass, field
from typing import List, Sequence

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.core import ParsedMetadata
from mew3.document import PageDoc

from .api import CaptionFinder, CaptionFinderSpec

_LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class LocalitySpec(CaptionFinderSpec):
    search_bbox_with_offsets: List[int] = field(default_factory=lambda: [1, -1, 2, -2, 3, -3])
    """
    The order of the offsets to search for the caption/title for the current bbox.
    Negative/Positive values indicate searching for bboxes above/below the current bbox.
    Once found a good caption/title, the search stops.
    """

    target_bbox_type: str = "PLAIN"
    """
    The ideal bbox type for the final caption/header
    """

    bbox_types_to_search_for: List[str] = field(default_factory=lambda: ["PLAIN", "HEADER", "CAPTION"])
    """
    Fallback bbox types to search for if the `target_bbox_type` is not found
    """

    enable_cross_page_search: bool = False
    """
    Whether to allow searching for the caption/title in two adjacent pages.
    """


class Locality(CaptionFinder, spec_class=LocalitySpec):
    """
    Given a document and their parsed layout,
    return the captions for each image by locating a text bounding box near the image bounding box.
    This parser assumes that the layout parser already does a decent job of parsing the document layout,
    so it only explores nearby bounding boxes, from near to far, to find the caption.
    """

    def _parse(
        self,
        document: PageDoc,
        bounding_boxes: LayoutParserOutput,
        current_bbox_typ: Sequence[str],
    ) -> List[List[str]]:
        bboxes = bounding_boxes.to_list_of_list()
        offsets = [int(x) for x in self.spec.search_bbox_with_offsets]
        assert len(offsets) == len(set(offsets)), "Offsets must be unique"

        # For faster accessing.
        meta_list_list: List[List[str]] = []

        for page_idx, boxes_on_page in enumerate(bboxes):
            metadata_on_page: List[str] = []

            for fig_idx in range(len(boxes_on_page)):
                if boxes_on_page[fig_idx]["markdown_class"] not in current_bbox_typ:
                    metadata_on_page.append("")
                    continue

                # Get the caption/title for the figure/table. It could locate in an adjacent page.
                caption = get_for_box(
                    document=document,
                    target_page_number=page_idx,
                    target_box_idx=fig_idx,
                    all_bboxes=bboxes,
                    offsets=offsets,
                    target_bbox_type=self.spec.target_bbox_type,
                    bbox_types_to_search_for=self.spec.bbox_types_to_search_for,
                    enable_cross_page_search=self.spec.enable_cross_page_search,
                )
                assert isinstance(caption, str), type(caption)
                metadata_on_page.append(caption)

            meta_list_list.append(metadata_on_page)

        return meta_list_list


def get_for_box(
    document: PageDoc,
    target_page_number: int,
    target_box_idx: int,
    all_bboxes: Sequence[Sequence[ParsedMetadata]],
    offsets: List[int],
    target_bbox_type: str,
    bbox_types_to_search_for: List[str],
    enable_cross_page_search: bool = False,
) -> str:
    """
    Look for the caption of a figure in the nearby bounding boxes.

    Args:
        document: The document.
        target_page_number: The page number.
        figure_box_idx: The index of the figure bounding box.
        page_bounding_boxes: List of bounding boxes.
        keywords: Keywords to search for in the captions.
        top_k: Number of nearby bounding boxes to consider.
    """

    prev_page_number = target_page_number - 1
    next_page_number = target_page_number + 1

    prev_page_bboxes = all_bboxes[prev_page_number] if prev_page_number >= 0 else ()
    curr_page_bboxes = all_bboxes[target_page_number]
    next_page_bboxes = all_bboxes[next_page_number] if next_page_number < len(all_bboxes) else ()

    if enable_cross_page_search:
        all_bboxes = [*prev_page_bboxes, *curr_page_bboxes, *next_page_bboxes]
        global_target_box_idx = len(prev_page_bboxes) + target_box_idx
    else:
        all_bboxes = curr_page_bboxes
        global_target_box_idx = target_box_idx

    nearest_bboxes: List[ParsedMetadata] = []

    for offset in offsets:
        idx = global_target_box_idx + offset
        if idx >= 0 and idx < len(all_bboxes):
            bbox = all_bboxes[idx]

            if bbox["markdown_class"] in bbox_types_to_search_for:
                nearest_bboxes.append(bbox)

    # This is a hack that returns empty string if no nearby bounding boxes are found,
    # while this is a hack, it exists in previous build so I'm not responsible for it.
    if not nearest_bboxes:
        return ""

    nearest_caption_bboxes = [bbox for bbox in nearest_bboxes if bbox["markdown_class"] == target_bbox_type]
    use_bboxes = nearest_caption_bboxes if nearest_caption_bboxes else nearest_bboxes

    caption = ""
    for bbox in use_bboxes:
        try:
            caption = document.page_contents[bbox["page"]].crop_text(bbox.norm_bbox)

            if caption.strip():
                return caption
        except Exception as e:
            _LOG.warning(f"Failed to extract content from bbox {bbox} on page {target_page_number}: {e}")
            continue

    return ""
