# Copyright 2009-2025 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


import logging
from dataclasses import dataclass, field
from typing import List, Sequence

from mew3.core import BoundingBox
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.layout import LayoutParserOutput

_LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class GetSurroundingTextSpec(LayoutExecSpec):
    current_bbox_typ: str = "TABLE"
    """
    The current bbox type around which to extract information. Typically either "TABLE" or "FIGURE".
    """

    extract_bbox_with_offsets: List[int] = field(default_factory=lambda: [-3, -2, -1, 1, 2, 3])
    """
    The offsets of surrounding bboxes to extract information for the current bbox.
    Negative/Positive values indicate searching for bboxes above/below the current bbox.
    """

    extract_bbox_with_type: List[str] = field(default_factory=lambda: ["PLAIN", "HEADER", "CAPTION", "LIST"])
    """
    Bbox types to extract information from.
    """

    enable_cross_page_search: bool = False
    """
    Whether to allow searching for the caption/title in two adjacent pages.
    """

    def delta_columns(self):
        return ("+surrounding_text",)


class GetSurroundingText(LayoutExec, spec_class=GetSurroundingTextSpec):
    """
    For a Table/Figure, extract the surrounding text. Add a new column to the output.
    This information will facilitate the subsequent verbalization to improve quality and reduce hallucination.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        doc = output.document
        all_records = output.to_records(with_ids=True)

        bbxs: List[BoundingBox] = [
            BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in output.to_records()
        ]
        pages: List[int] = output["page"].to_numpy().tolist()
        list_classes = output["markdown_class"].to_numpy().tolist()
        list_texts = [
            (str(doc.pages[p].crop_text(b)) if c not in ["FIGURE", "TABLE", "IDK"] else "")
            for b, p, c in zip(bbxs, pages, list_classes)
        ]
        all_surrounding_text = []

        for idx, box in enumerate(all_records):
            if box["markdown_class"] != self.spec.current_bbox_typ:
                all_surrounding_text.append("")
                continue
            else:
                valid_texts = [
                    (list_texts[idx + offset], offset)
                    for offset in map(int, self.spec.extract_bbox_with_offsets)
                    if 0 <= idx + offset < len(list_texts)
                    and list_classes[idx + offset] in self.spec.extract_bbox_with_type
                    and (self.spec.enable_cross_page_search or pages[idx + offset] == pages[idx])
                ]

                curr_string = self.format_string(valid_texts, self.spec.current_bbox_typ.lower())

                all_surrounding_text.append(curr_string)

        output["surrounding_text"] = all_surrounding_text
        return output

    def format_string(self, text_list: List[Sequence], obj_type: str) -> str:
        output_string = """"""
        for text, offset in text_list:
            if offset < 0:
                output_string += f"Text above {obj_type}: {text}\n"
            else:
                output_string += f"Text below {obj_type}: {text}\n"

        return output_string.strip()


@dataclass(frozen=True)
class GetParentHeaderSpec(LayoutExecSpec):
    do_hierarchy_detection: bool = False
    """
    Boolean flag to control whether this heuristic hierarchy detection component is executed
    """

    extract_header_for_type: List[str] = field(default_factory=lambda: ["PLAIN", "LIST"])
    """
    Markdown bounding box types to extract hierarchy information for.
    """

    header_parent_types: List[str] = field(default_factory=lambda: ["HEADER"])
    """
    Markdown bounding box types to consider as parents.
    """

    enable_cross_page_search: bool = True
    """
    Whether to allow searching for the parent header in two adjacent pages.
    """

    def delta_columns(self):
        return ("+parent_text",)


class GetParentHeader(LayoutExec, spec_class=GetParentHeaderSpec):
    """
    For a Text passage, extract the associated header text. Add a new column to the output.
    This information will facilitate passage-level metadata to improve retrieval.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        if self.spec.do_hierarchy_detection:
            bbox_ids = list(range(output.num_rows))
            current_parent_bbox_idx = output.num_rows + 1
            tmp_output = output.with_column("bbox_id", bbox_ids)

            header_text_list = []

            for page_bboxes in tmp_output:
                if not self.spec.enable_cross_page_search:
                    current_parent_bbox_idx = tmp_output.num_rows + 1
                for bbox in page_bboxes:
                    if bbox.markdown_class in self.spec.header_parent_types:
                        current_parent_bbox_idx = bbox.bbox_id
                        header_text_list.append("")
                    elif (
                        bbox.markdown_class in self.spec.extract_header_for_type
                        and current_parent_bbox_idx < bbox.bbox_id
                    ):
                        header_text = tmp_output.gf.df.query(f"bbox_id == {current_parent_bbox_idx}").text[0]
                        header_text_list.append(header_text)
                    else:
                        header_text_list.append("")
            return output.with_column("parent_text", header_text_list)
        return output
