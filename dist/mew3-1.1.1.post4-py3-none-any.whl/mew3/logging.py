# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import json
from logging import Handler

from mew3 import ctx, settings


class C3JSDataHandler(Handler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def emit(self, record):
        if ctx.c3_not_set():
            return

        if not settings.c3_json_data_debug:
            return

        if not callable(settings.c3_json_data_debug):
            raise TypeError("c3_json_data_debug must be callable")

        record_dict = record.__dict__

        ctx.c3().JSData.make(
            {
                "data": {
                    "data_json": json.loads(json.dumps(record, default=lambda x: x.__dict__)),
                    "log_record": settings.c3_json_data_debug(record_dict),
                },
            }
        ).upsert()
