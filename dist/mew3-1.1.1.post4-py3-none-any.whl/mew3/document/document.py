# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import List, Protocol, Tuple, runtime_checkable

import numpy as np
from numpy.typing import NDArray

from mew3.croppers import ImageCropper, TableCropper, TextCropper
from mew3.reader import GridGen, PageCnt
from mew3.specs import Spec, specify

from .contents import Content


@runtime_checkable
class HasSupports(Protocol):
    def supports(self) -> List[str | re.Pattern]:
        return NotImplemented


@dataclass(frozen=True)
class PageDocSpec(Spec):
    """
    The document class. A document is simply a file URL with some metadata.

    It provides some convenience methods to load the document as images,
    and to get the name and type of the document.

    Represents a document that is stored in a file.

    """

    filename: str | Path
    """
    The location of the documents.
    """

    image_crop: str = "AUTO"
    """
    The image cropper to use for the document.
    """

    text_crop: str = "AUTO"
    """
    The text cropper to use for the document.
    """

    table_crop: str = "AUTO"
    """
    The table cropper to use for the document.
    """

    page_cnt: str = "AUTO"
    """
    Counting how many pages are in this document.
    """

    grid_gen: str = "AUTO"
    """
    Grid generation for the document.
    """


@specify(PageDocSpec)
class PageDoc:
    @property
    def dpi(self) -> int:
        return self.image_cropper.dpi

    @property
    def filename(self):
        return self.spec.filename

    @property
    def image_crop(self):
        return self.spec.image_crop

    @property
    def text_crop(self):
        return self.spec.text_crop

    @property
    def table_crop(self):
        return self.spec.table_crop

    @property
    def page_cnt(self):
        return self.spec.page_cnt

    @property
    def grid_gen(self):
        return self.spec.grid_gen

    def __hash__(self):
        return hash(self.fname)

    def __post_init__(self):
        if not Path(self.filename).exists():
            raise FileNotFoundError(f"File {self.filename} does not exist.")

        if self.dpi <= 0:
            raise ValueError(f"DPI must be positive, got {self.dpi}.")

        self.assert_support(self.text_cropper)
        self.assert_support(self.image_cropper)
        self.assert_support(self.table_cropper)
        self.assert_support(self.page_counter)
        self.assert_support(self.grid_generator)

    def __len__(self):
        return self.page_counter(self)

    def assert_support(self, proc: HasSupports, /) -> None:
        if not self.check_support(proc):
            raise ValueError(
                f"Document {self} has type: {self.type}, "
                f"which is nots supported by {proc.__class__.__qualname__}, "
                f"which only supports {proc.supports()}."
            )

    def check_support(self, proc: HasSupports, /) -> bool:
        """
        Check if the processor supports the document type.

        Args:
            proc: The processor to check.

        Raises:
            TypeError: If the processor does not support the document type.

        Returns:
            bool: Whether the processor supports the document type.
        """

        if not isinstance(proc, HasSupports):
            raise TypeError(f"Expected HasSupports, got {type(proc)}.")

        if proc.supports() is NotImplemented:
            return True

        for doc_type in proc.supports():
            if isinstance(doc_type, str):
                if self.type == doc_type:
                    return True
            elif isinstance(doc_type, re.Pattern):
                if doc_type.fullmatch(self.type):
                    return True
            else:
                raise TypeError(f"Expected str or re.Pattern, got {type(doc_type)}")

        return False

    @property
    def rel_scale(self) -> float:
        """
        The relative scale of the document.

        Returns:
            float: The relative scale of the document.
        """

        return self.dpi / 72

    @property
    def fname(self) -> str:
        """
        Returns the filename as a string.
        """

        fname_path = Path(self.filename)
        fname_path = fname_path.expanduser()
        fname_path = fname_path.absolute()
        return str(fname_path)

    @property
    def name(self) -> str:
        """
        Returns the name of the document

        Returns:
            str: The name of the document.
        """
        return Path(self.fname).stem

    @property
    def type(self) -> str:
        """
        Returns the type of the document

        Returns:
            str: The type of the document.
        """
        return self.fname.split(".")[-1]

    @property
    def is_pdf(self) -> bool:
        return self.type == "pdf"

    def __array__(self):
        return np.array(self._to_numpy_list())

    def _to_numpy_list(self) -> List[NDArray]:
        return [np.array(page) for page in self.page_contents]

    @property
    def pages(self):
        return self.page_contents

    @property
    @cache
    def page_contents(self) -> Tuple[Content, ...]:
        """
        Loads a single pages as a list of platform independent, croppable pages,
        on which you would be able to perform various extraction operations.

        Returns:
            A tuple of pages, each of which is a `Content` object.
            The `Content` object supports cropping and extraction of text, images and tables.
        """

        length = len(self)

        return tuple(Content(document=self, page=i) for i in range(length))

    @property
    @cache
    def text_cropper(self) -> TextCropper:
        return TextCropper.factory(self.spec.text_crop)

    @property
    @cache
    def table_cropper(self) -> TableCropper:
        return TableCropper.factory(self.spec.table_crop)

    @property
    @cache
    def image_cropper(self) -> ImageCropper:
        return ImageCropper.factory(self.spec.image_crop)

    @property
    @cache
    def page_counter(self) -> PageCnt:
        return PageCnt.factory(self.spec.page_cnt)

    @property
    @cache
    def grid_generator(self) -> GridGen:
        return GridGen.factory(self.spec.grid_gen)

    def view(self, page_chunks: int) -> List[PageDocSlice]:
        length = len(self)
        return [self.slice(idx, min(idx + page_chunks, length)) for idx in range(0, length, page_chunks)]

    def slice(self, start: int, end: int) -> PageDocSlice:
        """
        Splits the document into chunks of size `page_chunk_size`.

        Args:
            page_chunk: The number of pages per chunks.

        Returns:
            The document views.
        """

        return PageDocSlice(
            page_idxs=range(start, end),
            filename=self.filename,
            image_crop=self.image_crop,
            text_crop=self.text_crop,
            table_crop=self.table_crop,
            page_cnt=self.page_cnt,
            grid_gen=self.grid_gen,
        )


@dataclass(frozen=True)
class _DocViewMixin:
    """
    A mixin made to ensure that keyword arguments always exist last (some dataclass mechanism).
    This should be placed after any other dataclass that has optional (keyword) arguments.
    """

    page_idxs: range
    """
    The pages to view. Must be have a start and end, with step = 1.
    Both start and end must be in the range [0, len(document)].
    """


@dataclass(frozen=True)
class PageDocSliceSpec(PageDocSpec, _DocViewMixin):
    pass


class PageDocSlice(PageDoc, spec_class=PageDocSliceSpec):
    """
    ``PageDocSlice`` is a view of a document, kind of like slices to arrays, but for documents.
    Acting like a proxy to read only a portion of the document,
    this class makes it possible to do page-level parallel processing.

    NOTE:
        This class inherits from ``PageDoc``, s.t. no code changes are needed for existing code.
        However, this might not be the best decision going forward.
    """

    def __post_init__(self):
        super().__post_init__()

        assert self.spec.page_idxs.start >= 0, "Start must be >= 0."
        assert self.spec.page_idxs.stop <= super().__len__(), "End must be <= len(document)."
        assert self.spec.page_idxs.step == 1, "Step must be 1."
        assert self.spec.page_idxs.start <= self.spec.page_idxs.stop, "Start must be <= end."

    def __len__(self) -> int:
        return len(self.page_idxs)

    @property
    def start(self) -> int:
        return self.page_idxs.start

    @property
    def end(self) -> int:
        return self.page_idxs.stop

    @property
    @cache
    def page_contents(self: PageDoc) -> Tuple[Content, ...]:
        return tuple(Content(document=self, page=i) for i in self.page_idxs)
