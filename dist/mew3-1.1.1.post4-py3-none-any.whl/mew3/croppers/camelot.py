# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import json
import logging
import warnings
from functools import cache
from typing import TYPE_CHECKING

from pandas import DataFrame

from mew3.providers import camelot_read_pdf, pdfplumber_read_pdf

from .api import TableCropper, TableCropperSpec

if TYPE_CHECKING:
    from mew3 import BoundingBox
    from mew3.document import Content


_LOG = logging.getLogger(__name__)


class Camelot(TableCropper, spec_class=TableCropperSpec):
    """
    Camelot is a table content extractor that uses the camelot library to extract tables from PDFs.

    Since this is more or less a "traditional" table extractor,
    it is not as flexible as the other table extractors,
    and can fail on more complex tables.
    """

    @cache
    def warn_bbox(self):
        warnings.warn(
            "Bounding box cropping has been disabled with Camelot, " "due to having issues. Ignoring the bounding box."
        )

    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        if bbox is not None:
            self.warn_bbox()
        dfs = camelot_read_pdf(document=content.document, page_number=content.page)

        chosen_df = dfs[0]
        return self._table_to_text(chosen_df)

    def supports(self):
        return ["pdf"]

    def _table_to_text(self, df_table: DataFrame):
        """
        Returns a string representation of a pandas dataframe.
        """
        table_rows = []
        for _, row in df_table.iterrows():
            table_rows.append("\t| ".join([x.replace("\n", " ") for x in list(row)]))
        return "\n".join(table_rows)


class CamelotAllowFail(TableCropper, spec_class=TableCropperSpec):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        from mew3.core import BoundingBox

        curr_page = pdfplumber_read_pdf(content.document.fname, content.page, lambda x: x)

        page_width = curr_page.width
        page_height = curr_page.height

        # If not specified, use the whole page.
        bbox = bbox or BoundingBox(0, 0, page_width, page_height)

        margin = 5
        converted_bbox = [  # x1, y1 (top-left), x2, y2 (bottom-right)
            max(0, bbox.x_1 - margin),  # x1 (Left boundary)
            min(page_height, page_height - bbox.y_1 + margin),  # y1 (Top boundary)
            min(page_width, bbox.x_2 + margin),  # x2 (Right boundary)
            max(0, page_height - bbox.y_2 - margin),  # y2 (Bottom boundary)
        ]

        area = ",".join([str(int(i)) for i in converted_bbox])

        try:
            dfs = camelot_read_pdf(document=content.document, page_number=content.page, table_areas=[area])

            return json.dumps([df.to_dict(orient="records") for df in dfs])
        except:
            return "[]"
