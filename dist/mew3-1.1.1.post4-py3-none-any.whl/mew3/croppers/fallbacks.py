# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reservedc.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import re

from mew3.providers.plumber import CID_PATTERN
from mew3.specs import TryStep, try_this_then_that

from .api import TableCropper, TextCropper

EmptyTextFallbackSpec, EmptyTextFallback = try_this_then_that(
    klass_type=TextCropper,
    steps=[
        TryStep(
            kind="PLUMBER_AUTO",
            mark_fail=lambda x: not x,
        ),
        TryStep(
            kind="OCR",
            mark_fail=lambda _: False,
        ),
    ],
    class_name="EMPTY_THEN_DO_OCR",
    func_name="crop_bbox",
)

NUMBER_REGEX = re.compile(r"^\d+(\.\d+)?$")
NumberEmptyTextFallbackSpec, NumberEmptyTextFallback = try_this_then_that(
    klass_type=TextCropper,
    steps=[
        TryStep(
            kind="PLUMBER_AUTO",
            mark_fail=lambda x: not x or bool(NUMBER_REGEX.match(x)),
        ),
        TryStep(
            kind="OCR",
            mark_fail=lambda _: False,
        ),
    ],
    class_name="EMPTY_OR_IS_PAGE_NUMBER_THEN_DO_OCR",
    func_name="crop_bbox",
)

TableFallbackSpec, TableFallback = try_this_then_that(
    klass_type=TableCropper,
    steps=[
        TryStep(
            kind="CAMELOT",
            mark_fail=lambda x: CID_PATTERN.search(x),
        ),
        TryStep(
            kind="OCR",
            mark_fail=lambda x: CID_PATTERN.search(x),
        ),
    ],
    class_name="IF_CAMELOT_CID_THEN_DO_OCR",
    func_name="crop_bbox",
)
