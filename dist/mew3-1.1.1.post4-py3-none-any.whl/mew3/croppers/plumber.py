# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as d
import re
import warnings
from copy import deepcopy
from typing import TYPE_CHECKING, Callable, List, NamedTuple, TypeVar

from PIL.Image import Image

from mew3.providers.plumber import pdfplumber_extract_font_size, pdfplumber_read_pdf
from mew3.rules import english_words, get_tols_for_files, tokenize_and_count
from mew3.specs import Spec, signature_parse

from .api import ImageCropper, ImageCropperSpec, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from pdfplumber.page import Page

    from mew3 import BoundingBox
    from mew3.document import Content

WHITE_SPACE = re.compile(r"\s+")


def remove_whitespace(text: str) -> str:
    """
    Replace whitespace with single space.

    """
    return WHITE_SPACE.sub(" ", text)


T = TypeVar("T")


def rewrite_xy_tol(spec, val):
    sig = signature_parse(val)
    kwargs = deepcopy(sig.kwargs)
    filename = str(spec.filename)
    tols = get_tols_for_files(filename)
    return {"x_tolerance": tols.x_tol, "y_tolerance": tols.y_tol}


def _read_and_call(
    content: Content,
    callback: Callable[[Page], T],
    bbox: BoundingBox | None = None,
) -> T:
    return pdfplumber_read_pdf(file=content.document.fname, page=content.page, callback=callback, bbox=bbox)


@d.dataclass
class _PlumberSpecForText(TextCropperSpec):
    dedupe_chars_kwargs: dict[str, bool] = d.field(default_factory=dict)
    extract_text_kwargs: dict[str, bool] = d.field(default_factory=lambda: {"x_tolerance": 1.5, "y_tolerance": 1.5})


class TextPDFPlumber(TextCropper, spec_class=_PlumberSpecForText, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        return remove_whitespace(
            _read_and_call(
                content=content,
                callback=lambda page: page.dedupe_chars(
                    **self.spec.dedupe_chars_kwargs,
                ).extract_text(
                    **self.spec.extract_text_kwargs,
                ),
                bbox=bbox,
            )
        )

    def supports(self):
        return ["pdf"]


class ImagePDFPlumber(ImageCropper, spec_class=ImageCropperSpec, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> Image:
        return _read_and_call(
            content=content,
            callback=lambda page: page.to_image(resolution=self.dpi).original,
            bbox=bbox,
        )

    def supports(self):
        return ["pdf"]


@d.dataclass
class _PlumberSpecForTable(TableCropperSpec):
    extract_table_kwargs: dict[str, bool] = d.field(default_factory=dict)


class TablePDFPlumber(TableCropper, spec_class=_PlumberSpecForTable, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        table = _read_and_call(
            content=content,
            callback=lambda page: page.extract_table(**self.spec.extract_table_kwargs),
            bbox=bbox,
        )
        return remove_whitespace("\n".join(", ".join(map(str, row) or []) for row in (table or [])))

    def supports(self):
        return ["pdf"]


@d.dataclass
class _PlumberSpecForTableTextOnly(TableCropperSpec):
    dedupe_chars_kwargs: dict[str, bool] = d.field(default_factory=dict)
    extract_text_kwargs: dict[str, bool] = d.field(default_factory=lambda: {"x_tolerance": 1.5, "y_tolerance": 1.5})


class PlumberText(TableCropper, spec_class=_PlumberSpecForTableTextOnly):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        result = _read_and_call(
            content=content,
            callback=lambda page: page.dedupe_chars(
                **self.spec.dedupe_chars_kwargs,
            ).extract_text(
                **self.spec.extract_text_kwargs,
            ),
            bbox=bbox,
        )
        return remove_whitespace(result)

    def supports(self):
        return ["pdf"]


WORDS = frozenset(english_words())
S = TypeVar("S", bound=Spec)


class _PlumberResult(NamedTuple):
    x_tol: float
    y_tol: float
    text: str
    count: int


def plumber_auto_xy_tol(super_cls: T, super_spec_cls: S) -> T:
    assert isinstance(super_cls, type)

    @d.dataclass
    class PlumberExtractWithAutoGridSpec(super_spec_cls):
        minimum: float = 0.1
        """
        The minimum value of the grid.
        """

        maximum_grid_func: Callable = lambda spec: spec.maximum
        """
        The maximum grid function.
        """

    class PlumberExtractWithAutoGrid(super_cls, spec_class=PlumberExtractWithAutoGridSpec, class_name="PLUMBER_AUTO"):
        def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning, module="pdfplumber")

                try:
                    return self._crop_bbox(content, bbox)
                except ValueError:
                    return ""

        def _crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
            font_size = pdfplumber_extract_font_size(content.document.fname, page=content.page, bbox=bbox)

            maximum = self.spec.maximum_grid_func(font_size)

            tol = self.spec.minimum
            results: List[_PlumberResult] = []

            while tol <= maximum:
                result = remove_whitespace(
                    _read_and_call(
                        content=content,
                        callback=lambda page: page.dedupe_chars().extract_text(x_tolerance=tol, y_tolerance=tol),
                        bbox=bbox,
                    )
                )
                results.append(_PlumberResult(x_tol=tol, y_tol=tol, text=result, count=tokenize_and_count(result)))

                tol *= 1.5

            # print(results)
            # Revsered to prefer smaller tolerances.
            return max(reversed(results), key=lambda r: r.count).text

        def supports(self):
            return ["pdf"]

    return PlumberExtractWithAutoGrid


TextPlumberAuto = plumber_auto_xy_tol(TextCropper, TextCropperSpec)
TablePlumberAuto = plumber_auto_xy_tol(TableCropper, TableCropperSpec)
