# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import base64
import json
import logging
from collections import defaultdict
from io import BytesIO, StringIO

import numpy as np
import pdfplumber

from mew3.ctx import c3, c3_not_set

from .c3_styling import HTML_CONTENT_STRING, JS_SCRIPT_STRING

_LOG = logging.getLogger(__name__)
_LOG.setLevel(logging.ERROR)


class C3UiDebugger:
    """

    Processing layout/component parser outputs for debugging.
    Pdf with bounding boxes overlay are stored.
    Json from either mew3 output or c3.Genai.SourcePassage are stored.
    Should work both in Jupyter notebook and in console.

    Serve an UI to view the stored images and bounding boxes in a webpage.
    """

    def __init__(
        self,
        source_file,
        bbox_class_to_overlay: str = "markdown_class",
    ):
        self.source_file = source_file
        self.source_file_id = source_file.id
        self.original_file_url = source_file.originalFile.url
        self.passages_json_url = source_file.passagesFile.url
        self.components_json = None
        self.display_json = None
        self.image_obj_list = []
        self.box_class_to_overlay = bbox_class_to_overlay
        self.output_dir = "c3_ui_debugger_output"
        self.output_html_url = ""
        self.display_url_prefix = (
            f"https://{c3().Cluster.url.id}/" f"{c3().C3.env().name}/" f"{c3().App.inst().name}/file/"
        )

    def run(self):
        """
        Generate bboxes, images; render html using these data; save to local folder.
        """

        if c3_not_set():
            return "c3 NOT SET!"

        self._get_components()
        self._get_doc_info()
        self._save_img_with_bbox()
        self._create_html_file()
        return self._display_html_url()

    def _get_components(self):
        """
        Read the components json from the source file.
        """
        self.source_passages = self.source_file.readPassages().toJson()
        self.components_json = [sp["componentInfo"] for sp in self.source_passages]

        display_json = []
        for i in self.source_passages:
            display_json.append(
                {
                    **{
                        f"SP.{key}": i[key]
                        for key in [
                            "intraSourceId",
                            "pageNumber",
                            "contentStr",
                            "caption",
                            "imageVerbalization",
                            "header",
                            "title",
                            "tableVerbalization",
                        ]
                        if key in i
                    },
                    **({"SP.imageFile": i["imageFile"]["url"]} if "imageFile" in i and "url" in i["imageFile"] else {}),
                    **(
                        {"SP.dataFrameFile": i["dataFrameFile"]["url"]}
                        if "dataFrameFile" in i and "url" in i["dataFrameFile"]
                        else {}
                    ),
                    **(
                        {"SP.tableImageFile": i["tableImageFile"]["url"]}
                        if "tableImageFile" in i and "url" in i["tableImageFile"]
                        else {}
                    ),
                    **i["componentInfo"],
                }
            )

        self.display_json = display_json

    def _get_doc_info(self):
        """
        Read the document info json from the source file.
        """

        self.document_info_url = self.source_passages[0]["documentInfoFile"]["url"]

        f = c3().FileSystem.openFile(self.document_info_url)
        buffer = BytesIO(f.read())
        buffer.seek(0)
        content = buffer.read()
        self.doc_info_json = json.loads(content.decode("utf-8"))

        self.dpi = self.doc_info_json["file_info"]["dpi"]

    def _display_html_url(self):
        """
        Render link in console
        """

        return self.html_file_display_url

    def _create_html_file(self) -> None:
        """
        Display the PDF debugger interface in a Jupyter notebook cell.

        Parameters:
        -----------
        image_dir : str
            Directory containing the image files (PNG format)
        bbox_json_path : str
            Path to the JSON file containing bounding box data
        output_path : str, optional
            Path to save the HTML file for external viewing

        Returns:
        --------
        IPython.display.HTML
            HTML display object for rendering in the notebook
        """

        self.output_html_url = f"{self.output_dir}/dashboard_{self.source_file.id}.html"
        self.html_file_display_url = c3().File.make(self.output_html_url).apiEndpoint("get", True)

        js_string = JS_SCRIPT_STRING.replace("{BBOX_DATA}", json.dumps(self.display_json, default=vars))
        js_string = js_string.replace("{IMAGE_DATA}", json.dumps(self.image_obj_list, default=vars))
        js_string = js_string.replace("{DOCUMENT_INFO}", json.dumps(self.doc_info_json, default=vars))
        js_string = js_string.replace("{DISPLAY_URL_PREFIX}", self.display_url_prefix)
        js_string = js_string.replace("{DEBUGGER}", "c3")

        output_html = HTML_CONTENT_STRING.replace("{JS_SCRIPT}", js_string)

        buffer = StringIO()
        buffer.write(output_html)
        buffer.seek(0)
        c3().FileSystem.uploadFile(srcFile=buffer, dstPath=self.output_html_url)
        buffer.close()

    def _save_img_with_bbox(self) -> None:
        """
        Save images of each page with bounding boxes overlay.
        """

        import matplotlib.pyplot as plt
        import seaborn as sns
        from matplotlib.patches import Patch, Rectangle

        sns.set_theme()

        palette = sns.color_palette("husl", 8)

        color_map = {
            "PLAIN": palette[0],
            "Text": palette[0],
            "HEADER": palette[1],
            "Header": palette[1],
            "LIST": palette[3],
            "List-item": palette[3],
            "FIGURE": palette[5],
            "Figure": palette[5],
            "Picture": palette[5],
            "Formula": palette[5],
            "TABLE": palette[6],
            "Table": palette[6],
            "CAPTION": palette[7],
            "Caption": palette[7],
            "IDK": "gray",
            "Page-footer": "gray",
            "Page-header": "gray",
        }

        def _save_page_img(bboxes_on_page, img) -> None:
            img_dpi = 250  # DO NOT CHANGE
            img_height, img_width, _ = np.shape(img)

            # Create figure with exact size. DO NOT CHANGE.
            fig = plt.figure(figsize=(img_width / 100, img_height / 100), dpi=img_dpi)

            # Add axis that takes up entire figure. DO NO CHANGE.
            ax = fig.add_axes((0, 0, 1, 1))
            ax.imshow(img)

            seen_klass = set()

            for bbox in bboxes_on_page:
                x0, y0, x1, y1 = bbox["scaled_x_1"], bbox["scaled_y_1"], bbox["scaled_x_2"], bbox["scaled_y_2"]

                curr_class = bbox[self.box_class_to_overlay]
                if curr_class not in color_map:
                    color_map[curr_class] = "gray"

                color = color_map[curr_class]
                seen_klass.add(curr_class)
                rect = Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color, lw=3, alpha=0.7)
                ax.add_patch(rect)
                ax.text(
                    x0,
                    y0,
                    str(np.round(float(bbox["score"]), 3)),
                    color=color,
                    fontsize=16,
                )

            plt.axis("off")
            plt.legend(
                handles=[Patch(facecolor=color_map[klass], label=klass) for klass in seen_klass],
                prop={"size": 12},
            )

            img_buffer = BytesIO()
            plt.savefig(img_buffer, format="png", dpi=img_dpi, pad_inches=0)
            plt.close(fig)

            img_buffer.seek(0)
            img_data = base64.b64encode(img_buffer.read()).decode()
            self.image_obj_list.append(f"data:image/png;base64,{img_data}")

        bboxes_by_page = defaultdict(list)

        for curr_box in self.components_json:
            bboxes_by_page[curr_box["page"]].append(curr_box)  # idx starts from 0

        all_images = []

        f = c3().FileSystem.openFile(self.original_file_url)
        buffer = BytesIO(f.read())
        buffer.seek(0)

        with pdfplumber.open(buffer) as pdf:
            for page in pdf.pages:
                im = page.to_image(resolution=self.dpi).original
                all_images.append(im)

        for page_num, img in enumerate(all_images):
            bboxes_on_page = bboxes_by_page.get(page_num, [])
            _save_page_img(bboxes_on_page, img)
