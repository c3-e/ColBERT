# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
import os
import re
from typing import Any, Callable, List

import pandas as pd

c3: Any = None
"""
The c3 global object, injected by the C3 AI platform.
"""

warn_experimental: bool = True
"""
Whether to warn about experimental features.
"""

pd.options.future.infer_string = True
"""
Whether to infer the dtype of string columns.
"""

debug_mode: bool = False
"""
Whether to enable debug mode.
"""

_API_NOT_SET = "you_did_not_set_api_key_or_endpoint_please_see_tutorial_for_details"

api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("AZURE_OPENAI_API_KEY") or _API_NOT_SET
"""
The OpenAI API key.
"""

endpoint = os.environ.get("OPENAI_ENDPOINT") or os.environ.get("AZURE_OPENAI_ENDPOINT") or _API_NOT_SET
"""
The OpenAI API endpoint.
"""

blacklist_rules: List[re.Pattern | str] = []
"""
Whether to enable auto-tuning rules.
"""

c3_json_data_debug: Callable[[logging.LogRecord], Any] | None = None
"""
Whether to enable debug mode for JSON data.
"""

allow_none_in_gf: bool = False
"""
Whether to allow none-in graphframes.
"""

stack_trace_renderer: dict | None = {}
"""
Stack trace renderer settings.
"""

KEYS = tuple(
    [
        "c3",
        "warn_experimental",
        "debug_mode",
        "api_key",
        "endpoint",
        "blacklist_rules",
        "c3_json_data_debug",
        "allow_none_in_gf",
        "stack_trace_renderer",
    ]
)
