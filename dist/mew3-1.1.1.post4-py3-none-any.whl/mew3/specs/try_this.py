# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from functools import cached_property
from typing import TYPE_CHECKING, Callable, List, Sequence

from .signature import CompatibleKindAndKwargs, KindAndKwargs, signature_parse

if TYPE_CHECKING:
    pass


@dc.dataclass(frozen=True)
class TryStep:
    """
    A step in the try_this_then_that process.

    Attributes:
        cropper: The cropper to use.
        fail: The function to call to check if the result is valid.
    """

    kind: str
    """
    The kind passed into the `signature_parse` function.
    """

    kwargs: dict = dc.field(default_factory=dict)
    """
    The kwargs sent into the `signature_parse` function.
    """

    mark_fail: Callable[..., bool] = lambda _: False
    """
    Mark the step as failing if the function returns True.
    If it's true, the next step is tried.
    """

    @property
    def config(self) -> KindAndKwargs:
        """
        The config for the step.

        Returns:
            The config for the step.
        """

        result = signature_parse(self.kind)

        return KindAndKwargs(
            kind=result.kind,
            kwargs={**result.kwargs, **self.kwargs},
        )


def try_this_then_that(*, klass_type: type, steps: Sequence[TryStep], class_name: str, func_name: str):
    """
    Try the first thing, then the second thing, and so on, until one of them works.


    Args:
        klass_type:
            The class type to subclass from. Must have a `__registry__` attribute.
        steps:
            The steps to take. The first argument would be the item to use,
            that would go into `signature_parse` to get the kind and kwargs,
            and look up on the `klass_type`'s `factory` method.
        class_name: The class name to register.
        func_name: The function name to override.

    Raises:
        ValueError: If it doesn't work.

    Returns:
        _description_
    """

    # Get the spec class from the class type.
    spec_type = klass_type.__registry__.spec_cls

    default_configs = [step.config.dict() for step in steps]
    default_mark_fails = [step.mark_fail for step in steps]

    @dc.dataclass
    class FallbackSpec(spec_type):
        items: List[CompatibleKindAndKwargs] = dc.field(default_factory=lambda: default_configs)
        mark_fails: List[Callable[[str], bool]] = dc.field(default_factory=lambda: default_mark_fails)

        def __post_init__(self):
            if len(self.items) != len(self.mark_fails):
                raise ValueError("The number of croppers and fails must be the same.")

        @cached_property
        def item_instances(self):
            result = []
            for item in self.items:
                parsed_signatures = signature_parse(item)
                result.append(klass_type.factory(parsed_signatures.kind, **parsed_signatures.kwargs))
            return result

    class Fallback(klass_type, spec_class=FallbackSpec, class_name=class_name):
        def children(self):
            # Return the children of the spec class.
            yield from self.spec.item_instances

    def compute_with_fallback(self, *args, **kwargs):
        # Try the items one by one.
        for idx, instance in enumerate(self.spec.item_instances):
            method = getattr(instance, func_name, None)

            if method is None:
                raise ValueError(f"{func_name} is not a method of {instance}")

            result = method(*args, **kwargs)

            if not self.spec.mark_fails[idx](result):
                return result

        raise ValueError("Everything failed.")

    compute_with_fallback.__name__ = func_name

    setattr(Fallback, func_name, compute_with_fallback)
    Fallback.__abstractmethods__ = frozenset(elem for elem in Fallback.__abstractmethods__ if elem != func_name)

    return FallbackSpec, Fallback
