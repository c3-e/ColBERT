# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
import logging
import re
from abc import ABC, abstractmethod
from functools import cached_property, lru_cache
from io import StringIO
from types import FunctionType
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Container,
    Dict,
    Iterator,
    List,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    final,
    no_type_check,
)

from rich import print
from typing_extensions import Self

from mew3 import settings
from mew3.specs import Spec, factorize

from .delta import Delta
from .explainer import LayoutModuleException, LayoutModuleExplainer, LayoutModuleRenderer, LayoutModuleStack

if TYPE_CHECKING:
    from mew3.core.doc_bboxes import DocBboxes
    from mew3.document import Content, PageDoc

I = TypeVar("I", bound="DocBboxes", contravariant=True)
O = TypeVar("O", bound="DocBboxes", covariant=True)
S = TypeVar("S", bound=Spec, contravariant=True)
D = TypeVar("D", "Content", "PageDoc")
V = TypeVar("V", covariant=True)


_LOG = logging.getLogger(__name__)
_LOG.setLevel(logging.WARNING)


class DeltaSpecMixin:
    def delta_columns(self) -> Tuple[str, ...] | Delta:
        """
        Returns the column changes for the `DocBboxes` object,
        once processed.

        This should return a tuple of strings, with the rules as follows:

        1. If a column is added, the column name should be prefixed with `+` ("+a" means addig a column "a", and "a" must not be present before).
        2. If a column is removed, the column name should be prefixed with `-` ("-b" means removing a column "b", and "b" must be present before).
        3. If a column is required, the column name should be present here ("c" means column "c" must be present, and possibly modified).

        If nothing is given (returns an empty tuple), it means that type checks are disabled.
        """

        return ()


class LayoutModSpec(Spec, ABC):
    pass


def get_stack_trace_renderer():
    if settings.stack_trace_renderer is None:
        return None

    default = {
        "params": True,
        "full": False,
        "class_name": "alias",
        "highlight": "monokai",
        "doc": False,
        "delta": False,
    }

    default.update(settings.stack_trace_renderer)
    return LayoutModuleRenderer(**default)


@factorize(LayoutModSpec)
class LayoutMod(ABC):
    """
    `LayoutModule` is the base class for all layout components,
    it defines and provides a bunch of utility functions for layout components.
    """

    if TYPE_CHECKING:
        from mew3.specs import TreeRegistry

        __registry__: ClassVar[TreeRegistry]
        """
        The registry for the class.
        """

        @abstractmethod
        def __init__(self, *args, **kwargs):
            pass

        @classmethod
        @abstractmethod
        def factory(cls, name: str, **kwargs) -> Self:
            """
            Factory method to create a new instance of the class.

            Args:
                name: The name of the class to create.
                **kwargs:
                    The keyword arguments to pass to the class.
                    Same as subclass's spec class.

            Returns:
                A subclass of `LayoutModule`.
            """

        @property
        @abstractmethod
        def spec(self) -> LayoutModSpec:
            """
            The specification for the class.
            This is a dataclass that defines the parameters for the class.
            """

    @classmethod
    def _get_desc_by_name(cls, name: str) -> List[LayoutMod]:
        path = name.split(".")
        return cls._get_desc_by_path(*path)

    @classmethod
    @lru_cache(maxsize=1024)
    def _get_desc_by_path(cls, *path: str) -> List[LayoutMod]:
        """
        Return the module if the path is either the full path,
        or a post fix of the full path.
        Or else return None.

        Args:
            path: The path to the module.

        Returns:
            The module if found, else None.
        """

        if not path:
            return [cls]

        results = []
        head, *rest = path

        # Find subclass where the head matches the name.
        subc = next((subc for subc in cls.__subclasses__() if subc.__name__ == head), None)

        # Exhausively search for all cases.
        # Implementing this is a little tricky, as this pattern is not commonly seen.
        #
        # This can still be solved with DFS,
        # tho a little tricky because we are searching for a path rather than the full thing.
        #
        # There are 2 ways to solve this:
        # 1. Remember the path, and match postfix at each node.
        # 2. Use fuzzy search, and we can break problems down with simple recursion / DP.
        # Here, I implemented the 2nd way.
        #
        # There are 2 cases in the 2nd way:
        # 1. The path is a full path, in which case, the root of the path should match one of the base classes.
        # 2. The path is a post fix of the full path. In which case, we recursively ask the submodules if they found anything.
        # This should be able to be proven to always be the case,
        # if we compute this in a bottom up fasion (all paths from short to long), so this should be Ok.

        # Recurively find all fuzzy path that consumes the current head.
        if subc is not None:
            found = subc._get_desc_by_path(*rest)
            results.extend(found)

        # Recursively find all fuzzy path that doesn't consume the current head.
        for klass in cls.__subclasses__():
            found = klass._get_desc_by_path(*path)
            results.extend(found)

        return results

    @final
    def __call__(self, item):
        renderer = get_stack_trace_renderer()

        def call_but_catch_exception(item):
            system_exit = False
            assert renderer is not None

            # Ensure that the stack is set for all children.
            # Setting it here s.t. we do not need to modify signature of the children.
            # This is not re-entrant, but I don't care.
            for child in self.children_module():
                child.stack = self.stack

            self.stack.push(self)

            try:
                result = self.forward(item)
            except Exception as e:
                mapping = {cid: "" for cid in self.stack.to_id_set()}
                args = ", ".join(map(repr, e.args))
                klass = "[green]" + e.__class__.__qualname__ + "([/green]" + args + "[green])[/green]"
                mapping[id(self)] = klass

                print(self.stack.root().render(select=mapping, renderer=renderer))
                print(self.stack.render(renderer=renderer))
                print(LayoutModuleException(e).render(renderer=renderer))
                system_exit = True

            # This is s.t. we do not raise exceptions in except blocks.
            if system_exit:
                raise SystemExit

            self.stack.pop()
            return result

        forward = self.forward if renderer is None else call_but_catch_exception

        return forward(item)

    @abstractmethod
    def forward(self, item, /):
        pass

    def _repr_pretty_(self, p, _) -> str:
        sb = StringIO()
        print(self, file=sb)
        p.text(sb.getvalue())

    def __rich__(self, renderer=LayoutModuleRenderer()):
        explainer = LayoutModuleExplainer(self)
        return explainer(renderer=renderer)

    def render(
        self, *, renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer(), select: Container[int] = ()
    ) -> None:
        """
        Returns a human-readable explanation of the module.
        """

        explainer = LayoutModuleExplainer(self)
        return explainer(renderer=renderer, select=select)

    def explain(self, *, renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer()):
        print(self.render(renderer=renderer))

    @classmethod
    def registered(
        cls,
        renderer: LayoutModuleRenderer
        | dict = LayoutModuleRenderer(
            highlight=None, doc=False, class_name="alias", full=False, params=False, delta=False
        ),
    ) -> List[str]:
        """
        Examples:
            >>> Foo.factory.registered()
            ['BAR', 'BAZ']

        Returns:
            A list of available class names registered with the factory method.
        """

        regs = cls.__registry__.sub_regs()

        result: List[str] = []

        for reg in regs:
            assert issubclass(reg.cls, LayoutMod), f"Expected a subclass of LayoutMod, got {reg.cls}"
            result.append(renderer(klass=reg.cls))
        return result

    @classmethod
    def print_registered(cls, renderer: LayoutModuleRenderer | dict = LayoutModuleRenderer()) -> None:
        """
        Print all registered classes.
        """

        reg = cls.registered(renderer)

        for r in reg:
            print(r)
            print()

    def children(self) -> Iterator[LayoutMod | Tuple[str, LayoutMod]]:
        """
        Returns the children of the module.
        """

        return
        yield

    def children_module(self) -> Iterator[LayoutMod]:
        """
        Returns the children of the module.
        """

        for child in self.children():
            if isinstance(child, LayoutMod):
                yield child
            else:
                yield child[1]

    @cached_property
    def stack(self) -> LayoutModuleStack:
        """
        Returns the stack of the module.
        """

        return LayoutModuleStack()


LayoutModule = LayoutMod
LayoutModuleSpec = LayoutModSpec


@dc.dataclass(frozen=True)
class LayoutProcSpec(LayoutModuleSpec, ABC):
    def supports(self) -> List[str | re.Pattern]:
        """
        Describes what this processor supports.

        If given, this is a constraint on the input processor that must match its `type` attribute on the given document.

        Returns a list of strings or regular expressions that this processor supports,
        or `NotImplemented` if it supports everything.

        If a string is provided, it is matched exactly, if a regular expression is provided, it is matched using `re.fullmatch`.
        """

        return NotImplemented

    @abstractmethod
    def input_type(self) -> Type[D]:
        pass


@factorize(LayoutProcSpec)
class LayoutProc(LayoutModule, ABC, spec_class=LayoutProcSpec):
    """
    `LayoutProc` converts `Document` into something else.
    It handles `supports` documents and calls `process` to do the actual work.
    """

    def forward(self, item: D, /) -> DocBboxes:
        from mew3.document import PageDoc

        _LOG.info(f"Processing %s with %s", self.__class__.__name__, item)

        if not isinstance(item, self.spec.input_type()):
            raise TypeError(f"Expected {self.spec.input_type()}, got {type(item)}")

        # Check if the document is supported.
        doc = item if isinstance(item, PageDoc) else item.document
        doc.assert_support(self)

        output = self.process(item)
        return output

    @abstractmethod
    def process(self, item: D, /) -> V:
        pass

    def supports(self) -> List[str | re.Pattern]:
        return self.spec.supports()


LayoutProcessor = LayoutProc
LayoutProcessorSpec = LayoutProcSpec


@dc.dataclass(frozen=True)
class LayoutProdSpec(DeltaSpecMixin, LayoutProcSpec, ABC):
    def input_type(self):
        from mew3.document import PageDoc

        return PageDoc


@no_type_check
@factorize(LayoutProdSpec)
class LayoutProd(LayoutProc, ABC, spec_class=LayoutProdSpec):
    """
    The producer API for layout modules.

    Subclasses should implement the `produce` method,
    which takes in a `Document` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def process(self, document: PageDoc, /) -> DocBboxes:
        _LOG.info(f"Producing %s with %s", self.__class__.__name__, document)

        # Run the static type checks here.
        _ = self.spec.delta_columns()

        output = self.produce(document)
        _check_docbbxs(output, self.__class__, "output")
        return output

    @abstractmethod
    def produce(self, document: PageDoc, /) -> O:
        pass

    @classmethod
    def make(cls, supports: Sequence[str | re.Pattern] = (), delta_columns: Sequence[str] | Delta = ()) -> LayoutProc:
        """
        Convert a function into a `LayoutProc`.
        """

        if not isinstance(delta_columns, (Delta, Sequence)):
            raise ValueError(
                f"delta_columns must be a sequence of strings or a Delta object, not {type(delta_columns)}.\nUsage: @LayoutExec.register(delta_columns=('a', 'b'))"
            )

        def wrapper(func: Callable[[D], V]) -> LayoutProc:
            if not callable(func):
                raise TypeError(f"Expected a callable, got {type(func)}")

            @dc.dataclass(frozen=True)
            class FuncProdSpec(cls.__registry__.spec_cls):
                def input_type(self):
                    from mew3.document import PageDoc

                    return PageDoc

                def supports(self):
                    return supports

                def delta_columns(self):
                    return delta_columns

            class FuncProd(cls, spec_class=FuncProdSpec, class_name=func.__name__.upper()):
                def produce(self, item: D, /) -> V:
                    return func(item)

            FuncProd.__doc__ = func.__doc__
            FuncProd.__qualname__ = func.__qualname__
            return FuncProd()

        return wrapper


LayoutProducer = LayoutProd
LayoutProducerSpec = LayoutProdSpec


@dc.dataclass(frozen=True)
class LayoutExecSpec(DeltaSpecMixin, LayoutModuleSpec):
    pass


_T = TypeVar("_T", bound=Callable[["DocBboxes"], "DocBboxes"])


@factorize(LayoutExecSpec)
class LayoutExec(LayoutModule, ABC, spec_class=LayoutExecSpec):
    """
    The executor API for layout modules.

    Subclasses should implement the `execute` method,
    which takes in a `DocBboxes` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def forward(self, input: DocBboxes, /) -> DocBboxes:
        _LOG.info(f"Executing %s with %s", self.__class__.__name__, input)

        # Run the static type checks here.
        _ = self.spec.delta_columns()

        _check_docbbxs(input, self.__class__, "input")
        output = self.execute(input.clone())
        _check_docbbxs(output, self.__class__, "output")
        return output

    @abstractmethod
    def execute(self, input: DocBboxes, /) -> DocBboxes:
        pass

    @classmethod
    def register(cls, delta_columns: Sequence[str] | Delta = ()) -> Callable[[_T], _T]:
        """
        Register a pure post-processing function (of type types.FunctionType) into the factory.

        Example:
            >>> @LayoutExec.register()
            ... def my_post_proc(output):
            ...     return output

            >>> @LayoutExec.register()
            ... def my_other_post_proc(output):
            ...     return output

            >>> # Note that the function name must be in snake case.
            ... # After register, it would be available in the registry.

            >>> # After registering the post-processing functions, you can use them as follows:
            ... output = LayoutExec.factory("MY_POST_PROC")(output)
            ... output = LayoutExec.factory("MY_OTHER_POST_PROC")(output)
        """

        if not isinstance(delta_columns, (Delta, Sequence)):
            raise ValueError(
                f"delta_columns must be a sequence of strings or a Delta object, not {type(delta_columns)}.\nUsage: @LayoutExec.register(delta_columns=('a', 'b'))"
            )

        def reg_fn(post_proc: _T) -> _T:
            return cls._register(post_proc=post_proc, delta_columns=delta_columns)

        return reg_fn

    @classmethod
    def _register(cls, post_proc: _T, delta_columns: Sequence[str] | Delta = ()) -> _T:
        if not isinstance(post_proc, FunctionType):
            raise ValueError(f"Can only register functions!")

        if not _is_snake_case(func_name := post_proc.__name__):
            raise ValueError(f"Function name must be in snake case!")

        # Only
        if len(inspect.signature(post_proc).parameters) != 1:
            raise ValueError(f"Function must take exactly one argument for it to be an exectuor!")

        # Dynamically create a subclass of LayoutExec.
        # This has the effect of automatially registering the function.
        class _SubType(cls, spec_class=cls.__registry__.spec_cls, class_name=func_name.upper()):
            def execute(self, output):
                return post_proc(output)

            def delta_columns(self):
                return delta_columns

        _SubType.__doc__ = post_proc.__doc__
        _SubType.__qualname__ = post_proc.__qualname__
        _SubType.__signature__ = inspect.Signature()

        return _SubType()


LayoutExecutor = LayoutExec
LayoutExecutorSpec = LayoutExecSpec


def _check_docbbxs(obj, cls: type, tag):
    from mew3.core import DocBboxes

    if not isinstance(obj, DocBboxes):
        raise TypeError(f"{cls.__name__} {tag} must be of type DocBboxes, not {type(obj)}")


_SNAKE_CASE_REGEX = re.compile(r"^[a-z][a-z0-9_]*[a-z0-9]$")


def _is_snake_case(s: str) -> bool:
    return _SNAKE_CASE_REGEX.fullmatch(s) is not None
