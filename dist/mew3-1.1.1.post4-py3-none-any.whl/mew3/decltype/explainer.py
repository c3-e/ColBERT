# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
from functools import cached_property
from io import StringIO
from types import FunctionType
from typing import TYPE_CHECKING, Any, Dict, FrozenSet, List, Literal, Mapping

from pygments.styles import get_all_styles
from rich import print
from rich.align import Align
from rich.console import Group
from rich.panel import Panel
from rich.syntax import Syntax
from rich.traceback import Traceback
from rich.tree import Tree

from mew3 import settings

from .delta import Delta

if TYPE_CHECKING:
    from .api import LayoutMod as LayoutModule


@dc.dataclass
class LayoutModuleRenderer:
    """
    The renderer for the module, which is essentially just a bunch of configs used for rendering the class / instance.
    """

    params: bool = True
    """
    Whether to render the parameters of the class. If False, only the class name will be rendered.
    """

    full: bool = False
    """
    Whether to render the full class with all parameters and their default values. If False, only the class name will be rendered.
    """

    class_name: Literal["alias", "module"] = "alias"
    """
    The type of class name to render. Can be one of "alias", "qualname", "name", or "module".
    """

    highlight: Literal["monokai", None] = "monokai"
    """
    The color scheme to use for highlighting the class name. Can be one of "monokai" or any pygments color scheme.
    """

    doc: bool = True
    """
    Toggle the documentation of the class. If False, the documentation will not be rendered.
    """

    delta: bool = True
    """
    The signature of the module. If False, the signature will not be rendered.
    """

    def _get_alias(self, klass: type) -> str:
        "Get the alias of the class. This is the name of the class in the module."
        if self.class_name == "alias":
            return klass.__registry__.alias
        elif self.class_name == "qualname":
            return klass.__qualname__
        elif self.class_name == "name":
            return klass.__name__
        elif self.class_name == "module":
            return f"{klass.__module__}.{klass.__qualname__}"
        else:
            raise ValueError(f"Invalid class_name: {self.class_name}. Must be one of 'alias', 'qualname', 'name'.")

    def _get_doc(self, klass: type) -> str:
        "Get the documentation of the class. This is the docstring of the class."

        if not klass.__doc__:
            return ""

        docs = [klass.__doc__, ""]

        spec_type = klass.__registry__.spec_cls
        for fields in dc.fields(spec_type):
            if fields.__doc__:
                docs.append(f"{fields.name}: {fields.__doc__}")
        return "\n".join(docs)

    def _get_delta(self, klass: type, values: Dict[str, Any] | None) -> str:
        "Get the signature of the module. This is the signature of the class in the module."

        if not self.delta:
            return ""

        values = values or {}

        delta_columns = klass.__registry__.spec_cls(**values).delta_columns()
        return str(Delta.parse(delta_columns))

    def __call__(self, *, label: str = "", klass: type, dyn_vals: Dict[str, Any] | None = None) -> str:
        """
        The entry point for the renderer. This is the method that will be called to render the class.

        Parameters:
            label: An optional label to prepend to the alias.
            klass: The class to render.
            dyn_vals:
                If present, dynamic values to be used for rendering the class parameters.
                Or else, the class signature will be rendered.
        """

        alias = self._get_alias(klass)

        # Use the optional label for clarity.
        if label:
            alias = f"{label}: {alias}"

        # Render the parameters. Can disable for `registered` where only class names are needed.
        if self.params:
            params = _render_spec_class_body(klass=klass.__registry__.spec_cls, values=dyn_vals or {}, full=self.full)
            result = f"{alias}({params})"
        else:
            result = alias

        # Show signature of the module.
        if self.delta and dyn_vals is not None:
            delta = self._get_delta(klass, values=dyn_vals)
            result = f"{result}\n    Column changes: {delta}\n"

        # Documentation.
        if self.doc and klass.__doc__:
            doc = self._get_doc(klass).rstrip().lstrip("\n")
            result = f"{result}\n{doc}"

        result = result.rstrip().lstrip("\n")

        # Highlighting color
        if self.highlight:
            if self.highlight not in self._pygments_colors:
                raise ValueError(f"Invalid color scheme {self.highlight}. Must be one of {self._pygments_colors}")

            result = Syntax(result, "python", theme=self.highlight, line_numbers=False)

        return result

    @cached_property
    def _pygments_colors(self) -> List[str]:
        return list(get_all_styles())

    @classmethod
    def get(cls, renderer: LayoutModuleRenderer | Dict[str, Any], /) -> LayoutModuleRenderer:
        """
        Converts a renderer to a LayoutModuleRenderer.

        Parameters:
            renderer: The renderer to convert. Can be a LayoutModuleRenderer or a dictionary.

        Returns:
            A LayoutModuleRenderer.
        """

        if isinstance(renderer, LayoutModuleRenderer):
            return renderer

        if isinstance(renderer, Mapping):
            return cls(**renderer)

        raise TypeError(f"Expected a dict or LayoutModuleRenderer, got {type(renderer)}")


@dc.dataclass(frozen=True)
class LayoutModuleStack:
    """
    The stack of modules. This is used to keep track of the modules that are currently being rendered.
    """

    stack: List[LayoutModule] = dc.field(default_factory=list)
    """
    The stack of modules. This is used to keep track of the modules that are currently being rendered.
    """

    def __bool__(self):
        """
        This is used to keep the stack alive, even if it's empty.
        """
        return True

    def __len__(self) -> int:
        return len(self.stack)

    def root(self) -> LayoutModule:
        return self.stack[0]

    def top(self) -> LayoutModule:
        return self.stack[-1]

    def push(self, module: LayoutModule) -> None:
        """
        Push a module to the stack.

        Parameters:
            module: The module to push to the stack.
        """

        assert id(module) not in self.to_id_set(), module
        self.stack.append(module)

    def pop(self):
        """
        Drop the last module.
        """

        return self.stack.pop()

    def to_id_set(self) -> FrozenSet[int]:
        """
        Convert the stack to a set of ids.
        This is used to keep track of the modules.

        The reason I use `id` here is because set comparison uses `__hash__` and `__eq__`,
        which might be expensive for large objects,
        and that we would be matching the exact object with `is` anyways.
        """

        return frozenset(id(module) for module in self.stack)

    def render(self, renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer()):
        """
        Returns a human-readable representation of the module.
        """

        renderer = LayoutModuleRenderer.get(renderer)

        TEXT = """
+                      +
    Mew3 Error Stack
+                      +
""".strip()

        group = Group(
            Align.center(Panel.fit(TEXT)),
            *[Panel(renderer(klass=type(module), dyn_vals=dc.asdict(module.spec))) for module in self.stack],
        )
        return Panel(group)

    def _repr_pretty_(self, p, cycle):
        """
        Returns a human-readable representation of the module.
        """

        sb = StringIO()
        print(self, file=sb)
        p.text(sb.getvalue())


@dc.dataclass(frozen=True)
class LayoutModuleException:
    exception: Exception

    def render(self, renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer()):
        """
        Returns a human-readable representation of the module.
        """

        renderer = LayoutModuleRenderer.get(renderer)

        REMAINING = """
+                     +
    Remaining Steps
+                     +
""".strip()

        if settings.debug_mode:
            show_locals = {
                "show_locals": True,
            }
        else:
            show_locals = {}

        return Panel(
            Group(
                Align.center(Panel.fit(REMAINING)),
                Align.center(
                    Traceback.from_exception(
                        type(self.exception),
                        self.exception,
                        self.exception.__traceback__,
                        extra_lines=2,
                        **show_locals,
                        width=144,
                    )
                ),
            )
        )


@dc.dataclass(frozen=True)
class LayoutModuleExplainer:
    """
    A class to explain the module in a human-readable format.
    This class is used to render the module and its children in a tree format.
    It uses the `LayoutModuleRenderer` to render the module and its children.
    """

    module: LayoutModule
    """
    The module to explain. This is the module that will be rendered in a tree format.
    """

    def __call__(
        self,
        *,
        renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer(),
        select: Mapping[int, str] = (),
    ) -> None:
        """
        Returns a human-readable explanation of the module.

        Parameters:
            renderer: The renderer to use for the module. If a dictionary is provided, it will be converted to a LayoutModuleRenderer.
            select: A mapping of indices to select specific children of the module. If empty, all children will be selected.
        """

        renderer = LayoutModuleRenderer.get(renderer)
        TEXT = """
+                        +
    Mew3 Planning Tree
+                        +
""".strip()
        return Panel(Group(Align.center(Panel.fit(TEXT)), self._explain_tree(renderer=renderer, select=select)))

    def _explain_tree(self, *, label: str = "", renderer: LayoutModuleRenderer, select: Mapping[int, str]) -> Tree:
        rendered = renderer(klass=type(self.module), dyn_vals=dc.asdict(self.module.spec), label=label)

        # Highlight the tree if it's in selected.
        if id(self.module) in select:
            rendered = Panel(title=select[id(self.module)], renderable=rendered, border_style="bold red")

        tree = Tree(rendered)
        for child in self.module.children():
            try:
                label, child = child
            except (ValueError, TypeError):
                label = ""

            child_explained = type(self)(child)._explain_tree(label=label, renderer=renderer, select=select)
            tree.add(child_explained)
        return tree


def _render_spec_class_body(*, klass: type, values: Dict[str, Any], full: bool) -> str | Syntax:
    from mew3.specs import Spec

    if not dc.is_dataclass(klass):
        raise TypeError(f"Expected a dataclass, got {klass}")

    if not issubclass(klass, Spec):
        raise TypeError(f"Expected a subclass of Spec, got {klass}")

    args: List[str] = []

    for field in dc.fields(klass):
        field_name = field.name
        type_name = _get_type_name(field.type)

        # No values give, rendering the class template.
        if not values:
            if field.default is dc.MISSING:
                rendered = f"{field_name}: {type_name}"
            else:
                rhs_repr = str(field.default) if full else _no_expand_nest(field.default)

                rendered = f"{field_name}: {type_name} = {field.default}"
        # Values given, rendering the class with values
        else:
            rhs = values[field_name] if field_name in values else field.default

            if rhs is dc.MISSING:
                raise ValueError(f"Missing value for field {field_name}")

            rhs_repr = str(rhs) if full else _no_expand_nest(rhs)

            rendered = f"{field_name}: {type_name} = {rhs_repr}"
        args.append(rendered)

    return ", ".join(args)


def _get_type_name(klass) -> str:
    if isinstance(klass, type):
        return klass.__name__

    if isinstance(klass, str):
        return klass

    return str(klass)


def _no_expand_nest(data):
    if isinstance(data, dict):
        return "{...}"

    if isinstance(data, (list, tuple)):
        return "[...]"

    if isinstance(data, type):
        return data.__qualname__

    if isinstance(data, FunctionType):
        return data.__name__ + str(inspect.signature(data))

    return repr(data)
