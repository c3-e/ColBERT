# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import logging
from typing import Any, Callable, List, Protocol, Sequence, TypeVar, runtime_checkable

from mew3.specs import Spec

AUTO = "AUTO"
T = TypeVar("T")
LOG = logging.getLogger(__name__)


@runtime_checkable
class CfgRewrite(Protocol):
    def __call__(self, spec: Spec, val: Any) -> Any:
        """
        Rewriter function to transform the configuration.
        """


@runtime_checkable
class CfgValid(Protocol):
    def __call__(self, spec: Spec, val: Any) -> bool:
        """
        Validator function to check the validity of the configuration.
        """

        return True


@dc.dataclass(frozen=True)
class PostRule:
    """
    `PostRule` class for applying transformations to dataclass instances,
    it applies the rules after the wrapped function is executed.
    """

    key_path: str | Sequence[str]
    """
    The key path to the field in the dataclass to be transformed.

    Since Rule works on mappings, the key path can be a list of keys or a string with dot notation.
    """

    rewrite: CfgRewrite
    """
    The rewriter function to apply to the field.

    The rewriter function should take the dataclass instance and the value of the field as arguments.
    It should return the transformed value.
    """

    enable: CfgValid = lambda spec, cfg: True
    """
    Whether or not to enable the rule, based on the conifg.
    By default, all rules are enabled.
    """

    def apply_(self, spec: T) -> T:
        """
        Rewrite the spec in-place.

        Args:
            spec: The spec to rewrite. Must define getitem and setitem.

        Raises:
            TypeError: If the spec does not define getitem and setitem.
        """
        if not hasattr(spec, "__getitem__"):
            raise TypeError(f"Expected spec to have __getitem__, got {type(spec)}")

        if not hasattr(spec, "__setitem__"):
            raise TypeError(f"Expected spec to have __setitem__, got {type(spec)}")

        LOG.debug(f"Applying rule to %s", spec)
        key_path = list(self.key_path) if not isinstance(self.key_path, str) else self.key_path.split(".")

        LOG.debug(f"Key path: %s", key_path)

        # Do nothing if the key path is not used.
        try:
            cfg = self._get_cfg(spec, key_path)
        except KeyError:
            LOG.info(f"Key path %s not found in spec %s. Ignore", key_path, spec)
            return spec

        enabled = self.enable(spec, cfg)
        LOG.debug(f"Rule: %s enabled: %s", self, enabled)

        if not enabled:
            return spec

        cfg = self.rewrite(spec, cfg)
        LOG.debug(f"Rewritten cfg: %s", cfg)

        cfg = self._set_cfg(spec, key_path, cfg)
        LOG.debug(f"Set cfg: %s", cfg)

    def __call__(self, spec_cls: Callable):
        """
        Since `PostRule` is a decorator, we need to define the `__call__` method.

        Args:
            spec_cls: The spec class to apply the rule to.
        """

        rself = self

        def wrapper(*args, **kwargs):
            spec = spec_cls(*args, **kwargs)
            LOG.debug(f"Applying rule to %s", spec)
            rself.apply_(spec)
            return spec

        wrapper.__name__ = spec_cls.__name__
        wrapper.__qualname__ = f"PostRule<{spec_cls.__name__}>"
        wrapper.__doc__ = spec_cls.__doc__
        wrapper.__annotations__ = spec_cls.__annotations__
        return wrapper

    @classmethod
    def _get_cfg(cls, item, key_path: List[str]):
        """
        Get the configuration from the spec.
        """

        if not len(key_path):
            return item

        if not hasattr(item, "__getitem__"):
            raise TypeError(f"Expected item to have __getitem__, got {type(item)}")

        head, *rest = key_path

        item = item[head]

        return cls._get_cfg(item, rest)

    @classmethod
    def _set_cfg(cls, item, key_path: List[str], value):
        """
        Set the configuration in the spec, in-place.
        """
        if not hasattr(item, "__setitem__"):
            raise TypeError(f"Expected item to have __setitem__, got {type(item)}")

        head, *rest = key_path
        if not len(rest):
            item[head] = value
            return type(item)(**item)

        overwritten = cls._set_cfg(item[head], key_path=rest, value=value)
        item[head] = overwritten
        return type(item)(**item)


if __name__ == "__main__":

    @dc.dataclass
    class SpecExample(Spec):
        a: int
        b: int
        c: int

    # Example usage
    @PostRule(key_path="a", rewrite=lambda spec, cfg: cfg + 1)
    @PostRule(key_path="c", rewrite=lambda spec, cfg: spec.b << 2)
    def example_func(spec: SpecExample):
        return spec

    se = SpecExample(a=1, b=2, c=3)
    print(example_func(se))
