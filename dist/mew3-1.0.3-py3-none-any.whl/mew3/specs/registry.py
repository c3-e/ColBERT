# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import Callable, Generic, Iterator, Type, TypeVar, runtime_checkable

from typing_extensions import Protocol, Self

_T = TypeVar("_T")


def _identity(x):
    return x


@runtime_checkable
class HasRegistry(Protocol):
    __registry__: TreeRegistry


@dc.dataclass(frozen=True)
class TreeRegistry(Generic[_T]):
    """
    A registry for classes that form a tree structure.

    A `__registry__` attribute would be set on the class (`TreeRegistry.cls`) during `__init_subclass__`.
    """

    cls: Type[_T]
    """
    The class that this registry is for.
    """

    spec_cls: Type
    """
    The specification class for the class.
    """

    alias: str
    """
    The alias for the class.
    """

    def query(self, name: str, /) -> Type:
        """
        Query the registry for a class by name.

        Args:
            name: The name of the class to query.

        Returns:
            The class corresponding to the name.
        """

        for reg in self.sub_regs():
            if reg.alias == name:
                return reg.cls

        aliases = list(self.sub_aliases())
        raise KeyError(f"Could not find class with name {name}. Registered aliases: {aliases}")

    def sub_aliases(self, preorder: bool = True, include_self: bool = False) -> Iterator[str]:
        """
        Yield all subclasses' aliases of the `cls` in the registry.
        """

        return self.sub_regs(preorder=preorder, callback=lambda reg: reg.alias, include_self=include_self)

    def sub_clses(self, preorder: bool = True, include_self: bool = False) -> Iterator[Type]:
        """
        Yield all subclasses of the `cls` in the registry.

        Args:
            preorder: Whether to yield the registry before or after its subclasses.

        Yields:
            The `cls` and all its subclasses.
        """

        return self.sub_regs(preorder=preorder, callback=lambda reg: reg.cls, include_self=include_self)

    def sub_regs(
        self, preorder: bool = True, callback: Callable[[TreeRegistry], _T] = _identity, include_self: bool = False
    ) -> Iterator[_T]:
        """
        Yield all subclasses' registries of the `cls` in the registry.

        Args:
            preorder: Whether to yield the registry before or after its subclasses.

        Yields:
            The registry of the `cls` and all its subclasses' registries.
        """

        if not callable(callback):
            raise TypeError(f"{callback} is not callable")

        if include_self:
            yield callback(self)

        for reg in self._sub_regs(visited=set(), preorder=preorder):
            yield callback(reg)

    def _sub_regs(self, *, visited: set, preorder: bool = True) -> Iterator[Self]:
        for subclass in self.cls.__subclasses__():
            visited.add(subclass)
            yield subclass.__registry__

            if not isinstance(subclass, HasRegistry):
                raise TypeError(
                    f"{subclass} does not contain a `__registry__` attribute. "
                    "This is impossible unless someone removed it manually because `__init_subclass__` should have added it."
                )

            sub_reg = subclass.__registry__

            if not isinstance(sub_reg, TreeRegistry):
                raise TypeError(f"{sub_reg} is not a TreeRegistry")

            sub_reg.validate()

            yield from sub_reg._sub_regs(visited=visited, preorder=preorder)

    def validate(self):
        if not isinstance(self.cls, type):
            raise TypeError(f"{self.cls} is not a class")

        if not callable(self.spec_cls):
            raise TypeError(f"{self.spec_cls} is not callable")

        if not isinstance(self.alias, str):
            raise TypeError(f"{self.alias} is not a string")

    def parents(self):
        """
        Get the parents of the class.

        Returns:
            A list of parent classes.
        """

        return [*self._parents()]

    def _parents(self):
        for base in self.cls.__bases__:
            yield base.__registry__

    def children(self):
        """
        Get the children of the class.

        Returns:
            A list of child classes.
        """

        return [*self._children()]

    def _children(self):
        for subclass in self.cls.__subclasses__():
            yield subclass.__registry__
