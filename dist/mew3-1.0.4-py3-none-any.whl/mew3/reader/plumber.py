# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING, List

from mew3.providers import pdfplumber_file, pdfplumber_read_pdf

from .api import CropWithBbox, GridGen, GridGenSpec, PageCnt, PageCntSpec

if TYPE_CHECKING:
    from mew3.document import Content, PageDoc


@dc.dataclass(frozen=True)
class PlumberPageSpec(PageCntSpec):
    def supports(self):
        return ["pdf"]


class PlumberPage(PageCnt, spec_class=PlumberPageSpec, class_name="PLUMBER"):
    def page_count(self, doc: PageDoc):
        file = pdfplumber_file(doc.fname)
        return len(file.pages)


@dc.dataclass(frozen=True)
class PlumberGridSpec(GridGenSpec):
    def supports(self):
        return ["pdf"]


class PlumberGrid(GridGen, spec_class=PlumberGridSpec, class_name="PLUMBER"):
    def gen_grid(self, content: Content) -> List[CropWithBbox[str]]:
        from mew3.core import BoundingBox

        pdf_plumber_dict = pdfplumber_read_pdf(
            file=content.document.fname,
            page=content.page,
            callback=lambda page: page.extract_words(),
        )

        return [
            CropWithBbox(
                bbox=BoundingBox(d["x0"], d["top"], d["x1"], d["bottom"]),
                data=d["text"],
            )
            for d in pdf_plumber_dict
        ]
