# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, TypeVar

from mew3.decltype import LayoutProc, LayoutProcSpec
from mew3.specs import factorize

if TYPE_CHECKING:
    from mew3 import BoundingBox, Content, LayoutProc, PageDoc

T = TypeVar("T")


@dc.dataclass(frozen=True)
class CropWithBbox:
    bbox: BoundingBox
    data: T


@dc.dataclass(frozen=True)
class GridGenSpec(LayoutProcSpec, ABC):
    def input_type(self):
        from mew3.document import Content

        return Content


@factorize(GridGenSpec)
class GridGen(LayoutProc, spec_class=GridGenSpec):
    def process(self, content: Content, /) -> List[CropWithBbox[T]]:
        return self.gen_grid(content)

    @abstractmethod
    def gen_grid(self, content: Content, /) -> List[CropWithBbox[T]]:
        """
        Generate some grids from the content, as reference.
        """

        raise NotImplementedError


@dc.dataclass(frozen=True)
class PageCntSpec(LayoutProcSpec, ABC):
    def input_type(self):
        from mew3.document import PageDoc

        return PageDoc


@factorize(PageCntSpec)
class PageCnt(LayoutProc, spec_class=PageCntSpec):
    def process(self, document: PageDoc, /) -> int:
        return self.page_count(document)

    @abstractmethod
    def page_count(self, document: PageDoc, /) -> int:
        """
        Generate some grids from the content, as reference.
        """

        raise NotImplementedError
