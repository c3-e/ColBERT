# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING

from .api import GridGen, GridGenSpec, PageCnt, PageCntSpec

if TYPE_CHECKING:
    from mew3.document import PageDoc


@dc.dataclass(frozen=True)
class NullPageSpec(PageCntSpec):
    pass


class NullPage(PageCnt, spec_class=NullPageSpec, class_name="NULL"):
    def page_count(self, doc: PageDoc):
        return 1


@dc.dataclass(frozen=True)
class NullGridGenSpec(GridGenSpec):
    pass


class NullGridGen(GridGen, spec_class=NullGridGenSpec, class_name="NULL"):
    def gen_grid(self, doc: PageDoc):
        return []
