# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import json
import logging
from dataclasses import asdict, dataclass, field
from functools import cached_property
from typing import Any, Dict, List, Optional

import numpy as np

from mew3.core import DocBboxes
from mew3.ctx import c3_not_set
from mew3.decltype import ExecPipe
from mew3.document import PageDoc
from mew3.providers import C3GenaiCoreLLM, OpenaiProvider, vlm

LOGGER = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class VLMParserCfg:
    model: str = "gpt-4o"
    """
    Must be provided to GenaiCore LLM
    """

    max_tokens: int = 4096
    """
    Max input + output tokens for LLM
    """

    system_prompt: str = """
    You are an OCR engine and a verbalizer.
    """

    page_verbalization_prompt: str = """
    Extract the page content in an OCR format.

    The output is a list of JSON, where each item represents a component on the page. The type of component could only be either text, image, or table.
    The order of these output components should be in the natural reading order of the page.
    The document could be multi-column or have complicated structures, hand-written annotations, etc, so be careful.
    A document may not have all three types of components. Only output the components that exist in the document.

    Each component in the output JSON should strictly have the following format and fields. The dict values here are your guidelines. `parser` fields are hardocded strings.

    if text:
    {
        "parser": "TEXT",
        "text": extracted text in OCR style.
        "header": (nested) sections of the text passage. E.g., 'Section A/Section A.1/Section A.1.1'
    }

    if image:
    {
        "parser": "IMAGE",
        "verbalization": provide a brief description of its contents. Include important details, keywords, values, etc.
        "caption": (if exists; otherwise use empty string) caption of the image. Extract in OCR style.
    }

    if table:
    {
        "parser": "TABLE",
        "verbalization": provide a brief description of its contents. Include important details, keywords, values, etc.
        "title": (if exists; otherwise use empty string) title/caption of the table. Extract in OCR style.
        "header": table header (typically the top row. output if exists; otherwise use empty string). Extract in OCR style.
    }

    Your output should only be a pytho list of JSON with the above three types of components. DO NOT add any explanation.
    """

    dpi: int = 150
    """
    DPI for the converted pdf -> image
    """


@dc.dataclass(frozen=True)
class TextChunkerCfg:
    chunk_typ: str = "LONG_CHAIN"
    """
    The type of text chunker to use. Default to using the long chain chunker.
    """

    chunker_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "column_to_chunk": "text",
            "split_length": 20,
        }
    )
    """
    The keyword arguments for the text chunker. See individual text chunker classes for details.
    """


def text_chunker_pipeline(cfg: TextChunkerCfg, /):
    """
    Text parser pipeline. Use for chunking only.
    """

    from mew3.component import TextChunker

    return ExecPipe(
        execs=[
            TextChunker.factory(cfg.chunk_typ, **cfg.chunker_kwargs),
        ]
    )


@dc.dataclass(frozen=True)
class TableChunkerCfg:
    chunk_typ: str = "LONG_CHAIN"
    """
    The type of text chunker to use. Default to using the long chain chunker.
    """

    chunker_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "column_to_chunk": "verbalization",
            "split_length": 20,
        }
    )
    """
    The keyword arguments for the text chunker. See individual text chunker classes for details.
    """


def table_chunker_pipeline(cfg: TableChunkerCfg, /):
    """
    Text parser pipeline. Use for chunking only.
    """

    from mew3.component import TextChunker

    return ExecPipe(
        execs=[
            TextChunker.factory(cfg.chunk_typ, **cfg.chunker_kwargs),
        ]
    )


@dataclass(frozen=False)
class VLMParser:
    """
    This is an LLM parser that does OCR and verbalization.
    """

    vlm_parser_spec: Dict[str, Any] = field(default_factory=dict)
    text_parser_spec: Dict[str, Any] = field(default_factory=dict)
    table_parser_spec: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.actual_vlm_cfg = VLMParserCfg(**self.vlm_parser_spec)
        self.actual_text_cfg = TextChunkerCfg(**self.text_parser_spec)
        self.actual_table_cfg = TableChunkerCfg(**self.table_parser_spec)
        self.text_chunker = text_chunker_pipeline(self.actual_text_cfg)
        self.table_chunker = table_chunker_pipeline(self.actual_table_cfg)
        self.list_components = []

    def __call__(self, document: PageDoc) -> Optional[dict]:
        """
        Parse document with LLM!
        """

        page_list = self._prepare_document(document)

        for curr_page in page_list:
            curr_llm_output = self.vlm(
                self.actual_vlm_cfg.page_verbalization_prompt,
                curr_page["image"],
            )

            try:
                llm_output_components = json.loads(curr_llm_output)
            except Exception as e:
                LOGGER.error(f"Error parsing LLM output: {e}")
                llm_output_components = []

            page_components = self._parse_llm_output(document, llm_output_components, curr_page)

            if page_components:
                self.list_components.extend(page_components)

        self.list_components = self._clean_list_components(self.list_components)

        document_info = {
            "file_info": {
                "filename": document.filename,
                "fname": document.fname,
                "filetype": document.type,
                "dpi": self.actual_vlm_cfg.dpi,
            },
            "full_specs": self.cfg_to_dict(),
        }

        return {
            "document_info": document_info,
            "list_components": self.list_components,
        }

    def _prepare_document(self, document: PageDoc) -> List[Dict]:
        """
        Convert the document (pdf) to a list of json pages using pdfplumber.
        """

        page_info_list = []

        for idx, page in enumerate(document.pages):
            img = page.crop_image()
            np_image = np.array(img)

            page_dict = {
                "page": idx,
                "image": np_image,  # Now an ndarray instead of base64
                "width": img.width,  # pixels
                "height": img.height,  # pixels
            }

            page_info_list.append(page_dict)

        return page_info_list

    def _append_page_data(self, list_of_dict: List[Dict[str, Any]], page_data: Dict[str, Any]):
        list_of_dict = [
            {
                "page": page_data["page"],
                "image": page_data["image"],
                "x_1": 0,  # use 0 to handle the BBox creation in doChunkFile. Remove later.
                "y_1": 0,
                "x_2": 0,
                "y_2": 0,
                "doc_width_px": page_data["width"],
                "doc_height_px": page_data["height"],
                **item,
            }
            for item in list_of_dict
        ]

        return list_of_dict

    def _parse_llm_output(
        self, document: PageDoc, llm_output_compo: List[dict], curr_page: dict
    ) -> List[Dict[str, Any]]:
        """
        Parse LLM output into components.
        """

        text_compo = []
        image_compo = []
        table_compo = []
        for idx, comp in enumerate(llm_output_compo):
            if not isinstance(comp, dict) or "parser" not in comp:
                continue

            if comp.get("parser") == "TEXT":
                text_compo.append(
                    {
                        "parser": "TEXT",
                        "markdown_class": "PLAIN",
                        "score": 1.0,
                        "text": comp.get("text", ""),
                        "header": comp.get("header", ""),
                        "global_idx": curr_page["page"] + idx,
                    }
                )
            elif comp.get("parser") == "IMAGE":
                image_compo.append(
                    {
                        "parser": "IMAGE",
                        "markdown_class": "FIGURE",
                        "score": 1.0,
                        "verbalization": comp.get("verbalization", ""),
                        "caption": comp.get("caption", ""),
                        "global_idx": curr_page["page"] + idx,
                    }
                )
            elif comp.get("parser") == "TABLE":
                table_compo.append(
                    {
                        "parser": "TABLE",
                        "markdown_class": "TABLE",
                        "score": 1.0,
                        "verbalization": comp.get("verbalization", ""),
                        "title": comp.get("title", ""),
                        "header": comp.get("header", ""),
                        "global_idx": curr_page["page"] + idx,
                    }
                )

        # format to be consistent with mew3 formatting
        page_components = []

        if text_compo:
            text_compo = self._append_page_data(text_compo, curr_page)
            text_bboxes = DocBboxes.from_records(text_compo, document)
            text_compo_processed = self.text_chunker(text_bboxes)
            page_components.extend(text_compo_processed.to_records(with_ids=True))

        if image_compo:
            image_compo = self._append_page_data(image_compo, curr_page)
            image_bboxes = DocBboxes.from_records(image_compo, document)
            image_compo_processed = image_bboxes  # no chunking for image verbal by default
            page_components.extend(image_compo_processed.to_records(with_ids=True))

        if table_compo:
            table_compo = self._append_page_data(table_compo, curr_page)
            table_bboxes = DocBboxes.from_records(table_compo, document)
            table_compo_processed = self.table_chunker(table_bboxes)
            page_components.extend(table_compo_processed.to_records(with_ids=True))

        return page_components

    def _clean_list_components(self, list_compo: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Make output compatible with doChunkFilesBatch and Genai.SourcePassage
        """

        for item in list_compo:
            item["text"] = item.get("text", "")
            item["chunked"] = item.get("chunked", [])

            if item["parser"] == "TEXT":
                item["description_for_vectorstore"] = [
                    f"Header: {item['header']}; Text: {piece}" for piece in item["chunked"]
                ]
            elif item["parser"] == "TABLE":
                item["surrounding_text"] = ""
                item["title"] = item.get("title", "")
                item["header"] = item.get("header", "")
                item["verbalization"] = ""
                item["csv"] = ""
                item["csv_url_c3"] = ""
                item["table_image_url_c3"] = ""
                item["description_for_vectorstore"] = [
                    f"Title: {item['title']}; Text: {piece}" for piece in item["chunked"]
                ]

            elif item["parser"] == "IMAGE":
                item["surrounding_text"] = ""
                item["caption"] = item.get("caption", "")
                item["verbalization"] = item.get("verbalization", "")
                item["image_url_c3"] = ""
                item[
                    "description_for_vectorstore"
                ] = f"Caption: {item['caption']}; Verbalization: {item['verbalization']}"

        return list_compo

    @cached_property
    def vlm(self):
        if c3_not_set():
            return vlm(
                OpenaiProvider(
                    max_tokens=self.actual_vlm_cfg.max_tokens,
                    system_prompt=self.actual_vlm_cfg.system_prompt,
                )
            )

        else:
            return vlm(
                C3GenaiCoreLLM(
                    model=self.actual_vlm_cfg.model,
                    max_tokens=self.actual_vlm_cfg.max_tokens,
                    system_prompt=self.actual_vlm_cfg.system_prompt,
                )
            )

    def cfg_to_dict(self):
        return {
            "VLMParserCfg": asdict(self.actual_vlm_cfg),
            "TextChunkerCfg": asdict(self.actual_text_cfg),
            "TableChunkerCfg": asdict(self.actual_table_cfg),
        }

    def to_dict(self):
        return asdict(self)

    def __repr__(self):
        return json.dumps(self.cfg_to_dict(), indent=4)

    def __rich__(self):
        from rich.pretty import Pretty

        return Pretty(self.cfg_to_dict())
