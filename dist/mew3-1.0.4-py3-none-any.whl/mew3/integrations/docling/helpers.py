# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import no_type_check

from mew3.core import DocBboxes
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.layout import LayoutParserOutput
from mew3.providers import OpenaiLikeLLM, OpenaiProvider, vlm


@dc.dataclass(frozen=True)
class DoclingTableVerbalSpec(LayoutExecSpec):
    max_tokens: int = 4096
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a good table verbalizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = """
    Given the JSON representation of the table, 
    come up with a brief descriptions of the table.
    Also give important values and keywords.

    Parsed JSON content:

    "{text}"
    """

    """
    The user prompt to use for the table verbalization.
    """

    def delta_columns(self):
        return (".text", "+verbalization")


class DoclingTableVerbal(LayoutExec, spec_class=DoclingTableVerbalSpec):
    """
    A debug post-processor that plots the bounding boxes on the page.

    Note:
        Only works in Jupyter notebooks, and does nothing if not in a Jupyter notebook.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        all_verbalization = []
        for box in output.to_records():
            curr_verbalization = self.verbalize_box(box)
            all_verbalization.append(curr_verbalization)

        output["verbalization"] = all_verbalization

        return output

    def verbalize_box(self, box: dict):
        prompt = self.spec.user_text_prompt.format(
            text=box["text"],
        )

        return self.llm(prompt)

    @property
    def llm(self):
        return LLM(OpenaiProvider(max_tokens=self.spec.max_tokens, system_prompt=self.spec.system_prompt))


@dc.dataclass(frozen=True)
class DoclingImageVerbalSpec(LayoutExecSpec):
    max_tokens: int = 4096
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a good image verbalizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = """
    Given the image come up with the description along with any important keywords and title.
    """

    """
    The user prompt to use for the image verbalization.
    """

    def delta_columns(self):
        return (".text", "+verbalization")


class DoclingImageVerbal(LayoutExec, spec_class=DoclingImageVerbalSpec):
    """
    A debug post-processor that plots the bounding boxes on the page.

    Note:
        Only works in Jupyter notebooks, and does nothing if not in a Jupyter notebook.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        all_verbalization = []
        for box in output.to_records():
            curr_verbalization = self.verbalize_box(box)
            all_verbalization.append(curr_verbalization)

        output["verbalization"] = all_verbalization

        return output

    def verbalize_box(self, box: dict):
        prompt = self.spec.user_text_prompt
        img = box["image"]
        return self.vlm(prompt, img)

    @property
    def vlm(self):
        return vlm(OpenaiProvider(max_tokens=self.spec.max_tokens, system_prompt=self.spec.system_prompt))


@LayoutExec.register(delta_columns=["text", "+csv"])
def docling_csv_extract(bboxes: DocBboxes) -> DocBboxes:
    """
    Extract the CSV data from the tables.

    """

    records = bboxes.to_records(with_ids=True)

    all_csv = []
    for record in records:
        csv = record["text"]
        all_csv.append(csv)

    bboxes["csv"] = all_csv
    return bboxes


@dc.dataclass(frozen=True)
class LLM:
    provider: OpenaiLikeLLM

    def __call__(self, text: str) -> str:
        messages = [
            {"type": "text", "text": text},
        ]
        return self.provider(messages)
