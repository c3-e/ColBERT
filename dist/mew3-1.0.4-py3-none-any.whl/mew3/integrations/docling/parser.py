# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import base64
import dataclasses as dc
import json
from dataclasses import asdict, dataclass, field
from functools import cached_property
from io import BytesIO
from typing import Any, Dict, Optional, Tuple

import numpy as np
from PIL import Image

from mew3.core import DocBboxes
from mew3.decltype import ExecPipe, Filter, Mark, Rename, Tag
from mew3.document import PageDoc


@dc.dataclass(frozen=True)
class TextParserCfg:
    contextual: Tuple[str, ...] = ("PLAIN",)
    parse: Tuple[str, ...] = ("PLAIN",)
    ext_typ: str = "DEFAULT"
    chunk_typ: str = "LONG_CHAIN"
    ext_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    chunk_kwargs: Dict[str, Any] = dc.field(default_factory=dict)


@dc.dataclass(frozen=True)
class ImageParserCfg:
    contextual: Tuple[str, ...] = ("FIGURE",)
    parse: Tuple[str, ...] = ("FIGURE",)
    verbal_typ: str = "OPENAI"
    verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)


@dc.dataclass(frozen=True)
class TableParserCfg:
    contextual: Tuple[str, ...] = ("TABLE",)
    parse: Tuple[str, ...] = ("TABLE",)
    content_parser_typ: str = "DEFAULT"
    content_parser_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    verbal_typ: str = "OPENAI"
    verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    chunker_typ: str = "LONG_CHAIN"
    chunker_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "column_to_chunk": "verbalization",
            "split_overlap": 100,
        }
    )


def text_parser_pipeline(cfg: TextParserCfg, /):
    from mew3.component import TextChunker

    return ExecPipe(
        execs=[
            Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
            Rename(source="content", target="text"),
            TextChunker.factory(cfg.chunk_typ, **cfg.chunk_kwargs),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            Tag(column="parser", tag="TEXT"),
        ]
    )


def image_parser_pipeline(cfg: ImageParserCfg, /):
    from mew3.component.image import save_image_c3
    from mew3.integrations.docling import DoclingImageVerbal

    return ExecPipe(
        [
            Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
            Mark(
                column="markdown_class",
                target="to_parse",
                function=lambda key: key in cfg.parse,
            ),
            Rename(source="content", target="image"),
            DoclingImageVerbal(**cfg.verbal_kwargs),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            save_image_c3,
            Tag(column="parser", tag="IMAGE"),
        ]
    )


def table_parser_pipeline(cfg: TableParserCfg, /):
    from mew3.component import TextChunker, save_csv_c3
    from mew3.integrations.docling import DoclingTableVerbal, docling_csv_extract

    return ExecPipe(
        [
            Mark(
                column="markdown_class",
                target="to_parse",
                function=lambda key: key in cfg.parse,
            ),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            Rename(source="content", target="text"),
            docling_csv_extract,
            DoclingTableVerbal(**cfg.verbal_kwargs),
            TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            save_csv_c3,
            Tag(column="parser", tag="TABLE"),
        ]
    )


class _DoclingExtractor:
    def __init__(self, json_content):
        self.json_content = json_content
        self.texts = json_content["texts"]
        self.images = json_content["pictures"]
        self.tables = json_content["tables"]
        self.body = json_content["body"]
        self.combined_content = []

    def extract_texts(self):
        """Extract valid text content (non-empty)."""
        text_dict = {}
        for text_ref in self.body["children"]:
            if "$ref" in text_ref and text_ref["$ref"].startswith("#/texts/"):
                index = int(text_ref["$ref"].split("/")[2])  # Extract index of text
                text_item = self.texts[index]
                if text_item["text"].strip():  # Skip empty texts
                    text_dict[text_ref["$ref"]] = text_item["text"].strip()
        return text_dict

    def extract_images(self):
        """Extract picture objects and store them as Pillow images."""
        picture_dict = {}
        for pic_ref in self.body["children"]:
            if "$ref" in pic_ref and pic_ref["$ref"].startswith("#/pictures/"):
                index = int(pic_ref["$ref"].split("/")[2])  # Extract index of picture
                picture_item = self.images[index]
                image_data = picture_item["image"]["uri"]

                # Decode base64 image string
                image_data = image_data.split(",")[1]  # Remove the 'data:image/png;base64,' part
                image_bytes = base64.b64decode(image_data)
                image = np.array(Image.open(BytesIO(image_bytes)))
                picture_dict[pic_ref["$ref"]] = image
        return picture_dict

    def extract_tables(self):
        """Extract table content dynamically for any table size."""
        table_dict = {}
        for table_ref in self.body["children"]:
            if "$ref" in table_ref and table_ref["$ref"].startswith("#/tables/"):
                index = int(table_ref["$ref"].split("/")[2])
                table_item = self.tables[index]
                table_data = table_item["data"]["table_cells"]

                rows = {}
                for cell in table_data:
                    row_idx = cell["start_row_offset_idx"]  # Get the row index for this cell
                    col_idx = cell["start_col_offset_idx"]  # Get the column index for this cell

                    if row_idx not in rows:
                        rows[row_idx] = {}

                    rows[row_idx][col_idx] = cell["text"]

                sorted_rows = []
                max_cols = max(len(row) for row in rows.values())
                for row_idx in sorted(rows.keys()):
                    row = [rows[row_idx].get(col_idx, "") for col_idx in range(max_cols)]
                    sorted_rows.append(row)

                table_dict[table_ref["$ref"]] = sorted_rows

        return table_dict

    def extract_content(self):
        """Run the extraction of texts, images, and tables."""
        text_dict = self.extract_texts()
        picture_dict = self.extract_images()
        table_dict = self.extract_tables()

        # Combine texts, images, and tables into the final list following the 'body' order
        for item in self.body["children"]:
            if "$ref" in item:
                ref = item["$ref"]
                if ref in text_dict:
                    self.combined_content.append(
                        {
                            "klass": "Text",
                            "content": text_dict[ref],
                            "page": 0,
                            "markdown_class": "PLAIN",
                        }
                    )
                elif ref in picture_dict:
                    self.combined_content.append(
                        {
                            "klass": "Figure",
                            "content": picture_dict[ref],
                            "page": 0,
                            "markdown_class": "FIGURE",
                        }
                    )
                elif ref in table_dict:
                    table_content = table_dict[ref]
                    headers = table_content[0]
                    table_json = [dict(zip(headers, row)) for row in table_content[1:]]
                    table_json_str = json.dumps(table_json, indent=4)
                    self.combined_content.append(
                        {
                            "klass": "Table",
                            "content": table_json_str,
                            "page": 0,
                            "markdown_class": "TABLE",
                        }
                    )

    def get_combined_content(self):
        """Return the final combined list with texts, images, and tables."""
        return self.combined_content


@dataclass(frozen=False)
class DoclingParser:
    """
    This is a parser whose output is consistent with TextComponent,
    ImageComponent, and TableComponent from GenAi Base.

    Examples:
        ```python
        parser = DoclingParser(
            text_parser_spec={},
            table_parser_spec={},
            image_parser_spec={},
        )
        ```
    """

    text_parser_spec: Optional[Dict[str, Any]] = field(default_factory=dict)
    table_parser_spec: Optional[Dict[str, Any]] = field(default_factory=dict)
    image_parser_spec: Optional[Dict[str, Any]] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)

    def __call__(self, document: PageDoc) -> Optional[dict]:
        """
        Parse the document using the specified parser inference settings.

        Args:
            document: The document to be parsed.

        Returns:
            The result of parsing the document, including parsed components
                and any relevant logs generated during the parsing process.
        """

        source = document.fname

        try:
            from docling.document_converter import DocumentConverter
        except ImportError:
            raise ImportError("Please install the 'docling' package to use this layout.")

        converter = DocumentConverter()
        result = converter.convert(source)

        json_content = result.document.export_to_dict()

        extractor = _DoclingExtractor(json_content)
        extractor.extract_content()

        combined_content = extractor.get_combined_content()

        list_of_dicts = [
            {
                "klass": item["klass"],
                "content": item["content"],
                "markdown_class": item["markdown_class"],
                "global_idx": idx,
            }
            for idx, item in enumerate(combined_content)
        ]

        layout_bboxes = DocBboxes.dict_init([list_of_dicts], document=document)

        text_compo = self.text_parser(layout_bboxes)
        image_compo = self.image_parser(layout_bboxes)
        table_compo = self.table_parser(layout_bboxes)

        list_components = []
        if text_compo is not None:
            list_components.extend(text_compo.to_records(with_ids=True))
        if table_compo is not None:
            list_components.extend(table_compo.to_records(with_ids=True))
        if image_compo is not None:
            list_components.extend(image_compo.to_records(with_ids=True))

        document_info = {
            "file_info": {
                "filename": layout_bboxes.document.filename,
                "fname": layout_bboxes.document.name,
                "filetype": layout_bboxes.document.type,
            },
            "full_specs": self.to_dict(),
        }

        for item in list_components:
            item["text"] = item.get("text", "")
            item["chunked"] = item.get("chunked", [])

            if item["parser"] == "TEXT":
                item["description_for_vectorstore"] = item["chunked"]

            elif item["parser"] == "TABLE":
                item["csv_url_c3"] = item.get("csv_url_c3", "")
                item["description_for_vectorstore"] = f"Verbalization: {item['verbalization']}"

            elif item["parser"] == "IMAGE":
                item["caption"] = item.get("caption", "")
                item["verbalization"] = item.get("verbalization", "")
                item["image_url_c3"] = item.get("image_url_c3", "")
                item["description_for_vectorstore"] = f"Verbalization: {item['verbalization']}"

        return {
            "document_info": document_info,
            "list_components": list_components,
        }

    @cached_property
    def text_parser(self):
        if self.text_parser_spec is None:
            return None

        return text_parser_pipeline(TextParserCfg(**self.text_parser_spec))

    @cached_property
    def table_parser(self):
        if self.table_parser_spec is None:
            return None

        return table_parser_pipeline(TableParserCfg(**self.table_parser_spec))

    @cached_property
    def image_parser(self):
        if self.image_parser_spec is None:
            return None

        return image_parser_pipeline(ImageParserCfg(**self.image_parser_spec))
