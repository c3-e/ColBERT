# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import base64
import dataclasses as dc

import cv2
from numpy.typing import NDArray

from .openai import OpenaiLikeLLM


def vlm(provider: OpenaiLikeLLM) -> VLM:
    return VLM(provider)


@dc.dataclass(frozen=True)
class VLM:
    provider: OpenaiLikeLLM

    def __call__(self, text: str, img: NDArray | None = None) -> str:
        if img is None:
            messages = [{"type": "text", "text": text}]
            return self.provider(messages)

        succ, png = cv2.imencode(".png", img)

        assert succ, "Failed to encode image."
        b64_img = base64.b64encode(png).decode("utf-8")

        img_encode_text = f"data:image/jpeg;base64,{b64_img}"
        messages = [
            {"type": "text", "text": text},
            {"type": "image_url", "image_url": {"url": img_encode_text}},
        ]
        return self.provider(messages)
