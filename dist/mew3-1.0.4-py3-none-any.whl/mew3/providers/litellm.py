# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc

from litellm import completion

from .openai import OpenaiProvider


@dc.dataclass(frozen=True)
class ModelMixin:
    model: str
    """
    The model to use for the API.
    """


@dc.dataclass(frozen=True)
class LiteLLM(OpenaiProvider, ModelMixin):
    """
    Spec for verbalizer that does nothing and returns an empty string.
    """

    def call(self, message, **options):
        return completion(model=self.model, messages=message, **options, api_key=self.api_key, api_base=self.endpoint)
