# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import json
from abc import abstractmethod
from functools import cache, lru_cache

from .openai import OpenaiLikeLLM


@dc.dataclass(frozen=True)
class _SerializedOpenaiLikeLLM:
    provider: OpenaiLikeLLM

    def __call__(self, messages):
        key = json.dumps(messages)
        return self._call_with_json(key)

    @abstractmethod
    def _call_with_json(self, key) -> str:
        return self.provider(json.load(key))


def openai_cache(proivder: OpenaiLikeLLM) -> OpenaiLikeLLM:
    @dc.dataclass(frozen=True, repr=False)
    class Cached(_SerializedOpenaiLikeLLM):
        @cache
        def _call_with_json(self, key) -> str:
            return self.provider(json.loads(key))

        def __repr__(self):
            return f"Cached({self.provider})"

    return Cached(proivder=proivder)


def openai_lru_cache(proivder: OpenaiLikeLLM, max_size: int) -> OpenaiLikeLLM:
    @dc.dataclass(frozen=True, repr=False)
    class LRUCached(_SerializedOpenaiLikeLLM):
        @lru_cache(maxsize=max_size)
        def _call_with_json(self, key) -> str:
            return self.provider(json.loads(key))

        def __repr__(self):
            return f"LRUCached({self.provider}, max_size={max_size})"

    return LRUCached(proivder=proivder)
