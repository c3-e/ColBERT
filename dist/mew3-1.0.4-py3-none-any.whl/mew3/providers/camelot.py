# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from pandas import DataFrame

    from mew3.document import PageDoc


def camelot_read_pdf(document: PageDoc, page_number: int, **camelot_kwargs: Any) -> List[DataFrame]:
    """
    Attempts to read a PDF using camelot on page ``page_number``.
    This function is cached to avoid re-reading the same page multiple times,
    since this is called whenever a table is parsed.

    TODO:
        Ensure that each page is read only once, which gets rid of the ``lru_cache``.

    Warning:
        Sometimes camelot parsing would fail with the ``table_regions`` or ``table_area``.
        Therefore, it was removed alltogether (might affect parsing quality).
    """

    import camelot

    tables = camelot.read_pdf(document.fname, pages=str(page_number + 1), flavor="stream", **camelot_kwargs)
    tables = [table.df for table in tables]
    return [t.fillna("") for t in tables]
