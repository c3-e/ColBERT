# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as d
from typing import TYPE_CHECKING, Callable, TypeVar

from PIL.Image import Image

from mew3.providers.plumber import pdfplumber_read_pdf

from .api import ImageCropper, ImageCropperSpec, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from pdfplumber.page import Page

    from mew3 import BoundingBox
    from mew3.document import Content


T = TypeVar("T")


def _read_and_call(
    content: Content,
    callback: Callable[[Page], T],
    bbox: BoundingBox | None = None,
) -> T:
    return pdfplumber_read_pdf(file=content.document.fname, page=content.page, callback=callback, bbox=bbox)


@d.dataclass
class _PlumberSpecForText(TextCropperSpec):
    dedupe_chars_kwargs: dict[str, bool] = d.field(default_factory=dict)
    extract_text_kwargs: dict[str, bool] = d.field(default_factory=lambda: {"x_tolerance": 1.5, "y_tolerance": 1.5})


class TextPDFPlumber(TextCropper, spec_class=_PlumberSpecForText, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        return _read_and_call(
            content=content,
            callback=lambda page: page.dedupe_chars(
                **self.spec.dedupe_chars_kwargs,
            ).extract_text(
                **self.spec.extract_text_kwargs,
            ),
            bbox=bbox,
        )

    def supports(self):
        return ["pdf"]


class ImagePDFPlumber(ImageCropper, spec_class=ImageCropperSpec, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> Image:
        return _read_and_call(
            content=content,
            callback=lambda page: page.to_image(resolution=self.dpi).original,
            bbox=bbox,
        )

    def supports(self):
        return ["pdf"]


@d.dataclass
class _PlumberSpecForTable(TableCropperSpec):
    extract_table_kwargs: dict[str, bool] = d.field(default_factory=dict)


class TablePDFPlumber(TableCropper, spec_class=_PlumberSpecForTable, class_name="PLUMBER"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        table = _read_and_call(
            content=content,
            callback=lambda page: page.extract_table(**self.spec.extract_table_kwargs),
            bbox=bbox,
        )
        return "\n".join(", ".join(map(str, row) or []) for row in (table or []))

    def supports(self):
        return ["pdf"]


@d.dataclass
class _PlumberSpecForTableTextOnly(TableCropperSpec):
    dedupe_chars_kwargs: dict[str, bool] = d.field(default_factory=dict)
    extract_text_kwargs: dict[str, bool] = d.field(default_factory=lambda: {"x_tolerance": 1.5, "y_tolerance": 1.5})


class PlumberText(TableCropper, spec_class=_PlumberSpecForTableTextOnly):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        result = _read_and_call(
            content=content,
            callback=lambda page: page.dedupe_chars(
                **self.spec.dedupe_chars_kwargs,
            ).extract_text(
                **self.spec.extract_text_kwargs,
            ),
            bbox=bbox,
        )
        return result

    def supports(self):
        return ["pdf"]
