# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING

import numpy as np

from .api import ImageCropper, ImageCropperSpec, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from PIL.Image import Image

    from mew3 import BoundingBox, Content


@dc.dataclass
class NullTextCropperSpec(TextCropperSpec):
    pass


@dc.dataclass
class NullTableCropperSpec(TableCropperSpec):
    pass


@dc.dataclass
class NullImageCropperSpec(ImageCropperSpec):
    pass


class NullTextCropper(TextCropper, spec_class=NullTextCropperSpec, class_name="NULL"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        return ""


class NullTableCropper(TableCropper, spec_class=NullTableCropperSpec, class_name="NULL"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        return ""


class NullImageCropper(ImageCropper, spec_class=NullImageCropperSpec, class_name="NULL"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> Image:  # type: ignore
        return np.array(None)
