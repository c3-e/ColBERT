# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING, TypeVar

from mew3.decltype import LayoutProc, LayoutProcSpec

if TYPE_CHECKING:
    from mew3 import BoundingBox, Content

    from .api import Cropper

T = TypeVar("T")


@dc.dataclass(frozen=True)
class CropperAsProcSpec(LayoutProcSpec):
    bbox: BoundingBox | None
    cropper: Cropper[T]

    def input_type(self):
        from mew3.document import Content

        return Content


class CropperAsProc(LayoutProc, spec_class=CropperAsProcSpec):

    """
    Adaptor to adapt the cropper to the content processor,
    to ensure that all `crop_bbox` calls go through the content processor API.
    """

    def process(self, item: Content):
        return self.cropper.crop_bbox(item, self.bbox)

    def supports(self):
        return self.cropper.supports()

    @property
    def cropper(self):
        return self.spec.cropper

    @property
    def bbox(self):
        return self.spec.bbox
