# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from lark import LarkError
from lark.exceptions import LarkError

from .registry import TreeRegistry
from .signature import signature_parse

if TYPE_CHECKING:
    from mew3.decltype import LayoutModule

_T = TypeVar("_T", bound="LayoutModule")


@dc.dataclass(frozen=True)
class Factory(Generic[_T]):
    """
    Factory method to create instances of the class with the given name.
    The name always would be in UPPER_SNAKE_CASE format, corresponding to the class name `UpperSnakeCase` originally.

    Parameters:
        name:
            The name of the class to create an instance of.
            The name can also be an inline evaluation string.
        **kwargs: The keyword arguments to pass to the class constructor

    Example:
        >>> Foo.factory("BAR", a=20, b=22.2)
        Bar(a=20, b=22.2)

        >>> Foo.factory("BAR(a=20)", b=22.2)
        Bar(a=20, b=22.2)

    Returns:
        An instance of the class with the given name.
    """

    registry: TreeRegistry[_T]

    def __post_init__(self):
        if not isinstance(self.registry, TreeRegistry):
            raise TypeError(f"Expected registry to be of type TreeRegistry, got {type(self.registry)}")

    def __contains__(self, name: str) -> bool:
        from mew3.decltype import LayoutModuleRenderer

        return name in self.registry.cls.registered(
            LayoutModuleRenderer(params=False, color=None, class_name="alias", doc=False, delta=False)
        )

    def __call__(self, name: str, **kwargs) -> _T:
        try:
            n, kw = signature_parse(name)
        except LarkError as le:
            raise KeyError(f"Invalid name {name}! Must be a valid class name or an inline evaluation string.") from le
        return self._factory(name=n, **{**kw, **kwargs})

    def _factory(self, name: str, **kwargs: Any):
        try:
            klass = self.registry.query(name)
        except KeyError as ke:
            raise KeyError(f"Class {name} is not registered! Registered: {self.registry.cls.registered()}") from ke
        return klass(**kwargs)
