# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import re

_PASCAL_CASE_REGEX = re.compile(r"^[A-Z]+[a-z]*(?:\d*(?:[A-Z]+[a-z]*)?)*$")
_CAMEL_BOUNDARY_REGEX = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def pascal_to_upper_snake(name: str) -> str:
    """
    Convert a camel case string to an upper snake case string.

    Parameters:
        name: The camel case string to convert.

    Returns:
        The upper snake case string.

    Raises:
        ValueError: If the name is not in PascalCase format
    """

    if not _PASCAL_CASE_REGEX.match(name):
        raise ValueError(f"{name} is not in PascalCase format!")

    name = _CAMEL_BOUNDARY_REGEX.sub("_", name)
    return name.upper()
