# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import logging
from typing import List, Tuple

import numpy as np
from numpy.typing import NDArray

LOGGER = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class Graph:
    """
    A graph represented by an adjacency matrix.
    """

    adj_mat: NDArray
    """
    The adjacency matrix of the graph.
    """

    def __post_init__(self):
        assert self.adj_mat.dtype == int
        assert self.adj_mat.ndim == 2
        assert self.adj_mat.shape[0] == self.adj_mat.shape[1]

    def __len__(self) -> int:
        return len(self.adj_mat)

    def __eq__(self, value: object) -> bool:
        if not isinstance(value, Graph):
            return NotImplemented

        return np.all(self.adj_mat.astype(int), value.adj_mat.astype(int))

    def degrees(self):
        return self.adj_mat.sum(axis=1)

    @property
    def edges(self):
        return np.argwhere(self.adj_mat)

    def _set_edge(self, i: int, j: int, to: bool, bi: bool = False):
        """
        Connect two nodes.

        Parameters:
            i: The index of the first node.
            j: The index of the second node.
            to: Whether to connect the nodes.
            bi: Whether to connect the nodes in both directions.
        """

        self.adj_mat[i, j] = int(to)

        if bi:
            self.adj_mat[j, i] = int(to)

    def link(self, i: int, j: int, *, bi: bool = False):
        "Link two nodes."
        self._set_edge(i, j, True, bi)

    def unlink(self, i: int, j: int, *, bi: bool = False):
        "Unlink two nodes."
        self._set_edge(i, j, False, bi)

    def is_linked(self, i: int, j: int, *, bi: bool = False) -> bool:
        "Whether two nodes are connected."
        if bi:
            return bool(self.adj_mat[i, j] and self.adj_mat[j, i])
        else:
            return bool(self.adj_mat[i, j])

    def children_of(self, i: int) -> List[int]:
        "Children of a node."
        return np.arange(len(self))[self.adj_mat[i, :].astype(bool)].tolist()

    def parents_of(self, i: int) -> List[int]:
        "Parents of a node."
        return np.arange(len(self))[self.adj_mat[:, i].astype(bool)].tolist()

    def take(self, indices: List[int], /) -> Graph:
        "Select the indices"

        self._check_valid_indices(indices)

        return Graph(self.adj_mat[np.ix_(indices, indices)])

    def split(self, crit: List[int]) -> Tuple[Graph, Graph]:
        "Split the graph based on a criterion."

        self._check_valid_indices(crit)

        left_idx = sorted(crit)
        right_idx = sorted(set(range(len(self))) - set(crit))

        left = self.take(left_idx)
        right = self.take(right_idx)

        if left.adj_mat.sum() + right.adj_mat.sum() != self.adj_mat.sum():
            LOGGER.warning("Split graph has fewer edges than the original.")

        return left, right

    def _check_valid_indices(self, indices: List[int], /) -> None:
        if max(indices) >= len(self):
            raise IndexError(f"Some indices are out of bounds. Largest: {max(indices)}")

        if min(indices) < 0:
            raise IndexError(f"Some indices are out of bounds. Smallest: {min(indices)}")

    @classmethod
    def concat(cls, *graphs: Graph) -> Graph:
        "Joined graphs."

        lengths = [len(graph) for graph in graphs]
        cumsums = np.cumsum(lengths)
        adj_mat = np.zeros([cumsums[-1], cumsums[-1]]).astype(int)

        for i, graph in enumerate(graphs):
            length_i = lengths[i]
            cumsum_i = cumsums[i]
            adj_mat[cumsum_i - length_i : cumsum_i, cumsum_i - length_i : cumsum_i] = graph.adj_mat

        return cls(adj_mat=adj_mat)

    @classmethod
    def zeros(cls, n: int) -> Graph:
        "For initialising a graph with no edges."
        return cls(np.zeros((n, n), dtype=int))
