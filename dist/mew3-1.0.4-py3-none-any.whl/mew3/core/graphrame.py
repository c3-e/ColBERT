# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import copy
import dataclasses as dc
import logging
import warnings
from functools import cached_property
from typing import Any, Callable, Dict, Hashable, Iterable, Iterator, List, Mapping, MutableMapping, TypeVar

import networkx as nx
import numpy as np
import pandas as pd
from typing_extensions import Self

from .bbox import ParsedMetadata
from .dicts import GraphDict
from .graphs import Graph
from .unique_ids import UniqueIds
from .utils import Locator

T = TypeVar("T")
LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)

__all__ = ["Graphrame"]


@dc.dataclass(frozen=True, eq=False)
class Graphrame(Mapping[str, pd.Series]):
    """
    Graphrame is both a graph and a dataframe, it provides a convenient way to store and
    manipulate data, and track relationships between different entities.

    In its core, the `Graphrame` can be split into 3 parts:

    1. `df`:
        A pandas DataFrame that stores the attributes of the nodes.
        Using a dataframe makes filtering and mapping operations simple to perform and test.
    2. `ids`:
        A unique identifier for each node.
        This is used for guaranteeing the uniqueness of the nodes.
    3. graph:
        An graph object with a similar API to networkx graph to track the relationships between the nodes.
    """

    df: pd.DataFrame
    """
    Attributes of the nodes.
    """

    graphs: GraphDict = dc.field(default_factory=GraphDict.empty)
    """
    Graphs associated with the nodes.
    """

    @cached_property
    def ids(self) -> UniqueIds:
        return UniqueIds.parse(self.df.index)

    def __post_init__(self):
        if len(self.df) != len(self.ids):
            raise ValueError(
                "The number of records must match the number of unique ids. "
                f"Got {len(self.df)} records and {len(self.ids)} ids."
            )

        if (num_rows := self.graphs.num_rows) is not None and len(self.df) != num_rows:
            raise ValueError(
                "The number of records must match the number of rows in the graphs. "
                f"Got {len(self.df)} records and {self.graphs.num_rows} rows."
            )

        if self.df.isnull().values.any():
            raise ValueError("The dataframe must not contain any null values. Got df:\n" + str(self.df))

        if not self.df.index.is_unique:
            raise ValueError("The index of the dataframe must be unique.")

    def __iter__(self):
        return iter(self.df)

    def __getitem__(self, key: str) -> pd.Series:
        return self.df[key]

    def __setitem__(self, key: str, value: pd.Series | List):
        if not isinstance(value, (pd.Series, list)):
            raise ValueError("Value must be a pandas Series or a list.")

        if len(value) != len(self):
            raise ValueError(
                "The length of the value must match the number of nodes. "
                f"Got {len(value)} values and {len(self)} nodes."
            )

        if not all(item is not None for item in value):
            raise ValueError("The value must not contain any null values. Got value: " + str(value))

        if isinstance(value, pd.Series):
            value = list(value)

        self.df[key] = value

    def __delitem__(self, key: str) -> None:
        del self.df[key]

    def __len__(self) -> int:
        return len(self.df)

    @property
    def dtypes(self) -> pd.Series:
        return self.df.dtypes

    @property
    def index(self) -> pd.Index:
        return self.df.index

    @property
    def rels(self) -> _GraphDictWithDefault:
        return _GraphDictWithDefault(self.graphs, len(self.ids))

    @property
    def data(self) -> pd.DataFrame:
        return self.df

    @property
    def columns(self) -> List[str]:
        return self.df.columns.tolist()

    def unique(self, key: str):
        return self.df[key].unique()

    def clone(self):
        return copy.deepcopy(self)

    copy = clone

    def _repr_html_(self):
        return self.data.to_html()

    def idx_where(self, key: str, func: Callable[[T], bool]) -> List[int]:
        if not callable(func):
            raise ValueError("func must be callable.")

        select = self.df[key].apply(func)
        return np.arange(len(self))[select].tolist()

    def where(self, idx: List[int], /) -> Self:
        return self.from_pandas(self.df.iloc[idx], ids=self.ids[idx])

    @property
    def iloc(self):
        return self.df.iloc

    @property
    def loc(self) -> Locator:
        return Locator(self.df)

    @classmethod
    def concat(cls, *graphrames: Graphrame) -> Graphrame:
        """
        Merge multiple `Graphrame`s.
        Only merge the common keys, which are going to be the intersection of the keys of all `Graphrame`s.

        Parameters:
            graphrames: A list of Graphrames.

        Returns:
            A merged `Graphrame`.
        """

        if not graphrames:
            raise ValueError("At least one Graphrame must be provided.")

        if len(graphrames) == 1:
            return graphrames[0]

        keys_in_common = common_keys(*(g.df.columns for g in graphrames))

        if not keys_in_common:
            warnings.warn("No common keys found. Returning an empty Graphrame.")

        dfs = [g.df[keys_in_common] for g in graphrames]
        ids = UniqueIds.parse([uid for g in graphrames for uid in g.ids])

        return cls.from_pandas(pd.concat(dfs, ignore_index=True), ids=ids)

    @classmethod
    def from_dataclasses(cls, records: List[Mapping[str, Any]], /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a list of dataclasses.

        Parameters:
            records: A list of dataclasses.

        Returns:
            A Graphrame.
        """

        return cls.from_records([dc.asdict(record) for record in records], ids=ids)

    @classmethod
    def from_records(cls, records: List[Dict[str, Any]], /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a list of records.

        Parameters:
            records: A list of records.

        Returns:
            A Graphrame.
        """

        LOGGER.debug(f"Creating Graphrame from %s", records)

        for record in records:
            if not isinstance(record, dict):
                raise ValueError("Records must be mappings.")

        df = pd.DataFrame.from_records(records)
        return Graphrame.from_pandas(df, ids=ids)

    @classmethod
    def from_records_with_unique_ids(cls, records: List[Dict[str, Any]]):
        """
        Create a Graphrame from a list of records with unique ids.

        Parameters:
            records: A list of records.

        Returns:
            A Graphrame.
        """

        records = copy.deepcopy(records)
        for record in records:
            if not isinstance(record, dict):
                raise ValueError("Records must be mappings.")

            if "__id__" not in record:
                raise ValueError("Records must contain a unique id.")

        unique_ids = UniqueIds.parse([record.pop("__id__") for record in records])
        df = pd.DataFrame.from_records(records)
        return cls.from_pandas(df, ids=unique_ids)

    @classmethod
    def from_pandas(cls, df: pd.DataFrame, /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a pandas DataFrame.

        Parameters:
            df: A pandas DataFrame.

        Returns:
            A Graphrame.
        """

        if ids is None:
            ids = UniqueIds.uuid(len(df))

        if not isinstance(ids, UniqueIds):
            raise ValueError("ids must be a UniqueIds object.")

        df.index = list(ids)

        # Try converting to arrow if available.
        try:
            df = df.convert_dtypes(dtype_backend="pyarrow")
        except ImportError:
            pass

        return Graphrame(df=df)

    def to_objects(self, with_ids: bool = False) -> List[ParsedMetadata]:
        return [ParsedMetadata.flat_init(**record) for record in self._to_records(with_ids)]

    def to_records(self, with_ids: bool = False) -> List[Dict[str, Any]]:
        """
        Convert the Graphrame to a list of records.

        Args:
            with_ids:
                If True, include the unique ids in the records under the key `__id__`.
                Default is False.

        Returns:
            A list of dictionary records, where each records represents a row.
        """

        return list(self._to_records(with_ids))

    def _to_records(self, with_ids: bool = False) -> Iterator[Dict[str, Any]]:
        records = self.df.to_dict(orient="records")
        for idx, record in enumerate(records):
            result = {**record}
            if "score" in result:
                result["score"] = float(result["score"])
            if with_ids:
                result["__id__"] = self.ids[idx]
            yield result

    def reorder(self, order: List[int]) -> Graphrame:
        if sorted(order) != list(range(len(self))):
            raise ValueError("The order must be a permutation of the node indices.")

        return self.take(order)

    def group_to_dict(self, by: str) -> Dict[Hashable, Graphrame]:
        page_to_item = list(self.df.groupby(by))
        return {k: Graphrame.from_pandas(v, ids=UniqueIds.parse(v.index)) for k, v in page_to_item}

    def take(self, indices: List[int]) -> Self:
        return Graphrame(self.df.iloc[indices], graphs=self.graphs.take(indices))

    def networkx(self):
        G = nx.Graph()

        for id, row in zip(self.ids, self.df.iterrows()):
            G.add_node(id, **row.to_dict())

        G.add_edges_from(self.rels.edges)
        return G

    @classmethod
    def empty(cls, columns: List[str]):
        return cls.from_pandas(
            pd.DataFrame(columns=sorted({"x_1", "y_1", "x_2", "y_2", "page", "score", "klass", *columns}))
        )

    def query(self, ids: List[int] | List[str] | UniqueIds, /) -> Graphrame:
        """
        Query the Graphrame by a list of ids.

        Parameters:
            ids: A list of ids.

        Returns:
            A Graphrame.
        """

        if isinstance(ids, list) and all(isinstance(i, int) for i in ids):
            return self.take(ids)

        if isinstance(ids, list) and all(isinstance(i, str) for i in ids) or isinstance(ids, UniqueIds):
            return self.take(self.ids.index(ids))

        raise NotImplementedError(f"Querying with {ids} is not supported.")


@dc.dataclass(frozen=True)
class _GraphDictWithDefault(MutableMapping[str, Graph]):
    """
    `_GraphDictWithDefault` is a default dictionary storing multiple graphs,
    with some additional checks and methods for convenience.
    """

    graphs: GraphDict
    """
    The graphs.
    """

    _default_len: int = dc.field(repr=False)
    """
    The default length of the graphs.
    """

    def __len__(self) -> int:
        return len(self.graphs)

    def __iter__(self) -> Iterator[str]:
        return iter(self.graphs)

    def __getitem__(self, key: str) -> Graph:
        # This acts kind of like a default dict.
        if key not in self.graphs:
            self.graphs[key] = Graph.zeros(self._default_len)

        assert (nr := self.graphs.num_rows) is None or nr == self._default_len, (
            "The number of rows in the graphs must match the number of nodes."
            f"Got {nr} rows and {self._default_len} nodes."
        )
        return self.graphs[key]

    def __setitem__(self, key: str, value: Graph):
        if len(value) != self._default_len:
            raise ValueError("The graph must have the same number of nodes as the context.")

        self.graphs[key] = value

    def __delitem__(self, key: str):
        del self.graphs[key]

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _GraphDictWithDefault):
            return self.graphs == other.graphs

        # Use `GraphDict`'s `__eq__` method.
        return self.graphs == other


def common_keys(*keys: Iterable[str]) -> List[str]:
    """
    Get the common keys from a list of keys.

    Args:
        keys: A list of keys.

    Returns:
        A list of common keys.
    """

    if not keys:
        return []

    common = set(keys[0])
    for k in keys[1:]:
        common.intersection_update(k)

    return sorted(common)
