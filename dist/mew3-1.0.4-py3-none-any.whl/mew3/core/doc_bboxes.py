# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from collections.abc import Callable
from typing import Any, Dict, Iterable, List, Sequence

import pandas as pd
from pandas import Series
from typing_extensions import Self

from mew3.document import PageDoc

from .bbox import ParsedMetadata
from .graphrame import Graphrame
from .unique_ids import NotUniqueError, UniqueIds


def _get_col(name: str):
    def getter(self: DocBboxes) -> Series:
        return self.data[name]

    return getter


def _set_col(name: str):
    def setter(self: DocBboxes, value) -> None:
        self.data[name] = value

    return setter


@dc.dataclass(frozen=True)
class ExtraFields:
    parsed: Any
    """
    The original parsed metadata.
    """

    properties: Dict[str, Callable] = dc.field(default_factory=dict)
    """
    "Properties" are like python properties, looks like a member but is a function.
    """

    def __post_init__(self):
        for func in self.properties.values():
            if not callable(func):
                raise ValueError("The extras must be a dictionary of callables")

    def __repr__(self) -> str:
        extra_strings = ", ".join(f"{key}={value(self)}" for key, value in self.properties.items())
        return f"+({self.parsed}, {extra_strings})"

    def __getitem__(self, key: str):
        return getattr(self, key)

    def __getattr__(self, member: str):
        if member in self.properties:
            function = self.properties[member]
            return function(self)

        return getattr(self.parsed, member)


@dc.dataclass(frozen=True)
class DocBboxes:
    """
    Represents the bounding boxes on a document. This class can be thought of as a `List[List[ParsedMetadata]]`.
    """

    gf: Graphrame
    """
    The underlying data of the bounding box on a document.
    """

    document: PageDoc
    """
    The document the bounding boxes belong to.
    """

    @property
    def data(self) -> Graphrame:
        return self.gf

    @property
    def unique_ids(self) -> UniqueIds:
        return self.gf.ids

    x_1 = property(_get_col("x_1"), _set_col("x_1"))
    y_1 = property(_get_col("y_1"), _set_col("y_1"))
    x_2 = property(_get_col("x_2"), _set_col("x_2"))
    y_2 = property(_get_col("y_2"), _set_col("y_2"))
    klasses = property(_get_col("klass"))

    @property
    def width(self):
        return self.x_2 - self.x_1

    @property
    def height(self):
        return self.y_2 - self.y_1

    def __getitem__(self, idx: str):  # -> Series:
        if isinstance(idx, str):
            return self.gf[idx]

        raise TypeError(f"Invalid index type: {type(idx)}. Must be str.")

    def __setitem__(self, idx: str, value: Series | List) -> None:
        if isinstance(idx, str):
            self.gf[idx] = value
            return

        raise TypeError(f"Assigning keys that are not strings are not allowed yet. Got {idx} of {type(idx)}.")

    def __delitem__(self, key: str) -> None:
        if isinstance(key, str):
            del self.gf[key]
            return

        raise TypeError(f"Deleting keys that are not strings are not allowed yet. Got {key} of {type(key)}.")

    def count(self):
        return len(self.document)

    @property
    def num_pages(self):
        return self.count()

    def __post_init__(self):
        if not isinstance(self.document, PageDoc):
            raise ValueError("The document attribute must be a Document.")

        if not isinstance(self.gf, Graphrame):
            raise ValueError("The gf attribute must be a Graphrame.")

        unique_pages = self.data["page"].unique().tolist()

        if set(unique_pages).difference(range(len(self.document))):
            raise ValueError("The page numbers must be in the range of the document.")

    def __eq__(self, other: object) -> bool:
        if isinstance(other, DocBboxes):
            return self.document == other.document and self.gf == other.gf

        return NotImplemented

    def __iter__(self):
        list_of_list = self.to_list_of_list()

        for page in list_of_list:
            yield page

    def keys(self):
        return self.gf.keys()

    @property
    def num_rows(self) -> int:
        return len(self.data)

    num_bboxes = num_rows

    @property
    def pages(self) -> pd.Series:
        return self.data["page"]

    @property
    def dtypes(self) -> Series:
        return self.gf.dtypes

    def filter_class(self, *tags: str) -> Self:
        return self.filter("klass", lambda klass: klass in tags)

    def map_class(self, mapping: Dict[str, str]):
        if set(self.data["klass"].unique()).difference(mapping.keys()):
            raise KeyError("The classes must be in the mapping.")

        mapping_func = lambda klass: mapping[klass]
        return self.apply_to_column("klass", "klass", mapping_func)

    def filter(self, column: str, func: Callable):
        select = self.data.idx_where(column, func)
        return dc.replace(self, gf=self.gf.query(select))

    def apply(self, column: str, /, func: Callable):
        df = self.gf.clone()
        return df[column].apply(func)

    def apply_to_column(self, source: str, target: str, mapping: Callable) -> Self:
        df = self.gf.df.copy()
        return self.with_column(target, self.apply(source, mapping))

    def validate_classes(self, valid_classes: Sequence[str]):
        assert "klass" in self.data.columns, "The data must have a 'klass' column."
        return self.data["klass"].isin(valid_classes).all()

    def to_list_of_list(self) -> List[List[ExtraFields]]:
        pages_dict = self.gf.group_to_dict("page")
        pages = self.pages.unique().tolist()

        extra_fields = {
            "scaled_bbox": lambda record: record.bbox * self.document.rel_scale,
        }

        result_in_gf = [pages_dict[page].to_objects() for page in pages]
        return [[ExtraFields(record, properties=extra_fields) for record in gf] for gf in result_in_gf]

    @property
    def classes(self):
        return sorted(self.data["klass"].unique().tolist())

    def columns(self, *columns: str):
        cols = list(columns)
        df = self.data[cols]
        return type(self)(gf=df, document=self.document)

    def with_column(self, name: str, value: Sequence):
        if len(value) != len(self.gf.df):
            raise ValueError("The length of the value must match the length of the bounding boxes.")

        df = self.data.copy()
        df[name] = value
        return type(self)(gf=df, document=self.document)

    def with_new_document(self, document: PageDoc):
        return dc.replace(self, document=document)

    def index(self, unique_ids: UniqueIds) -> List[int]:
        return [self.unique_ids.index(uid) for uid in unique_ids]

    def where(self, idx: List[int]) -> Self:
        return type(self)(gf=self.gf.where(idx), document=self.document)

    @classmethod
    def dict_init(
        cls,
        sequence: Iterable[Iterable[Dict[str, Any]]],
        /,
        document: PageDoc,
        ids: Sequence[str] = (),
        ignore_page: bool = False,
    ) -> Self:
        """
        This is the more flexible version of the `init` method.
        It allows for the sequence to be a list of dictionaries without constraints to what keys are present.

        Args:
            sequence: The sequence of bounding boxes.
            document: The document the bounding boxes belong to.
            ids: The unique ids of the bounding boxes. If not provided, the unique ids will be generated.
            ignore_page: Whether to ignore the "page" key in the bounding boxes.

        Raises:
            ValueError: If the given document is not a ``Document``.
            KeyError: If "page" is present in the bounding box.
            TypeError: If the sequence contains non-dictionaries.
            NotUniqueError: If the sequence contains identical bounding boxes.

        Returns:
            _description_
        """

        if not isinstance(document, PageDoc):
            raise ValueError(f"The document attribute must be provided as a Document. Got {document}")

        seq_of_seq = [list(seq) for seq in sequence]

        # Convert the sequence to the standardized format.
        df_seq = []

        for page_num, page_bboxes in enumerate(seq_of_seq):
            for box in page_bboxes:
                if not isinstance(box, dict):
                    raise TypeError(f"The sequence must contain dictionaries. Got: {box}")

                if not ignore_page and "page" in box:
                    raise KeyError(f"The dictionary must not contain a 'page' key. Got: {box}")

            df = pd.DataFrame.from_records(
                [
                    {
                        **box,
                        "page": page_num,
                    }
                    for box in page_bboxes
                ]
            )

            if not df.notna().all().all():
                raise ValueError(f"The sequence cannot contain None values. On page: {page_num} Got: \n" + str(df))

            df_seq.append(df)

        # Concatenate the dataframes to form a single graph.
        dfs = pd.concat(df_seq)

        try:
            # If ids are given, pass through.
            gf = Graphrame.from_pandas(dfs, ids=ids or None)
        except NotUniqueError as ue:
            raise NotUniqueError("The sequence cannot contain identical bounding boxes.") from ue

        return cls(gf=gf, document=document)

    @classmethod
    def init(cls, sequence: Iterable[Iterable[ParsedMetadata]], document: PageDoc, ids: Sequence[str] = ()) -> Self:
        """
        Initialize a ``LayoutParserOutput`` with the given sequence.

        Args:
            sequence: The sequence of bounding boxes.
            document: The document the bounding boxes belong to.

        Returns:
            A ``LayoutParserOutput`` object.

        Raises:
            ValueError: If the document is invalid (not a ``Document``).

        NOTE:
            Must have the following attributes:
            - x_1: The minimum x-coordinate of the bounding box.
            - y_1: The minimum y-coordinate of the bounding box.
            - x_2: The maximum x-coordinate of the bounding box.
            - y_2: The maximum y-coordinate of the bounding box.
            - klass: The class of the bounding box.
            - score: The score of the bounding box.
            - page: The page number of the bounding box. Note that this is indexed from 0.
        """

        if not isinstance(document, PageDoc):
            raise ValueError(f"The document attribute must be provided as a Document. Got {document}")

        seq_of_seq = [[pm.to_dict() for pm in seq] for seq in sequence]

        return cls.dict_init(seq_of_seq, document=document, ids=ids, ignore_page=True)

    @property
    def rels(self):
        return self.data.rels

    def to_records(self, with_ids: bool = False):
        return self.data.to_records(with_ids=with_ids)

    @classmethod
    def from_records(cls, records: List[Dict[str, Any]], document: PageDoc):
        has_id = True if "__id__" in records[0] else False

        if has_id:
            _gf = Graphrame.from_records_with_unique_ids(records)
        else:
            _gf = Graphrame.from_records(records)

        return cls(gf=_gf, document=document)

    def clone(self) -> Self:
        return dc.replace(self, gf=self.gf.clone())

    copy = clone

    def _repr_html_(self):
        # For jupyter viewing
        return self.data._repr_html_()

    def __str__(self) -> str:
        return (
            f"{type(self).__name__}(document={self.document}, num_pages={self.num_pages}, num_bboxes={self.num_bboxes})"
        )

    def __repr__(self) -> str:
        return str(self)

    @classmethod
    def concat(cls, *bboxes: DocBboxes) -> Self:
        """
        Concatenate the bounding boxes of multiple documents.

        Args:
            *bboxes: The documents to concatenate.

        Returns:
            A ``DocBboxes`` object.
        """

        if not bboxes:
            raise ValueError("At least one document must be provided.")

        if len(bboxes) == 1:
            return bboxes[0]

        try:
            [document] = {d.document for d in bboxes}
        except ValueError as ve:
            docs = [d.document for d in bboxes]
            raise ValueError(f"All documents must be the same. Got {docs}.") from ve

        return cls(gf=Graphrame.concat(*[d.gf for d in bboxes]), document=document)
