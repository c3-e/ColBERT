# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


import dataclasses as dc

import numpy as np

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.decltype import LayoutExec, LayoutExecSpec


@dc.dataclass(frozen=True)
class GrowBoxSpec(LayoutExecSpec):
    """
    Unit: fraction of page height or width.
    Parameters could be negative, but may not be useful.
    """

    markdown_class: str = "FIGURE"  # or TABLE
    """
    The markdown class to grow the bbox
    """

    upper: float = 0.1
    """
    Upper margin to grow the bbox. 
    """

    lower: float = 0.1
    """
    Lower margin to grow the bbox.
    """

    left: float = 0.05
    """
    Left margin to grow the bbox.
    """

    right: float = 0.05
    """
    Right margin to grow the bbox.
    """

    def delta_columns(self):
        return (".x_1", ".x_2", ".y_1", ".y_2")


class GrowBox(LayoutExec, spec_class=GrowBoxSpec):
    """
    Grow FIGURE or TABLE image bbox to account for VGT artifacts/get surrounding information.
    Use only after box merging, de-overlapping, etc!
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        doc = output.document

        list_output = output.to_records(with_ids=True).copy()

        for idx, r in enumerate(list_output):
            if r["markdown_class"] == self.spec.markdown_class:
                page_height, page_width, _ = np.shape(doc.pages[r["page"]])
                page_height /= doc.rel_scale
                page_width /= doc.rel_scale

                x_1 = max(0, r["x_1"] - self.spec.left * page_width)
                y_1 = max(0, r["y_1"] - self.spec.lower * page_height)
                # account for rounding err
                x_2 = min(page_width - 2, r["x_2"] + self.spec.right * page_width)
                y_2 = min(page_height - 2, r["y_2"] + self.spec.upper * page_height)

                list_output[idx]["x_1"] = x_1
                list_output[idx]["x_2"] = x_2
                list_output[idx]["y_1"] = y_1
                list_output[idx]["y_2"] = y_2

        return LayoutParserOutput.from_records(list_output, doc)
