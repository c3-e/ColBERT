# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from dataclasses import dataclass

from mew3.core import BoundingBox, DocBboxes, ParsedMetadata
from mew3.document import PageDoc

from .api import LayoutModel, LayoutModelSpec, LayoutParserOutput


@dataclass(frozen=True)
class DummySpec(LayoutModelSpec):
    """
    A specification for a dummy layout parser.
    """


class Dummy(LayoutModel, spec_class=DummySpec):
    """
    A dummy layout parser that always returns an empty list of bounding boxes.
    """

    def produce(self, document: PageDoc) -> LayoutParserOutput:
        _ = document
        return DocBboxes.init(
            [
                [
                    ParsedMetadata.canon_init(BoundingBox(0, 0, 1, 1), klass="HEADER"),
                    ParsedMetadata.canon_init(BoundingBox(1, 1, 2, 2), klass="IDK"),
                    ParsedMetadata.canon_init(BoundingBox(2, 2, 3, 3), klass="IDK"),
                    ParsedMetadata.canon_init(BoundingBox(3, 3, 4, 4), klass="PLAIN"),
                ]
            ],
            document=document,
        )
