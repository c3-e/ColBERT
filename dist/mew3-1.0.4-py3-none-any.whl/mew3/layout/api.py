# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod

from mew3.core import DocBboxes
from mew3.decltype import LayoutProducer, LayoutProducerSpec
from mew3.document import PageDoc
from mew3.specs import factorize

LayoutParserOutput = DocBboxes


@dc.dataclass(frozen=True)
class LayoutModelSpec(LayoutProducerSpec, ABC):
    """
    A specification for a layout parser.
    """


@factorize(LayoutModelSpec)
class LayoutModel(LayoutProducer, ABC, spec_class=LayoutModelSpec):
    """
    A layout parser is an object that takes a filename and returns a list of bounding boxes.
    """

    @abstractmethod
    def produce(self, filename: PageDoc, /) -> LayoutParserOutput:
        """
        Parse the layout of a document and return a list of bounding boxes.

        Args:
            filename: The filename of the document to parse.

        Returns:
            A list of bounding boxes, grouped by page.
        """
