# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from typing import TYPE_CHECKING

from mew3.rules import get_tols_for_files
from mew3.specs import signature_parse

if TYPE_CHECKING:
    from .document import PageDoc


def cma_rules_tolerance_settings(doc: PageDoc):
    x_tol, y_tol = get_tols_for_files(doc.fname)
    assert x_tol > 0, "x_tol must be positive"
    assert y_tol > 0, "y_tol must be positive"
    return {"x_tolerance": x_tol, "y_tolerance": y_tol}


def cma_installed():
    try:
        pass
    except ImportError:
        return False
    return True


def is_default_pdfplumber(key):
    sig = signature_parse(key)
    return "PLUMBER" in sig.kind and not sig.kwargs
