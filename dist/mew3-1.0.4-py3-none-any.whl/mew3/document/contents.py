# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
from PIL.Image import Image

from mew3.croppers import ImageCropper, TableCropper, TextCropper
from mew3.reader import CropWithBbox

if TYPE_CHECKING:
    from mew3 import BoundingBox, PageDoc


@dataclass(frozen=True)
class Content:
    """
    A central location for accessing what's inside of a document.
    It handles scaling and cropping of images and text extraction,
    s.t. externally, the bounding boxes can be kept normalized.

    The content would utilize the cropping strategy specified in the document to perform cropping,
    allowing the underlying medium to be platform and document type agnostic.
    """

    document: PageDoc
    page: int

    @property
    def dpi(self) -> int:
        """
        The DPI of the image.
        """

        return self.image_cropper.dpi

    @property
    def image_cropper(self) -> ImageCropper:
        """
        The image cropper to use (on this page).
        This is directly retrieved from the document.
        """
        return self.document.image_cropper

    @property
    def text_cropper(self) -> TextCropper:
        """
        The text cropper to use (on this page).
        This is directly retrieved from the document.
        """

        return self.document.text_cropper

    @property
    def table_cropper(self) -> TableCropper:
        """
        The table cropper to use (on this page).
        This is directly retrieved from the document.
        """
        return self.document.table_cropper

    @property
    def image(self) -> Image:
        return self.crop_image()

    @property
    def type(self) -> str:
        return self.document.type

    def __post_init__(self):
        assert np.array(self).ndim == 3, "Image must be 3D."
        assert np.array(self).shape[2] == 3, "Image must have 3 channels."

    def __array__(self) -> NDArray:
        """
        Allowing the content to be treated as an array.
        """

        return np.array(self.image)

    def find_and_gen_grid(self) -> CropWithBbox:
        return self.document.grid_generator(self)

    def crop_image(self, bbox: BoundingBox | None = None) -> Image:
        """
        Crop the image to the given bounding box region.

        Parameters:
            bbox: The (normalized) bounding box region.

        Returns:
            The cropped image.
        """

        return self.image_cropper.as_proc(bbox)(self)

    def crop_text(self, bbox: BoundingBox | None = None) -> str:
        """
        Extract text from the given bounding box region.

        Parameters:
            bbox: The (normalized) bounding box region.

        Returns:
            The extracted text.
        """

        return self.text_cropper.as_proc(bbox)(self)

    def crop_table(self, bbox: BoundingBox | None = None) -> str:
        """
        Crop the table to the given bounding box region

        Args:
            bbox: The (normalized) bounding box region.

        Returns:
            The cropped table in string representation.
        """

        return self.table_cropper.as_proc(bbox)(self)
