# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import warnings

import nltk

from .decltype import LayoutExec, LayoutExecSpec


@dc.dataclass(frozen=True)
class WarnUnusualWordsSpec(LayoutExecSpec):
    pass


class WarnUnusualWords(LayoutExec, spec_class=WarnUnusualWordsSpec):
    def consume(self, input):
        text = input["text"]
        unusual = _unusual_words(text)

        warnings.warn(f"Unusual words found: {unusual}")

        return input


def _unusual_words(text):
    text_vocab = set(w.lower() for w in text.split() if w.isalpha())
    english_vocab = set(w.lower() for w in nltk.corpus.words.words())
    unusual = text_vocab - english_vocab
    return sorted(unusual)
