# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import numpy as np
from PIL import Image

LOGO_STR = """
0 0 0 0 0 1 0 0 0 0 0;
0 1 0 1 0 1 0 1 1 1 1;
0 1 0 1 0 1 0 0 0 0 0;
0 1 0 1 0 1 0 1 1 1 1;
0 1 0 1 0 1 0 0 0 0 0;
1 1 1 1 1 1 1 1 1 1 1;
0 1 0 1 0 1 0 0 0 0 0;
0 1 0 1 0 1 1 1 1 1 0;
0 1 0 1 0 1 0 0 0 0 0;
0 1 0 1 0 1 1 1 1 1 0;
0 0 0 0 0 1 0 0 0 0 0
"""
LOGO = np.array(np.matrix(LOGO_STR.strip())).astype("uint8") * 255
LOGO = np.kron(LOGO, np.ones((30, 30), dtype="uint8"))


class Logo:
    def _repr_png_(self):
        return Image.fromarray(LOGO)
