# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import io
import json
import logging
import uuid
from dataclasses import asdict, dataclass, field
from functools import cached_property
from typing import Any, Dict, List

import numpy as np
from typing_extensions import Any, Dict, List, Tuple

from ..ctx import c3_ctx, c3_not_set
from ..decltype import Chain, ExecPipe, Filter, Mark, Rename, Tag
from ..document import PageDoc

LOGGER = logging.getLogger(__name__)

ALL_CLASSES = ("FIGURE", "TABLE", "PLAIN", "HEADER", "CAPTION", "LIST", "IDK")


@dc.dataclass(frozen=True)
class TextParserCfg:
    contextual: Tuple[str, ...] = "HEADER", "PLAIN", "LIST", "CAPTION"
    """
    The classes to consider (aka kept after filtering) when parsing text. Default to consider headers, plain text, and lists
    """

    parse: Tuple[str, ...] = "HEADER", "PLAIN", "LIST", "CAPTION"
    """
    The classes to parse. Default to parse headers, plain text, and lists.
    """

    ext_typ: str = "DEFAULT"
    """
    The type of text extractor to use. Default to using the default text extractor.
    """

    chunk_typ: str = "LONG_CHAIN"
    """
    The type of text chunker to use. Default to using the long chain chunker.
    """

    ext_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the text extractor. See individual text extractor classes for details.
    """

    chunk_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the text chunker. See individual text chunker classes for details.
    """


@dc.dataclass(frozen=True)
class ImageParserCfg:
    """
    The image parser specification class.
    """

    contextual: Tuple[str, ...] = ALL_CLASSES
    """
    The classes to consider (aka kept after filtering) when parsing images. Default to consider both figures and plain text.
    """

    parse: Tuple[str, ...] = ("FIGURE",)
    """
    The classes to parse. Default to parse only figures.
    """

    get_surrounding_text_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "current_bbox_typ": "FIGURE",
            "extract_bbox_with_offsets": [-3, -2, -1, 1, 2, 3],
            "extract_bbox_with_type": ["CAPTION", "PLAIN", "HEADER", "LIST"],
            "enable_cross_page_search": False,
        }
    )
    """
    The keyword arguments for the get_surrounding_text component. See GetSurroundingTextSpec for details.
    """

    caption_finder_typ: str = "LOCALITY"
    """
    The type of caption finder to use. Default to using the locality-based caption finder,
    because layout parsers are availalbe for all documents.
    """

    caption_finder_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "search_bbox_with_offsets": [1, -1, 2, -2, 3, -3],
            "current_bbox_typ": ["FIGURE"],
            "target_bbox_type": "CAPTION",
            "bbox_types_to_search_for": ["CAPTION", "PLAIN", "HEADER"],
            "enable_cross_page_search": False,
        }
    )
    """
    The keyword arguments for the caption finder. See individual caption finder classes for details.
    """

    verbal_typ: str = "OPENAI"
    """
    The type of verbalizer to use. Can also use NULL (just output empty string).
    """

    verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the verbalizer. See individual verbalizer classes for details.
    """


@dc.dataclass(frozen=True)
class TableParserCfg:
    contextual: Tuple[str, ...] = ALL_CLASSES
    """
    The classes to consider (aka kept after filtering) when parsing tables. Default to consider tables, headers, and plain text.
    """
    parse: Tuple[str, ...] = ("TABLE",)
    """
    The classes to parse. Default to parse only tables.
    """

    content_parser_typ: str = "DEFAULT"
    """
    The type of content parser to use. 'DEFAUT' means using cropping_strategy for documents, which can be 'PLUMBER', 'OPENAI', 'GROUNDED_LLM', etc.
    """

    content_parser_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the content parser.
    """

    get_surrounding_text_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "current_bbox_typ": "TABLE",
            "extract_bbox_with_offsets": [-3, -2, -1, 1, 2, 3],
            "extract_bbox_with_type": ["CAPTION", "PLAIN", "HEADER", "LIST"],
            "enable_cross_page_search": False,
        }
    )
    """
    The keyword arguments for the get_surrounding_text component. See GetSurroundingTextSpec for details.
    """

    title_finder_typ: str = "LOCALITY"
    """
    The type of title finder to use.
    """

    title_finder_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "current_bbox_typ": ["TABLE"],
            "search_bbox_with_offsets": [-1, 1, -2, 2, -3, 3],
            "target_bbox_type": "HEADER",
            "bbox_types_to_search_for": ["HEADER", "CAPTION", "PLAIN"],
            "enable_cross_page_search": False,
        }
    )

    verbal_typ: str = "OPENAI"
    """
    The type of verbalizer to use. Can also use NULL (just output empty string).
    """

    verbal_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments for the verbalizer. See individual verbalizer classes for details.
    """

    chunker_typ: str = "LONG_CHAIN"
    """
    The type of chunker to use.
    """

    chunker_kwargs: Dict[str, Any] = dc.field(
        default_factory=lambda: {
            "column_to_chunk": "verbalization",
            "split_overlap": 100,
        }
    )
    """
    The keyword arguments for the chunker. See individual chunker classes for details.
    """


@dc.dataclass(frozen=True)
class LayoutParserCfg:
    """
    A specification for a layout parser.
    """

    layout_model_typ: str = "VGT"
    """
    The type of layout model to use. Default to vgt layout model because it has been the most mature.
    """

    layout_model_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    """
    The keyword arguments to pass to the layout model.
    See individual layout model for the list of supported keyword arguments.
    """

    post_process: List[str] = dc.field(
        default_factory=lambda: [
            "FILTER_DOC",
            "UNION_BOX",
            "NO_OVERLAP",
            "ORDER_BY_GRID(grid_step=32)",
            "TO_MARKDOWN_CLASS",
            "MERGE_LIST",
            "MERGE_MANY_THING_BY_COLUMN",
            "RESOLVE_CLASS_CONFLICT(iou_threshold=0.85)",
            "REMOVE_CONTAINED_BOXES(containment_threshold=0.9)",
            "MERGE_TEXT_UNDER_HEADER",
        ]
    )
    """
    The list of post-processing steps to apply to the layout model output.
    """


def layout_parser_pipeline(spec: LayoutParserCfg):
    """
    The overall flow for parsing layout is as follows:

    1. Parse the layout of the document using the layout model.
    2. Post-process the layout using the post-processing pipeline.
    """

    from mew3.layout import LayoutModel

    return Chain(
        [
            LayoutModel.factory(spec.layout_model_typ, **spec.layout_model_kwargs),
            ExecPipe(spec.post_process),
        ]
    )


def image_parser_pipeline(cfg: ImageParserCfg, /):
    from mew3.component import CaptionFinder, GetSurroundingText, ImageVerbal
    from mew3.component.image import image_extract, save_image_c3

    return ExecPipe(
        [
            Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
            GetSurroundingText(**cfg.get_surrounding_text_kwargs),
            CaptionFinder.factory(cfg.caption_finder_typ, **cfg.caption_finder_kwargs),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            image_extract,
            ImageVerbal.factory(cfg.verbal_typ, **cfg.verbal_kwargs),
            save_image_c3,
            Tag(column="parser", tag="IMAGE"),
        ]
    )


def table_parser_pipeline(cfg: TableParserCfg, /):
    from mew3.component import (
        CaptionFinder,
        GetSurroundingText,
        TableContent,
        TableVerbal,
        TextChunker,
        csv_extract,
        save_csv_c3,
        save_table_image_c3,
        table_image_extract,
    )

    return ExecPipe(
        [
            Mark(column="markdown_class", target="to_parse", function=lambda key: key in cfg.parse),
            GetSurroundingText(**cfg.get_surrounding_text_kwargs),
            CaptionFinder.factory(cfg.title_finder_typ, **cfg.title_finder_kwargs),
            Rename(source="caption", target="title"),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            TableContent.factory(cfg.content_parser_typ, **cfg.content_parser_kwargs),
            table_image_extract,
            csv_extract,
            TableVerbal.factory(cfg.verbal_typ, **cfg.verbal_kwargs),
            TextChunker.factory(cfg.chunker_typ, **cfg.chunker_kwargs),
            save_table_image_c3,
            save_csv_c3,
            Tag(column="parser", tag="TABLE"),
        ]
    )


def text_parser_pipeline(cfg: TextParserCfg, /):
    """
    The overall flow for parsing text components is as follows:

    1. Extract text from the document using the extractor.
    2. Chunk the extracted text using the chunker.

    The extractor and chunker are specified in the spec.
    """

    from mew3.component import TextChunker, TextExtractor

    return ExecPipe(
        execs=[
            Filter(column="markdown_class", function=lambda key: key in cfg.contextual),
            TextExtractor.factory(cfg.ext_typ, **cfg.ext_kwargs),
            TextChunker.factory(cfg.chunk_typ, **cfg.chunk_kwargs),
            Filter(column="markdown_class", function=lambda key: key in cfg.parse),
            Tag(column="parser", tag="TEXT"),
        ]
    )


@dataclass(frozen=False)
class SourceFileParser:
    """
    This is a parser whose output is consitent with TextComponent,
    ImageComponent, and TableComponent from GenAi Base.
    This parser is expected to be called by Genai.SourceFile.Chunker.Mew3.doChunkFilesBatch()

    Examples:
        ```python
        parser = SourceFileParser(
            layout_parser_spec={},
            text_parser_spec={},
            text_parser_spec={},
            image_parser_spec={},
        )
        ```
    """

    layout_parser_spec: Dict[str, Any]
    text_parser_spec: Dict[str, Any] | None = field(default_factory=dict)
    table_parser_spec: Dict[str, Any] | None = field(default_factory=dict)
    image_parser_spec: Dict[str, Any] | None = field(default_factory=dict)

    def __post_init__(self):
        # triggers the cached_property and creates actual_cfg for inspection
        _ = self.layout_parser
        _ = self.text_parser
        _ = self.table_parser
        _ = self.image_parser

    def to_dict(self):
        return asdict(self)

    def __repr__(self):
        return json.dumps(self.cfg_to_dict(), indent=4)

    def __rich__(self):
        from rich.pretty import Pretty

        return Pretty(self.cfg_to_dict())

    def explain(self, kwargs: Dict[str, Any] | None = None):
        kwargs = kwargs or {"doc": True, "color": "solarized-light"}

        children = {
            "LayoutParser": self.layout_parser,
            "TextParser": self.text_parser,
            "TableParser": self.table_parser,
            "ImageParser": self.image_parser,
        }

        for key, val in children.items():
            print(f"{key} pipeline:")
            val.explain(kwargs)

    def cfg_to_dict(self):
        return {
            "LayoutParserCfg": (asdict(self.actual_layout_cfg) if self.actual_layout_cfg else None),
            "TextParserCfg": (asdict(self.actual_text_cfg) if self.actual_text_cfg else None),
            "TableParserCfg": (asdict(self.actual_table_cfg) if self.actual_table_cfg else None),
            "ImageParserCfg": (asdict(self.actual_image_cfg) if self.actual_image_cfg else None),
        }

    def __call__(self, document: PageDoc) -> dict | None:
        """
        Parse the document using the specified parser inference settings.

        Args:
            document: The document to be parsed.
        Returns:
            The result of parsing the document, including parsed components
                and any relevant logs generated during the parsing process.
        """

        layout_bboxes = self.custom_pipeline(document)

        # parser will be None if spec is None
        parser_config = {
            "text": (self.text_parser, self.text_parser_spec),
            "table": (self.table_parser, self.table_parser_spec),
            "image": (self.image_parser, self.image_parser_spec),
        }

        self.list_components = []
        for _, (parser_func, parser_spec) in parser_config.items():
            if parser_spec is not None:
                if component := parser_func(layout_bboxes):
                    self.list_components.extend(component.to_records(with_ids=True))

        # store info for debugging
        document_info = {
            "file_info": {
                "filename": layout_bboxes.document.filename,
                "fname": layout_bboxes.document.name,
                "filetype": layout_bboxes.document.type,
                "rel_scale": layout_bboxes.document.rel_scale,
                "dpi": layout_bboxes.document.dpi,
            },
            "full_specs": self.cfg_to_dict(),
            "cropping_strategy": {
                "text_crop": document.text_crop,
                "image_crop": document.image_crop,
                "table_crop": document.table_crop,
                "page_cnt": document.page_cnt,
                "grid_gen": document.grid_gen,
            },
        }

        # create components for SourcePassage
        remote_json_path = ""
        if not c3_not_set():
            buffer = io.StringIO()
            json.dump(document_info, buffer, indent=4)
            buffer.seek(0)

            unique_id = str(uuid.uuid4())
            remote_json_path = f"mew3_parsed/document_info/{document_info['file_info']['fname'].split('.')[0]}_info__uniqueid_{unique_id}.json"
            c3_ctx().FileSystem.uploadFile(srcFile=buffer, dstPath=remote_json_path)

        for item in self.list_components:
            item["text"] = item.get("text", "")
            item["chunked"] = item.get("chunked", [])

            if item["parser"] == "TEXT":
                item["description_for_vectorstore"] = item["chunked"]

            elif item["parser"] == "TABLE":
                item["surrounding_text"] = item.get("surrounding_text", "")
                item["title"] = item.get("title", "")
                item["verbalization"] = item.get("verbalization", "")
                item["csv"] = item.get("csv", "")
                item["csv_url_c3"] = item.get("csv_url_c3", "")
                item["table_image_url_c3"] = item.get("table_image_url_c3", "")
                item["description_for_vectorstore"] = [
                    f"Title: {item['title']}; Text: {piece}" for piece in item["chunked"]
                ]

            elif item["parser"] == "IMAGE":
                item["surrounding_text"] = item.get("surrounding_text", "")
                item["caption"] = item.get("caption", "")
                item["verbalization"] = item.get("verbalization", "")
                item["image_url_c3"] = item.get("image_url_c3", "")
                item["description_for_vectorstore"] = (
                    f"Caption: {item['caption']}; Verbalization: {item['verbalization']}"
                )

            rel_scale = layout_bboxes.document.rel_scale
            doc_shape = np.shape(layout_bboxes.document.page_contents[item["page"]])

            item["scaled_x_1"] = item["x_1"] * rel_scale
            item["scaled_y_1"] = item["y_1"] * rel_scale
            item["scaled_x_2"] = item["x_2"] * rel_scale
            item["scaled_y_2"] = item["y_2"] * rel_scale
            item["doc_height_px"] = doc_shape[0]
            item["doc_width_px"] = doc_shape[1]
            item["document_info_url_c3"] = remote_json_path

        # sort by page, then by y_1, then by x_1
        self.list_components = sorted(self.list_components, key=lambda x: (x["page"], x["scaled_y_1"], x["scaled_x_1"]))

        return {
            "document_info": document_info,
            "list_components": self.list_components,
        }

    @cached_property
    def custom_pipeline(self):
        from mew3.decltype import Chain, Range

        layout_output = Chain(
            [
                self.layout_parser,
                Range("global_idx"),
            ]
        )

        return layout_output

    @cached_property
    def layout_parser(self):
        self.actual_layout_cfg = LayoutParserCfg(**self.layout_parser_spec)

        return layout_parser_pipeline(self.actual_layout_cfg)

    @cached_property
    def text_parser(self):
        if self.text_parser_spec is None:
            self.actual_text_cfg = None
            return None

        self.actual_text_cfg = TextParserCfg(**self.text_parser_spec)

        return text_parser_pipeline(self.actual_text_cfg)

    @cached_property
    def table_parser(self):
        if self.table_parser_spec is None:
            self.actual_table_cfg = None
            return None

        self.actual_table_cfg = TableParserCfg(**self.table_parser_spec)

        return table_parser_pipeline(self.actual_table_cfg)

    @cached_property
    def image_parser(self):
        if self.image_parser_spec is None:
            self.actual_image_cfg = None
            return None

        self.actual_image_cfg = ImageParserCfg(**self.image_parser_spec)
        return image_parser_pipeline(self.actual_image_cfg)
