# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from datetime import datetime
from typing import TYPE_CHECKING, Literal

from .api import LayoutExec, LayoutExecSpec

if TYPE_CHECKING:
    from mew3.core import DocBboxes


@dc.dataclass(frozen=True)
class LogTimeSpec(LayoutExecSpec):
    format: Literal["iso"] = "iso"


class LogTime(LayoutExec, spec_class=LogTimeSpec):
    def __post_init__(self):
        if self.spec.format != "iso":
            raise ValueError("Only iso format is supported")

    def execute(self, dbb: DocBboxes) -> DocBboxes:
        print(datetime.now().isoformat())
        return dbb
