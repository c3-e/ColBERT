# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from enum import Enum
from typing import Any, Dict, List, Mapping, Sequence, Tuple, final

from typing_extensions import Self


class DeltaKind(Enum):
    ADD = "+"
    REMOVE = "-"
    REQUIRE = "."

    def __eq__(self, other) -> bool:
        if isinstance(other, DeltaKind):
            return self.value == other.value

        if isinstance(other, str):
            return self.value == other

        return NotImplemented


@final
@dc.dataclass(frozen=True, repr=False)
class Delta(Mapping[str, Any]):
    """
    Returns the column changes for the `DocBboxes` object,
    once processed.

    This should return a tuple of strings, with the rules as follows:

    1. If a column is added, the column name should be prefixed with `+` ("+a" means addig a column "a", and "a" must not be present before).
    2. If a column is removed, the column name should be prefixed with `-` ("-b" means removing a column "b", and "b" must be present before).
    3. If a column is required, the column name should be prefixed with `@` (".c" means column "c" must be present, and possibly modified).

    If nothing is given (returns an empty tuple), it means that type checks are disabled.
    """

    deltas: Dict[str, DeltaKind] = dc.field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.deltas)

    def __post_init__(self) -> None:
        for column, kind in self.deltas.items():
            if not isinstance(column, str):
                raise ValueError(f"Invalid column name: {column}")

            if not isinstance(kind, DeltaKind):
                raise ValueError(f"Invalid delta kind: {kind}")

    def __repr__(self):
        args = ", ".join(f"{kind.value}{column}" for column, kind in self.deltas.items())
        return "∆(" + args + ")"

    def __iter__(self):
        return iter(self.deltas)

    def __contains__(self, column: str) -> bool:
        return column in self.deltas

    def __getitem__(self, column: str) -> DeltaKind:
        return self.deltas[column]

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, Delta):
            return self.deltas == other.deltas

        if isinstance(other, Mapping):
            return dict(self.deltas) == dict(other)

        if isinstance(other, Sequence):
            try:
                parsed = Delta.parse(other)
            except ValueError:
                return NotImplemented

            return self == parsed

        return NotImplemented

    def __call__(self, columns: List[str]):
        result_set = set(columns)

        for key, kind in self.deltas.items():
            if kind == "+":
                result_set.add(key)

            if kind == "-":
                try:
                    result_set.remove(key)
                except KeyError as ke:
                    raise ValueError(f"Column {key} must be present") from ke

            if kind == ".":
                if key not in result_set:
                    raise ValueError(f"Column {key} must be present")

        return sorted(result_set)

    def __iadd__(self, column: str) -> Delta:
        self.deltas.update({column: DeltaKind.ADD})
        return self

    def __isub__(self, column: str) -> Delta:
        self.deltas.update({column: DeltaKind.REMOVE})
        return self

    def __imatmul__(self, column: str) -> Delta:
        self.deltas.update({column: DeltaKind.REQUIRE})
        return self

    @classmethod
    def parse(cls, delta: Delta | List[str] | Tuple[str, ...], /) -> Self:
        if isinstance(delta, Delta):
            return delta

        if not isinstance(delta, (list, tuple)) or not all(isinstance(item, str) for item in delta):
            raise ValueError(
                f"Invalid delta object: {delta}. Must be a `Delta` object or a list of strings or a tuple of strings"
            )

        return cls({column: sign for column, sign in map(_parse_item, delta)})

    def concatenate(self, other: Delta) -> Delta:
        if not isinstance(other, Delta):
            return NotImplemented

        result_dict = {**self.deltas}

        for key in other:
            if result_dict.get(key) == other[key] == "+":
                raise ValueError("Cannot add a column that is already added")

            if result_dict.get(key) == "-":
                if other[key].value in "-.":
                    raise ValueError(f"Cannot remove or require a column ({key}) that is already removed")

            if key not in result_dict:
                result_dict[key] = other[key]

        return Delta(result_dict)

    __and__ = concatenate

    def merge(self, other: Delta):
        if not isinstance(other, Delta):
            return NotImplemented

        for key in self.keys() & other.keys():
            if not (self[key] == other[key] == "."):
                raise ValueError(
                    f"Cannot merge conflicting deltas for column {key}. "
                    "Colliding keys only allowed if both require the column"
                )

        return Delta({**self.deltas, **other.deltas})

    __or__ = merge


def _parse_item(item: str) -> Tuple[str, DeltaKind]:
    if item[0] not in {"+", "-", "."}:
        raise ValueError(f"Invalid delta item: {item}")

    return item[1:], DeltaKind(item[0])
