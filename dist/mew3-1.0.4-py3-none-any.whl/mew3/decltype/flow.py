# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import logging
from functools import cached_property, reduce
from typing import TYPE_CHECKING, Callable, Dict, List, Type, TypeVar

import numpy as np

from mew3.specs import CompatibleKindAndKwargs, HasRegistry, UnparsableError, signature_parse

from .api import LayoutExec, LayoutExecSpec, LayoutModule, LayoutModuleSpec
from .delta import Delta

if TYPE_CHECKING:
    from mew3.core import DocBboxes

    D = TypeVar("D", bound=DocBboxes)

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)


@dc.dataclass(frozen=True)
class ChainSpec(LayoutModuleSpec):
    items: List[LayoutModule] = dc.field(default_factory=list)
    """
    The list of post-processing functions, would be processed in order.
    """

    stage_names: List[str] | None = None
    """
    The names of the post-processing functions.
    If given, it must be of the same length as `items`.
    """

    def __post_init__(self):
        if self.stage_names is not None:
            if len(self.stage_names) != len(self.items):
                raise ValueError("Names must be of the same length as items.")

    def delta_columns(self):
        return reduce(
            lambda x, y: x & y,
            [Delta.parse(i.spec.delta_columns()) for i in self.items],
            Delta(),
        )


class Chain(LayoutModule, spec_class=ChainSpec):
    """
    A chain of post-processing functions.

    items: List[LayoutModule]
        The list of post-processing functions, in calling order.

        Together the items would form a pipeline,
        and called in the order they are listed.

        It resembles something like this:
        ```python
        for f in items:
            result = f(result)
        ```

    stage_names: List[str] | None = None
        The names of the stages.
        If given, it must be of the same length as `items`.
    """

    def forward(self, item):
        return reduce(lambda x, y: y(x), self.spec.items, item)

    def children(self):
        if self.spec.stage_names is not None:
            yield from zip(self.spec.stage_names, self.spec.items)
        else:
            yield from self.spec.items


@dc.dataclass(frozen=True)
class ExecPipeSpec(LayoutExecSpec):
    """
    The base class for all pipelines.

    A pipeline is a component that takes a document and processes it through a series of steps.
    """

    execs: List[CompatibleKindAndKwargs | LayoutExec | Callable]
    """
    The list of post-processing functions.
    """

    factory_type: Type[LayoutExec] = LayoutExec
    """
    The base class to look up the factory method.
    """

    @cached_property
    def _pipeline(self) -> List[LayoutExec]:
        """
        Construct the post-processing pipeline.
        """

        pipeline: List[LayoutExec] = []

        for pp in self.execs:
            if isinstance(pp, self.factory_type):
                LOGGER.info("Adding subtype object: %s to pipeline", pp)
                pipeline.append(pp)
                continue

            if callable(pp):
                LOGGER.info("Adding function: %s to pipeline", pp)
                pp = self.factory_type.register()(pp)
                pipeline.append(pp)
                continue

            try:
                result = signature_parse(pp)
                step = self.factory_type.factory(result.kind, **result.kwargs)

                LOGGER.info("Adding factory object: %s to pipeline. Config: %s", step, pp)
                pipeline.append(step)
            except UnparsableError as upe:
                raise ValueError(f"Invalid processing step {pp}.") from upe

        return pipeline

    def delta_columns(self):
        return reduce(
            lambda x, y: x & y,
            [Delta.parse(exec.spec.delta_columns()) for exec in self._pipeline],
            Delta(),
        )

    @cached_property
    def chain(self):
        return Chain(self._pipeline)

    def delta_columns(self):
        return self.chain.spec.delta_columns()


class ExecPipe(LayoutExec, spec_class=ExecPipeSpec):
    """
    The pipeline for post-processing functions.

    Examples:
        >>> # If both post-processing functions are registered functions (not objects)...
        ... # Calls `LayoutExec.factory("MY_POST_PROC")` and `LayoutExec.factory("MY_OTHER_POST_PROC")`
        ... post_proc = ExecPipe(["MY_POST_PROC", "MY_OTHER_POST_PROC"])

        >>> # If one of the post-processing functions is an object...
        ... # Calls `LayoutExec.factory("MY_OTHER_POST_PROC", arg1=1, arg2=2)` for the second function.
        ... post_proc = ExecPipe([
        ...     {"kind": "MY_POST_PROC", "kwargs": {}},
        ...     ("MY_OTHER_POST_PROC", {"arg1": 1, "arg2": 2}),
        ... ])
    """

    def __post_init__(self):
        if not isinstance(self.spec.execs, list):
            raise ValueError("Execs must be a list.")

        if not isinstance(self.spec.factory_type, type):
            raise ValueError("Base must be a type.")

        if not isinstance(self.spec.factory_type, HasRegistry):
            raise ValueError("Base must have the `__registry__` attribute.")

        if not hasattr(self.spec.factory_type, "factory"):
            raise ValueError("Base must have a `factory` method.")

    def execute(self, output: DocBboxes) -> DocBboxes:
        return self.spec.chain(output)

    def children(self):
        yield from self.spec._pipeline


@dc.dataclass(frozen=True)
class SplitAndMergeSpec(LayoutExecSpec):
    column: str
    categories: List[str]
    execs: List[LayoutExec]

    def children(self):
        for exec in self.execs:
            yield exec.spec


class SplitAndMerge(LayoutExec, spec_class=SplitAndMergeSpec):
    def __post_init__(self):
        if len(self.spec.execs) != len(self.spec.categories):
            raise ValueError("Number of execs and categories must be the same")

    def execute(self, dbb: D) -> D:
        from mew3.core import DocBboxes

        column: str = self.spec.column
        cats = self.spec.categories

        if column not in dbb.keys():
            raise KeyError("Column not found in DocBboxes")

        if diff := set(cats).difference(dbb.data.df[column].unique().tolist()):
            raise ValueError(f"Categories {diff} not found in DocBboxes")

        executed: List[D] = []
        for cat, exec in zip(cats, self.spec.execs):
            filt = dbb.where(np.flatnonzero(dbb.data.df[column] == cat))
            result = exec(filt)
            executed.append(result)
        return DocBboxes.concat(*executed)


@dc.dataclass(frozen=True)
class DuplicateAndMergeSpec(LayoutExecSpec):
    execs: Dict[str, LayoutExec]


class DuplicateAndMerge(LayoutExec, spec_class=DuplicateAndMergeSpec):
    def __post_init__(self):
        if len(self.spec.execs) != len(self.spec.categories):
            raise ValueError("Number of execs and categories must be the same")

    def execute(self, dbb: D) -> D:
        from mew3.core import DocBboxes

        executed: List[D] = []
        for exec in self.spec.execs.values():
            result = exec(dbb)
            executed.append(result)
        return DocBboxes.concat(*executed)

    def children(self):
        yield from self.spec.execs.items()
