# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import List

import pandas as pd

from mew3.core import DocBboxes
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.specs import factorize


@dc.dataclass(frozen=True)
class TextChunkerSpec(LayoutExecSpec, ABC):
    column_to_chunk: str = "text"
    chunked_column: str = "chunked"
    split_length: int = 500


@factorize(TextChunkerSpec)
class TextChunker(LayoutExec, ABC, spec_class=TextChunkerSpec):
    """
    The base class for all text chunkers.

    A text chunker is a component that takes a text and chunks it into smaller text blocks.

    NOTE:
        Currently `chunk` only works on 1 text at a time,
        maybe make it batched.
    """

    def execute(self, bboxes: DocBboxes) -> DocBboxes:
        column = bboxes[self.spec.column_to_chunk]
        result = pd.Series(column.apply(self.chunk))
        bboxes[self.spec.chunked_column] = result
        return bboxes

    @abstractmethod
    def chunk(self, text: str) -> List[str]:
        pass
