# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from typing import List

from .api import TextChunker, TextChunkerSpec


@dc.dataclass(frozen=True)
class NullSpec(TextChunkerSpec):
    pass


class Null(TextChunker, spec_class=NullSpec):
    """
    A null chunker that does not chunk the text at all (returns an empty list).
    This is used for testing purposes.
    """

    def chunk(self, text: str) -> List[str]:
        return []
