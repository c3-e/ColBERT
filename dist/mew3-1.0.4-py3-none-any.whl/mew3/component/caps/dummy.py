# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass
from typing import List

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.document import PageDoc

from .api import CaptionFinder, CaptionFinderSpec


@dataclass(frozen=True)
class DummySpec(CaptionFinderSpec):
    pass


class Dummy(CaptionFinder, spec_class=DummySpec):
    def _parse(
        self, document: PageDoc, bounding_boxes: LayoutParserOutput, current_bbox_typ: List[str]
    ) -> List[List[str]]:
        lol = bounding_boxes.to_list_of_list()
        return [["" for _ in l] for l in lol]
