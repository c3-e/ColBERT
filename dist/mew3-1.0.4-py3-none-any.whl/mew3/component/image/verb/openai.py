# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from mew3.ctx import c3_not_set
from mew3.providers import C3GenaiCoreLLM, OpenaiProvider, vlm

from .api import ImageVerbal, ImageVerbalSpec


@dc.dataclass(frozen=True)
class OpenaiSpec(ImageVerbalSpec):
    model: str = "gpt-4o"
    """
    Necessary is using GenaiCore LLM.
    """

    max_tokens: int = 4096
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a good image verbalizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = """
    Given the image, provide a brief description of its contents. Also, highlight important values and keywords.
    The following extracted information from the page can assist with your verbalization:

    {caption_prompt}

    {context_awareness_prompt}

    Your output:"""

    """
    The user prompt to use for the table verbalization.
    """

    def delta_columns(self):
        return (".image", "+verbalization")


class Openai(ImageVerbal, spec_class=OpenaiSpec):
    """
    Use LLM for image verbalization.
    Input: image, image caption, surrounding text (optional). Output: verbalization.
    """

    def _call(self, box: dict):
        if "caption" in box:
            caption_prompt = f"=== Image Caption ===\n\n{box['caption']}"
        else:
            caption_prompt = ""

        if "surrounding_text" in box:
            context_awareness_prompt = f"=== Parsed text surrounding the image ===\n\n{box['surrounding_text']}"
        else:
            context_awareness_prompt = ""

        prompt = self.spec.user_text_prompt.format(
            caption_prompt=caption_prompt,
            context_awareness_prompt=context_awareness_prompt,
        )

        return self.vlm(prompt, box["image"])

    @property
    def vlm(self):
        if c3_not_set():
            return vlm(
                OpenaiProvider(
                    max_tokens=self.spec.max_tokens,
                    system_prompt=self.spec.system_prompt,
                )
            )

        else:
            return vlm(
                C3GenaiCoreLLM(
                    model=self.spec.model,
                    max_tokens=self.spec.max_tokens,
                    system_prompt=self.spec.system_prompt,
                )
            )
