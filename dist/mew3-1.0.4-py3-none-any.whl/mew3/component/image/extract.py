# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import io
from typing import List

import numpy as np
from numpy.typing import NDArray
from PIL import Image

from mew3.core import BoundingBox, DocBboxes
from mew3.ctx import c3_ctx, c3_not_set
from mew3.decltype import LayoutExec


@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", "+image"])
def image_extract(bboxes: DocBboxes) -> DocBboxes:
    doc = bboxes.document

    bbxs: List[BoundingBox] = [
        BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in bboxes.to_records()
    ]
    pages: List[int] = bboxes["page"].to_numpy().tolist()
    imgs: List[NDArray] = [np.array(doc.pages[p].crop_image(b)) for b, p in zip(bbxs, pages)]

    bboxes["image"] = imgs
    return bboxes


@LayoutExec.register(delta_columns=[".image"])
def save_image_c3(bboxes: DocBboxes) -> DocBboxes:
    if c3_not_set():
        return bboxes

    records = bboxes.to_records()
    ids = [r["__id__"] for r in bboxes.to_records(with_ids=True)]
    fname = bboxes.document.filename.split("/")[-1].split(".pdf")[0]

    all_urls = []
    for i, r in enumerate(records):
        if "image" in r.keys() and type(r["image"]) == np.ndarray:
            image = Image.fromarray(r["image"])
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            buffer.seek(0)

            remote_img_path = f"mew3_parsed/images/{fname}/page_{r['page']}_gidx_{r['global_idx']}_id_{ids[i]}.png"
            c3_ctx().FileSystem.uploadFile(srcFile=buffer, dstPath=remote_img_path)

            all_urls.append(remote_img_path)
        else:
            all_urls.append("")

    bboxes["image_url_c3"] = all_urls

    return bboxes
