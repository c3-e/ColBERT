# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from abc import ABC, abstractmethod
from dataclasses import dataclass

from mew3.core import DocBboxes
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.document import PageDoc
from mew3.specs import factorize


@dataclass(frozen=True)
class TableContentSpec(LayoutExecSpec, ABC):
    def delta_columns(self):
        return ("+text",)


@factorize(TableContentSpec)
class TableContent(LayoutExec, ABC, spec_class=TableContentSpec):
    """
    The base class for all table content parsers.
    """

    def execute(self, bboxes: DocBboxes) -> DocBboxes:
        """
        The table content parser.

        Args:
            bboxes: The bounding boxes of the table.

        Returns:
            The bounding boxes of the table content.
        """

        packed = [self._call(bboxes.document, b) for b in bboxes.to_records()]

        bboxes["text"] = packed
        return bboxes

    @abstractmethod
    def _call(self, document: PageDoc, box: dict, /) -> str:
        pass
