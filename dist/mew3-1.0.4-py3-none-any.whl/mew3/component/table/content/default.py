# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from mew3.core import BoundingBox
from mew3.document import PageDoc

from .api import TableContent, TableContentSpec


@dc.dataclass(frozen=True)
class DefaultSpec(TableContentSpec):
    """
    The specification for the pdfplumber-based table content parser.
    """


class Default(TableContent, spec_class=DefaultSpec):
    """
    A pdfplumber-based table content parser, using the cropping utilities of the Document directly.
    """

    def _call(self, document: PageDoc, box: dict) -> str:
        curr_box = BoundingBox(x_1=box["x_1"], x_2=box["x_2"], y_1=box["y_1"], y_2=box["y_2"])
        return document.page_contents[box["page"]].crop_table(curr_box)
