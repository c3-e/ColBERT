# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from .api import TableVerbal, TableVerbalSpec


@dc.dataclass(frozen=True)
class NullSpec(TableVerbalSpec):
    """
    Spec for verbalizer that does nothing and returns an empty string.
    """


class Null(TableVerbal, spec_class=NullSpec):
    def _call(self, box: dict) -> str:
        """
        Verbalization that serves as a default for images,
        which does nothing and use an empty string as verbalization.

        Args:
            box: The input bbox as a dict.

        Returns:
            An empty string.
        """

        return ""
