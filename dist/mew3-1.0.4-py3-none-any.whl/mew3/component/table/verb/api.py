# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod

from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.layout import LayoutParserOutput
from mew3.specs import factorize


@dc.dataclass(frozen=True)
class TableVerbalSpec(LayoutExecSpec, ABC):
    def delta_columns(self):
        return ("+verbalization", ".title", ".text", ".x_1", ".y_1", ".x_2", ".y_2")


@factorize(TableVerbalSpec)
class TableVerbal(LayoutExec, ABC, spec_class=TableVerbalSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        verbalized = [self._call(item) for item in output.to_records()]
        output["verbalization"] = verbalized
        return output

    @abstractmethod
    def _call(self, box: dict) -> str:
        """
        Verbalize the bbox component. This bbox typically be a TABLE in markdown_class.

        Args:
            box: The bbox as a dict.

        Returns:
            The verbalization of the image.
        """
