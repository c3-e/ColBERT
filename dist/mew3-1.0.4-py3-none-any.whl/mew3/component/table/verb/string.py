# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from .api import TableVerbal, TableVerbalSpec


@dc.dataclass(frozen=True)
class TitleAndContentSpec(TableVerbalSpec):
    def delta_columns(self):
        return (".text", "+verbalization")


class TitleAndContent(TableVerbal, spec_class=TitleAndContentSpec):
    """
    Use concatenated string as table verbalization. No LLM.
    Input: table title (optional), content text (required). Output: verbalization.
    """

    def _call(self, box: dict):
        title_string = f"=== Title ===\n\n{box['title']}".strip() if "title" in box else ""
        context_string = (
            f"=== Parsed surrounding text ===\n\n{box['surrounding_text']}".strip() if "surrounding_text" in box else ""
        )

        output_string = (
            f"""{title_string}\n\n{context_string}\n\n"""
            f"""=== Extracted table content ===\n\n{box["text"].strip()}""".strip()
        )

        return output_string
