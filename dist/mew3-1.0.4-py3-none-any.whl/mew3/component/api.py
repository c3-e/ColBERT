# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic, Tuple, TypeVar

from mew3.core import BoundingBox
from mew3.core import DocBboxes
from mew3.core import DocBboxes as LayoutParserOutput
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.layout import MarkdownClass
from mew3.specs import factorize

if TYPE_CHECKING:
    from typing_extensions import TypeIs


@dataclass(frozen=True)
class Component:
    """
    The base component class represents a document component. This contains the common attributes for all
    document components.
    """

    page: int
    """The document page this bounding box is in."""

    global_idx: int
    """
    The index of the bounding box within the page.
    """

    bbox: BoundingBox
    """The bounding box of the component."""


@dataclass(frozen=True)
class ComponentParserOutputItem(Component, ABC):
    """
    The base component parser output class.
    """

    @property
    def x_1(self) -> float:
        return self.bbox.x_1

    @property
    def x_2(self) -> float:
        return self.bbox.x_2

    @property
    def y_1(self) -> float:
        return self.bbox.y_1

    @property
    def y_2(self) -> float:
        return self.bbox.y_2

    @property
    @abstractmethod
    def description_for_vectorstore(self) -> str:
        """
        A description of the component for the vector store.

        Returns:
            The description of the component for the vector store.
        """

    @property
    @abstractmethod
    def parser(self) -> str:
        """
        The parser that parsed this component.
        """


@dataclass(frozen=True)
class ComponentParserSpec(LayoutExecSpec, ABC):
    """
    The base parser specification class.
    """

    contextual: Tuple[MarkdownClass, ...]
    """
    The contextual classes that the parser can parse.
    """

    parse: Tuple[MarkdownClass, ...]
    """
    The classes that the parser can parse.
    """

    def __post_init__(self):
        if not is_tuple_of_str(self.contextual):
            raise TypeError(f"contextual must be a tuple of strings. Got {self.contextual}.")

        if not is_tuple_of_str(self.parse):
            raise TypeError(f"parse must be a tuple of strings. Got {self.parse}.")


def is_tuple_of_str(tos: Tuple[str, ...]) -> TypeIs[Tuple[str, ...]]:
    return isinstance(tos, tuple) and all(isinstance(cls, str) for cls in tos)


_S = TypeVar("_S", bound=ComponentParserSpec)
_C = TypeVar("_C", bound=ComponentParserOutputItem)


@factorize(ComponentParserSpec)
class ComponentParser(
    Generic[_S, _C], LayoutExec, ABC, spec_class=ComponentParserSpec
):  # interface for all parsing workstreams
    """
    The interface for all component-wise parsing workstreams.

    Parsers are responsible for both choosing which components to parse and parsing the content of the document.

    To choose which components to parse, the parser should define `CONTEXTUAL` and `PARSE` classvars,
    where it should return a list of component classes that the parser can parse.

    To parse the content of the document, the parser should implement the `parse` method,
    where it should return the parsed content, based on a given document and bounding boxes that contains only classes in the list returned by `PARSE`.
    """

    def execute(self, bboxes: DocBboxes, /) -> DocBboxes:
        """
        Parses the content of the document.

        Parameters:
            bboxes: The bounding boxes of the document.

        Returns:
            The parsed content stored in a `Graphrame`.
        """

        if not isinstance(bboxes, DocBboxes):
            raise TypeError(f"bounding_boxes must be of type DocBboxes, not {type(bboxes)}")

        filtered = bboxes.filter("markdown_class", lambda x: x in set(self.spec.contextual))
        return self.parse(filtered)

    @abstractmethod
    def parse(self, filtered: LayoutParserOutput, /) -> LayoutParserOutput:
        """
        Parses the content of the document.

        Parameters:
            bounding_boxes: The bounding boxes of the document.
            unfiltered: The bounding boxes of the document that contains all classes.

        Returns:
            The parsed content.
        """
