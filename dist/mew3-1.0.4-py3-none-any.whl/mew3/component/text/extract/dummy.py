# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass

from mew3.core import DocBboxes

from .api import TextExtractor, TextExtractorSpec


@dataclass(frozen=True)
class DummySpec(TextExtractorSpec):
    pass


class Dummy(TextExtractor, spec_class=DummySpec):
    def execute(self, original: DocBboxes) -> DocBboxes:
        return original
