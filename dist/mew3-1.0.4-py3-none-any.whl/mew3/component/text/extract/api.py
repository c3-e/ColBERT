# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import Tuple

from mew3.core import DocBboxes as LayoutParserOutput
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.specs import factorize


@dc.dataclass(frozen=True)
class TextExtractorSpec(LayoutExecSpec, ABC):
    contextual: Tuple[str, ...] = "HEADER", "PLAIN", "LIST"
    parse: Tuple[str, ...] = "HEADER", "PLAIN", "LIST"


@factorize(TextExtractorSpec)
class TextExtractor(LayoutExec, ABC, spec_class=TextExtractorSpec):
    """
    An abstract class for extracting text from a document.
    """

    @abstractmethod
    def execute(self, original: LayoutParserOutput) -> LayoutParserOutput:
        pass
