# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import pickle
from typing import Any

c3: Any


def execute(bboxes):
    from mew3 import set_c3

    set_c3(c3)

    unpickled = pickle.loads(bboxes)
    mod = pickle.loads(c3.Genai.SourceFile.Chunker.MultimodalExtractionWorkflow3.Config.getConfig()["mod"])
    result = mod(unpickled)
    return pickle.dumps(result)
