# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import pickle

from mew3.ctx import c3_ctx
from mew3.decltype import LayoutExec, LayoutExecSpec


@dc.dataclass(frozen=True)
class C3ExecutorSpec(LayoutExecSpec):
    executor: LayoutExec


class RunInC3(LayoutExec, spec_class=C3ExecutorSpec):
    def execute(self, input):
        c3_ctx().Genai.SourceFile.Chunker.MultimodalExtractionWorkflow3.Executor.Config.setConfig(
            "function", pickle.dumps(self.spec.executor)
        )

        input = pickle.dumps(input)
        output = c3_ctx().Genai.SourceFile.Chunker.MultimodalExtractionWorkflow3.Executor.run(input)
        output = pickle.loads(output)
        return output
