# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import pickle

from mew3.ctx import c3_ctx
from mew3.decltype import LayoutProducer, LayoutProducerSpec


@dc.dataclass(frozen=True)
class C3ProducerSpec(LayoutProducerSpec):
    producer: LayoutProducer


class RunInC3(LayoutProducer, spec_class=C3ProducerSpec):
    def execute(self, document):
        c3_ctx().Genai.SourceFile.Chunker.MultimodalExtractionWorkflow3.Producer.Config.setConfig(
            "function", pickle.dumps(self.spec.executor)
        )

        output = c3_ctx().Genai.SourceFile.Chunker.MultimodalExtractionWorkflow3.Producer.produce(document.fname)
        output = pickle.loads(output)
        return output
