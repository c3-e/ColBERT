# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import os
import re
from typing import Any, List

import pandas as pd

c3: Any = None
"""
The c3 global object, injected by the C3 AI platform.
"""

warn_experimental: bool = True
"""
Whether to warn about experimental features.
"""

pd.options.future.infer_string = True
"""
Whether to infer the dtype of string columns.
"""

api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("AZURE_OPENAI_API_KEY")
"""
The OpenAI API key.
"""

endpoint = os.environ.get("OPENAI_ENDPOINT") or os.environ.get("AZURE_OPENAI_ENDPOINT")
"""
The OpenAI API endpoint.
"""

blacklist_rules: List[re.Pattern | str] = []
"""
Whether to enable auto-tuning rules.
"""
