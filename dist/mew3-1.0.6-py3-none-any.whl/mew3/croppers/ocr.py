# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reservedc.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING

import numpy as np
import torch
from PIL.Image import Image

from mew3.providers.plumber import CID_PATTERN
from mew3.rules import RewritePostRule

from .api import ImageCropper, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from mew3 import BoundingBox
    from mew3.document import Content


@dc.dataclass
class OCRForTextSpec(TextCropperSpec):
    engine: str = "easyocr"
    """
    The OCR engine to use: `easyocr` or `tesseract`.
    easyocr: accurate but slow.
    tesseract: fast but less accurate.
    """

    engine_spec: dict = dc.field(default_factory=lambda: {"lang_list": ["en"], "gpu": False})
    """
    The spec for the OCR engine. Default is for easyocr. Language list can be ['en', 'fr', 'de', 'es'].
    """

    image_cropper_typ: str = "PLUMBER"
    """
    Method to crop the image from document to pass to OCR.
    """

    image_cropper_spec: dict = dc.field(default_factory=lambda: {"dpi": 150})
    """
    Cropper spec for the image.
    """


class OCRForText(TextCropper, spec_class=OCRForTextSpec, class_name="OCR"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        img_crop = ImageCropper.factory(self.spec.image_cropper_typ, **self.spec.image_cropper_spec)
        img: Image = img_crop.as_proc(bbox)(content)
        img_np = np.array(img)

        if self.spec.engine == "easyocr":
            import easyocr

            reader = easyocr.Reader(**self.spec.engine_spec)
            result = reader.readtext(img_np)
            text = " ".join([item[1] for item in result])
            return text

        elif self.spec.engine == "tesseract":
            import pytesseract

            text = pytesseract.image_to_string(img)
            return text

        else:
            raise ValueError(f"Unsupported OCR engine: {self.spec.engine}")

    def supports(self):
        return ["pdf"]


def use_gpu_when_avaialble_for_easyocr(spec: OCRForTextSpec):
    """
    A decorator to use GPU when available for easyocr.
    """

    if spec.engine == "easyocr" and not spec.engine_spec["gpu"]:
        if torch.cuda.is_available():
            spec.engine_spec["gpu"] = True

    return spec


@RewritePostRule(use_gpu_when_avaialble_for_easyocr.__name__, use_gpu_when_avaialble_for_easyocr)
@dc.dataclass
class OCRForTableSpec(TableCropperSpec):
    engine: str = "easyocr"
    """
    The OCR engine to use: `easyocr` or `tesseract`.
    easyocr: accurate but slow.
    tesseract: fast but less accurate.
    """

    engine_spec: dict = dc.field(default_factory=lambda: {"lang_list": ["en"], "gpu": False})
    """
    The spec for the OCR engine. Default is for easyocr. Language list can be ['en', 'fr', 'de', 'es'].
    """

    image_cropper_typ: str = "PLUMBER"
    """
    Method to crop the image from document to pass to OCR.
    """

    image_cropper_spec: dict = dc.field(default_factory=lambda: {"dpi": 150})
    """
    Cropper spec for the image.
    """


class OCRForTable(TableCropper, spec_class=OCRForTableSpec, class_name="OCR"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        img_crop = ImageCropper.factory(self.spec.image_cropper_typ, **self.spec.image_cropper_spec)
        img: Image = img_crop.as_proc(bbox)(content)
        img_np = np.array(img)

        if self.spec.engine == "easyocr":
            import easyocr

            reader = easyocr.Reader(**self.spec.engine_spec)
            result = reader.readtext(img_np)
            text = " ".join([item[1] for item in result])
            return text

        elif self.spec.engine == "tesseract":
            import pytesseract

            text = pytesseract.image_to_string(img)
            return text

        else:
            raise ValueError(f"Unsupported OCR engine: {self.spec.engine}")

    def supports(self):
        return ["pdf"]


@dc.dataclass
class OcrFallbackSpec(TableCropperSpec):
    plumber_typ: str = "PLUMBER_TEXT"
    plumber_spec: dict = dc.field(default_factory=dict)

    ocr_typ: str = "OCR"
    ocr_spec: dict = dc.field(default_factory=dict)


class OcrFallback(TableCropper, spec_class=OcrFallbackSpec, class_name="OCR_FALLBACK"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        plumber_crop = TableCropper.factory(self.spec.plumber_typ, **self.spec.plumber_spec)
        result = plumber_crop.crop_bbox(content, bbox)

        if not CID_PATTERN.search(result):
            return result

        ocr_crop = TableCropper.factory(self.spec.ocr_typ, **self.spec.ocr_spec)
        result = ocr_crop.crop_bbox(content, bbox)
        return result
