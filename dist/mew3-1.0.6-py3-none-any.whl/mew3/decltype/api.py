# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
import logging
import re
from abc import ABC, abstractmethod
from functools import cached_property, lru_cache
from types import FunctionType
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Dict,
    Iterator,
    List,
    Literal,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    no_type_check,
)

from pygments.styles import get_all_styles
from rich import print
from rich.syntax import Syntax
from rich.tree import Tree
from typing_extensions import Self

from mew3.specs import Spec, factorize

from .delta import Delta

if TYPE_CHECKING:
    from mew3.core.doc_bboxes import DocBboxes
    from mew3.document import Content, PageDoc

I = TypeVar("I", bound="DocBboxes", contravariant=True)
O = TypeVar("O", bound="DocBboxes", covariant=True)
S = TypeVar("S", bound=Spec, contravariant=True)
D = TypeVar("D", "Content", "PageDoc")
V = TypeVar("V", covariant=True)


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)


class DeltaSpecMixin:
    def delta_columns(self) -> Tuple[str, ...] | Delta:
        """
        Returns the column changes for the `DocBboxes` object,
        once processed.

        This should return a tuple of strings, with the rules as follows:

        1. If a column is added, the column name should be prefixed with `+` ("+a" means addig a column "a", and "a" must not be present before).
        2. If a column is removed, the column name should be prefixed with `-` ("-b" means removing a column "b", and "b" must be present before).
        3. If a column is required, the column name should be present here ("c" means column "c" must be present, and possibly modified).

        If nothing is given (returns an empty tuple), it means that type checks are disabled.
        """

        return ()


@dc.dataclass(frozen=True)
class LayoutModuleRenderer:
    params: bool = True
    full: bool = False
    class_name: Literal["alias", "module"] = "alias"
    color: Literal["monokai", None] = "monokai"
    doc: bool = True
    delta: bool = True

    def _get_alias(self, klass: type) -> str:
        if self.class_name == "alias":
            return klass.__registry__.alias
        elif self.class_name == "qualname":
            return klass.__qualname__
        elif self.class_name == "name":
            return klass.__name__
        elif self.class_name == "module":
            return f"{klass.__module__}.{klass.__qualname__}"
        else:
            raise ValueError(f"Invalid class_name: {self.class_name}. Must be one of 'alias', 'qualname', 'name'.")

    def _get_doc(self, klass: type) -> str:
        if not klass.__doc__:
            return ""

        docs = [klass.__doc__, ""]

        spec_type = klass.__registry__.spec_cls
        for fields in dc.fields(spec_type):
            if fields.__doc__:
                docs.append(f"{fields.name}: {fields.__doc__}")
        return "\n".join(docs)

    def _get_delta(self, klass: type, values: Dict[str, Any]) -> str:
        if not self.delta:
            return ""

        delta_columns = klass.__registry__.spec_cls(**values).delta_columns()
        return str(Delta.parse(delta_columns))

    def __call__(self, *, label: str = "", klass: type, values: Dict[str, Any] | None = None) -> str:
        values = values or {}

        alias = self._get_alias(klass)

        if label:
            alias = f"{label}: {alias}"

        if self.params:
            params = _render_spec_class_body(klass=klass.__registry__.spec_cls, values=values or {}, full=self.full)
            result = f"{alias}({params})"
        else:
            result = alias

        if self.delta and values:
            delta = self._get_delta(klass, values=values)
            result = f"{result}\n    Column requirements: {delta}\n"

        if self.doc and klass.__doc__:
            doc = self._get_doc(klass).rstrip().lstrip("\n")
            result = f"{result}\n{doc}"

        result = result.rstrip().lstrip("\n")

        if self.color:
            if self.color not in self._pygments_colors:
                raise ValueError(f"Invalid color scheme {self.color}. Must be one of {self._pygments_colors}")

            result = Syntax(result, "python", theme=self.color, line_numbers=False)

        return result

    @cached_property
    def _pygments_colors(self) -> List[str]:
        return list(get_all_styles())


def _render_spec_class_body(*, klass: type, values: Dict[str, Any], full: bool) -> str | Syntax:
    from mew3.specs import Spec

    if not dc.is_dataclass(klass):
        raise TypeError(f"Expected a dataclass, got {klass}")

    if not issubclass(klass, Spec):
        raise TypeError(f"Expected a subclass of Spec, got {klass}")

    args: List[str] = []

    for field in dc.fields(klass):
        field_name = field.name
        type_name = _get_type_name(field.type)

        # No values give, rendering the class template.
        if not values:
            if field.default is dc.MISSING:
                rendered = f"{field_name}: {type_name}"
            else:
                rhs_repr = str(field.default) if full else _no_expand_nest(field.default)

                rendered = f"{field_name}: {type_name} = {field.default}"
        # Values given, rendering the class with values
        else:
            rhs = values[field_name] if field_name in values else field.default

            if rhs is dc.MISSING:
                raise ValueError(f"Missing value for field {field_name}")

            rhs_repr = str(rhs) if full else _no_expand_nest(rhs)

            rendered = f"{field_name}: {type_name} = {rhs_repr}"
        args.append(rendered)

    return ", ".join(args)


def _get_type_name(klass) -> str:
    if isinstance(klass, type):
        return klass.__name__

    if isinstance(klass, str):
        return klass

    return str(klass)


class LayoutModSpec(Spec, ABC):
    pass


@factorize(LayoutModSpec)
class LayoutMod(ABC):
    """
    `LayoutModule` is the base class for all layout components,
    it defines and provides a bunch of utility functions for layout components.
    """

    if TYPE_CHECKING:
        from mew3.specs import TreeRegistry

        __registry__: ClassVar[TreeRegistry]
        """
        The registry for the class.
        """

        @abstractmethod
        def __init__(self, *args, **kwargs):
            pass

        @classmethod
        @abstractmethod
        def factory(cls, name: str, **kwargs) -> Self:
            """
            Factory method to create a new instance of the class.

            Args:
                name: The name of the class to create.
                **kwargs:
                    The keyword arguments to pass to the class.
                    Same as subclass's spec class.

            Returns:
                A subclass of `LayoutModule`.
            """

        @property
        @abstractmethod
        def spec(self) -> LayoutModSpec:
            """
            The specification for the class.
            This is a dataclass that defines the parameters for the class.
            """

    @classmethod
    def _get_desc_by_name(cls, name: str) -> List[LayoutMod]:
        path = name.split(".")
        return cls._get_desc_by_path(*path)

    @classmethod
    @lru_cache(maxsize=1024)
    def _get_desc_by_path(cls, *path: str) -> List[LayoutMod]:
        """
        Return the module if the path is either the full path,
        or a post fix of the full path.
        Or else return None.

        Args:
            path: The path to the module.

        Returns:
            The module if found, else None.
        """

        if not path:
            return [cls]

        results = []
        head, *rest = path

        # Find subclass where the head matches the name.
        subc = next((subc for subc in cls.__subclasses__() if subc.__name__ == head), None)

        # Exhausively search for all cases.
        # Implementing this is a little tricky, as this pattern is not commonly seen.
        #
        # This can still be solved with DFS,
        # tho a little tricky because we are searching for a path rather than the full thing.
        #
        # There are 2 ways to solve this:
        # 1. Remember the path, and match postfix at each node.
        # 2. Use fuzzy search, and we can break problems down with simple recursion / DP.
        # Here, I implemented the 2nd way.
        #
        # There are 2 cases in the 2nd way:
        # 1. The path is a full path, in which case, the root of the path should match one of the base classes.
        # 2. The path is a post fix of the full path. In which case, we recursively ask the submodules if they found anything.
        # This should be able to be proven to always be the case,
        # if we compute this in a bottom up fasion (all paths from short to long), so this should be Ok.

        # Recurively find all fuzzy path that consumes the current head.
        if subc is not None:
            found = subc._get_desc_by_path(*rest)
            results.extend(found)

        # Recursively find all fuzzy path that doesn't consume the current head.
        for klass in cls.__subclasses__():
            found = klass._get_desc_by_path(*path)
            results.extend(found)

        return results

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)

    @abstractmethod
    def forward(self, *args, **kwargs):
        pass

    @classmethod
    def initialize(cls, *args, **kwargs) -> Self:
        """
        This is just for type hinting.
        """

        raise NotImplementedError("Unreachable code")

    def explain(self, renderer: LayoutModuleRenderer | Dict[str, Any] = LayoutModuleRenderer()) -> None:
        """
        Returns a human-readable explanation of the module.
        """

        renderer = LayoutModuleRenderer(**renderer) if isinstance(renderer, dict) else renderer
        print(self._explain_tree(renderer=renderer))

    def _explain_tree(self, *, label: str = "", renderer: LayoutModuleRenderer) -> Tree:
        rendered = self.render(values=dc.asdict(self.spec), renderer=renderer, label=label)

        tree = Tree(rendered)
        for child in self.children():
            try:
                label, child = child
            except (ValueError, TypeError):
                label = ""

            child_explained = child._explain_tree(label=label, renderer=renderer)
            tree.add(child_explained)
        return tree

    def children(self) -> Iterator[LayoutMod | Tuple[str, LayoutMod]]:
        """
        Returns the children of the module.
        """

        return
        yield

    @classmethod
    def render(cls, *, label: str = "", renderer: LayoutModuleRenderer, values: Dict[str, Any] | None = None) -> str:
        return renderer(label=label, klass=cls, values=values or {})

    @classmethod
    def print_registered(cls, renderer: LayoutModuleRenderer | dict = LayoutModuleRenderer()) -> None:
        """
        Print all registered classes.
        """

        renderer = LayoutModuleRenderer(**renderer) if isinstance(renderer, dict) else renderer
        reg = cls.registered(renderer=renderer)

        for r in reg:
            print(r)
            print()

    @classmethod
    def registered(
        cls,
        renderer: LayoutModuleRenderer
        | dict = LayoutModuleRenderer(color=None, doc=False, class_name="alias", full=False, params=False, delta=False),
    ) -> List[str]:
        """
        Examples:
            >>> Foo.factory.registered()
            ['BAR', 'BAZ']

        Returns:
            A list of available class names registered with the factory method.
        """

        renderer = LayoutModuleRenderer(**renderer) if isinstance(renderer, dict) else renderer

        regs = cls.__registry__.sub_regs()

        result: List[str] = []

        for reg in regs:
            assert issubclass(reg.cls, LayoutMod), f"Expected a subclass of LayoutMod, got {reg.cls}"
            result.append(reg.cls.render(renderer=renderer))
        return result


def _no_expand_nest(data):
    if isinstance(data, dict):
        return "{...}"

    if isinstance(data, (list, tuple)):
        return "[...]"

    if isinstance(data, type):
        return data.__qualname__

    if isinstance(data, FunctionType):
        return data.__name__ + str(inspect.signature(data))

    return repr(data)


LayoutModule = LayoutMod
LayoutModuleSpec = LayoutModSpec


@dc.dataclass(frozen=True)
class LayoutProcSpec(LayoutModuleSpec, ABC):
    def supports(self) -> List[str | re.Pattern]:
        """
        Describes what this processor supports.

        If given, this is a constraint on the input processor that must match its `type` attribute on the given document.

        Returns a list of strings or regular expressions that this processor supports,
        or `NotImplemented` if it supports everything.

        If a string is provided, it is matched exactly, if a regular expression is provided, it is matched using `re.fullmatch`.
        """

        return NotImplemented

    @abstractmethod
    def input_type(self) -> Type[D]:
        pass


@factorize(LayoutProcSpec)
class LayoutProc(LayoutModule, ABC, spec_class=LayoutProcSpec):
    """
    `LayoutProc` converts `Document` into something else.
    It handles `supports` documents and calls `process` to do the actual work.
    """

    def forward(self, item: D, /) -> DocBboxes:
        from mew3.document import PageDoc

        LOGGER.info(f"Processing %s with %s", self.__class__.__name__, item)

        if not isinstance(item, self.spec.input_type()):
            raise TypeError(f"Expected {self.spec.input_type()}, got {type(item)}")

        # Check if the document is supported.
        doc = item if isinstance(item, PageDoc) else item.document
        doc.assert_support(self)

        output = self.process(item)
        return output

    @abstractmethod
    def process(self, item: D, /) -> V:
        pass

    def supports(self) -> List[str | re.Pattern]:
        return self.spec.supports()


LayoutProcessor = LayoutProc
LayoutProcessorSpec = LayoutProcSpec


@dc.dataclass(frozen=True)
class LayoutProdSpec(DeltaSpecMixin, LayoutProcSpec, ABC):
    def input_type(self):
        from mew3.document import PageDoc

        return PageDoc


@no_type_check
@factorize(LayoutProdSpec)
class LayoutProd(LayoutProc, ABC, spec_class=LayoutProdSpec):
    """
    The producer API for layout modules.

    Subclasses should implement the `produce` method,
    which takes in a `Document` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def process(self, document: PageDoc, /) -> DocBboxes:
        LOGGER.info(f"Producing %s with %s", self.__class__.__name__, document)

        # Run the static type checks here.
        _ = self.spec.delta_columns()

        output = self.produce(document)
        _check_docbbxs(output, self.__class__, "output")
        return output

    @abstractmethod
    def produce(self, document: PageDoc, /) -> O:
        pass

    @classmethod
    def make(cls, supports: Sequence[str | re.Pattern] = (), delta_columns: Sequence[str] | Delta = ()) -> LayoutProc:
        """
        Convert a function into a `LayoutProc`.
        """

        if not isinstance(delta_columns, (Delta, Sequence)):
            raise ValueError(
                f"delta_columns must be a sequence of strings or a Delta object, not {type(delta_columns)}.\nUsage: @LayoutExec.register(delta_columns=('a', 'b'))"
            )

        def wrapper(func: Callable[[D], V]) -> LayoutProc:
            if not callable(func):
                raise TypeError(f"Expected a callable, got {type(func)}")

            @dc.dataclass(frozen=True)
            class FuncProdSpec(cls.__registry__.spec_cls):
                def input_type(self):
                    from mew3.document import PageDoc

                    return PageDoc

                def supports(self):
                    return supports

                def delta_columns(self):
                    return delta_columns

            class FuncProd(cls, spec_class=FuncProdSpec, class_name=func.__name__.upper()):
                def produce(self, item: D, /) -> V:
                    return func(item)

            FuncProd.__doc__ = func.__doc__
            FuncProd.__qualname__ = func.__qualname__
            return FuncProd()

        return wrapper


LayoutProducer = LayoutProd
LayoutProducerSpec = LayoutProdSpec


@dc.dataclass(frozen=True)
class LayoutExecSpec(DeltaSpecMixin, LayoutModuleSpec):
    pass


_T = TypeVar("_T", bound=Callable[["DocBboxes"], "DocBboxes"])


@factorize(LayoutExecSpec)
class LayoutExec(LayoutModule, ABC, spec_class=LayoutExecSpec):
    """
    The executor API for layout modules.

    Subclasses should implement the `execute` method,
    which takes in a `DocBboxes` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def forward(self, input: DocBboxes, /) -> DocBboxes:
        LOGGER.info(f"Executing %s with %s", self.__class__.__name__, input)

        # Run the static type checks here.
        _ = self.spec.delta_columns()

        _check_docbbxs(input, self.__class__, "input")
        output = self.execute(input.clone())
        _check_docbbxs(output, self.__class__, "output")
        return output

    @abstractmethod
    def execute(self, input: DocBboxes, /) -> DocBboxes:
        pass

    @classmethod
    def register(cls, delta_columns: Sequence[str] | Delta = ()) -> Callable[[_T], _T]:
        """
        Register a pure post-processing function (of type types.FunctionType) into the factory.

        Example:
            >>> @LayoutExec.register()
            ... def my_post_proc(output):
            ...     return output

            >>> @LayoutExec.register()
            ... def my_other_post_proc(output):
            ...     return output

            >>> # Note that the function name must be in snake case.
            ... # After register, it would be available in the registry.

            >>> # After registering the post-processing functions, you can use them as follows:
            ... output = LayoutExec.factory("MY_POST_PROC")(output)
            ... output = LayoutExec.factory("MY_OTHER_POST_PROC")(output)
        """

        if not isinstance(delta_columns, (Delta, Sequence)):
            raise ValueError(
                f"delta_columns must be a sequence of strings or a Delta object, not {type(delta_columns)}.\nUsage: @LayoutExec.register(delta_columns=('a', 'b'))"
            )

        def reg_fn(post_proc: _T) -> _T:
            return cls._register(post_proc=post_proc, delta_columns=delta_columns)

        return reg_fn

    @classmethod
    def _register(cls, post_proc: _T, delta_columns: Sequence[str] | Delta = ()) -> _T:
        if not isinstance(post_proc, FunctionType):
            raise ValueError(f"Can only register functions!")

        if not _is_snake_case(func_name := post_proc.__name__):
            raise ValueError(f"Function name must be in snake case!")

        # Only
        if len(inspect.signature(post_proc).parameters) != 1:
            raise ValueError(f"Function must take exactly one argument for it to be an exectuor!")

        # Dynamically create a subclass of LayoutExec.
        # This has the effect of automatially registering the function.
        class _SubType(cls, spec_class=cls.__registry__.spec_cls, class_name=func_name.upper()):
            def execute(self, output):
                return post_proc(output)

            def delta_columns(self):
                return delta_columns

        _SubType.__doc__ = post_proc.__doc__
        _SubType.__qualname__ = post_proc.__qualname__

        return _SubType()


LayoutExecutor = LayoutExec
LayoutExecutorSpec = LayoutExecSpec


def _check_docbbxs(obj, cls: type, tag):
    from mew3.core import DocBboxes

    if not isinstance(obj, DocBboxes):
        raise TypeError(f"{cls.__name__} {tag} must be of type DocBboxes, not {type(obj)}")


_SNAKE_CASE_REGEX = re.compile(r"^[a-z][a-z0-9_]*[a-z0-9]$")


def _is_snake_case(s: str) -> bool:
    return _SNAKE_CASE_REGEX.fullmatch(s) is not None
