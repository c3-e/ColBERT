import functools
import logging
from typing import NamedTuple

import nltk.tokenize
import numpy as np
from nltk.corpus import stopwords, words

from mew3.providers import pdfplumber_file

LOG = logging.getLogger(__name__)


class Tols(NamedTuple):
    x_tol: float
    y_tol: float


@functools.cache
def english_words():
    WORDS = frozenset(w.lower() for w in words.words()) - frozenset(w.lower() for w in stopwords.words("english"))
    return WORDS


def get_tols_for_files(file: str):
    import cma

    es = cma.CMAEvolutionStrategy(2 * [0], 3)

    def tokenize_and_count(input_texts: str) -> float:
        tokenized = nltk.tokenize.word_tokenize(input_texts)
        return sum(int(is_valid_word(word)) for word in tokenized)

    def is_valid_word(word: str) -> bool:
        return word.isalpha() and word.lower() in english_words() and len(word) > 1

    f = pdfplumber_file(str(file))

    def extract_all(tols):
        LOG.info("tols %s", tols)
        x_tol, y_tol = np.exp(tols)
        texts = [page.extract_text_simple(x_tolerance=x_tol, y_tolerance=y_tol) for page in f.pages]
        return "\n".join(texts)

    def word_count(tols):
        text = extract_all(tols)
        p = tokenize_and_count(text)
        LOG.debug("count=%s, tols=%s, text='%s'", p, tols, text[-100:].replace("\n", " "))
        return p

    i = 0
    while not es.stop():
        LOG.info("iteration %s", i)
        sols = es.ask()
        es.tell(sols, [-word_count(x) for x in sols])
        i += 1
    sols = es.ask()

    x_tol, y_tol = map(float, np.exp(sols[0]))
    return Tols(x_tol, y_tol)
