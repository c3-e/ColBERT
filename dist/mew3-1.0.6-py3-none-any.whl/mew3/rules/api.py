# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
import logging
import re
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, Final, Generic, List, Sequence, TypeVar, get_type_hints

from mew3 import settings
from mew3.specs import CompatibleKindAndKwargs, Spec, signature_parse

T = TypeVar("T")
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.ERROR)
S = TypeVar("S", bound=Callable[..., Spec])


EXISTING_RULES: Dict[str, "PostRule"] = {}





@dc.dataclass(frozen=True)
class PostRule(Generic[T], ABC):
    name: str
    """
    The user-defined name for the rule.
    """

    def __post_init__(self) -> None:
        if self.name in EXISTING_RULES:
            raise ValueError(f"Rule with name {self.name} already exists.")

        EXISTING_RULES[self.name] = self

    @abstractmethod
    def apply(self, spec: T) -> None:
        pass

    def apply_maybe_skip(self, spec: T) -> None:
        for rule in settings.blacklist_rules:
            if isinstance(rule, re.Pattern):
                if rule.match(self.name):
                    LOG.info(f"Skipping rule %s", self.name)
                    return
            elif isinstance(rule, str):
                if rule in self.name:
                    LOG.info(f"Skipping rule %s", self.name)
                    return
            else:
                raise ValueError(f"Expected rule to be a string or a regex, got {rule=} and {type(rule)}.")

        self.apply(spec)

    def __call__(self, spec_init: S, /) -> S:
        """
        Since `PostRule` is a decorator, we need to define the `__call__` method.

        Args:
            spec_cls: The spec class to apply the rule to.
        """

        rself = self

        if isinstance(spec_init, type):

            class Wrapper(spec_init):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    LOG.debug(f"Applying rule to %s", self)
                    rself.apply_maybe_skip(self)

        elif callable(spec_init):

            def Wrapper(*args, **kwargs):
                spec = spec_init(*args, **kwargs)
                LOG.debug(f"Applying rule to %s", spec)
                rself.apply_maybe_skip(spec)
                return spec

        else:
            raise TypeError(
                f"Expected spec_init to be a callable or a type, got {spec_init}. This might cause issues because the returns of `PostRule` cannot be subclassed."
            )

        Wrapper.__signature__ = inspect.signature(spec_init)
        Wrapper.__name__ = spec_init.__name__
        Wrapper.__qualname__ = spec_init.__qualname__
        Wrapper.__doc__ = spec_init.__doc__
        return Wrapper


@dc.dataclass(frozen=True)
class RewritePostRule(PostRule[T]):
    rewrite: Callable[[T], None]

    def apply(self, spec) -> None:
        self.rewrite(spec)


@dc.dataclass(frozen=True)
class KeyMapPostRule(PostRule[T]):
    """
    `PostRule` class for applying transformations to dataclass instances,
    it applies the rules after the wrapped function is executed.
    """

    key_path: str | Sequence[str]
    """
    The key path to the field in the dataclass to be transformed.

    Since Rule works on mappings, the key path can be a list of keys or a string with dot notation.
    """

    set_as: Callable[[Any], Any]
    """
    The rewriter function to apply to the field.

    The rewriter function should take the dataclass instance and the value of the field as arguments.
    It should return the transformed value.
    """

    enable: Callable[[Any], bool] = lambda _: True
    """
    Whether or not to enable the rule, based on the conifg.
    By default, all rules are enabled.
    """

    def apply(self, spec: T):
        """
        Rewrite the spec in-place.

        Args:
            spec: The spec to rewrite. Must define getitem and setitem.

        Raises:
            TypeError: If the spec does not define getitem and setitem.
        """
        if not hasattr(spec, "__getitem__"):
            raise TypeError(f"Expected spec to have __getitem__, got {type(spec)}")

        if not hasattr(spec, "__setitem__"):
            raise TypeError(f"Expected spec to have __setitem__, got {type(spec)}")

        LOG.debug(f"Applying rule to %s", spec)
        key_path = list(self.key_path) if not isinstance(self.key_path, str) else self.key_path.split(".")

        LOG.debug(f"Key path: %s", key_path)

        # Do nothing if the key path is not used.
        try:
            cfg = self._get_cfg(spec, key_path)
        except (KeyError, TypeError):
            LOG.info(f"Key path %s not found in spec %s. Ignore", key_path, spec)
            return spec

        enabled = self.enable(cfg)
        LOG.debug(f"Rule: %s enabled: %s", self, enabled)

        if not enabled:
            return

        cfg = self.set_as(cfg)
        LOG.debug(f"Rewritten cfg: %s", cfg)

        self._set_cfg(spec, key_path, cfg)
        LOG.debug(f"Set cfg: %s", cfg)

    @classmethod
    def _get_cfg(cls, item, key_path: List[str]):
        """
        Get the configuration from the spec.
        """

        if not len(key_path):
            return item

        if not hasattr(item, "__getitem__"):
            raise TypeError(f"Expected item to have __getitem__, got {type(item)}")

        head, *rest = key_path

        item = item[head]

        return cls._get_cfg(item, rest)

    @classmethod
    def _set_cfg(cls, item, key_path: List[str], value) -> None:
        """
        Set the configuration in the spec, in-place.
        """
        if not hasattr(item, "__setitem__"):
            raise TypeError(f"Expected item to have __setitem__, got {type(item)}")

        head, *rest = key_path
        if not len(rest):
            item[head] = value
            return type(item)(**item)

        cls._set_cfg(item[head], key_path=rest, value=value)


def kwargs_is_given(obj: CompatibleKindAndKwargs) -> bool:
    result = signature_parse(obj)
    return bool(result.kwargs)
