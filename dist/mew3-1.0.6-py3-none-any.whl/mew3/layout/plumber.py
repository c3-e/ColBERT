# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import List

from pdfplumber.page import Page

from mew3.core import DocBboxes, ParsedMetadata
from mew3.document import PageDoc
from mew3.providers import pdfplumber_file

from .api import LayoutModel, LayoutModelSpec


@dc.dataclass(frozen=True)
class PlumberSpec(LayoutModelSpec):
    def supports(self):
        return ["pdf"]

    def delta_columns(self):
        return "+x_1", "+y_1", "+x_2", "+y_2", "+klass", "+score", "+page"


class Plumber(LayoutModel, spec_class=PlumberSpec):
    def produce(self, document: PageDoc) -> DocBboxes:
        pdf = pdfplumber_file(document.fname)

        pages = []
        for page in pdf.pages:
            pages.append(self._parse_page(page))

        return DocBboxes.init(sequence=pages, document=document)

    def _parse_page(self, page: Page) -> List[ParsedMetadata]:
        result: List[ParsedMetadata] = []

        for word in page.extract_words():
            result.append(
                ParsedMetadata.flat_init(
                    x_1=word["x0"],
                    y_1=word["top"],
                    x_2=word["x1"],
                    y_2=word["bottom"],
                    klass="Text",
                    score=1,
                )
            )

        for table in page.find_tables():
            result.append(
                ParsedMetadata.flat_init(
                    x_1=table.bbox[0],
                    y_1=table.bbox[1],
                    x_2=table.bbox[2],
                    y_2=table.bbox[3],
                    klass="Table",
                    score=1,
                )
            )

        for image in page.images:
            result.append(
                ParsedMetadata.flat_init(
                    x_1=image["x0"],
                    y_1=image["top"],
                    x_2=image["x1"],
                    y_2=image["bottom"],
                    klass="Figure",
                    score=1,
                )
            )

        return [
            r
            for r in result
            if True
            and r.x_1 >= 0
            and r.y_1 >= 0
            and r.x_2 <= page.width
            and r.y_2 <= page.height
            and r.x_2 - r.x_1 > 0
            and r.y_2 - r.y_1 > 0
        ]
