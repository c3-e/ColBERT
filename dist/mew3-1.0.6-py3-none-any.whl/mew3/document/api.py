# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, Mapping

from mew3.providers import pdfplumber_found_cid, pdfplumber_is_scanned_pdf
from mew3.rules import KeyMapPostRule, RewritePostRule, get_tols_for_files
from mew3.specs import signature_parse

from .document import PageDoc, PageDocSpec


def rewrite_only_xy_tol(key: str, enable_for: str):
    def rewrite(spec):
        val = spec[key]
        parsed = signature_parse(val).dict()

        if parsed["kind"] != enable_for:
            return

        x_tol, y_tol = _get_xy_tol(spec)
        parsed["kwargs"]["extract_text_kwargs"] = {"x_tolerance": x_tol, "y_tolerance": y_tol}
        spec[key] = parsed

    return rewrite


def auto_pdf_or_null(key: Literal["image_crop", "text_crop", "table_crop", "page_cnt", "grid_gen"], value: str):
    def rewrite(spec: PageDocSpec):
        if spec[key] != "AUTO":
            return

        if Path(spec.filename).suffix == ".pdf":
            spec[key] = value
        else:
            spec[key] = "NULL"

    return rewrite


def use_ocr_if_cid_detected(key: str):
    def rewrite(spec: PageDocSpec):
        if spec[key] != "AUTO":
            return

        fname = str(spec.filename)
        if not fname.endswith(".pdf"):
            return

        if not pdfplumber_found_cid(fname):
            return

        spec[key] = "OCR"

    return rewrite


def use_ocr_if_scanned(key: str):
    def rewrite(spec: PageDocSpec):
        if spec[key] != "AUTO":
            return

        fname = str(spec.filename)
        if not fname.endswith(".pdf") or not pdfplumber_is_scanned_pdf(fname):
            return

        spec[key] = "OCR"

    return rewrite


@RewritePostRule("xy_tol_table_crop", rewrite_only_xy_tol("table_crop", enable_for="PLUMBER_TEXT"))
@RewritePostRule("xy_tol_text_crop", rewrite_only_xy_tol("text_crop", enable_for="PLUMBER"))
@RewritePostRule("pdf_set_grid_gen", auto_pdf_or_null("grid_gen", "PLUMBER"))
@RewritePostRule("pdf_set_page_cnt", auto_pdf_or_null("page_cnt", "PLUMBER"))
@RewritePostRule("pdf_set_table_crop", auto_pdf_or_null("table_crop", "PLUMBER_TEXT"))
@RewritePostRule("pdf_set_text_crop", auto_pdf_or_null("text_crop", "PLUMBER"))
@RewritePostRule("pdf_set_image_crop", auto_pdf_or_null("image_crop", "PLUMBER(margins=5,dpi=144)"))
@RewritePostRule("scanned_ocr_table", use_ocr_if_scanned("table_crop"))
@RewritePostRule("scanned_ocr_text", use_ocr_if_scanned("text_crop"))
@RewritePostRule("on_cid_talbe", use_ocr_if_cid_detected("table_crop"))
@RewritePostRule("on_cid_text", use_ocr_if_cid_detected("text_crop"))
@KeyMapPostRule(
    name="str_to_path",
    key_path="filename",
    set_as=lambda val: Path(val),
    enable=lambda val: isinstance(val, str),
)
def cropping_document_spec(
    filename: str | Path,
    cropping: Mapping[str, Any] | None = None,
    grid_gen: str = "AUTO",
    page_cnt: str = "AUTO",
) -> PageDocSpec:
    cropping = cropping or {}
    return PageDocSpec(
        filename=filename,
        image_crop=cropping.get("image", "AUTO"),
        text_crop=cropping.get("text", "AUTO"),
        table_crop=cropping.get("table", "AUTO"),
        page_cnt=page_cnt,
        grid_gen=grid_gen,
    )


def Document(*args, **kwargs):
    """
    A backwards-compatible version of the document class.

    Args:
        args: The arguments to pass to the document class.
        kwargs: The keyword arguments to pass to the document class.

    Returns:
        A new style `PageDoc` that acts mostly the same.
    """

    spec = cropping_document_spec(*args, **kwargs)
    return PageDoc(**spec)


def _get_xy_tol(spec):
    filename = spec.filename
    return get_tols_for_files(filename)
