# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from typing import Callable, Tuple

from mew3.doc_parser import SourceFileParser
from mew3.document import PageDoc
from mew3.integrations.docling import DoclingParser


@dc.dataclass(frozen=True)
class Candidate:
    name: str
    use_if: Callable[[PageDoc], bool]
    parser: Callable[..., Callable[[PageDoc], dict]]
    kwargs: dict = dc.field(default_factory=dict)

    def construct_parser(self, cache: dict):
        if self.name in cache:
            return cache[self.name]

        parser = self.parser(**self.kwargs)
        cache[self.name] = parser
        return parser


@dc.dataclass(frozen=True)
class Parser:
    candidates: Tuple[Candidate, ...] = (
        Candidate(
            name="source file parser",
            use_if=lambda doc: doc.is_pdf,
            parser=SourceFileParser,
            kwargs={},
        ),
        Candidate(
            name="docling parser",
            use_if=lambda _: True,
            parser=DoclingParser,
            kwargs={},
        ),
    )

    def __call__(self, doc: PageDoc) -> dict:
        """
        Parse the document using the first candidate that matches.
        """

        cache = {}
        for candidate in self.candidates:
            if not candidate.use_if(doc):
                continue
            return candidate.construct_parser(cache)(doc)
        raise ValueError("No suitable parser found for document.")
