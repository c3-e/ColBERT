# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod

from c3pdfparser.specs import Spec, factorise

from ..api import RawImageComponent


@dc.dataclass(frozen=True)
class ImageVerbalSpec(Spec, ABC):
    pass


@factorise(ImageVerbalSpec)
class ImageVerbal(ABC):
    @abstractmethod
    def __call__(self, image: RawImageComponent) -> str:
        """
        Verbalise the image component.

        Args:
            image: The raw image component.

        Returns:
            The verbalisation of the image.
        """
