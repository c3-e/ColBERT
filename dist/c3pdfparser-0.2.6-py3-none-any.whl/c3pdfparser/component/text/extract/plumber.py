# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import itertools
import logging
from collections import defaultdict
from typing import Dict, List, Tuple

import alive_progress as ap

from c3pdfparser.document import Document
from c3pdfparser.layout import DocBboxes

from .api import RawTextComponent, TextExtractor, TextExtractorSpec

LOGGER = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class PdfPlumberSpec(TextExtractorSpec):
    pass


class PdfPlumber(TextExtractor[PdfPlumberSpec], spec_class=PdfPlumberSpec):
    """
    PDF Plumber text extractor takes in a PDF document and bounding boxes,
    and extract text from those regions using the pdfplumber library.

    This must be used in conjunction with a layout parser that extracts bounding boxes.
    """

    def parse(self, doc: Document, parsed: DocBboxes) -> List[RawTextComponent]:
        texts = self.extract_text(doc, parsed)
        return [RawTextComponent(document=doc, text=text, page=page) for page, _, text in texts]

    @property
    def known_components(self) -> List[str]:
        return ["Header", "Text", "Caption"]

    def extract_text(self, document: Document, bounding_boxes: DocBboxes) -> List[Tuple[int, int, str]]:
        """
        Extracts text from a page using the pdfplumber library.

        Args:
            document: The PDF document.
            bounding_boxes: The bounding boxes of texts on each page.

        Returns:
            A list cropped text boxes.
        """

        import pdfplumber

        pdf_file_url = document.fname
        texts: List[Tuple[int, int, str]] = []

        with pdfplumber.open(pdf_file_url) as pdf_plumber_document:
            assert len(pdf_plumber_document.pages) == len(bounding_boxes), (
                "Mismatch between number of pages and bounding boxes. "
                "This indicates that there is a bug in the layout parser and / or pdfplumber."
            )

            for page_num, bounding_box_on_page, pdf_plumber_document_page in zip(
                itertools.count(),
                bounding_boxes,
                ap.alive_it(pdf_plumber_document.pages, title="Extracting text (page)"),
            ):
                for idx, parsed in enumerate(bounding_box_on_page):
                    assert parsed.klass in self.known_components, f"Unexpected class {parsed.klass}"

                    bbox = parsed.bbox.x_1, parsed.bbox.y_1, parsed.bbox.x_2, parsed.bbox.y_2
                    text_page_box = (
                        page_num,
                        idx,
                        pdf_plumber_document_page.crop(bbox, relative=False, strict=True).dedupe_chars().extract_text(),
                    )

                    texts.append(text_page_box)

        return texts


class PdfPlumberMergeSpec(PdfPlumberSpec):
    pass


class PdfPlumberMerge(PdfPlumber, spec_class=PdfPlumberMergeSpec):
    """
    Merges the text components extracted by the pdfplumber text extractor, and then merge them by page.
    """

    def parse(self, doc: Document, parsed: DocBboxes) -> List[RawTextComponent]:
        super_parsed = super().parse(doc, parsed)
        by_page: Dict[int, List[RawTextComponent]] = defaultdict(list)

        for parsed in super_parsed:
            by_page[parsed.page].append(parsed)

        # Join the components on each page.
        return [
            RawTextComponent(document=doc, text="\n".join(comp.text for comp in parsed), page=page)
            for page, parsed in by_page.items()
        ]
