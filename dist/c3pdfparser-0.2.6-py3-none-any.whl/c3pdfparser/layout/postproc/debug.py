# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import collections
import dataclasses as dc
import itertools
from typing import List, no_type_check

from c3pdfparser.core import DocBboxes, PageBboxesView
from c3pdfparser.document import Content, Document
from c3pdfparser.utils import running_in

from ..api import LayoutParserOutput
from .api import LayoutPostProc, LayoutPostProcSpec


@LayoutPostProc.register
def print(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    Print the output of the layout parser.
    """
    from rich import print

    print(output)
    return output


@dc.dataclass(frozen=True)
class ScaleBboxSpec(LayoutPostProcSpec):
    """
    A specification for a rescale post-processor.
    """

    scale: float
    """
    The scale factor to apply to the bounding boxes.
    """


class ScaleBbox(LayoutPostProc, spec_class=ScaleBboxSpec):
    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        output = output.clone()

        output.data["x_1"] *= self.spec.scale
        output.data["x_2"] *= self.spec.scale
        output.data["y_1"] *= self.spec.scale
        output.data["y_2"] *= self.spec.scale

        return output


@dc.dataclass(frozen=True)
class JupyterDebugSpec(LayoutPostProcSpec):
    """
    A specification for a debug post-processor.
    """

    title: str
    """
    The title of the debug plot.
    """


class JupyterDebug(LayoutPostProc, spec_class=JupyterDebugSpec):
    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        _debug_layout_impl(output.document, output, self.spec.title)
        return output


def _debug_layout_impl(document: Document, bounding_boxes: LayoutParserOutput, title: str) -> None:
    if running_in() != "jupyter":
        return

    import matplotlib.pyplot as plt
    import seaborn as sns
    from matplotlib.patches import Patch

    sns.set_theme()

    palette = sns.color_palette("Paired", 8)

    counter = itertools.count()
    color_map = collections.defaultdict(lambda: palette[next(counter) % len(palette)])

    # Plot the bounding boxes on the page, overlayed on the image, with the label, subtle.
    def plot_page(bboxes: PageBboxesView, img: Content):
        _, ax = plt.subplots()
        ax.imshow(img)

        for bbox in bboxes:
            # Detectron's output is normalised, but we need to scale it back to the original image size.
            x0, y0, x1, y1 = bbox.scaled_bbox
            color = color_map[bbox.klass]  # Get color based on class
            rect = plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color)
            ax.add_patch(rect)
            ax.text(x0, y0, str(float(bbox.score)), color=color, fontsize=12)  # Set fontsize to 8 for smaller labels

        plt.axis("off")  # Optional: Turn off axis
        plt.title(title)
        plt.legend(
            handles=[Patch(facecolor=color_map[klass], label=klass) for klass in color_map.keys()], prop={"size": 12}
        )
        plt.show()

    def plot_multi_page(bboxes_list: DocBboxes, imgs: List[Content]):
        for bboxes, img in zip(bboxes_list, imgs):
            plot_page(bboxes, img)

    plot_multi_page(bounding_boxes, document.page_contents)


@dc.dataclass(frozen=True)
class VerifyClassSpec(LayoutPostProcSpec):
    """
    Verify that the class of each bbox is in the list of valid classes.
    """

    valid_classes: list[str]


class VerifyClass(LayoutPostProc, spec_class=VerifyClassSpec):
    """
    TODO:
        Add tests for this post-processor.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        output.validate_classes(self.spec.valid_classes)
        return output
