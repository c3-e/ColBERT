# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from typing import Any, List, Sequence, Tuple, TypedDict

import numpy as np
from numpy.typing import NDArray
from transformers import AutoTokenizer, PreTrainedTokenizerBase

from c3pdfparser.document import CropWithBbox, Document


class VGTDocGrid(TypedDict):
    input_ids: Any
    bbox_subword_list: Any
    texts: Any
    bbox_texts_list: Any


class VGTGridInputGenerator:
    """
    VGTGridInputGenerator is a class that generates the input grid for the VGT model.
    """

    def __init__(self, tokenizer_name: str, do_not_generate_grid: bool):
        """
        Args:
            tokenizer_name (str): The name of the tokenizer.
            do_not_generate_grid (bool): Whether to generate the grid or not.
        """
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        self.do_not_generate_grid = do_not_generate_grid

    def return_subword_grid_per_page(self, document: Document) -> List[List[CropWithBbox[str]]]:
        """
        Return subword grid for the given page.

        Parameters:
            document: The document object.

        Returns:
            List of subword grid for the given page
        """

        contents = []
        for page_content in document.page_contents:
            result = page_content.find_and_gen_grid()
            contents.append(result)
        return contents

    def create_grids_for_document(self, document: Document, /) -> List[VGTDocGrid]:
        pdf_num_pages = len(document)

        grids: List[VGTDocGrid] = []

        # Return empty grid if do_not_generate_grid is True.
        if self.do_not_generate_grid:
            return [
                {
                    "input_ids": np.array([]),
                    "bbox_subword_list": np.array([]),
                    "texts": np.array([]),
                    "bbox_texts_list": np.array([]),
                }
                for _ in range(pdf_num_pages)
            ]

        word_grid = self.return_subword_grid_per_page(document)
        for word_grid_per_page in word_grid:
            grids.append(create_grid_dict_per_page(self.tokenizer, word_grid_per_page))
        return grids


def readjust_bbox_coords(bounding_box: Sequence[Tuple[float, float, float, float]], tokens: Sequence[NDArray]):
    """
    Readjust the bounding box coordinates based on the tokenized input.
    If a token is split into multiple subwords, the bounding box is split accordingly.

    Parameters:
        bounding_box: List of bounding box coordinates in the format (x, y, w, h).
        tokens: List of input_ids from the tokenizer.

    Returns:
        A list of the adjusted bounding box coordinates.
    """

    assert len(bounding_box) == len(tokens), "Bounding box and tokens should have the same length."

    adjusted_boxes = []

    for box, sub_tokens in zip(bounding_box, tokens):
        x, y, w, h = box

        if len(sub_tokens) <= 1:
            adjusted_boxes.append(box)
            continue

        # Add for each part, split the original box into equal parts to fit everthing nicely.
        wid = w / len(sub_tokens)
        for idx in range(len(sub_tokens)):
            adjusted_boxes.append((x + idx * wid, y, wid, h))

    return adjusted_boxes


def create_grid_dict_per_page(tokenizer: PreTrainedTokenizerBase, page_data: List[CropWithBbox[str]]) -> VGTDocGrid:
    """Create a dictionary with the tokenized input,
    bounding box coordinates, and text.

    Parameters:
        tokenizer : The tokenizer to be used.
        page_data : List of word information from pdfplumber.
    Returns:
        Returns a dictionary with the tokenized input, bounding box coordinates, and text.
    """

    input_ids = []
    bbox_subword_list = []
    texts: List[str] = []
    bbox_texts_list: List[Tuple[float, float, float, float]] = []

    for elem in page_data:
        texts.append(elem.data)

        # since expected bbox format is (x, y, w, h)
        bbox_texts_list.append((elem.bbox.x_1, elem.bbox.y_1, elem.bbox.width, elem.bbox.height))

    input_ids = tokenizer.batch_encode_plus(
        texts, return_token_type_ids=False, return_attention_mask=False, add_special_tokens=False
    )["input_ids"]

    bbox_subword_list = readjust_bbox_coords(bbox_texts_list, input_ids)

    return {
        "input_ids": np.concatenate(input_ids),
        "bbox_subword_list": np.array(bbox_subword_list),
        "texts": np.array(texts),
        "bbox_texts_list": np.array(bbox_texts_list),
    }
