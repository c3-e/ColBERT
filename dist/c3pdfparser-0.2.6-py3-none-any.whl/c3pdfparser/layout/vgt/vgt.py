# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
import os
import tempfile
import typing
import zipfile
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, List, Sequence

import numpy as np
from PIL.Image import Image

from c3pdfparser import utils
from c3pdfparser.core import ParsedMetadata
from c3pdfparser.document import Document

from ..api import LayoutModel, LayoutModelSpec, LayoutParserOutput
from ..outputs import DOCLAYNET_LABELS
from ..postproc.doclaynets import boxes_to_grid, dumb_merge
from ..postproc.doclaynets import filter_doc as vgt_filter_doc
from ..postproc.doclaynets import filter_page as vgt_filter_page
from ..postproc.doclaynets import (
    find_seperator_of_groups,
    group_list_by,
    removing_overlapping_dict,
    union_find_bounding_box,
    unioning_dict,
)

if TYPE_CHECKING:
    from detectron2.structures import Instances

    from .gen import VGTDocGrid

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)

__all__ = [
    "Vgt",
    "VgtSpec",
    "vgt_outputs_to_bboxes",
    "boxes_to_grid",
    "find_seperator_of_groups",
    "vgt_filter_page",
    "vgt_filter_doc",
    "group_list_by",
    "removing_overlapping_dict",
    "unioning_dict",
    "dumb_merge",
    "union_find_bounding_box",
]


os.environ["TOKENIZERS_PARALLELISM"] = "true"


@dataclass(frozen=True)
class VgtSpec(LayoutModelSpec):
    models_zip: str = "models_m.zip"
    """
    The base directory of the weights zip file.

    If this file is in gcs, it is downloaded to the local cache directory.

    If not provided, skip the download and assume that the weights are already in the local cache.
    """

    base_dir: str = "models"
    """
    The base directory that the zip file contains.
    """

    vgt_model_path: str = "doclaynet_VGT_model.pth"
    """
    The (relative) path to the VGT model.
    """

    wordgrid_model_path: str = "bros-base-uncased"
    """
    The (relative) path to the wordgrid model.
    """

    config_file_path: str = "doclaynet_VGT_cascade_PTM.yaml"
    """
    The (relative) path to the configuration file for the layout parser.
    """

    model_name: str = "bert-base-uncased"
    """
    The name of the model to use.
    """

    device: str = "cpu"
    """
    The device to which VGT model will be processed on, e.g. "cuda", "cpu".
    """

    dont_generate_grid: bool = False
    """
    Do not generate grid for VGT. Note: VGT will have slightly worse performance
    in the absence of the grid.
    """

    pdfplumber_to_image_kwargs: Mapping[str, Any] = field(default_factory=dict)
    """
    Keyword arguments to be used when calling pdfplumber.to_image().
    """

    vgt_inference_batch_size: int = 1
    """
    The batch size of data when calling VGT inference. Note: setting this to 1 is recommended
    as higher value does not lead to significant latency improvement.
    """


class Vgt(LayoutModel, spec_class=VgtSpec):
    """
    LayoutParser is a class that uses the LayoutLM model to extract bounding boxes from a PDF file.
    """

    def __init__(self, spec: VgtSpec, /):
        super().__init__(spec)

        from .gen import VGTGridInputGenerator
        from .pred import VGTPredictor

        self.vgt_grid_input_generator = VGTGridInputGenerator(
            tokenizer_name=self.spec.model_name, do_not_generate_grid=self.spec.dont_generate_grid
        )

        if models_zip := self.spec.models_zip:
            # Set up base dir or download zip file.
            models_zip = gcs_to_local(models_zip)

            if not Path(models_zip).exists():
                raise FileNotFoundError(f"Models zip file {models_zip} does not exist.")

            # If it's a zip file.
            unzip_to_tmp(models_zip)

        base_dir = Path(tempfile.gettempdir()) / self.spec.base_dir

        if not base_dir.exists():
            raise FileNotFoundError(f"Base directory {base_dir} does not exist.")

        model_weight_path = str(base_dir / self.spec.vgt_model_path)
        wordgrid_model_path = str(base_dir / self.spec.wordgrid_model_path)
        config_file_path = str(base_dir / self.spec.config_file_path)

        self.vgt_predictor = VGTPredictor(
            model_weight_path=model_weight_path,
            config_file_path=config_file_path,
            wordgrid_model_path=wordgrid_model_path,
            device=self.spec.device,
        )

    def produce(self, document: Document) -> LayoutParserOutput:
        LOGGER.info("Parsing images from PDF document.")

        # Get images from pdf document with the original dpi.
        document_images = [im.image for im in document.page_contents]
        LOGGER.debug("Document images = %s", document_images)

        LOGGER.info("Generating document grids.")

        # Generate document grids
        document_grids = self.vgt_grid_input_generator.create_grids_for_document(document)
        LOGGER.debug("Document grids = %s", document_grids)

        LOGGER.info("Calling VGT model on the document images and grids.")

        vgt_outputs = self.return_vgt_outputs(document_images=document_images, document_grids=document_grids)
        LOGGER.debug("VGT outputs = %s", vgt_outputs)

        LOGGER.info("Converting VGT outputs to bounding boxes.")

        doc_bboxes = vgt_outputs_to_bboxes(vgt_outputs, bbox_classes=DOCLAYNET_LABELS)
        LOGGER.debug("Document bounding box dict = %s", doc_bboxes)

        bboxes = LayoutParserOutput.init(doc_bboxes, document=document)

        # VGT seems to generate large bounding boxes with larger dpi, so we need to rescale them.
        bboxes = rescale_bbox(bboxes, document.rel_scale)

        return bboxes

    def return_vgt_outputs(self, document_images: List[Image], document_grids: List["VGTDocGrid"]) -> List["Instances"]:
        """
        Call VGT model on the document images and grids.

        Args:
            document_images: The images of the document.
            document_grids: The grids of the document.

        Returns:
            The VGT outputs.
        """

        cur_page_num = 0
        batch_size = self.spec.vgt_inference_batch_size
        document_size = len(document_images)
        vgt_outputs: List["Instances"] = []

        # Call VGT model on a queue with queue size = batch size.
        for cur_page_num in range(0, document_size, batch_size):
            batch_end_idx = min(cur_page_num + batch_size, document_size)

            imgs = document_images[cur_page_num:batch_end_idx]
            grids = document_grids[cur_page_num:batch_end_idx]
            vgt_output_pages = self.vgt_predictor(original_images=[np.asarray(img) for img in imgs], grids=grids)
            assert len(vgt_output_pages) == batch_end_idx - cur_page_num, f"Got {len(vgt_output_pages)}"

            vgt_outputs.extend([page["instances"].to("cpu") for page in vgt_output_pages])

        return vgt_outputs


def vgt_outputs_to_bboxes(vgt_outputs: List["Instances"], bbox_classes: Sequence[str]) -> List[List[ParsedMetadata]]:
    """
    Convert VGT outputs to bounding boxes, organized by page.

    Args:
        vgt_outputs: The VGT outputs.
        bbox_classes: The bounding box classes.

    Returns:
        The bounding boxes, which is a list of pages, where each page is a list of bounding boxes.

    NOTE:
        The bounding boxes outputed by vgt is ALREADY scaled by the relative scale of the document,
        since detectron does its own scaling (which doesn't work with our own scaling methods)
    """

    document_bounding_box_dict: List[List[ParsedMetadata]] = []

    for vgt_output_page in vgt_outputs:
        bounding_box_on_page = [
            # This is a normalised bounding box because the VGT model uses DPI = 72,
            # which is what the downstream models are expecting.
            ParsedMetadata.flat_init(
                x_1=x_1.item(),
                y_1=y_1.item(),
                x_2=x_2.item(),
                y_2=y_2.item(),
                klass=bbox_classes[int(bbox_class_idx)],
                score=bbox_score,
            )
            for (x_1, y_1, x_2, y_2), bbox_class_idx, bbox_score in zip(
                vgt_output_page.pred_boxes, vgt_output_page.pred_classes, vgt_output_page.scores
            )
        ]

        document_bounding_box_dict.append(bounding_box_on_page)

    return document_bounding_box_dict


def rescale_bbox(bboxes: LayoutParserOutput, rel_scale: float):
    """
    Rescale the bounding boxes.

    Args:
        bboxes: The bounding boxes.
        rel_scale: The relative scale of the document.
    """

    bboxes = bboxes.clone()

    bboxes.x_1 = bboxes.x_1 / rel_scale
    bboxes.x_2 = bboxes.x_2 / rel_scale
    bboxes.y_1 = bboxes.y_1 / rel_scale
    bboxes.y_2 = bboxes.y_2 / rel_scale

    return bboxes


@typing.no_type_check
def gcs_to_local(source_path: str) -> str:
    """
    Downlaod the model from google cloud storage,
    and return the local path where it's stored.

    If the source_path is not a gcs path, return the source_path as is.

    The return value references the local file, and must exist after call.
    """

    if not source_path.startswith("gcs://"):
        return source_path

    result_file = Path(tempfile.gettempdir()) / (source_path.split("/")[-1])

    LOGGER.debug("Downloading %s to %s", source_path, result_file)

    with result_file.open("wb") as f:
        utils.c3_ctx().FileSystem.downloadFile(srcPath=source_path, destFile=f)

    return str(result_file)


def unzip_to_tmp(source_path: str):
    """
    Unzip the source_path and return the directory where it's stored.

    The unzipped folder would be located in the temporary directory.
    """

    base = Path(source_path)

    if not base.exists():
        raise FileNotFoundError(f"Source path {source_path} does not exist.")

    if not base.is_file():
        raise FileNotFoundError(f"The source path must be a directory or a zip file. Got {source_path}.")

    if base.suffix != ".zip":
        raise ValueError(f"The source path must be a directory or a zip file. Got {source_path}.")

    with zipfile.ZipFile(base, "r") as zip_ref:
        zip_ref.extractall(tempfile.gettempdir())
