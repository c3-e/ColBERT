# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import uuid
from typing import List, Sequence, overload

__all__ = ["UniqueIds", "NotUniqueError"]


class NotUniqueError(ValueError):
    """
    This error is raised if a sequence of unique IDs contains duplicates.
    """


@dc.dataclass(frozen=True, eq=False)
class UniqueIds:
    """
    A set of unique_ids that are guaranteed to be unique.

    This class provides some additional indexing and comparison utilities that are not available in a simple list.
    """

    unique_ids: Sequence[str]
    """
    The unique IDs.
    """

    def __post_init__(self):
        if len(self.unique_ids) != len(set(self.unique_ids)):
            raise NotUniqueError("Unique IDs must be unique.")

    def __eq__(self, value: object) -> bool:
        if isinstance(value, (list, tuple)) and all(isinstance(uid, str) for uid in value):
            return tuple(self.unique_ids) == tuple(value)

        if isinstance(value, UniqueIds):
            return self.equal_after_sorted(value)

        return NotImplemented

    def __ne__(self, value: object) -> bool:
        return not self == value

    def __contains__(self, unique_id: str) -> bool:
        return unique_id in self.unique_ids

    def __sub__(self, other: UniqueIds) -> UniqueIds:
        return UniqueIds([uid for uid in self.unique_ids if uid not in other])

    def __len__(self) -> int:
        return len(self.unique_ids)

    def __iter__(self):
        return iter(self.unique_ids)

    @overload
    def __getitem__(self, idx: int) -> str:
        ...

    @overload
    def __getitem__(self, idx: List[int]) -> UniqueIds:
        ...

    def __getitem__(self, idx: int | List[int]) -> str | UniqueIds:
        if isinstance(idx, int):
            return self._getitem_int(idx)

        if isinstance(idx, list):
            return self._getitem_list(idx)

        raise TypeError("Index must be an integer or a list of integers.")

    def _getitem_list(self, idx: List[int]) -> UniqueIds:
        return UniqueIds([self.unique_ids[i] for i in idx])

    def _getitem_int(self, idx: int) -> str:
        return self.unique_ids[idx]

    def isdisjoint(self, other: UniqueIds) -> bool:
        return set(self).isdisjoint(other)

    def issuperset(self, other: UniqueIds) -> bool:
        return set(self).issuperset(other)

    def issubset(self, other: UniqueIds) -> bool:
        return set(self).issubset(other)

    def equal_before_sorted(self, other: UniqueIds) -> bool:
        return self.unique_ids == other.unique_ids

    def equal_after_sorted(self, other: UniqueIds) -> bool:
        return sorted(self.unique_ids) == sorted(other.unique_ids)

    @overload
    def index(self, unique_id: str) -> int:
        ...

    @overload
    def index(self, unique_id: List[str] | UniqueIds) -> List[int]:
        ...

    def index(self, unique_id: str | List[str] | UniqueIds) -> int | List[int]:
        """
        Get the index of the given string or a sequence of unique ids.

        Args:
            unique_id: The unique ID or a sequence of unique IDs.

        Raises:
            ValueError: If the unique ID is not found.

        Returns:
            An integer (if the input is a string) or a list of integers (if the input is a sequence of unique IDs).
        """
        if isinstance(unique_id, str):
            return self._index(unique_id)

        if isinstance(unique_id, list) and all(isinstance(uid, str) for uid in unique_id):
            return self._all_index_of(UniqueIds(unique_id))

        if isinstance(unique_id, UniqueIds):
            return self._all_index_of(unique_id)

        raise TypeError("Unique ID must be a string or a UniqueIds object.")

    def _index(self, unique_id: str) -> int:
        return self.unique_ids.index(unique_id)

    def _all_index_of(self, query: UniqueIds, /) -> List[int]:
        # TODO: Optimize this.
        return [self._index(unique_id) for unique_id in query.unique_ids]

    @classmethod
    def uuid(cls, length: int) -> UniqueIds:
        """
        Hash the given object sequence by the md5 representation of each object's string representation.

        Args:
            length: The sequence of objects to hash.

        Returns:
            The unique IDs.
        """

        return cls([str(uuid.uuid4()) for _ in range(length)])
