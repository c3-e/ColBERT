# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import copy
import dataclasses as dc
from typing import Any, Callable, Dict, Iterator, List, Mapping, MutableMapping, TypeVar

import networkx as nx
import numpy as np
import pandas as pd

from .dicts import GraphDict
from .graphs import Graph
from .unique_ids import UniqueIds
from .utils import Locator

T = TypeVar("T")

__all__ = ["Graphrame"]


@dc.dataclass(frozen=True, eq=False)
class Graphrame(Mapping[str, pd.Series]):
    """
    Graphrame is both a graph and a dataframe, it provides a convenient way to store and
    manipulate data, and track relationships between different entities.

    In its core, the `Graphrame` can be split into 3 parts:

    1. `df`:
        A pandas DataFrame that stores the attributes of the nodes.
        Using a dataframe makes filtering and mapping operations simple to perform and test.
    2. `ids`:
        A unique identifier for each node.
        This is used for guaranteeing the uniqueness of the nodes.
    3. graph nodes:
        An graph object with a similar API to networkx graph to track the relationships between the nodes.
    """

    df: pd.DataFrame
    """
    Attributes of the nodes.
    """

    ids: UniqueIds
    """
    Unique identifiers of the nodes.
    """

    graphs: GraphDict = dc.field(default_factory=GraphDict.empty)
    """
    Graphs associated with the nodes.
    """

    def __post_init__(self):
        if len(self.df) != len(self.ids):
            raise ValueError(
                "The number of records must match the number of unique ids. "
                f"Got {len(self.df)} records and {len(self.ids)} ids."
            )

        if (num_rows := self.graphs.num_rows) is not None and len(self.df) != num_rows:
            raise ValueError(
                "The number of records must match the number of rows in the graphs. "
                f"Got {len(self.df)} records and {self.graphs.num_rows} rows."
            )

    def __iter__(self):
        return iter(self.df)

    def __getitem__(self, key: str) -> pd.Series:
        return self.df[key]

    def __setitem__(self, key: str, value: pd.Series):
        self.df[key] = value

    def __len__(self) -> int:
        return len(self.df)

    @property
    def index(self) -> pd.Index:
        return self.df.index

    @property
    def rels(self) -> _GraphDictWithDefault:
        return _GraphDictWithDefault(self.graphs, len(self.ids))

    @property
    def data(self) -> pd.DataFrame:
        return self.df

    @property
    def columns(self) -> List[str]:
        return self.df.columns.tolist()

    def unique(self, key: str):
        return self.df[key].unique()

    def clone(self):
        return copy.deepcopy(self)

    def _repr_html_(self):
        return self.data.to_html()

    def idx_where(self, key: str, func: Callable[[T], bool]) -> List[int]:
        if not callable(func):
            raise ValueError("func must be callable.")

        select = self.df[key].apply(func)
        return np.arange(len(self))[select].tolist()

    @property
    def iloc(self):
        return self.df.iloc

    @property
    def loc(self) -> Locator:
        return Locator(self.df)

    @classmethod
    def from_dataclasses(cls, records: List[Mapping[str, Any]], /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a list of dataclasses.

        Parameters:
            records: A list of dataclasses.

        Returns:
            A Graphrame.
        """

        return cls.from_records([dc.asdict(record) for record in records], ids=ids)

    @classmethod
    def from_records(cls, records: List[Dict[str, Any]], /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a list of records.

        Parameters:
            records: A list of records.

        Returns:
            A Graphrame.
        """

        for record in records:
            if not isinstance(record, dict):
                raise ValueError("Records must be mappings.")

        df = pd.DataFrame.from_records(records)
        return Graphrame.from_pandas(df, ids=ids)

    @classmethod
    def from_records_with_unique_ids(cls, records: List[Dict[str, Any]]):
        """
        Create a Graphrame from a list of records with unique ids.

        Parameters:
            records: A list of records.

        Returns:
            A Graphrame.
        """

        records = copy.deepcopy(records)
        for record in records:
            if not isinstance(record, dict):
                raise ValueError("Records must be mappings.")

            if "__id__" not in record:
                raise ValueError("Records must contain a unique id.")

        unique_ids = UniqueIds([record.pop("__id__") for record in records])
        df = pd.DataFrame.from_records(records)
        return cls.from_pandas(df, ids=unique_ids)

    @classmethod
    def from_pandas(cls, df: pd.DataFrame, /, *, ids: UniqueIds | None = None) -> Graphrame:
        """
        Create a Graphrame from a pandas DataFrame.

        Parameters:
            df: A pandas DataFrame.

        Returns:
            A Graphrame.
        """

        if ids is None:
            ids = UniqueIds.uuid(len(df))

        if not isinstance(ids, UniqueIds):
            raise ValueError("ids must be a UniqueIds object.")

        return Graphrame(df=df, ids=ids)

    def to_records(self, with_ids: bool = False) -> List[Dict[str, Any]]:
        """
        Convert the Graphrame to a list of records.

        Args:
            with_ids:
                If True, include the unique ids in the records under the key `__id__`.
                Default is False.

        Returns:
            A list of dictionary records, where each records represents a row.
        """

        return list(self._to_records(with_ids))

    def _to_records(self, with_ids: bool = False) -> Iterator[Dict[str, Any]]:
        records = self.df.to_dict(orient="records")
        for idx, record in enumerate(records):
            result = {**record}
            if with_ids:
                result["__id__"] = self.ids[idx]
            yield result

    def reorder(self, order: List[int]) -> Graphrame:
        if sorted(order) != list(range(len(self))):
            raise ValueError("The order must be a permutation of the node indices.")

        return self.take(order)

    def take(self, indices: List[int]):
        return dc.replace(
            self,
            df=self.df.iloc[indices],
            ids=self.ids[indices],
            graphs=self.graphs.take(indices),
        )

    def networkx(self):
        G = nx.Graph()

        for id, row in zip(self.ids, self.df.iterrows()):
            G.add_node(id, **row.to_dict())

        G.add_edges_from(self.rels.edges)
        return G

    @classmethod
    def empty(cls, columns: List[str]):
        return cls.from_pandas(
            pd.DataFrame(columns=sorted({"x_1", "y_1", "x_2", "y_2", "page", "score", "klass", *columns}))
        )

    def query(self, ids: List[int] | List[str] | UniqueIds, /) -> Graphrame:
        """
        Query the Graphrame by a list of ids.

        Parameters:
            ids: A list of ids.

        Returns:
            A Graphrame.
        """

        if isinstance(ids, list) and all(isinstance(i, int) for i in ids):
            return self.take(ids)

        if isinstance(ids, list) and all(isinstance(i, str) for i in ids) or isinstance(ids, UniqueIds):
            return self.take(self.ids.index(ids))

        raise NotImplementedError(f"Querying with {ids} is not supported.")


@dc.dataclass(frozen=True)
class _GraphDictWithDefault(MutableMapping[str, Graph]):
    """
    `_GraphDictWithDefault` is a default dictionary storing multiple graphs,
    with some additional checks and methods for convenience.
    """

    graphs: GraphDict
    """
    The graphs.
    """

    _default_len: int = dc.field(repr=False)
    """
    The default length of the graphs.
    """

    def __len__(self) -> int:
        return len(self.graphs)

    def __iter__(self) -> Iterator[str]:
        return iter(self.graphs)

    def __getitem__(self, key: str) -> Graph:
        # This acts kind of like a default dict.
        if key not in self.graphs:
            self.graphs[key] = Graph.zeros(self._default_len)

        assert (nr := self.graphs.num_rows) is None or nr == self._default_len, (
            "The number of rows in the graphs must match the number of nodes."
            f"Got {nr} rows and {self._default_len} nodes."
        )
        return self.graphs[key]

    def __setitem__(self, key: str, value: Graph):
        if len(value) != self._default_len:
            raise ValueError("The graph must have the same number of nodes as the context.")

        self.graphs[key] = value

    def __delitem__(self, key: str):
        del self.graphs[key]

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _GraphDictWithDefault):
            return self.graphs == other.graphs

        # Use `GraphDict`'s `__eq__` method.
        return self.graphs == other
