# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from typing import TypedDict


class _BlockBoxCoordsDict(TypedDict):
    x_1: float
    y_1: float
    x_2: float
    y_2: float


def translate_dict_coords(box_coords: _BlockBoxCoordsDict) -> _BlockBoxCoordsDict:
    """
    Translates the dictionary coordinates of a bounding box into a new dictionary
    with minimum and maximum coordinates.

    Args:
        box_coords (Dict): A dictionary containing the coordinates of a bounding box.

    Returns:
        Dict: A dictionary with translated coordinates, including 'x_min', 'y_min',
        'x_max', and 'y_max'.
    """
    bounding_box_coords: _BlockBoxCoordsDict = {
        "x_1": min(box_coords["x_1"], box_coords["x_2"]),
        "y_1": min(box_coords["y_1"], box_coords["y_2"]),
        "x_2": max(box_coords["x_1"], box_coords["x_2"]),
        "y_2": max(box_coords["y_1"], box_coords["y_2"]),
    }
    return bounding_box_coords
