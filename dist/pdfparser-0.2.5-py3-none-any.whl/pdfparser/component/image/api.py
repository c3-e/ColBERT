# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Dict, List

import numpy as np
from numpy.typing import NDArray

from pdfparser import settings
from pdfparser.core import BoundingBox
from pdfparser.document import Document
from pdfparser.layout import LayoutParserOutput

from ..api import Component, ComponentParser, ComponentParserOutputItem, ComponentParserSpec
from .helpers import translate_dict_coords

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class RawImageComponent(Component):
    """
    The class for an image in a document.
    This component is used as an intermediate result of the image parser,
    where captions are found but verbalisation is not yet performed.
    """

    img: NDArray
    """
    The image array. Must be a 3D array.
    """

    text: str
    """
    The caption of the image.
    """

    @property
    def parser(self) -> str:
        return "IMAGE"


@dataclass(frozen=True)
class VerbalImageComponent(RawImageComponent, ComponentParserOutputItem):
    verbalisation: str
    """
    The verbalisation of the image.
    """

    @property
    def description_for_vectorstore(self) -> str:
        return self.verbalisation


@dataclass(frozen=True)
class ImageParserSpec(ComponentParserSpec):
    """
    The image parser specification class.
    """

    caption_finder_typ: str = "LOCALITY"
    """
    The type of caption finder to use. Default to using the locality-based caption finder,
    because layout parsers are availalbe for all documents.
    """

    caption_finder_kwargs: Dict[str, Any] = field(default_factory=dict)
    """
    The keyword arguments for the caption finder. See individual caption finder classes for details.
    """

    verbal_typ: str = "NULL"
    """
    The type of verbaliser to use. Default to using the NULL verbaliser (no verbalization).
    """

    verbal_kwargs: Dict[str, Any] = field(default_factory=dict)
    """
    The keyword arguments for the verbaliser. See individual verbaliser classes for details.
    """

    keywords_for_caption: List[str] = field(
        default_factory=lambda: [
            "figure",
            "fig",
            "image",
            "diagram",
            "graph",
            "chart",
            "note",
            "plot",
            "photo",
            "drawing",
            "illustration",
            "schematic",
            "exhibit",
            "depiction",
            "pictogram",
            "map",
            "artwork",
            "plate",
            "legend",
            "key",
        ]
    )
    """
    Keywords to look for in the caption. If the caption contains any of these keywords, it is considered a caption. Otherwise, it is considered a standalone text.
    """


class ImageParser(ComponentParser[ImageParserSpec, VerbalImageComponent], spec_class=ImageParserSpec):
    """
    The overall flow for parsing image components is as follows:

    1. Find the captions for the images using the caption finder.
    2. Parse the images and captions into image components.
    3. Verbalise the image components using the verbaliser.

    """

    CONTEXTUAL = "FIGURE", "PLAIN"
    PARSE = "FIGURE"

    @cached_property
    def caption_finder(self):
        from ..caps import CaptionFinder

        return CaptionFinder.factory(self.spec.caption_finder_typ, **self.spec.caption_finder_kwargs)

    @cached_property
    def verbaliser(self):
        from .verb import ImageVerbal

        return ImageVerbal.factory(self.spec.verbal_typ, **self.spec.verbal_kwargs)

    def parse(self, bounding_boxes: LayoutParserOutput, unfiltered: LayoutParserOutput) -> List[VerbalImageComponent]:
        """
        The main method to parse image content from a document.

        Args:
            bounding_boxes: List of bounding boxes for the document.
            unfiltered: List of bounding boxes for the document that contains all classes

        Returns:
            ImageParserOutput: A dataclass containing the list of image components and parsing logs.
        """

        if settings.warn_planned_deprecation:
            warnings.warn("Rewrite this method by 0.3.0", DeprecationWarning)

        document = bounding_boxes.document
        if len(document) != len(bounding_boxes):
            raise ValueError(
                f"Number of bounding boxes ({len(bounding_boxes)}) does not match number of pages ({len(document)})"
            )

        LOGGER.debug(f"parse_content,{document.fname=},{len(document)=}")

        # Using the dedicated caption finder to find captions in the parsed layout for the images.
        captions_found = self.caption_finder(document, bounding_boxes, keywords=self.spec.keywords_for_caption)
        LOGGER.debug(f"parse_content,got captions,{len(captions_found)=}")

        # Create image components from the bounding boxes and captions found.
        image_components = _parse_image_components(
            document=document, bounding_boxes=bounding_boxes, caps_found=captions_found, unfiltered=unfiltered
        )

        verbal_components = [
            VerbalImageComponent(**vars(img), verbalisation=self.verbaliser(img)) for img in image_components
        ]

        return verbal_components


def _parse_image_components(
    *,
    document: Document,
    bounding_boxes: LayoutParserOutput,
    caps_found: List[List[str]],
    unfiltered: LayoutParserOutput,
) -> List[List[RawImageComponent]]:
    page_imgs = document.page_contents

    img_comps: List[RawImageComponent] = []
    bboxes = bounding_boxes.to_list_of_list()

    # TODO: GEN-8959
    #   Just being safe here.
    #   Since image - caption a 1-1 relationship, caption finder should operate on individual images (signature: image -> str).
    #   However, I do not want to change yet another thing, so I reserve this to be changed in a future PR.
    assert len(page_imgs) == len(bboxes), f"{len(page_imgs)=} != {len(bboxes)=}"
    assert len(page_imgs) == len(caps_found), f"{len(page_imgs)=} != {len(caps_found)=}"

    indices = iter(unfiltered.index(bounding_boxes.unique_ids))

    for page_idx, _ in enumerate(page_imgs):
        assert len(caps_found[page_idx]) == len(bboxes[page_idx]), (
            f"Number of captions found ({len(caps_found[page_idx])}) does not match number of bounding boxes "
            f"({len(bboxes[page_idx])}) on page {page_idx}"
        )
        boxes_on_page = bboxes[page_idx]

        for fig_idx, parsed_data in enumerate(boxes_on_page):
            # For all figures.
            if parsed_data.klass != "FIGURE":
                # HACK: This is ugly.
                _ = next(indices)
                continue

            bbox = parsed_data.norm_bbox
            cropped_image = document.page_contents[page_idx].crop_image(bbox)

            # Get the caption for the figure
            caption_figure = caps_found[page_idx][fig_idx]

            trans = translate_dict_coords({"x_1": bbox.x_1, "y_1": bbox.y_1, "x_2": bbox.x_2, "y_2": bbox.y_2})

            bbox = BoundingBox(x_1=trans["x_1"], y_1=trans["y_1"], x_2=trans["x_2"], y_2=trans["y_2"])

            img_comps.append(
                RawImageComponent(
                    img=np.array(cropped_image),
                    text=caption_figure,
                    page=page_idx,
                    # HACK: This is ugly.
                    global_idx=next(indices),
                    bbox=bbox,
                )
            )

    return img_comps
