# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import re
import warnings
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Dict, List, Sequence

import pandas as pd

from pdfparser import settings
from pdfparser.layout import LayoutParserOutput

from ..api import Component, ComponentParser, ComponentParserOutputItem, ComponentParserSpec

INLINE_MARKDONW_REGEX = re.compile("```(.+?)```", re.DOTALL)


@dataclass(frozen=True)
class TableParserSpec(ComponentParserSpec):
    content_parser_typ: str = "DEFAULT"
    """
    The type of content parser to use.
    """

    content_parser_kwargs: Dict[str, Any] = field(default_factory=dict)
    """
    The keyword arguments for the content parser.
    """

    title_finder_typ: str = "LOCALITY"
    """
    The type of title finder to use.
    """

    title_finder_kwargs: Dict[str, Any] = field(default_factory=lambda: {"later_first": False})

    chunker_typ: str = "LONG_CHAIN"
    """
    The type of chunker to use.
    """

    chunker_kwargs: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TableTitledComponent(Component):
    title: str
    """
    The title of the table.
    """


@dataclass(frozen=True)
class TableContentComponent(TableTitledComponent):
    text: str
    """
    The verbalisation of the table.
    """

    @property
    def description_for_vectorstore(self) -> str:
        return self.text

    @property
    def parser(self) -> str:
        return "TABLE"


@dataclass(frozen=True)
class ChunkedTableComponent(TableContentComponent, ComponentParserOutputItem):
    chunks: Sequence[str]
    """
    The chunks of the verbalisation.
    """

    @property
    def description_for_vectorstore(self) -> str:
        return "\n".join(self.chunks)

    def _repr_html_(self):
        import mdpd

        def extract_markdown(text):
            return re.findall(INLINE_MARKDONW_REGEX, text)

        raw_text = self.description_for_vectorstore

        table = extract_markdown(raw_text)[0]

        df: pd.DataFrame = mdpd.from_md(table)
        return df.to_html()


class TableParser(ComponentParser[TableParserSpec, ChunkedTableComponent], spec_class=TableParserSpec):
    """
    The overall flow for parsing table components is as follows:

    1. Extract the content of the table using the content parser.
    2. Find the title of the table using the title finder.
    3. Chunk the extracted content using the chunker.
    """

    CONTEXTUAL = "TABLE", "HEADER", "PLAIN"
    PARSE = "TABLE"

    def parse(self, bounding_boxes: LayoutParserOutput, unfiltered: LayoutParserOutput) -> List[ChunkedTableComponent]:
        """
        Parse the table components from the bounding boxes.

        Args:
            bounding_boxes: The bounding boxes of the table components.
            unfiltered: The unfiltered bounding boxes.
        """

        if settings.warn_planned_deprecation:
            warnings.warn("Rewrite this method by 0.3.0", DeprecationWarning)

        document = bounding_boxes.document
        indices = iter(unfiltered.index(bounding_boxes.unique_ids))

        if len(bounding_boxes) != len(document):
            raise ValueError(f"{len(bounding_boxes)=} != {len(document)=}")

        titles: List[List[str]] = self.title_finder(document, bounding_boxes, ["Table"])

        titled_bboxes: List[TableTitledComponent] = []
        for page_num, [page_table_boxes, page_table_titles] in enumerate(zip(bounding_boxes, titles)):
            for table_box, table_title in zip(page_table_boxes, page_table_titles):
                if table_box.klass != "TABLE":
                    # HACK: This is ugly.
                    _ = next(indices)
                    continue

                titled_bboxes.append(
                    TableTitledComponent(
                        page=page_num,
                        global_idx=next(indices),
                        bbox=table_box.bbox,
                        title=table_title,
                    )
                )

        contents: List[TableContentComponent] = [
            TableContentComponent(**vars(bbox), text=self.content_parser(document, bbox)) for bbox in titled_bboxes
        ]

        return [ChunkedTableComponent(**vars(box), chunks=self.chunker(f"{box.title}\n{box.text}")) for box in contents]

    @cached_property
    def content_parser(self):
        from .content import TableContent

        return TableContent.factory(self.spec.content_parser_typ, **self.spec.content_parser_kwargs)

    @cached_property
    def title_finder(self):
        from ..caps import CaptionFinder

        return CaptionFinder.factory(self.spec.title_finder_typ, **self.spec.title_finder_kwargs)

    @cached_property
    def chunker(self):
        from ..chunker import TextChunker

        return TextChunker.factory(self.spec.chunker_typ, **self.spec.chunker_kwargs)
