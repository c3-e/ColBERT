# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any, Callable, List, Literal, Tuple, TypeVar
from urllib.parse import urlparse

import numpy as np
import requests
from numpy.typing import NDArray

from pdfparser.specs import CompatibleKindAndKwargs, InlineEval

from .contents import Content
from .croppers import Cropper, ImageCropper, TableCropper, TextCropper
from .grids import GridGen

_EVALUATOR = InlineEval()
_T = TypeVar("_T", bound=Cropper)


@dataclass(frozen=True)
class CroppingStrategy:
    text: CompatibleKindAndKwargs = "PLUMBER"
    """
    The text cropper to use for cropping text, extracting text and finding text.
    """

    image: CompatibleKindAndKwargs = "PLUMBER(margins=5,dpi=72)"
    """
    The image cropper to use for cropping and image reading.
    """

    table: CompatibleKindAndKwargs = "PLUMBER"
    """
    The table cropper to use for converting tables to text.
    """

    def __getitem__(self, key: Literal["text", "image", "table"]) -> str:
        return getattr(self, key)


@dataclass(frozen=True)
class Document:
    """
    The document class. A document is simply a file URL with some metadata.

    It provides some convenience methods to load the document as images,
    and to get the name and type of the document.

    Represents a document that is stored in a file.

    """

    filename: str | Path
    """
    The location of the documents.
    """

    cropping: Callable[[int], dict] | dict = field(default_factory=lambda: vars(CroppingStrategy()))
    """
    The cropping strategy to use for the document.
    The strategies choose from different backend,
    which depends on what kinds of documents are being processed.

    Configurations of the croppers are limited to primitive types,
    such as `int`, `float`, `str`, `bool`, etc.
    They are configured as strings, and are evaluated at runtime with `InlineEval`.

    If a function of `int -> CroppingStrategy` is provided,
    the cropping strategy would be initialised per-page, dynamically.
    This allows users for specifying different strategies for different pages.
    """

    grid_gen: str = "PLUMBER"
    """
    The grid generation strategy to use
    """

    @property
    def dpi(self) -> int:
        return self.per_page_dpi()

    def per_page_dpi(self, page: int | None = None):
        return self.image_cropper(page).dpi

    def __post_init__(self):
        if not Path(self.filename).exists():
            raise FileNotFoundError(f"File {self.filename} does not exist.")

        if self.dpi <= 0:
            raise ValueError(f"DPI must be positive, got {self.dpi}.")

        # See if the cropping strategy is valid.
        _ = self.crop_strat_fn

    def __len__(self):
        with self._read_pages() as pages:
            return len(pages)

    @cached_property
    def crop_strat_fn(self) -> Callable[[int], CroppingStrategy]:
        """
        Convert the user-specified `cropping` strategy to a function that returns a `CroppingStrategy`.

        If the given `cropping` is a function (per-page cropping strategy), the page number cannot be negative.
        """

        if callable(self.cropping):

            def crop_strat_page(page: int) -> CroppingStrategy:
                if page < 0:
                    raise ValueError("Page must be specified when using a per-page cropping strategy.")
                return CroppingStrategy(**self.cropping(page))

            return crop_strat_page

        return lambda _: CroppingStrategy(**self.cropping)

    @property
    def rel_scale(self) -> float:
        """
        The relative scale of the document.

        Returns:
            float: The relative scale of the document.
        """

        return self.dpi / 72

    @property
    def fname(self) -> str:
        """
        Returns the filename as a string.
        """

        return str(self.filename)

    @property
    def name(self) -> str:
        """
        Returns the name of the document

        Args:
            document (Document): The document.

        Returns:
            str: The name of the document.
        """
        return Path(self.fname).stem

    @property
    def type(self) -> str:
        """
        Returns the type of the document

        Returns:
            str: The type of the document.
        """
        return self.fname.split(".")[-1]

    @property
    def is_pdf(self) -> bool:
        return self.type == "pdf"

    def __array__(self):
        return np.array(self._to_numpy_list())

    def _to_numpy_list(self) -> List[NDArray]:
        return [np.array(page) for page in self.page_contents]

    @contextlib.contextmanager
    def _read_pages(self, **pdf_plumber_kwargs: Any):
        """
        Open the PDF file and return the pages.

        Internally, this uses the `pdfplumber` library, and must be used in a ``with`` statement.

        Args:
            **pdf_plumber_kwargs: Additional keyword arguments to pass to `pdfplumber.open`.

        Example:
            >>> with document._read_pages() as pages:
            ...     for page in pages:
            ...         print(page)
        """

        import pdfplumber

        if not self.is_pdf:
            raise NotImplementedError(f"Only PDF files are supported, got {self.type}.")

        # Downlaod if the file is a URL. Try parsing it with urllib.
        if _valid_url(self.fname):
            fname = _download_file(self.fname)
        else:
            fname = self.fname

        with pdfplumber.open(fname, **pdf_plumber_kwargs) as pdf:
            yield pdf.pages

    @cached_property
    def grid_generator(self) -> GridGen:
        name_kwargs = _EVALUATOR(self.grid_gen)

        return GridGen.factory(name_kwargs.kind, **name_kwargs.kwargs)

    @property
    def pages(self):
        return self.page_contents

    @cached_property
    def page_contents(self) -> Tuple[Content, ...]:
        """
        Loads a single pages as a list of platform independent, croppable pages,
        on which you would be able to perform various extraction operations.

        Returns:
            A tuple of pages, each of which is a `Content` object.
            The `Content` object supports cropping and extraction of text, images and tables.
        """

        length = len(self)

        return tuple(Content(document=self, page=i) for i in range(length))

    def view(self, page_chunk: int) -> List[DocumentView]:
        """
        Splits the document into chunks of size `page_chunk_size`.

        Args:
            page_chunk: The number of pages per chunks.

        Returns:
            The document views.
        """

        return [
            DocumentView(**vars(self), page_idxs=range(i, min(i + page_chunk, len(self))))
            for i in range(0, len(self), page_chunk)
        ]

    def text_cropper(self, page: int = -1) -> TextCropper:
        return self.__get_cropper(page=page, crop="text")

    def table_cropper(self, page: int = -1) -> TableCropper:
        return self.__get_cropper(page=page, crop="table")

    def image_cropper(self, page: int = -1) -> ImageCropper:
        return self.__get_cropper(page=page, crop="image")

    def __get_cropper(
        self,
        *,
        page: int = -1,
        crop: Literal["image", "text", "table"],
    ) -> _T:
        """
        Get the cropper for the given strategy, page and crop.

        Args:
            strategy:
                Either a `CroppingStrategy` or a function of `int -> CroppingStrategy`.
                If a function is provided, the strategy would be initialised per-page, dynamically (page must be specified).
                If the strategy is a `CroppingStrategy`, the same strategy would be used for all pages.

            crop: The type of cropper to get. One of "image", "text" or "table".

            page: The current page. Defaults to -1.

        Raises:
            ValueError: If the cropping strategy is per-page but the page is not specified.
            ValueError: If the crop type is not one of "image", "text" or "table".

        Returns:
            The cropper for the given strategy, page and crop.
        """

        strategy = self.crop_strat_fn(page)
        crop_strategy = strategy[crop]

        # Parse the cropping strategy.
        name_kwargs = _EVALUATOR(crop_strategy)

        # Get the class.
        try:
            cropper_class = {"image": ImageCropper, "text": TextCropper, "table": TableCropper}[crop]
        except KeyError as ke:
            raise ValueError(f"Invalid cropper type: {crop}") from ke

        return cropper_class.factory(name_kwargs.kind, **name_kwargs.kwargs)


def _download_file(url: str):
    """Downloads a file from the given URL and saves it as the specified filename."""

    response = requests.get(url)
    [filename] = url.rsplit("/", 1)

    response.raise_for_status()
    with open(filename, "wb") as file:
        file.write(response.content)
    logging.info(f"File downloaded successfully: %s", filename)

    return filename


def _valid_url(path: str):
    try:
        result = urlparse(path)
        return result.scheme in ["http", "https"] and result.path
    except ValueError:
        return False


@dataclass(frozen=True)
class _DocViewMixin:
    """
    A mixin made to ensure that keyword arguments always exist last (some dataclass mechanism).
    This should be placed after any other dataclass that has optional (keyword) arguments.
    """

    page_idxs: range
    """
    The pages to view. Must be have a start and end, with step = 1.
    Both start and end must be in the range [0, len(document)].
    """


@dataclass(frozen=True)
class DocumentView(Document, _DocViewMixin):
    """
    ``PdfDocumentView`` is a view of a document, kind of like slices to arrays, but for documents.
    Acting like a proxy to read only a portion of the document,
    this class makes it possible to do page-level parallel processing.

    Note:
        This class inherits from ``Document``, s.t. no code changes are needed for existing code.
        However, this might not be the best decision going forward.
        It might be better to have a separate class.
    """

    def __post_init__(self):
        super().__post_init__()

        assert self.page_idxs.start >= 0, "Start must be >= 0."
        assert self.page_idxs.stop <= super().__len__(), "End must be <= len(document)."
        assert self.page_idxs.step == 1, "Step must be 1."
        assert self.page_idxs.start <= self.page_idxs.stop, "Start must be <= end."

    def __len__(self) -> int:
        return len(self.page_idxs)

    @property
    def start(self) -> int:
        return self.page_idxs.start

    @property
    def end(self) -> int:
        return self.page_idxs.stop

    @cached_property
    def page_contents(self: Document) -> Tuple[Content, ...]:
        return tuple(Content(document=self, page=i) for i in self.page_idxs)

    @contextlib.contextmanager
    def _read_pages(self, **pdf_plumber_kwargs: Any):
        with super()._read_pages(**pdf_plumber_kwargs) as pages:
            yield [pages[i] for i in self.page_idxs]
