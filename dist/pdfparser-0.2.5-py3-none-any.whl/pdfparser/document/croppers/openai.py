# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass, field
from functools import cached_property
from typing import TYPE_CHECKING, Any, Dict

import jinja2
import numpy as np
from PIL.Image import Image

from pdfparser.providers import OpenaiVLM, OpenaiVLMSpec

from .api import ImageCropper, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from pdfparser import BoundingBox
    from pdfparser.document import Content


@dataclass
class _OpenaiBaseSpec(ABC):
    """
    The shared part of the OpenAI spec.

    This dataclass is intentionally made mutable because this is the most DRY way to implement the default values,
    where subclasses set the default values for the fields inside the `__post_init__` method,
    or any values that are shared between the classes.
    """

    api_key: str
    """
    The API key to use.
    """

    endpoint: str
    """
    The endpoint to use.
    For example, "https://genai.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-05-01-preview"
    """

    max_tokens: int = 100
    """
    The maximum number of tokens to generate for the remote model.
    """
    system_prompt: str = ""
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = ""
    """
    The user prompt to use for the API.
    """

    image_cropper_type: str = "PLUMBER"
    """
    The type of image cropper to use.
    """

    image_cropper_spec: Dict[str, Any] = field(default_factory=dict)
    """
    The spec for the image cropper.
    """

    @property
    def vlm(self):
        return OpenaiVLM(
            OpenaiVLMSpec(
                api_key=self.api_key,
                endpoint=self.endpoint,
                max_tokens=self.max_tokens,
                system_prompt=self.system_prompt,
            )
        )

    @cached_property
    def jinja_template(self):
        return jinja2.Environment().from_string(self.user_text_prompt)


def openai_vlm_call(self, content: Content, bbox: BoundingBox | None = None) -> str:
    """
    The shared part for the OpenAI VLMs' `__call__` method.
    """

    img_crop = ImageCropper.factory(self.spec.image_cropper_type, **self.spec.image_cropper_spec)
    img: Image = img_crop.crop_bbox(content, bbox)
    out = self.spec.vlm(text=self.spec.user_text_prompt, img=np.array(img))
    return out


@dataclass
class OpenaiTextSpec(TextCropperSpec, _OpenaiBaseSpec):
    def __post_init__(self):
        self.system_prompt = self.system_prompt or "You are a good image recognizer."
        self.user_text_prompt = self.user_text_prompt or "Given the image, come up with a discriptive sentence."


class Openai(TextCropper, spec_class=OpenaiTextSpec):
    """
    The OpenAI enable backend to extract table from image or scanned document.
    """

    crop_bbox = openai_vlm_call


@dataclass
class OpenaiTableSpec(TableCropperSpec, _OpenaiBaseSpec):
    def __post_init__(self):
        self.system_prompt = self.system_prompt or "You are a good table recognizer."
        self.user_text_prompt = self.user_text_prompt or " ".join(
            [
                "Given the image of a tabular data,",
                "output the table in markdown table format.",
                "I want the table to be aligned in text and look nice.",
                "I just want the table, nothing else,",
                "not even markdown fences.",
            ]
        )


class Openai(TableCropper, spec_class=OpenaiTableSpec):
    """
    The OpenAI enable backend to extract table from image or scanned document.
    """

    crop_bbox = openai_vlm_call


def grounded_llm_call(self, content: Content, ground: str, bbox: BoundingBox | None = None) -> str:
    """
    The shared part for the grounded LLMs' `__call__` method.
    """

    img_crop = ImageCropper.factory(self.spec.image_cropper_type, **self.spec.image_cropper_spec)
    img = img_crop.crop_bbox(content, bbox)

    return self.spec.vlm(self.spec.jinja_template.render(output=ground), img=np.array(img))


@dataclass
class TextGroundedLLMSpec(TextCropperSpec, _OpenaiBaseSpec):
    text_cropper_type: str = "PLUMBER"
    """
    The type of text cropper to use.
    """

    text_cropper_spec: Dict[str, Any] = field(default_factory=dict)
    """
    The spec for the text cropper.
    """

    def __post_init__(self):
        self.system_prompt = self.system_prompt or "You are a good table recognizer."
        self.user_text_prompt = self.user_text_prompt or " ".join(
            [
                "{{ output }}",
                "",
                "The above is the (maybe failed) parsing outcome of extracting a page,"
                "Given that page output page in its correct order.",
            ]
        )


class GroundedLLM(TextCropper, spec_class=TextGroundedLLMSpec):
    """
    LLM that is grounded by the ground truth of the text.
    This works by using the ground truth text to generate the user prompt for the LLM,
    ensuring that LLM does not hallucinate.
    """

    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        text_crop: TextCropper = TextCropper.factory(self.spec.text_cropper_type, **self.spec.text_cropper_spec)
        verbal = text_crop.crop_bbox(content, bbox)

        return grounded_llm_call(self=self, content=content, ground=verbal, bbox=bbox)


@dataclass
class TableGroundedLLMSpec(TableCropperSpec, _OpenaiBaseSpec):
    table_cropper_type: str = "PLUMBER"
    """
    The type of table cropper to use.
    """

    table_cropper_spec: Dict[str, Any] = field(default_factory=dict)
    """
    The spec for the table cropper.
    """

    def __post_init__(self):
        self.system_prompt = self.system_prompt or "You are a good table recognizer."
        self.user_text_prompt = self.user_text_prompt or " ".join(
            [
                "{{ output }}",
                "",
                "The above is the (maybe failed) parsing outcome of extracting a table,"
                "Given that page table output the table in markdown table format.",
                "I want the table to be aligned in text and look nice.",
                "I just want the table, nothing else.",
            ]
        )


class GroundedLLM(TableCropper, spec_class=TableGroundedLLMSpec):
    """
    LLM that is grounded by the ground truth of the table.
    This works by using the ground truth table to generate the user prompt for the LLM,
    ensuring that LLM does not hallucinate.
    """

    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        table_crop: TableCropper = TableCropper.factory(self.spec.table_cropper_type, **self.spec.table_cropper_spec)
        verbal = table_crop.crop_bbox(content, bbox)

        return grounded_llm_call(self=self, content=content, ground=verbal, bbox=bbox)
