# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
from functools import reduce
from pathlib import Path
from typing import Mapping, NamedTuple, Sequence, Union

from lark import Lark, Transformer, v_args

_CURRENT_DIR = Path(__file__).parent

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)

__all__: list[str] = ["InlineEval", "UnparsableError"]


class UnparsableError(TypeError):
    pass


class _KindAndKwargs(NamedTuple):
    kind: str
    kwargs: Mapping[str, int | float | str | bool]


CompatibleKindAndKwargs = Union[
    _KindAndKwargs,
    dict[str, Union[int, float, str, bool]],
    tuple[str, dict[str, Union[int, float, str, bool]]],
    str,
]


class InlineEval:
    """
    Translate the inline evaluation syntax to a dictionary.

    Example:
        >>> parser = LarkInlineEvalAdaptor()
        >>> parser("int(x=1)")
        {'type': 'int', 'kwargs': {'x': 1}}

        >>> parser('function()')
        {'type': 'function', 'kwargs': {}}

        >>> parser('function(x=1, y="2")')
        {'type': 'function', 'kwargs': {'x': 1, 'y': '2'}}
    """

    def __init__(self, fname: str | Path = _CURRENT_DIR / "inline_eval.lark"):
        grammar = Path(fname).read_text()
        self._parser = Lark(grammar)

    def parse(self, s: str) -> _KindAndKwargs:
        tree = self._parser.parse(s)
        return _LarkTransformer().transform(tree)

    def __call__(self, pp) -> _KindAndKwargs:
        LOGGER.info("Parsing: %s", pp)

        if isinstance(pp, str):
            result = self.parse(pp)
            return result

        if isinstance(pp, Sequence) and len(pp) == 2:
            name, kwargs = pp
            return _KindAndKwargs(kind=name, kwargs=kwargs)

        if isinstance(pp, Mapping) and len(pp) == 2 and "kind" in pp and "kwargs" in pp:
            return _KindAndKwargs(**pp)

        # In case someone else decides to roll their own object.
        if hasattr(pp, "kind") and hasattr(pp, "kwargs"):
            return _KindAndKwargs(kind=pp.kind, kwargs=pp.kwargs)  # type: ignore

        raise UnparsableError(f"Invalid argument {pp}. Must be a string or a tuple of string and dict (kwargs).")


@v_args(inline=True)
class _LarkTransformer(Transformer):
    # NOTE:
    #   `ClassVar` of `FunctionType` is treated like a method, so you must have a first argument,
    #   whereas other objects are classvars, even if they are callable.

    INT = eval
    FLOAT = eval
    STRING = eval
    BOOL = eval
    token = str

    func = lambda self, *token: ".".join(token)
    posarg = lambda self, x: x
    kwarg = lambda self, token, posarg: {token: posarg}
    args = lambda self, *args: reduce(lambda x, y: {**x, **y}, args, {})

    start = lambda self, token, args=None: _KindAndKwargs(kind=token, kwargs=args or {})
