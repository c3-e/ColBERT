# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from functools import lru_cache
from typing import Generic, Iterator, List, Type, TypeVar, cast

import jinja2
from typing_extensions import Self

from pdfparser import utils
from pdfparser.document import Document

from .core.doc_bboxes import DocBboxes

I = TypeVar("I", bound=DocBboxes, contravariant=True)
O = TypeVar("O", bound=DocBboxes, covariant=True)

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)

# Match for example c3.ai, c3.ai.abc, c3.cafe.abc.def, etc.
C3_REGEX = re.compile(r"c3(?:\.[a-z]+)+\.[a-z]+")

ENV = jinja2.Environment()
DOC_TEMPLATE = ENV.from_string(
    """
    `LayoutModule` documentation:
    {{ layout_module_doc }}

    `{{ type }}` documentation:
    {{ submodules_doc }}
    """
)


class LayoutModule(ABC):
    """
    `LayoutModule` is the base class for all layout components,
    it defines and provides a bunch of utility functions for layout components.

    This class would be running remotely when:

        1. The class is called with `remote()`.
        2. The class is configured to run remotely with `remote` flag set in class parameters.
        3. The class is running inside a C3 environment.
    """

    _is_remote: bool = False
    """
    Whether this class is running remotely.

    This is a class variable by design so that it can be accessed without an instance.
    Subclasses can overwrite this value, or set it to True in the constructor (instance variable).
    """

    @classmethod
    def __init_subclass__(cls, remote: str | None = None, **kwargs):
        super().__init_subclass__(**kwargs)

        if remote is not None:
            if not C3_REGEX.match(remote):
                raise ValueError(f"{remote=} is not a valid C3 path.")

        cls.C3_TYPE_CLASS = remote
        cls.__doc__ = DOC_TEMPLATE.render(
            layout_module_doc=LayoutModule.__doc__, type=cls.__name__, submodules_doc=cls.__doc__
        )

    def remote(self, value: bool = True) -> Self:
        self._is_remote = value
        return self

    @property
    def proxy(self) -> Self:
        if not self._is_remote:
            return self

        # If the class isn't configured to run remotely, return self.
        if self.C3_TYPE_CLASS is None:
            LOGGER.info("Class configured to be remote, but no C3 path provided, running locally.")
            return self

        # If c3 is not present, this doens't work as well.
        if utils.c3_ctx() is None:
            LOGGER.info("Class configured to be remote, but C3 context not found, running locally.")
            return self

        c3 = utils.c3_ctx()

        # c3 stuff is present.
        return cast(Self, eval(self.C3_TYPE_CLASS))

    @classmethod
    def _get_desc_by_name(cls, name: str) -> List[LayoutModule]:
        path = name.split(".")
        return cls._get_desc_by_path(*path)

    @classmethod
    @lru_cache(maxsize=1024)
    def _get_desc_by_path(cls, *path: str) -> List[LayoutModule]:
        """
        Return the module if the path is either the full path,
        or a post fix of the full path.
        Or else return None.

        Args:
            path: The path to the module.

        Returns:
            The module if found, else None.
        """

        if not path:
            return [cls]

        results = []
        head, *rest = path

        # Find subclass where the head matches the name.
        subc = next((subc for subc in cls.__subclasses__() if subc.__name__ == head), None)

        # Exhausively search for all cases.
        # Implementing this is a little tricky, as this pattern is not commonly seen.
        #
        # This can still be solved with DFS,
        # tho a little tricky because we are searching for a path rather than the full thing.
        #
        # There are 2 ways to solve this:
        # 1. Remember the path, and match postfix at each node.
        # 2. Use fuzzy search, and we can break problems down with simple recursion / DP.
        # Here, I implemented the 2nd way.
        #
        # There are 2 cases in the 2nd way:
        # 1. The path is a full path, in which case, the root of the path should match one of the base classes.
        # 2. The path is a post fix of the full path. In which case, we recursively ask the submodules if they found anything.
        # This should be able to be proven to always be the case,
        # if we compute this in a bottom up fasion (all paths from short to long), so this should be Ok.

        # Recurively find all fuzzy path that consumes the current head.
        if subc is not None:
            found = subc._get_desc_by_path(*rest)
            results.extend(found)

        # Recursively find all fuzzy path that doesn't consume the current head.
        for klass in cls.__subclasses__():
            found = klass._get_desc_by_path(*path)
            results.extend(found)

        return results

    @classmethod
    def decltype(cls, name: str | List[str]) -> Type[LayoutModule]:
        """
        `decltype` is a function that can query any subclass of `LayoutModule` by name fuzzy path of family tree.

        Args:
            name:
                The name of the module to query.
                This can be a fuzzy path of the family tree.
                If a string is provided, it is treated as a path and split by ".".

        Raises:
            TypeError: If `name` is not a str or a list of str.
            ValueError: If multiple classes are found for the given path.

        Returns:
            The class if found, else None.
        """

        result = cls._decltype(name)

        if len(result) == 1:
            return result[0]

        if not result:
            raise ValueError(f"No class found for {name=}. Provide a valid path please.")

        raise ValueError(f"Multiple classes found for {name=}, {result=}. Provide a unique path please.")

    @classmethod
    def _decltype(cls, name: str | List[str]):
        if isinstance(name, str):
            return cls._get_desc_by_name(name)

        if isinstance(name, list) and all(isinstance(n, str) for n in name):
            return cls._get_desc_by_path(*name)

        raise TypeError(f"{name=} must be a str or a list of str")

    def children(self, recursive: bool = False) -> Iterator[LayoutModule]:
        """
        Get all children of the current module.
        This is similar to `PyTorch`'s `children` method.

        Args:
            recursive:
                Whether to yield in post-order traversal or just the immediate children.
                Defaults to False.

        Yields:
            The children of the current module that are also `LayoutModule`s.
        """
        for attr in dir(self):
            child = getattr(self, attr)

            if isinstance(child, LayoutModule):
                # If recursive, yield in post-order traversal.
                if recursive:
                    yield from child.children(recursive)

                yield child


class LayoutProducer(LayoutModule, Generic[O], ABC):
    """
    The producer API for layout modules.

    Subclasses should implement the `produce` method,
    which takes in a `Document` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def __call__(self, document: Document, /) -> O:
        LOGGER.info(f"Producing %s with %s", self.__class__.__name__, document)
        return self.proxy.produce(document)

    @abstractmethod
    def produce(self, document: Document, /) -> O:
        pass


class LayoutConsumer(LayoutModule, Generic[I], ABC):
    """
    The consumer API for layout modules.

    Subclasses should implement the `consume` method,
    which takes in a `DocBboxes` object and does not return anything.

    This class must produce side effects, or else it is useless.
    """

    def __call__(self, input: I, /) -> None:
        LOGGER.info(f"Consuming %s with %s", self.__class__.__name__, input)
        self.proxy.consume(input)

    @abstractmethod
    def consume(self, input: I, /) -> None:
        pass


class LayoutExec(LayoutModule, Generic[I, O], ABC):
    """
    The executor API for layout modules.

    Subclasses should implement the `execute` method,
    which takes in a `DocBboxes` object and returns a `DocBboxes` object.

    This class should not produce any side effects.
    """

    def __call__(self, input: I, /) -> O:
        LOGGER.info(f"Executing %s with %s", self.__class__.__name__, input)
        return self.proxy.execute(input)

    @abstractmethod
    def execute(self, input: I, /) -> O:
        pass


decltype = LayoutModule.decltype
