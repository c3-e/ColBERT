# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path

import pytest

from pdfparser import CaptionFinder, DocBboxes, Document, LayoutParserOutput, ParsedMetadata


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


def collect(doc_bbox: DocBboxes):
    return LayoutParserOutput.init_with_mapping(
        doc_bbox,
        {"table": "TABLE", "Figure": "FIGURE", "Caption": "PLAIN", "": "IDK"},
    )


def test_caption_finder_dummy(document):
    finder = CaptionFinder.factory("DUMMY")

    assert finder is not None
    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.9),
                ParsedMetadata.flat_init(0, 0, 100, 110),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.94),
            ]
        ],
        document=document,
    )
    finder(document, collect(p), keywords=[])


def test_caption_finder_locality(document):
    finder = CaptionFinder.factory("LOCALITY")

    assert finder is not None
    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.9),
                ParsedMetadata.flat_init(0, 0, 100, 110),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.93),
            ],
        ],
        document=document,
    )

    out = finder(document, collect(p), keywords=[])
    assert isinstance(out, list)
    assert all(isinstance(o, list) for o in out)
