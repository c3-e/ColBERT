# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass

import pytest

from pdfparser.specs import Spec, specify
from pdfparser.specs.specs import pascal_to_upper_snake


@dataclass
class SampleSpec(Spec):
    integer: int


@specify(SampleSpec)
class SampleWithSpec:
    def __init__(self, spec: SampleSpec):
        super().__init__(spec)


def test_sample_specs():
    sample_spec = SampleSpec(integer=3242342)
    assert SampleWithSpec(sample_spec).spec is sample_spec
    assert SampleWithSpec(sample_spec).spec.integer == 3242342


def test_sample_spec_init():
    cfg = {"integer": 123456}
    spec = SampleSpec(**cfg)

    assert isinstance(spec, SampleSpec)
    assert spec.integer == 123456


@pytest.mark.parametrize(
    "source, target",
    [
        ("PascalCase", "PASCAL_CASE"),
        ("PascalToSnake", "PASCAL_TO_SNAKE"),
        ("PdfPlumber", "PDF_PLUMBER"),
        ("Camelot", "CAMELOT"),
        ("Openai", "OPENAI"),
        ("OpenAi", "OPEN_AI"),
        ("OpenAI", "OPEN_AI"),
        ("PyPdf2", "PY_PDF2"),
    ],
)
def test_pascal_to_upper_snake(source, target) -> None:
    assert pascal_to_upper_snake(source) == target


@pytest.mark.parametrize(
    "source",
    [
        "camelCase",
        "snake_case",
        "kebab-case",
        "UPPER_SNAKE",
        "There are spaces",
    ],
)
def test_failing_pascal_to_upper_snake(source):
    with pytest.raises(ValueError):
        pascal_to_upper_snake(source)
