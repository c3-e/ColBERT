# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass
from pathlib import Path

import pytest
import torch

from pdfparser import (
    DocBboxes,
    Document,
    LayoutModel,
    LayoutParserOutput,
    LayoutPostProc,
    LayoutPostProcPipe,
    LayoutPostProcSpec,
    ParsedMetadata,
)

from .envs import default_vgt_paths


@pytest.fixture
def device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


@pytest.fixture
def doc_bbox(document):
    return DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.9),
                ParsedMetadata.flat_init(0, 0, 110, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.91),
            ],
        ],
        document=document,
    )


def test_dummy_str():
    from pdfparser.layout.dummy import Dummy

    layout_parser = LayoutModel.factory("DUMMY")
    assert layout_parser is not None
    assert isinstance(layout_parser, Dummy)


def test_non_exists():
    with pytest.raises(KeyError):
        LayoutModel.factory("non_exists")
    assert "non_exists" not in LayoutModel.registered_classes()


@pytest.mark.parametrize("dgg", [True, False])
@pytest.mark.skipif(not default_vgt_paths(), reason="Model not available")
def test_layout_parser_vgt(document, dgg):
    from pdfparser.layout.vgt import Vgt

    layout_parser = LayoutModel.factory("VGT", **default_vgt_paths(), dont_generate_grid=dgg)
    assert layout_parser is not None
    assert isinstance(layout_parser, Vgt)

    out = layout_parser(document)
    assert isinstance(out, LayoutParserOutput), f"Expected DocumentBoundingBoxes, got {type(out)}"


def test_layout_parser_dummy(document):
    parser = LayoutModel.factory("DUMMY")
    out = parser(document)
    assert isinstance(out, LayoutParserOutput), f"Expected DocumentBoundingBoxes, got {type(out)}"


def test_layout_output(doc_bbox):
    assert LayoutParserOutput.init_with_mapping(
        doc_bbox, {"table": "TABLE", "Figure": "FIGURE", "Caption": "PLAIN", "": "IDK"}
    ).classes == ["IDK", "TABLE"]


def test_layout_post_pure_function():
    @LayoutPostProc.register
    def my_post_proc(output: LayoutParserOutput) -> LayoutParserOutput:
        return output

    @LayoutPostProc.register
    def my_other_post_proc(output: LayoutParserOutput) -> LayoutParserOutput:
        return output

    assert "MY_POST_PROC" in LayoutPostProc.registered_classes()
    assert "MY_OTHER_POST_PROC" in LayoutPostProc.registered_classes()

    post_proc = LayoutPostProcPipe(["MY_POST_PROC", "MY_OTHER_POST_PROC"])

    # A lazy man's test.
    unique_object = object()
    assert post_proc(unique_object) is unique_object


def test_layout_post_object():
    @LayoutPostProc.register
    def not_my_post_proc(output: LayoutParserOutput) -> LayoutParserOutput:
        return output

    @dataclass(frozen=True)
    class MyAnotherPostProcSpec(LayoutPostProcSpec):
        arg1: int = 1
        arg2: int = 2

    class MyAnotherPostProc(LayoutPostProc, spec_class=MyAnotherPostProcSpec):
        def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
            return output

    assert "NOT_MY_POST_PROC" in LayoutPostProc.registered_classes()
    assert "MY_ANOTHER_POST_PROC" in LayoutPostProc.registered_classes()

    post_proc = LayoutPostProcPipe(
        [
            {"type": "MY_ANOTHER_POST_PROC", "kwargs": {"arg2": 3}},
            ("MY_ANOTHER_POST_PROC", {"arg1": 1, "arg2": 2}),
        ]
    )

    # A lazy man's test.
    unique_object = object()
    assert post_proc(unique_object) is unique_object
