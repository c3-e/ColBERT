# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pdfparser import TextChunker


def test_dummy():
    from pdfparser.component.chunker.dummy import Dummy

    chk = TextChunker.factory("DUMMY")
    assert chk is not None
    assert isinstance(chk, Dummy)

    assert chk.chunk("abc") == ["a", "b", "c"]


def test_null():
    from pdfparser.component.chunker.null import Null

    chk = TextChunker.factory("NULL")
    assert chk is not None
    assert isinstance(chk, Null)

    assert chk.chunk("abc") == []


def test_longchain_no_page_num():
    from pdfparser.component.chunker.longchain import LongChain

    chk = TextChunker.factory("LONG_CHAIN", add_page_number=False)
    assert chk is not None
    assert isinstance(chk, LongChain)

    assert chk.chunk("A sentence ended here. This is the next one.") == ["A sentence ended here. This is the next one."]


def test_longchain_page_num():
    from pdfparser.component.chunker.longchain import LongChain

    chk = TextChunker.factory("LONG_CHAIN", add_page_number=True)
    assert chk is not None
    assert isinstance(chk, LongChain)

    assert chk.chunk("A sentence ended here. This is the next one.") == ["A sentence ended here. This is the next one."]


def test_longchain_page_num_small_split_21():
    from pdfparser.component.chunker.longchain import LongChain

    chk = TextChunker.factory("LONG_CHAIN", add_page_number=True, split_overlap=2, split_length=1)
    assert chk is not None
    assert isinstance(chk, LongChain)

    assert chk.chunk("A sentence ended here. This is the next one.") == [
        "A sentence ended here. ",
        "This is the next one.",
    ]


def test_longchain_page_num_small_split_12():
    from pdfparser.component.chunker.longchain import LongChain

    chk = TextChunker.factory("LONG_CHAIN", add_page_number=True, split_overlap=1, split_length=2)
    assert chk is not None
    assert isinstance(chk, LongChain)

    assert chk.chunk("A sentence ended here. This is the next one.") == [
        "A sentence ended here. ",
        "This is the next one.",
    ]


def test_longchain_special_token():
    from pdfparser.component.chunker.longchain import LongChain

    chk = TextChunker.factory("LONG_CHAIN", add_page_number=True, split_overlap=1, split_length=2)
    assert chk is not None
    assert isinstance(chk, LongChain)

    assert chk.chunk("\fA sentence ended here. This is the next one.") == [
        "\fA sentence ended here. ",
        "This is the next one.",
    ]
