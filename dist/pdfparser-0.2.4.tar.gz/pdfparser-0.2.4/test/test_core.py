# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

import numpy as np
import pytest

from pdfparser.core import Graph, Graphrame, UniqueIds


@pytest.mark.parametrize(
    "lst",
    [
        "123456",
        list("123456"),
        tuple("123456"),
        ["1", "2", "3", "4", "5", "6"],
        ("1", "2", "3", "4", "5", "6"),
    ],
)
def test_unique_ids(lst):
    uid = UniqueIds(lst)

    assert len(lst) == len(uid)
    for i in range(len(lst)):
        assert lst[i] == uid[i]


def test_unique_ids_eq():
    uid1 = UniqueIds("123456")
    uid2 = UniqueIds("123456")
    uid3 = UniqueIds("654321")
    assert uid1.equal_before_sorted(uid2)
    assert uid1.equal_after_sorted(uid2)
    assert not uid1.equal_before_sorted(uid3)
    assert uid1.equal_after_sorted(uid3)

    assert uid1 == uid2
    assert uid1 == uid3


def test_unique_ids_getitem():
    uid = UniqueIds("123456")
    assert uid[0] == "1"
    assert uid[1] == "2"
    assert uid[2] == "3"

    with pytest.raises(IndexError):
        uid[6]

    assert uid[[1, 2, 3]] == list("234")


def test_unique_ids_index():
    uid = UniqueIds("123456")
    assert uid.index("1") == 0
    assert uid.index("2") == 1
    assert uid.index("3") == 2

    with pytest.raises(ValueError):
        uid.index("7")

    assert uid.index(UniqueIds("123")) == [0, 1, 2]


def test_unique_ids_init():
    uid = UniqueIds.uuid(9)
    assert len(uid) == 9
    assert len({*uid}) == 9


@pytest.mark.parametrize(
    "lst",
    [
        "1234567,,",
        list("12345673"),
        tuple("12345627"),
        ["1", "2", "3", "4", "1", "6", "7"],
        ("b", "b", "3", "4", "a", "6", "7"),
    ],
)
def test_unique_ids_fail(lst):
    with pytest.raises(ValueError):
        UniqueIds(lst)


@dc.dataclass(frozen=True)
class D:
    a: int
    b: str
    c: float


@pytest.fixture(scope="function")
def graphrame():
    return Graphrame.from_dataclasses(
        [
            D(1, "a", 1.0),
            D(2, "b", 2.0),
            D(3, "c", 3.0),
        ]
    )


@pytest.fixture(scope="function")
def graph():
    return Graph.zeros(3)


def test_graph_links(graph):
    assert len(graph) == 3
    assert (graph.adj_mat == 0).all()
    graph.link(0, 1, bi=True)
    assert graph.is_linked(0, 1, bi=False)
    assert graph.adj_mat.tolist() == [[0, 1, 0], [1, 0, 0], [0, 0, 0]]
    graph.unlink(0, 1, bi=True)
    assert (graph.adj_mat == 0).all()
    assert not graph.is_linked(0, 1)

    graph.link(0, 1, bi=False)
    assert graph.adj_mat.tolist() == [[0, 1, 0], [0, 0, 0], [0, 0, 0]]
    graph.unlink(1, 0, bi=False)
    assert graph.adj_mat.tolist() == [[0, 1, 0], [0, 0, 0], [0, 0, 0]]
    graph.unlink(0, 1, bi=True)
    assert (graph.adj_mat == 0).all()


def test_graphrame_heritage(graph):
    assert len(graph) == 3
    graph.link(0, 1, bi=False)

    assert graph.children_of(0) == [1]
    assert graph.children_of(1) == []
    assert graph.parents_of(1) == [0]
    assert graph.parents_of(0) == []

    graph.link(1, 2, bi=True)
    assert graph.children_of(0) == [1]
    assert graph.children_of(1) == [2]
    assert graph.children_of(2) == [1]
    assert graph.parents_of(2) == [1]
    assert graph.parents_of(1) == [0, 2]
    assert graph.parents_of(0) == []


def test_multigraph_list_query(graphrame):
    ids = graphrame.ids

    res_str = graphrame.query([ids[0], ids[1]])
    res_int = graphrame.query([0, 1])
    assert isinstance(res_str, Graphrame), f"Expected Graphrame, got {type(res_str)}"
    assert isinstance(res_int, Graphrame), f"Expected Graphrame, got {type(res_int)}"
    assert res_str.keys() == res_int.keys()
    assert np.all(res_str.df == res_int.df)
