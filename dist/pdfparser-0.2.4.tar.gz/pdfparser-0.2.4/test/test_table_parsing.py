# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import os
from pathlib import Path

import pytest

from pdfparser import (
    CroppingStrategy,
    DocBboxes,
    Document,
    LayoutParserOutput,
    ParsedMetadata,
    TableParser,
    TableParserSpec,
)

from .envs import skip_openai_test


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


def collect(doc_bbox: DocBboxes):
    return LayoutParserOutput.init_with_mapping(
        doc_bbox,
        {"Table": "TABLE", "Caption": "PLAIN", "": "IDK"},
    )


@pytest.mark.parametrize("typ", ["CAMELOT", "PLUMBER"])
def test_table_parsing(fname, typ):
    document = Document(filename=fname, cropping=CroppingStrategy(table=typ))
    table = TableParser(TableParserSpec(content_parser_typ="DEFAULT", title_finder_typ="LOCALITY"))

    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Table", 0.9),
                ParsedMetadata.flat_init(0, 0, 101, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Caption", 0.9),
            ],
        ],
        document=document,
    )

    out = table(collect(p))
    assert len(out) == 1


@pytest.mark.skipif(skip_openai_test(), reason="OpenAI API key and endpoint not set")
@pytest.mark.parametrize("typ", ["GROUNDED_LLM", "OPENAI"])
def test_table_openai(fname, typ):
    document = Document(
        filename=fname,
        cropping=CroppingStrategy(
            table={
                "type": typ,
                "kwargs": {
                    "api_key": os.environ["OPENAI_API_KEY"],
                    "endpoint": os.environ["OPENAI_ENDPOINT"],
                    "max_tokens": 1000,
                },
            }
        ),
    )

    from pdfparser.component import TableParser, TableParserSpec

    table = TableParser(
        TableParserSpec(
            content_parser_typ="DEFAULT",
            title_finder_typ="LOCALITY",
            content_parser_kwargs={},
        )
    )

    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Table", 0.9),
                ParsedMetadata.flat_init(0, 0, 100, 103),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Caption", 0.9),
            ],
        ],
        document=document,
    )

    out = table(collect(p))
    assert len(out) == 1


def test_table_content_dummy(document):
    from pdfparser.component.table import TableContent, TableTitledComponent

    table = TableContent.factory("DUMMY")

    compo = TableTitledComponent(page=1, title="title", bbox=ParsedMetadata.flat_init(0, 0, 100, 100))

    out = table(document, compo)
    assert out == ""
