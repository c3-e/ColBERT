# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path
from typing import List

import pytest

from pdfparser import BoundingBox, DocBboxes, Document, LayoutPostProc, ParsedMetadata


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


def box_list_equal(b1: List[BoundingBox], b2: List[BoundingBox]):
    b1 = sorted(b1, key=lambda x: x.corners)
    b2 = sorted(b2, key=lambda x: x.corners)

    return b1 == b2


def test_bboxes_to_grid():
    import numpy as np

    from pdfparser.layout.postproc.doclaynets import boxes_to_grid

    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=80, y_1=80, x_2=100, y_2=100)

    expected_output = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
        ]
    )
    skips = 0, 0
    output = boxes_to_grid([bbox1, bbox2], grid_step=10, page_image_size=(100, 100), boundary_skips=skips)
    assert np.array_equal(output, expected_output), f"Test case 1 failed: {output}"

    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=40, y_1=40, x_2=60, y_2=60)

    expected_output = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 1, 1, 1, 2, 2, 1, 0, 0, 0, 0],
            [0, 1, 1, 1, 2, 2, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]
    )
    output = boxes_to_grid([bbox1, bbox2], grid_step=10, page_image_size=(100, 100), boundary_skips=skips)
    assert np.array_equal(output, expected_output), f"Test case 2 failed: {output}"


def test_find_seperator_of_groups():
    from pdfparser.layout.postproc.doclaynets import find_seperator_of_groups

    grid_value_norm = [0.1, 0.2, 0.3, 0.1, 0.05, 0.2, 0.3, 0.4, 0.1, 0.05]
    lp_filter = 0.15
    grid_step = 10
    max_seps_allowed = 3

    expected_separators = [10, 45, 95]
    separators = find_seperator_of_groups(grid_value_norm, lp_filter, grid_step, max_seps_allowed)
    assert separators == expected_separators, f"Test case 1 failed: {separators}"

    grid_value_norm = [0.05, 0.1, 0.05, 0.2, 0.3, 0.1, 0.05, 0.2, 0.3, 0.4]
    lp_filter = 0.1
    grid_step = 5
    max_seps_allowed = 2

    expected_separators = []
    separators = find_seperator_of_groups(grid_value_norm, lp_filter, grid_step, max_seps_allowed)
    assert separators == expected_separators, f"Test case 2 failed: {separators}"


def test_filter_doc():
    from pdfparser.layout.postproc.doclaynets import filter_doc

    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.3)
    bbox2 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Text", score=0.1)
    bbox3 = ParsedMetadata.flat_init(x_1=20, y_1=20, x_2=60, y_2=60, klass="Picture", score=0.7)
    bbox4 = ParsedMetadata.flat_init(x_1=90, y_1=90, x_2=110, y_2=110, klass="Picture", score=0.5)

    doc_bboxes = [[bbox1, bbox2], [bbox3, bbox4]]
    bbox_filter_dict = {"Text": 0.2, "Picture": 0.6}

    expected_output = [[bbox1], [bbox3]]
    filtered_boxes = filter_doc(doc_bboxes, bbox_filter_dict)
    assert filtered_boxes == expected_output, f"Test case 1 failed: {filtered_boxes}"

    bbox_filter_dict = {"Text": 0.4, "Picture": 0.8}
    expected_output = [[], []]
    filtered_boxes = filter_doc(doc_bboxes, bbox_filter_dict)
    assert filtered_boxes == expected_output, f"Test case 2 failed: {filtered_boxes}"

    bbox_filter_dict = {"Text": 0.1, "Picture": 0.5}
    expected_output = [[bbox1, bbox2], [bbox3, bbox4]]
    filtered_boxes = filter_doc(doc_bboxes, bbox_filter_dict)
    assert filtered_boxes == expected_output, f"Test case 3 failed: {filtered_boxes}"

    bbox_filter_dict = {"Text": 0.2, "Picture": 0.6, "Table": 0.3}
    expected_output = [[bbox1], [bbox3]]
    filtered_boxes = filter_doc(doc_bboxes, bbox_filter_dict)
    assert filtered_boxes == expected_output, f"Test case 4 failed: {filtered_boxes}"


def test_image_from_pdf(document):
    result = [im.image for im in document.page_contents]
    assert isinstance(result, list)
    assert len(result)


def test_unioning_intra_dict():
    from pdfparser.layout.postproc.doclaynets import unioning_dict

    threshold = 0.1
    # Test case 1: Simple union
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=70, y_2=70, klass="Text", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Picture", score=0.7)

    bboxes = [bbox1, bbox2, bbox3]
    consolidation = {"Text": ["Text"], "Picture": ["Picture"]}

    expected_output = [BoundingBox(x_1=10, y_1=10, x_2=70, y_2=70), BoundingBox(x_1=80, y_1=80, x_2=100, y_2=100)]
    output = unioning_dict(bboxes, consolidation, threshold)
    assert box_list_equal([p.bbox for p in output], expected_output), f"Test case 1 failed: {output}"

    # Test case 2: No union needed
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=60, y_1=60, x_2=100, y_2=100, klass="Text", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=110, y_1=110, x_2=150, y_2=150, klass="Picture", score=0.7)

    bboxes = [bbox1, bbox2, bbox3]
    consolidation = {"Text": ["Text"], "Picture": ["Picture"]}

    output = unioning_dict(bboxes, consolidation, threshold)
    assert box_list_equal([p.bbox for p in output], [p.bbox for p in bboxes]), f"Test case 2 failed: {output}"


def test_removing_overlapping_inter_dict():
    from pdfparser.layout.postproc.doclaynets import removing_overlapping_dict

    # Test case 1: Simple overlap removal
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=70, y_2=70, klass="Text", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Picture", score=0.7)

    bboxes = [bbox1, bbox2, bbox3]
    consolidation = {"Text": ["Text"], "Picture": ["Picture"]}
    threshold = 0.5

    expected_output = [bbox2.bbox, bbox3.bbox]
    output = removing_overlapping_dict(bboxes, consolidation, threshold)
    assert box_list_equal([p.bbox for p in output], expected_output), f"Test case 1 failed: {output}"

    # Test case 2: No overlap removal
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=30, y_1=30, x_2=70, y_2=70, klass="Text", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Picture", score=0.7)

    bboxes = [bbox1, bbox2, bbox3]
    consolidation = {"Text": ["Text"], "Picture": ["Picture"]}
    threshold = 0.5

    output = removing_overlapping_dict(bboxes, consolidation, threshold)
    assert box_list_equal([p.bbox for p in output], [p.bbox for p in bboxes]), f"Test case 2 failed: {output}"


def test_dumb_merge():
    from pdfparser.layout.postproc.doclaynets import dumb_merge

    # Test case 1: Simple overlap removal
    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=10, y_1=10, x_2=70, y_2=70)
    bbox3 = BoundingBox(x_1=80, y_1=80, x_2=100, y_2=100)

    bboxes = [bbox1, bbox2, bbox3]
    threshold = 0.5

    output = dumb_merge(bboxes, threshold)
    assert output == {1, 2}, f"Test case 1 failed: {output}"

    # Test case 2: No overlap removal
    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=60, y_1=60, x_2=100, y_2=100)

    bboxes = [bbox1, bbox2]
    threshold = 0.5

    output = dumb_merge(bboxes, threshold)
    assert output == {0, 1}, f"Test case 2 failed: {output}"


def test_union_bounding_box():
    from pdfparser.layout.postproc.doclaynets import union_find_bounding_box

    # Test case 1: Simple union
    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=10, y_1=10, x_2=70, y_2=70)
    bbox3 = BoundingBox(x_1=80, y_1=80, x_2=100, y_2=100)

    bboxes = [bbox1, bbox2, bbox3]
    threshold = 0.1

    unioned_nodes = union_find_bounding_box(bboxes, threshold)
    expected_heads = [1, 1, 2]
    for unique in set(expected_heads):
        indices = [i for i, x in enumerate(expected_heads) if x == unique]
        assert (
            len(set(node.find(unioned_nodes) for node in [unioned_nodes[i] for i in indices])) == 1
        ), f"Test case 1 failed: {unioned_nodes} have different heads"

    # Test case 2: No union needed
    bbox1 = BoundingBox(x_1=10, y_1=10, x_2=50, y_2=50)
    bbox2 = BoundingBox(x_1=60, y_1=60, x_2=100, y_2=100)

    bboxes = [bbox1, bbox2]
    threshold = 0.1

    unioned_nodes = union_find_bounding_box(bboxes, threshold)
    expected_heads = [0, 1]
    assert set(node.find(unioned_nodes) for node in unioned_nodes) == {0, 1}, f"Test case 2 failed: {unioned_nodes}"


def test_group_list_by():
    from pdfparser.layout.postproc.doclaynets import group_list_by

    # Test case 1: Group by class name
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=30, y_1=30, x_2=70, y_2=70, klass="Caption", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Text", score=0.7)

    bboxes = [bbox1, bbox2, bbox3]
    grouped_by_class = group_list_by(bboxes, key=lambda i: bboxes[i].klass)

    expected_output_class = {
        "Text": [bbox1, bbox3],
        "Caption": [bbox2],
    }
    assert grouped_by_class == expected_output_class, f"Test case 1 failed: {grouped_by_class}"

    # Test case 2: Group by score
    bbox1 = ParsedMetadata.flat_init(x_1=10, y_1=10, x_2=50, y_2=50, klass="Text", score=0.9)
    bbox2 = ParsedMetadata.flat_init(x_1=30, y_1=30, x_2=70, y_2=70, klass="Caption", score=0.8)
    bbox3 = ParsedMetadata.flat_init(x_1=80, y_1=80, x_2=100, y_2=100, klass="Text", score=0.9)

    bboxes = [bbox1, bbox2, bbox3]
    grouped_by_score = group_list_by(bboxes, key=lambda x: bboxes[x].score)

    expected_output_score = {
        0.9: [bbox1, bbox3],
        0.8: [bbox2],
    }
    assert grouped_by_score == expected_output_score, f"Test case 2 failed: {grouped_by_score}"


@pytest.fixture(scope="function")
def doc_bboxes(document):
    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "Figure", 0.9),
                ParsedMetadata.flat_init(0, 0, 120, 100),
                ParsedMetadata.flat_init(0, 0, 100, 101, "Caption", 0.9),
            ],
        ],
        document=document,
    )
    return p


@pytest.fixture
def list_doc_bboxes(doc_bboxes):
    plll = ["PLAIN", "LIST", "LIST", "LIST"]
    doc_bboxes.data["klass"] = plll
    return doc_bboxes


@pytest.mark.parametrize("cross_page", [True, False])
def test_list_combiner(list_doc_bboxes, cross_page):
    combiner = LayoutPostProc.factory("LIST_COMBINER", cross_page=cross_page)
    output: DocBboxes = combiner(list_doc_bboxes)
    assert sorted(output.rels["parent"].edges.tolist()) == sorted([[1, 2], [1, 3]])


@pytest.fixture
def header_doc_bboxes(doc_bboxes):
    hphh = ["HEADER", "PLAIN", "HEADER", "HEADER"]
    doc_bboxes.data["klass"] = hphh
    doc_bboxes.data["y_2"] = [100, 99, 100, 97]
    return doc_bboxes


def test_bbox_size_header_hierarchy(header_doc_bboxes):
    output: DocBboxes = LayoutPostProc.factory("BBOX_SIZE_HEADER_HIERARCHY")(header_doc_bboxes)
    assert list(output.rels["parent"].edges)
