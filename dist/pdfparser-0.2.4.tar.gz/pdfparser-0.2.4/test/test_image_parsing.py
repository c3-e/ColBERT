# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import os
from pathlib import Path

import numpy as np
import pytest

from pdfparser import BoundingBox, DocBboxes, Document, ImageParser, ImageParserSpec, LayoutParserOutput, ParsedMetadata

from .envs import skip_openai_test


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def document(fname):
    return Document(fname)


def collect(doc_bbox: DocBboxes):
    return LayoutParserOutput.init_with_mapping(
        doc_bbox,
        {"table": "TABLE", "Figure": "FIGURE", "Caption": "PLAIN", "": "IDK"},
    )


def test_image_parser_null(document):
    img = ImageParser(ImageParserSpec(caption_finder_typ="LOCALITY"))

    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(0, 0, 100, 100),
                ParsedMetadata.flat_init(0, 0, 100, 100, "table", 0.9),
                ParsedMetadata.flat_init(0, 0, 110, 100),
                ParsedMetadata.flat_init(0, 0, 100, 110, "table", 0.9),
            ],
        ],
        document=document,
    )

    p = collect(p)
    out = img(p)
    assert len(out) == 1
    assert len(out.to_records()) == 0


def test_image_parser(document):
    img = ImageParser(ImageParserSpec(caption_finder_typ="LOCALITY"))

    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(5, 5, 100, 100),
                ParsedMetadata.flat_init(5, 5, 100, 100, "Figure", 0.9),
                ParsedMetadata.flat_init(5, 5, 101, 100),
                ParsedMetadata.flat_init(5, 5, 100, 100, "Caption", 0.92),
            ],
        ],
        document=document,
    )

    out = img(collect(p))
    assert len(out) == 1
    assert len(out.to_records()) == 1


def test_image_parser_multiple_figures(document):
    img = ImageParser(ImageParserSpec(caption_finder_typ="LOCALITY"))

    p = DocBboxes.init(
        [
            [
                ParsedMetadata.flat_init(5, 5, 100, 100),
                ParsedMetadata.flat_init(5, 5, 100, 100, "Figure", 0.9),
                ParsedMetadata.flat_init(5, 5, 120, 100, "Caption"),
                ParsedMetadata.flat_init(100, 5, 200, 100, "Figure", 0.91),
            ],
        ],
        document=document,
    )
    p = collect(p)
    out = img(p)
    assert len(out) == 1
    assert len(out.to_records()) == 2


def test_verbal_null(document):
    from pdfparser.component import RawImageComponent
    from pdfparser.component.image.verb import ImageVerbal

    vf = ImageVerbal.factory("NULL")
    img = RawImageComponent(
        page=3,
        img=np.random.randn(3, 4, 5),
        text="caption",
        bbox=BoundingBox(0, 0, 100, 100),
    )
    out = vf(img)

    assert isinstance(out, str)


@pytest.fixture
def siebel():
    return Path(__file__).parent / "siebel.png"


@pytest.mark.skipif(skip_openai_test(), reason="OpenAI API key and endpoint not set")
def test_verbal_openai(fname, siebel):
    from PIL import Image

    from pdfparser.component import RawImageComponent
    from pdfparser.component.image.verb import ImageVerbal

    api_key = os.environ["OPENAI_API_KEY"]
    endpoint = os.environ["OPENAI_ENDPOINT"]

    raw_image = Image.open(siebel)

    vf = ImageVerbal.factory("OPENAI", api_key=api_key, endpoint=endpoint)
    img_compo = RawImageComponent(
        page=3,
        img=np.array(raw_image),
        text="This man is called Tom Siebel, the CEO of C3.ai and Siebel Systems.",
        bbox=BoundingBox(0, 0, 100, 100),
    )
    out = vf(img_compo)
    assert isinstance(out, str)
