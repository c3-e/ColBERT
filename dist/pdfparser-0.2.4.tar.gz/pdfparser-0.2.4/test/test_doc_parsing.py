# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from pathlib import Path

import pytest
import torch

from pdfparser import Document, DocumentParser, DocumentParserOutput, DocumentParserSpec

from .envs import default_vgt_paths


@pytest.fixture
def fname():
    return Path(__file__).parent / "testing.pdf"


@pytest.fixture
def device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"


@pytest.mark.skipif(not default_vgt_paths(), reason="VGT model paths not set")
def test_doc_parser_init(device):
    dp = DocumentParser(
        DocumentParserSpec(
            layout_parser_spec={
                "layout_model_typ": "VGT",
                "layout_model_kwargs": {**default_vgt_paths(), "device": device},
            },
            image_parser_spec={},
            text_parser_spec={"ext_typ": "DEFAULT", "chunk_typ": "LONG_CHAIN"},
            table_parser_spec={},
        )
    )

    assert dp.image_parser
    assert dp.table_parser
    assert dp.text_parser
    assert dp.layout_parser


@pytest.mark.skipif(not default_vgt_paths(), reason="VGT model paths not set")
def test_document_parsing(fname, device):
    dp = DocumentParser(
        DocumentParserSpec(
            layout_parser_spec={
                "layout_model_typ": "VGT",
                "layout_model_kwargs": {**default_vgt_paths(), "device": device},
            },
            image_parser_spec={},
            text_parser_spec={"ext_typ": "DEFAULT", "chunk_typ": "LONG_CHAIN"},
            table_parser_spec={},
        )
    )

    out = dp(Document(fname))
    assert isinstance(out, DocumentParserOutput)


@pytest.mark.skipif(not default_vgt_paths(), reason="VGT model paths not set")
def test_document_parsing_with_chunks(fname, device):
    dp = DocumentParser(
        DocumentParserSpec(
            layout_parser_spec={
                "layout_model_typ": "VGT",
                "layout_model_kwargs": {**default_vgt_paths(), "device": device},
            },
            image_parser_spec={},
            text_parser_spec={"ext_typ": "DEFAULT", "chunk_typ": "LONG_CHAIN"},
            table_parser_spec={},
        )
    )

    out = dp(Document(fname), page_chunks=1)
    assert isinstance(out, DocumentParserOutput)
