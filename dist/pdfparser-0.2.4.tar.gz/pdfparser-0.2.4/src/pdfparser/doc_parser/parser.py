# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
from dataclasses import dataclass
from functools import cached_property
from typing import Any, Dict, List

import alive_progress as ap

from pdfparser.specs import Spec, specify

from ..component import ImageParser, ImageParserSpec, TableParser, TableParserSpec, TextParser, TextParserSpec
from ..document.document import Document
from ..layout import LayoutParser, LayoutParserSpec
from .out import DocumentParserOutput

LOGGER = logging.getLogger(__name__)

__all__ = ["DocumentParser", "DocumentParserSpec"]


@dataclass(frozen=True)
class DocumentParserSpec(Spec):
    """
    The parser build specification class.
    When instantiating the parser, the user can specify the build spec for the parser.

    Examples:
        ```python
        spec = DocumentParserBuildSpec(
            layout_parser_spec={},
            text_parser_spec={},
            text_chunker_spec={},
            image_parser_spec={},
        )
        parser = DocumentParser(spec)
        ```
    """

    layout_parser_spec: Dict[str, Any]
    text_parser_spec: Dict[str, Any]
    table_parser_spec: Dict[str, Any]
    image_parser_spec: Dict[str, Any]


@specify(DocumentParserSpec)
class DocumentParser:
    """
    This class represents the main parser for enterprise search. It handles the parsing
    of documents using various parsing specifications and workflows. The parser supports
    different components such as image parsing and verbalization, and can be extended
    for additional parsing capabilities.
    """

    def __init__(self, spec: DocumentParserSpec):
        """
        Initializes the DocumentParser with the given build specifications.

        Args:
            spec: The build specification for the document parser.
        """

        super().__init__(spec)

    @cached_property
    def layout_parser(self) -> LayoutParser:
        """
        The layout parser for the document parser.
        """

        return LayoutParser(LayoutParserSpec(**self.spec.layout_parser_spec))

    @cached_property
    def text_parser(self) -> TextParser:
        """
        The text parser for the document parser.
        """

        return TextParser(TextParserSpec(**self.spec.text_parser_spec))

    @cached_property
    def table_parser(self) -> TableParser:
        """
        The table parser for the document parser.
        """

        return TableParser(TableParserSpec(**self.spec.table_parser_spec))

    @cached_property
    def image_parser(self) -> ImageParser:
        """
        The image parser for the document parser.
        """

        return ImageParser(ImageParserSpec(**self.spec.image_parser_spec))

    def __call__(
        self,
        document: Document,
        page_chunks: int | None = None,
        do_table: bool = True,
        do_text: bool = True,
        do_image: bool = True,
    ) -> DocumentParserOutput:
        """
        Parse the document using the specified parser inference settings.

        Args:
            document: The document to be parsed.
            page_chunks: The number of chunks to split the document into.
            do_table: Whether to perform table parsing.
            do_image: Whether to perform image parsing.
            do_text: Whether to perform text parsing.

        Returns:
            The result of parsing the document, including parsed components
                and any relevant logs generated during the parsing process.
        """

        if page_chunks is None:
            return self._no_chunk(document, do_table=do_table, do_text=do_text, do_image=do_image)
        else:
            return self._chunk(document, page_chunks=page_chunks, do_table=do_table, do_text=do_text, do_image=do_image)

    def _chunk(
        self, document: Document, page_chunks: int, do_table: bool = True, do_text: bool = True, do_image: bool = True
    ) -> DocumentParserOutput:
        """
        Iteratively call out to the layout parser and the text parser to parse the document in chunks.

        Args:
            document: The document to be parsed.
            page_chunks: The number of chunks to split the document into.
            do_table: Whether to perform table parsing.
            do_image: Whether to perform image parsing.
            do_text: Whether to perform text parsing.

        Returns:
            The result of parsing the document, including parsed components
        """

        components: List[Dict[str, Any]] = []
        for view in ap.alive_it(document.view(page_chunks)):
            compos = self._no_chunk(view, do_table=do_table, do_text=do_text, do_image=do_image).components

            # Shift the page number of the components.
            components.extend({**co, "page": co["page"] + view.start} for co in compos)
        return DocumentParserOutput(document=document, components=components)

    def _no_chunk(
        self, document: Document, do_table: bool = True, do_text: bool = True, do_image: bool = True
    ) -> DocumentParserOutput:
        """
        Load the document from the file and parse the contents using the parsing workflows defined in parsers
        Parses the given document according to the specified parser inference settings.

        Args:
            document: The document to be parsed.
            do_table: Whether to perform table parsing.
            do_image: Whether to perform image parsing.
            do_text: Whether to perform text parsing.

        Returns:
            The result of parsing the document, including parsed components
                and any relevant logs generated during the parsing process.

        Note:
            This method automatically builds parser components if they haven't been built already.
        """

        LOGGER.debug(
            f"parse,{document.fname=},{do_table=}," f"{do_text=},{do_image=}",
        )

        components: List[dict[str, Any]] = []
        bounding_boxes = self.layout_parser(document)

        # Table parsing workflow
        if self.table_parser and do_table:
            LOGGER.debug(f"parse,table_parser,parse_content,{len(bounding_boxes)=}")
            table_parser_components = self.table_parser(bounding_boxes)
            components.extend(table_parser_components.to_records())

        # Text parsing workflow
        if self.text_parser and do_text:
            LOGGER.debug(f"parse,text_parser.parse_content,{len(components)=}")
            text_parser_components = self.text_parser(bounding_boxes)
            components.extend(text_parser_components.to_records())

        # Image Parsing Workflow
        if self.image_parser and do_image:
            LOGGER.debug(f"parse,image_parser.parse_content,{len(components)=}")
            image_parser_components = self.image_parser(bounding_boxes)
            components.extend(image_parser_components.to_records())

        components = sorted(components, key=lambda x: x["page"])
        LOGGER.debug(f"parse,done,{len(components)=}")

        return DocumentParserOutput(document=document, components=components)
