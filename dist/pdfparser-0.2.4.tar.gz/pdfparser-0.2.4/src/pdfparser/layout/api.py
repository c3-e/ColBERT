# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Dict, List

from pdfparser.core import DocBboxes
from pdfparser.decltype import LayoutProducer
from pdfparser.document import Document
from pdfparser.specs import Spec, factorise, specify


class LayoutParserOutput(DocBboxes):
    """
    The output of a layout parser.
    """


class LayoutModelSpec(Spec, ABC):
    """
    A specification for a layout parser.
    """


@factorise(LayoutModelSpec)
class LayoutModel(LayoutProducer[LayoutParserOutput], ABC):
    """
    A layout parser is an object that takes a filename and returns a list of bounding boxes.
    """

    @abstractmethod
    def produce(self, filename: Document, /) -> LayoutParserOutput:
        """
        Parse the layout of a document and return a list of bounding boxes.

        Args:
            filename: The filename of the document to parse.

        Returns:
            A list of bounding boxes, grouped by page.
        """


@dataclass(frozen=True)
class LayoutParserSpec(Spec):
    """
    A specification for a layout parser.
    """

    layout_model_typ: str = "VGT"
    """
    The type of layout model to use. Default to vgt layout model because it has been the most mature.
    """

    layout_model_kwargs: Dict[str, Any] = field(default_factory=dict)
    """
    The keyword arguments to pass to the layout model.
    See individual layout model for the list of supported keyword arguments.
    """

    post_process: List[str] = field(
        default_factory=lambda: [
            "JUPYTER_DEBUG(title='Model Output')",
            "FILTER_DOC",
            "JUPYTER_DEBUG(title='Filtered Bounding Boxes')",
            "UNION_BOX",
            "JUPYTER_DEBUG(title='Unioned Bounding Boxes')",
            "NO_OVERLAP",
            "JUPYTER_DEBUG(title='Non-overlapping Bounding Boxes')",
            "ORDER_BY_GRID(grid_step=128)",
            "JUPYTER_DEBUG(title='Ordered Bounding Boxes')",
            "TO_MARKDOWN_CLASS",
        ]
    )
    """
    The list of post-processing steps to apply to the layout model output.
    """


@specify(LayoutParserSpec)
class LayoutParser(LayoutProducer[LayoutParserOutput]):
    """
    The layout parser is responsible for parsing the layout of a document.

    Firstly, it goes through the layout model to get the bounding boxes of the document,
    and then it uses a post-processing pipeline to clean up the bounding boxes.
    """

    def produce(self, document: Document) -> DocBboxes:
        laid_out = self.layout_model(document)
        return self.post_process_pipe(laid_out)

    @cached_property
    def layout_model(self) -> LayoutModel:
        """
        The layout model to use.
        """

        return LayoutModel.factory(self.spec.layout_model_typ, **self.spec.layout_model_kwargs)

    @cached_property
    def post_process_pipe(self):
        """
        Create a post-processing pipeline.
        """
        from .postproc import LayoutPostProcPipe

        # This is OK because post process steps are "pure" functions, and does not take in any specs.
        return LayoutPostProcPipe(self.spec.post_process)
