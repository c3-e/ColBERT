# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from functools import reduce
from typing import List, no_type_check

from pdfparser.core import BoundingBox, ParsedMetadata

from .api import LayoutParserOutput, LayoutPostProc, LayoutPostProcSpec


@dc.dataclass(frozen=True)
class ListCombinerSpec(LayoutPostProcSpec):
    cross_page: bool = True
    """
    Combine lists across page boundaries.
    """


class ListCombiner(LayoutPostProc, spec_class=ListCombinerSpec):
    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        list_start_idx = None
        global_index = 0
        for page_bboxes in output:
            # Reset the list start index if we are not combining lists across pages.
            if not self.spec.cross_page:
                list_start_idx = None

            for bbox in page_bboxes:
                if bbox.klass != "LIST":
                    list_start_idx = None
                elif list_start_idx is None:
                    list_start_idx = global_index
                else:
                    output.rels["parent"].link(list_start_idx, global_index)
                global_index += 1
        return output


@no_type_check
@LayoutPostProc.register
def merge_list(output: LayoutParserOutput) -> LayoutParserOutput:
    list_bboxes = []
    result = []

    def clear_list_into_result(page_result: List[ParsedMetadata], list_bboxes: List[BoundingBox], /):
        if not len(list_bboxes):
            return

        merged_bbox = reduce(lambda left, right: left.merge(right, strategy="union"), list_bboxes[1:], list_bboxes[0])

        page_result.append(
            ParsedMetadata.flat_init(
                x_1=merged_bbox.x_1,
                y_1=merged_bbox.y_1,
                x_2=merged_bbox.x_2,
                y_2=merged_bbox.y_2,
                klass="LIST",
                score=max([bbox.score for bbox in list_bboxes]),
            )
        )
        list_bboxes.clear()

    for page_bboxes in output:
        page_result = []
        assert not list_bboxes
        for bbox in page_bboxes:
            if bbox.klass == "LIST":
                list_bboxes.append(bbox.detach())
                continue

            clear_list_into_result(page_result, list_bboxes)
            page_result.append(bbox.detach())
        else:
            clear_list_into_result(page_result, list_bboxes)

        result.append(page_result)

    output = LayoutParserOutput.init(result + list_bboxes, document=output.document)
    return output


@no_type_check
@LayoutPostProc.register
def bbox_size_header_hierarchy(output: LayoutParserOutput) -> LayoutParserOutput:
    """
    A heuristic to determine the hierarchy of headers in a document.
    """

    is_header = output.klasses == "HEADER"
    font_sizes = output.font_size[is_header]

    header_indices = [i for i, is_h in enumerate(is_header) if is_h]

    for idx in header_indices:
        # Find the nearest header above the current header.
        for prev in range(idx - 1, -1, -1):
            if is_header[prev] and font_sizes[prev] > font_sizes[idx]:
                output.rels["parent"].link(prev, idx)
                break
    return output
