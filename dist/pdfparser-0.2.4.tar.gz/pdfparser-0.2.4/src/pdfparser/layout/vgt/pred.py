# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from collections.abc import Sequence
from typing import Sequence

import detectron2.data.transforms as T
import numpy as np
import torch
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.data import MetadataCatalog
from detectron2.data import detection_utils as utils
from detectron2.modeling import build_model
from detectron2.structures import BoxMode
from numpy.typing import NDArray

from .ditod import VGT, add_vit_config
from .gen import VGTDocGrid


class VGTPredictor:
    """
    Create a simple end-to-end predictor with the given config that runs on
    single device for a single input image.

    Compared to using the model directly, this class does the following additions:

    1. Load checkpoint from `cfg.MODEL.WEIGHTS`.
    2. Always take BGR image as the input and apply conversion defined by `cfg.INPUT.FORMAT`.
    3. Apply resizing defined by `cfg.INPUT.{MIN,MAX}_SIZE_TEST`.

    Attributes:
        metadata (Metadata): the metadata of the underlying dataset, obtained from
            cfg.DATASETS.TEST.
    """

    def __init__(self, model_weight_path: str, config_file_path: str, wordgrid_model_path: str, device: str):
        opts = ["MODEL.WEIGHTS", model_weight_path, "MODEL.WORDGRID.MODEL_PATH", wordgrid_model_path]
        cfg = get_cfg()
        add_vit_config(cfg)
        cfg.merge_from_file(config_file_path)
        cfg.merge_from_list(opts)
        cfg.MODEL.DEVICE = device
        self.cfg = cfg.clone()  # cfg can be modified by model

        self.model: VGT = build_model(self.cfg)
        self.model.float()
        self.model.eval()

        self.metadata = MetadataCatalog.get(cfg.DATASETS.TEST[0])
        checkpointer = DetectionCheckpointer(self.model)
        checkpointer.load(cfg.MODEL.WEIGHTS)
        self.aug = T.ResizeShortestEdge([cfg.INPUT.MIN_SIZE_TEST, cfg.INPUT.MIN_SIZE_TEST], cfg.INPUT.MAX_SIZE_TEST)
        self.input_format = cfg.INPUT.FORMAT

    @torch.inference_mode()
    def __call__(self, original_images: Sequence[NDArray], grids: Sequence[VGTDocGrid]):
        """
        Args:
            original_image (np.ndarray): an image of shape (H, W, C) (in BGR order).

        Returns:
            predictions (dict):
                the output of the model for one image only.
                See :doc:`/tutorials/models` for details about the format.
        """

        # Apply pre-processing to image.
        dataset_dict_list = []
        for original_image, grid in zip(original_images, grids):
            height, width = original_image.shape[:2]
            image, transforms = T.apply_transform_gens([self.aug], original_image)
            assert isinstance(image, np.ndarray)

            # add grid
            image_shape = image.shape[:2]  # h, w
            image = torch.tensor(image.astype("float32").transpose(2, 0, 1))

            input_ids = grid["input_ids"]
            bbox_subword_list = grid["bbox_subword_list"]

            # Document bounding box
            bbox = []
            for bbox_per_subword in bbox_subword_list:
                text_word = {"bbox": bbox_per_subword.tolist(), "bbox_mode": BoxMode.XYWH_ABS}
                utils.transform_instance_annotations(text_word, transforms, image_shape)
                bbox.append(text_word["bbox"])

            dataset_dict_list.append(
                {"image": image, "height": height, "width": width, "input_ids": input_ids, "bbox": bbox}
            )

        return self.model(dataset_dict_list)
