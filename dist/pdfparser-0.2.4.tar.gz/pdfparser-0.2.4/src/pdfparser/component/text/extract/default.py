# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import itertools
import logging
from collections import defaultdict
from functools import reduce
from typing import Dict, List, Tuple

from pdfparser.core import BoundingBox, DocBboxes
from pdfparser.layout import LayoutParserOutput

from .api import RawTextComponent, TextExtractor, TextExtractorSpec

LOGGER = logging.getLogger(__name__)


@dc.dataclass(frozen=True)
class DefaultSpec(TextExtractorSpec):
    pass


class Default(TextExtractor, spec_class=DefaultSpec):
    """
    PDF Plumber text extractor takes in a PDF document and bounding boxes,
    and extract text from those regions using the pdfplumber library.

    This must be used in conjunction with a layout parser that extracts bounding boxes.
    """

    def execute(self, parsed: LayoutParserOutput) -> List[RawTextComponent]:
        texts = self.extract_text(parsed)
        return [RawTextComponent(text=text, page=page, bbox=bbox) for page, text, bbox, uid in texts]

    def extract_text(self, bounding_boxes: LayoutParserOutput) -> List[Tuple[int, int, str, BoundingBox]]:
        """
        Extracts text from a page using the pdfplumber library.

        Args:
            document: The PDF document.
            bounding_boxes: The bounding boxes of texts on each page.

        Returns:
            A list cropped text boxes.
        """

        document = bounding_boxes.document

        texts: List[Tuple[int, int, int, str]] = []

        assert len(document) == len(bounding_boxes), (
            "Mismatch between number of pages and bounding boxes. "
            "This indicates that there is a bug in the layout parser and / or pdfplumber."
        )

        for page_num, bbox_on_page, page_content in zip(itertools.count(), bounding_boxes, document.page_contents):
            for parsed in bbox_on_page:
                text_page_box = page_num, page_content.crop_text(parsed.norm_bbox), parsed.norm_bbox, parsed.uid
                texts.append(text_page_box)

        return texts


@dc.dataclass(frozen=True)
class MergeSpec(DefaultSpec):
    pass


class Merge(Default, spec_class=MergeSpec):
    """
    Merges the text components extracted by the pdfplumber text extractor, and then merge them by page.
    """

    def execute(self, parsed: DocBboxes) -> List[RawTextComponent]:
        super_parsed = super().execute(parsed)
        by_page: Dict[int, List[RawTextComponent]] = defaultdict(list)

        for parsed in super_parsed:
            by_page[parsed.page].append(parsed)

        def merge_bbox(bboxes: List[BoundingBox]) -> BoundingBox:
            """
            Merge a list of bounding boxes into a single bounding box.
            """
            assert bboxes
            return reduce(lambda bbox1, bbox2: bbox1.merge(bbox2, strategy="union"), bboxes[1:], bboxes[0])

        # Join the components on each page.
        return [
            RawTextComponent(
                text="\n".join(comp.text for comp in parsed_by_page),
                page=page,
                bbox=merge_bbox([comp.bbox for comp in parsed_by_page]),
            )
            for page, parsed_by_page in by_page.items()
        ]
