# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from pdfparser.document import Document

from .api import TableContent, TableContentSpec, TableTitledComponent


@dc.dataclass(frozen=True)
class DefaultSpec(TableContentSpec):
    """
    The specification for the pdfplumber-based table content parser.
    """


class Default(TableContent, spec_class=DefaultSpec):
    """
    A pdfplumber-based table content parser, using the cropping utilities of the Document directly.
    """

    def __init__(self, spec: DefaultSpec):
        super().__init__(spec)

    def __call__(self, document: Document, table: TableTitledComponent) -> str:
        return document.page_contents[table.page].crop_table(table.bbox)
