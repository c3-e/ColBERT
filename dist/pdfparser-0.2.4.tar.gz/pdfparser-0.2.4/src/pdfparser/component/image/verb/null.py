# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from ..api import RawImageComponent
from .api import ImageVerbal, ImageVerbalSpec


@dc.dataclass(frozen=True)
class NullSpec(ImageVerbalSpec):
    """
    Spec for verbaliser that does nothing and returns an empty string.
    """


class Null(ImageVerbal, spec_class=NullSpec):
    def __call__(self, image: RawImageComponent) -> str:
        """
        Verbalisation that serves as a default for images,
        which does nothing and use an empty string as verbalisation.

        Args:
            image: The raw image component.

        Returns:
            An empty string.
        """

        return ""
