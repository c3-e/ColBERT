# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Generic, List, TypeVar

from pdfparser.specs import factorise

if TYPE_CHECKING:
    from pdfparser import BoundingBox
    from pdfparser.document.contents import Content

T = TypeVar("T")


@dc.dataclass(frozen=True)
class CropWithBbox:
    bbox: BoundingBox
    data: T


@dc.dataclass(frozen=True)
class GridGenSpec(ABC):
    pass


@factorise(GridGenSpec)
class GridGen(Generic[T], ABC):
    @abstractmethod
    def gen(self, content: Content) -> List[CropWithBbox[T]]:
        pass
