# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
import logging
import warnings
from typing import Any, Callable, Type, TypeVar, no_type_check

from .. import settings
from .factory import Factory
from .registry import HasRegistry, TreeRegistry
from .specs import Spec
from .utils import pascal_to_upper_snake

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)

_Spec = TypeVar("_Spec", bound=Spec, covariant=True)

_T = TypeVar("_T", bound=Type)


def experimental(item: _T, /) -> _T:
    if settings.warn_experimental:
        warnings.warn(f"{item} is experimental and may change in the future.", stacklevel=2)

    return item


@no_type_check
def factorize(base_spec_class: Type[_Spec], /) -> Any:
    """
    A decorator that automatically modifies a class to accept a specification in its constructor,
    along with a factory method for creating instances of the class with the specified name.

    Every specified class accompanies a `Spec` dataclass that defines the specification for the class.
    After `factorize` is applied to a class, the class will have a `spec` attribute that is initialized with the given specification.

    Subclasses should inherit from the decorated class and put a `spec_class` attribute in the class definition,
    which should be a subclass of the `base_spec_class` given in the decorator.

    See examples below for more details.

    Examples:
        >>> @dc.dataclass
        ... class FooSpec:
        ...     a: int = 10

        >>> @factorize(FooSpec)
        ... class Foo:
        ...     pass

        >>> Foo(FooSpec()).spec
        FooSpec(a=10)

        Subclasses of the decorated class (`Foo` in the example above) should put a `spec_class` attribute
        in the class definition, which should be a subclass of the `base_spec_class`
        given in the decorator. The decorator ensures that the spec class is a subclass of the base spec class.

        >>> @dc.dataclass
        ... class BarSpec(FooSpec):
        ...     b: float = 666.666

        >>> class Bar(Foo, spec_class=BarSpec):
        ...     pass

        >>> Bar(BarSpec(a=20, b=30.0)).spec
        BarSpec(a=20, b=30.0)

        After decorating the class, the class will have a `factory` method
        that can be used to create instances of the class,
        and a `factory.registered` method that returns a list of available class names.

        >>> Foo.factory("BAR", a=20, b=22.2).spec
        BarSpec(a=20, b=22.2)

        >>> Foo.factory.registered()
        ['BAR']

        If we want to register more classes, we can do so by subclassing the `Foo` class in the same way.

        >>> @dc.dataclass
        ... class BazSpec(BarSpec):
        ...     c: str = "baz"

        >>> class Baz(Foo, spec_class=BazSpec):
        ...     pass

        >>> Foo.factory.registered()
        ['BAR', 'BAZ']

        >>> Foo.factory("BAZ", a=20, b=22.2, c="hello").spec
        BazSpec(a=20, b=22.2, c='hello')

    Parameters:
        base_spec_class: The base specification class for the class to decorate.

    Returns:
        A decorator that decorates the class with its specification class.

    Raises:
        TypeError: If the class is not abstract.
        KeyError: If the class with the same name is already registered.
    """

    def decorator(base_class: _T, /) -> _T:
        LOGGER.info(f"Factorising {base_class} with {base_spec_class}")

        _set_init(base_class, base_spec_class)
        _set_init_subc(base_class, base_spec_class)

        # If the class's base class is already `@factorized`,
        # a `__registry__` attribute would already be set on the class.
        # However, this doesn't matter,
        # because reassigning registry to the class doesn't do anything,
        # as the registries are looked up from the base class,
        # we can safely reassign the registry to the class,
        # regardless of whether there is already a `__registry__` attribute.
        _assign_registry(cls=base_class, base_spec_class=base_spec_class, rename=pascal_to_upper_snake)
        assert isinstance(base_class, HasRegistry)
        base_class.factory = Factory(base_class.__registry__)

        return base_class

    return decorator


def _set_init(base_class, base_spec_class):
    def __init__(self, *args, **kwargs) -> None:
        _check_registry(type(self), base_spec_class)

        spec = _get_spec(type(self), *args, **kwargs)

        if not isinstance(spec, base_spec_class):
            raise TypeError(f"{spec} should be an instance of {base_spec_class}")

        self.__spec = spec

    def spec(self) -> _Spec:
        """
        The getter for spec attribute.
        This is used as a readonly attribute for all the subclasses.

        The superclass must be `@factorize`-ed for this to work.
        """

        return self.__spec

    def spec_class(self: HasRegistry) -> Type[_Spec]:
        """
        The getter for spec_class attribute.
        This is used as a readonly attribute for all the subclasses.

        The superclass must be `@factorized`-ed for this to work.
        """

        return self.__registry__.spec_cls

    base_class.__init__ = __init__
    base_class.spec = property(spec)
    base_class.spec_class = property(spec_class)


def _set_init_subc(base_class, base_spec_class):
    def __init_subclass__(
        cls, spec_class: type[_Spec], class_name: Callable[[str], str] | str = pascal_to_upper_snake
    ) -> None:
        """
        The `__init_subclass__` method is called when the class is subclassed.
        Here, it registers the subclass with the factory method,
        with keys being computed from the class name.

        Parameters:
            spec_class: The specification class for the subclass.
            class_name:
                The key for the new subclass accessed from the factory,
                or the function to rewrite the ``cls.__name__`` attribute into the key.

                By default, it converts the ``__name__`` from PascalCase to UPPER_SNAKE_CASE.
        """

        # The given spec class should be a subclass of the base spec class.
        if not issubclass(spec_class, base_spec_class):
            raise TypeError(f"{spec_class} should be a subclass of {base_spec_class}")

        # The spec class should be a dataclass.
        if not dc.is_dataclass(spec_class):
            raise ValueError("Spec classes must be dataclasses.")

        # If the class has name `PascalCase`, the registered name would be `PASCAL_CASE`.
        if isinstance(class_name, str):
            name_func = lambda _: class_name
        elif callable(class_name):
            name_func = class_name
        else:
            raise TypeError(f"Invalid type for name: {type(class_name)=}. Must be a callable or a string.")

        assert callable(name_func)
        _assign_registry(cls=cls, base_spec_class=spec_class, rename=name_func)

    base_class.__init_subclass__ = classmethod(__init_subclass__)


@no_type_check
def _check_registry(cls: HasRegistry, base_spec_class) -> None:
    """
    Check if the spec class is up to spec,
    if not, raise `TypeError`.

    Args:
        base_spec_class: The base specification class for the class to decorate.
    """

    if not isinstance(cls, HasRegistry):
        raise TypeError(
            f"{cls} must not be used in the base class (you have to @factorize on the base class, but initialize in the subclass)."
        )

    if not isinstance(cls.__registry__, TreeRegistry):
        raise TypeError(f"{cls} must have a registry of type TreeRegistry, got {type(cls.__registry__)}")

    if not issubclass(cls.__registry__.spec_cls, base_spec_class):
        raise TypeError(f"{cls} must have a spec class of {base_spec_class}")

    cls.__registry__.validate()


def _assign_registry(cls: type, base_spec_class: type, rename: Callable[[str], str] = pascal_to_upper_snake):
    cls.__registry__ = TreeRegistry(cls=cls, spec_cls=base_spec_class, alias=rename(cls.__name__))


def _get_spec(cls: Type[HasRegistry], *args, **kwargs):
    """
    A convenience method to initialize the class with the given keyword arguments.
    As specs must be dataclasses, this method checks if the given keyword arguments are valid,
    and then initializes the class with the given specification.
    """

    try:
        spec = cls.__registry__.spec_cls(*args, **kwargs)
    except TypeError as te:
        signature = inspect.signature(cls.__registry__.spec_cls.___init____)
        user_signature = []

        if args:
            user_signature.append(", ".join(map(str, args)))

        if kwargs:
            user_signature.append(", ".join(f"{k}={v}" for k, v in kwargs.items()))

        raise TypeError(
            "\n".join(
                [
                    f"Invalid arguments in `{cls.__name__}.initialize`!",
                    f"Expected: {signature}.",
                    f"Given: ({', '.join(user_signature)}).",
                ]
            )
        ) from te
    return spec
