# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reservedc.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from typing import TYPE_CHECKING

import easyocr
import numpy as np
import pytesseract
from PIL.Image import Image

from .api import ImageCropper, TableCropper, TableCropperSpec, TextCropper, TextCropperSpec

if TYPE_CHECKING:
    from mew3 import BoundingBox
    from mew3.document import Content


@dc.dataclass
class OCRForTextSpec(TextCropperSpec):
    engine: str = "easyocr"
    """
    The OCR engine to use: `easyocr` or `tesseract`.
    easyocr: accurate but slow.
    tesseract: fast but less accurate.
    """

    engine_spec: dict = dc.field(default_factory=lambda: {"lang_list": ["en"], "gpu": False})
    """
    The spec for the OCR engine. Default is for easyocr. Language list can be ['en', 'fr', 'de', 'es'].
    """

    image_cropper_typ: str = "PLUMBER"
    """
    Method to crop the image from document to pass to OCR.
    """

    image_cropper_spec: dict = dc.field(default_factory=lambda: {"dpi": 150})
    """
    Cropper spec for the image.
    """


class OCRForText(TextCropper, spec_class=OCRForTextSpec, class_name="OCR"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        img_crop = ImageCropper.factory(self.spec.image_cropper_typ, **self.spec.image_cropper_spec)
        img: Image = img_crop.as_proc(bbox)(content)
        img_np = np.array(img)

        if self.spec.engine == "easyocr":
            reader = easyocr.Reader(**self.spec.engine_spec)
            result = reader.readtext(img_np)
            text = " ".join([item[1] for item in result])
            return text

        elif self.spec.engine == "tesseract":
            text = pytesseract.image_to_string(img)
            return text

        else:
            raise ValueError(f"Unsupported OCR engine: {self.spec.engine}")

    def supports(self):
        return ["pdf"]


@dc.dataclass
class OCRForTableSpec(TableCropperSpec):
    engine: str = "easyocr"
    """
    The OCR engine to use: `easyocr` or `tesseract`.
    easyocr: accurate but slow.
    tesseract: fast but less accurate.
    """

    engine_spec: dict = dc.field(default_factory=lambda: {"lang_list": ["en"], "gpu": False})
    """
    The spec for the OCR engine. Default is for easyocr. Language list can be ['en', 'fr', 'de', 'es'].
    """

    image_cropper_typ: str = "PLUMBER"
    """
    Method to crop the image from document to pass to OCR.
    """

    image_cropper_spec: dict = dc.field(default_factory=lambda: {"dpi": 150})
    """
    Cropper spec for the image.
    """


class OCRForTable(TableCropper, spec_class=OCRForTableSpec, class_name="OCR"):
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        img_crop = ImageCropper.factory(self.spec.image_cropper_typ, **self.spec.image_cropper_spec)
        img: Image = img_crop.as_proc(bbox)(content)
        img_np = np.array(img)

        if self.spec.engine == "easyocr":
            reader = easyocr.Reader(**self.spec.engine_spec)
            result = reader.readtext(img_np)
            text = " ".join([item[1] for item in result])
            return text

        elif self.spec.engine == "tesseract":
            text = pytesseract.image_to_string(img)
            return text

        else:
            raise ValueError(f"Unsupported OCR engine: {self.spec.engine}")

    def supports(self):
        return ["pdf"]
