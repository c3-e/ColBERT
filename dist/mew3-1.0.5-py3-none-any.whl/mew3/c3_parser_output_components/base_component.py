# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
import json
import csv
import os
import logging

logger = logging.getLogger(__name__)

File = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/file.py", ["File"])

ParsingDocument = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/document.py", ["Document"])
Document = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/c3genai/retrieval/common/doc.py", ["Document"])


@dataclass
class BoundingBox:
    """
    Represents a bounding box with page coordinates.

    Attributes:
        x_1 (float): The minimum x-coordinate of the bounding box.
        y_1 (float): The minimum y-coordinate of the bounding box.
        x_2 (float): The maximum x-coordinate of the bounding box.
        y_2 (float): The maximum y-coordinate of the bounding box.
        bounding_box_class (str): The class of the bounding box.
        bounding_box_score (float): The score of the bounding box related to the class.
        bounding_box_page (int): The page number where the bounding box is located.
    """

    x_1: float
    y_1: float
    x_2: float
    y_2: float
    bounding_box_class: str
    bounding_box_score: float
    bounding_box_page: int

    def __init__(
        self,
        data: Union[List[float], Dict[str, float]] = None,
        x_1: float = None,
        y_1: float = None,
        x_2: float = None,
        y_2: float = None,
        bounding_box_class: str = None,
        bounding_box_score: float = None,
        bounding_box_page: int = None,
    ):
        if isinstance(data, list):
            self.init_from_list(data)
        elif isinstance(data, dict):
            self.init_from_dict(data)
        else:
            self.init_from_kwargs(x_1, y_1, x_2, y_2, bounding_box_class, bounding_box_score, bounding_box_page)

    def init_from_list(self, properties):
        # TODO GEN-6564 the final version requires 7 values, remove the default values
        # after refactoring text, table, and image components
        if len(properties) == 4:
            self.x_1, self.y_1, self.x_2, self.y_2 = properties
            self.bounding_box_class = "None"
            self.bounding_box_score = 0.0
            self.bounding_box_page = -1
        elif len(properties) == 7:
            (
                self.x_1,
                self.y_1,
                self.x_2,
                self.y_2,
                self.bounding_box_class,
                self.bounding_box_score,
                self.bounding_box_page,
            ) = properties
        else:
            raise ValueError("Bounding box properties must contain exactly four or seven values.")

    # TODO GEN-6564 the final version requires 7 values, remove the default values
    # after refactoring text, table, and image components
    def init_from_dict(self, properties):
        self.x_1 = properties.get("x_1")
        self.y_1 = properties.get("y_1")
        self.x_2 = properties.get("x_2")
        self.y_2 = properties.get("y_2")
        self.bounding_box_class = properties.get("bounding_box_class", "None")
        self.bounding_box_score = properties.get("bounding_box_score", 0.0)
        self.bounding_box_page = properties.get("bounding_box_page", -1)

    # TODO GEN-6564 the final version requires 7 values, remove the default values
    # after refactoring text, table, and image components
    def init_from_kwargs(
        self,
        x_1: float,
        y_1: float,
        x_2: float,
        y_2: float,
        bounding_box_class: str,
        bounding_box_score: float,
        bounding_box_page: int,
    ):
        if None in (x_1, y_1, x_2, y_2):
            raise ValueError("All coordinates (x_1, y_1, x_2, y_2) must be provided.")
        self.x_1 = x_1
        self.y_1 = y_1
        self.x_2 = x_2
        self.y_2 = y_2
        # TODO GEN-6564 remove default values after refactoring text, table, and image components
        self.bounding_box_class = bounding_box_class or "None"
        self.bounding_box_score = bounding_box_score or 0.0
        self.bounding_box_page = bounding_box_page if bounding_box_page is not None else -1

    # TODO GEN-6564 add values of bounding box to the string representation
    # after refactoring text, table, and image components
    def to_list(self) -> List[float]:
        return [self.x_1, self.y_1, self.x_2, self.y_2]

    def to_string(self) -> str:
        return f"({self.x_1}, {self.y_1}, {self.x_2}, {self.y_2}, {self.bounding_box_class}, {self.bounding_box_score}, {self.bounding_box_page})"

    @classmethod
    def from_string(cls, string: str) -> "BoundingBox":
        """
        Class method to create a BoundingBox instance from a string representation.

        Args:
            string (str): The string representation of the bounding box, in the format "(x_1, y_1, x_2, y_2)" or
                          "(x_1, y_1, x_2, y_2, bounding_box_class, bounding_box_score, bounding_box_page)".

        Returns:
            BoundingBox: An instance of the BoundingBox class.
        """
        if string == "" or string is None:
            return None
        # Remove the parentheses and split the string by commas
        try:
            stripped_string = string.strip("()")
            parts = stripped_string.split(",")

            # Check if there are exactly four parts
            if len(parts) == 4:
                # Convert the parts to integers
                x_1, y_1, x_2, y_2 = [float(part.strip()) for part in parts]

                # Create and return a new BoundingBox instance
                return cls(x_1=x_1, y_1=y_1, x_2=x_2, y_2=y_2)
            elif len(parts) == 7:
                x_1, y_1, x_2, y_2, bounding_box_class, bounding_box_score, bounding_box_page = [
                    part.strip() for part in parts
                ]
                return cls(
                    x_1=float(x_1),
                    y_1=float(y_1),
                    x_2=float(x_2),
                    y_2=float(y_2),
                    bounding_box_class=str(bounding_box_class),
                    bounding_box_score=float(bounding_box_score),
                    bounding_box_page=float(bounding_box_page),
                )
            else:
                raise ValueError(f"Invalid number of parts in BoundingBox string: '{string}'")

        except (ValueError, IndexError) as e:
            # Handle errors in string format or conversion
            raise ValueError(f"Invalid string format for BoundingBox: '{string}'. Error: {e}")

    @classmethod
    def bounding_box_intersection_over_union(cls, bbox1, bbox2):
        """
        Class method to calculate the intersection over union (IoU) of two bounding boxes.

        Args:
            bbox1 (BoundingBox): The first bounding box.
            bbox2 (BoundingBox): The second bounding box.

        Returns:
            float: The intersection over union (IoU) of the two bounding boxes.
        """
        # Determine the (x, y)-coordinates of the intersection rectangle
        xA = max(bbox1.x_1, bbox2.x_1)
        yA = max(bbox1.y_1, bbox2.y_1)
        xB = min(bbox1.x_2, bbox2.x_2)
        yB = min(bbox1.y_2, bbox2.y_2)

        # Compute the area of intersection rectangle
        inter_area = max(0, xB - xA) * max(0, yB - yA)

        # Compute the area of both the prediction and ground-truth rectangles
        box_1_area = (bbox1.x_2 - bbox1.x_1) * (bbox1.y_2 - bbox1.y_1)
        box_2_area = (bbox2.x_2 - bbox2.x_1) * (bbox2.y_2 - bbox2.y_1)

        # Compute the intersection over union by taking the intersection
        # area and dividing it by the sum of prediction + ground-truth
        # areas - the interesection area
        iou = inter_area / float(box_1_area + box_2_area - inter_area)

        # Return the intersection over union value
        return iou

    @classmethod
    def bounding_box_within(cls, bbox1, bbox2, threshold=0.95):  # bbox1 within bbox2
        """
        Class method to determine if one bounding box (bbox1) is within another bounding box (bbox2)
        based on a threshold.
        Args:
            bbox1 (BoundingBox): The first bounding box.
            bbox2 (BoundingBox): The second bounding box.
            threshold (float): The threshold for the intersection over self (IoS) value. Default is 0.95.

        Returns:
            bool: True if bbox1 is within bbox2 based on the threshold, False otherwise.
        """

        def bounding_box_intersection_over_self(bbox1, bbox2):
            # Determine the (x, y)-coordinates of the intersection rectangle
            xA = max(bbox1.x_1, bbox2.x_1)
            yA = max(bbox1.y_1, bbox2.y_1)
            xB = min(bbox1.x_2, bbox2.x_2)
            yB = min(bbox1.y_2, bbox2.y_2)

            # Compute the area of intersection rectangle
            inter_area = max(0, xB - xA) * max(0, yB - yA)

            # Compute the area of both the prediction and ground-truth rectangles
            box_1_area = (bbox1.x_2 - bbox1.x_1) * (bbox1.y_2 - bbox1.y_1)

            intersect_over_bbox_1 = inter_area / box_1_area  # Over box 1

            # Return the intersection over union value
            return intersect_over_bbox_1

        return bounding_box_intersection_over_self(bbox1, bbox2) > threshold

    @classmethod
    def point_within(cls, bbox, point):
        """
        Class method to determine if a point is within a bounding box.

        Args:
            bbox (BoundingBox): The bounding box.
            point (Tuple[float, float]): The point to check.

        Returns:
            bool: True if the point is within the bounding box, False otherwise.
        """
        point_x = point[0]
        point_y = point[1]

        return (bbox.x_1 <= point_x <= bbox.x_2) and (bbox.y_1 <= point_y <= bbox.y_2)

    @classmethod
    def bbox_overlaps_iou(cls, bbox1, bbox2, threshold=0):
        """
        Class method to determine if two bounding boxes overlap based on the intersection over union (IoU) value.

        Args:
            bbox1 (BoundingBox): The first bounding box.
            bbox2 (BoundingBox): The second bounding box.
            threshold (float): The threshold for the intersection over union (IoU) value. Default is 0.

        Returns:
            bool: True if the two bounding boxes overlap based on the IoU value and threshold, False otherwise.
        """
        return cls.bounding_box_intersection_over_union(bbox1, bbox2) > threshold


@dataclass
class TableBoundingBox(BoundingBox):  # TODO GEN-9663 hacky, remove and have unified typing for bounding box.
    """
    A bounding box output by the table parser
    """

    def __init__(self, score: float, label: str, properties: List):
        super().__init__(properties)
        self.score = score
        self.label = label

    score: float
    label: str


@dataclass
class BaseComponent:
    """
    The base component class represents a document component. This contains the common attributes for all
    document components.

    Attributes:
        name (str): The unique name of the document component (for traceability + logging).
        id (str): The unique id of the document component.
        document (ParsingDocument): The document the component comes from.
        page (int): The document page this bounding box is in.
        order (int): The order of the component in the document.
        metadata (Dict): The metadata of the document component.
        bounding_box (BoundingBox): The bounding boxes of the document component.
        description (str): A description meant to be displayed to the user. This is the description that will be
                            displayed in the UI when the user clicks on the component source.
        description_for_vectorstore (str): A description meant to be embedded in a vector store. This textual
                            verbalization will be the content embedded into the vector store for this component.
    """

    document: ParsingDocument
    page: int
    order: int
    description_for_vectorstore: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    component_info: Optional[Dict[str, Any]] = None
    document_info_file: Optional[File] = None

    def __post_init__(self):
        """
        Post-initialization hook. Populates the id of the component if it is not already populated.
        """
        self.id = self._generate_id()

    @staticmethod
    def _generate_id():
        """
        Generates a random hash.

        Returns:
            str: A random hash.
        """
        import uuid

        return str(uuid.uuid4())

    def get_metadata(self) -> Dict[str, Any]:
        """
        Returns the metadata of the component.

        Returns:
            Dict[str, Any]: The metadata of the component.
        """
        document_url = ""
        if hasattr(self, "document") and self.document is not None:
            document_url = self.document.file.url
        bounding_box = ""
        if hasattr(self, "bounding_box") and self.bounding_box is not None:
            bounding_box = self.bounding_box.to_string()

        # Write id for retrieval display
        metadata = {
            "component_id": self.id,
            "document_url": document_url,
            "type": type(self).__name__,
            "page": self.page,
            "order": self.order,
            "bounding_box": bounding_box,
        }
        return metadata

    @classmethod
    def build_from_json(cls, json_data: Dict[str, Any], document: Optional[ParsingDocument] = None) -> "BaseComponent":
        """
        Class method to create a BaseComponent instance from a JSON representation.

        Args:
            json_data (Dict[str, Any]): The JSON dictionary containing the text component data.
            all_components (Dict[str, "BaseComponent"]): Dictionary mapping ids to BaseComponent instances,
                                                         used for resolving parent/children relationships.

        Returns:
            BaseComponent: An instance of the BaseComponent class.
        """
        pass

    def _expand_subcomponents(self) -> List["BaseComponent"]:
        """
        Recursively expands the subcomponents of the current component and returns a list of all expanded components.

        Returns:
            List[BaseComponent]: A list of expanded components.
        """
        if hasattr(self, "children") and self.children is not None:
            list_of_components = []
            for child in self.children:
                list_of_components.extend(child._expand_subcomponents())
            return list_of_components
        else:
            return [self]

    def get_serialized_repr(self) -> Dict[str, Any]:
        metadata = self.get_metadata()
        doc = {
            "_id": self.id,
            "text": self.description_for_vectorstore.strip(),
            "metadata": json.dumps(metadata),
        }
        return doc

    def add_to_corpus(self, corpus_path: str):
        """
        If there is no description for vectors store, it doesn't do anything.

        Adds a line to a jsonl file mapping "_id" to id and "text" to description_for_vectorstore.

        If there is no file, it creates one.

        Args:
            corpus_path (str): The file path to write the jsonl / tsv file to.
        """
        corpus_directory = os.path.dirname(corpus_path)
        if corpus_directory:
            os.makedirs(corpus_directory, exist_ok=True)

        corpus_file_type = corpus_path.split(".")[-1]
        if corpus_file_type == "jsonl":
            with open(corpus_path, "a") as f:
                for doc in self._expand_subcomponents():
                    serialiazed_doc = doc.get_serialized_repr()
                    json.dump(serialiazed_doc, f)
                    f.write("\n")

        elif corpus_path.endswith(".tsv"):
            # Check if TSV file exists
            if not os.path.exists(corpus_path):
                # Create a new TSV file with columns _id, text, metadata
                with open(corpus_path, "w", newline="") as tsv_file:
                    tsv_writer = csv.writer(tsv_file, delimiter="\t")
                    tsv_writer.writerow(["_id", "text", "metadata"])

            # Append a new line with values to the existing or new TSV file
            with open(corpus_path, "a", newline="") as tsv_file:
                tsv_writer = csv.writer(tsv_file, delimiter="\t")
                for doc in self._expand_subcomponents():
                    serialiazed_doc = doc.get_serialized_repr()
                    tsv_writer.writerow([serialiazed_doc["_id"], serialiazed_doc["text"], serialiazed_doc["metadata"]])
        else:
            raise ValueError(f"Invalid file path {corpus_path}. File path must end with .jsonl or .tsv")

        # TODO GEN-9663 add safeguard so that if the component is already in the corpus, it doesn't add it again.

    def generate_document(self) -> List[Document]:
        docs = []
        for doc in self._expand_subcomponents():
            metadata = doc.get_metadata()
            docs.append(
                Document(
                    page_content=doc.description_for_vectorstore.strip(),
                    metadata={
                        "page_number": metadata["page"],
                        "kind": metadata["type"],
                        "component_id": metadata["component_id"],
                        "source": metadata["document_url"],
                        "box": metadata["bounding_box"],
                    },
                )
            )

        return docs
