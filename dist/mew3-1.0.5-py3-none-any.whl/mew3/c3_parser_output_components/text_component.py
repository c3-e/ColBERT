# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass
from typing import Optional, List, Any, Dict

BaseComponent, BoundingBox = c3.Genai.PyUtil.importResourceFile(
    "/genAiBase/resource/code/parsing/parser_output_components/base_component.py",
    ["BaseComponent", "BoundingBox"],
)


File = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/file.py", ["File"])

Document = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/document.py", ["Document"])


@dataclass
class TextComponent(BaseComponent):
    """
    The class for a text passage in a document.
    """

    # The text of the passage. Will be inputed to the chunker
    text: str = ""
    # In case the component is a chunk, this is the parent component that the chunk belongs to
    parent: Optional["TextComponent"] = None
    # In case the component is chunked, those are the chunks that the component is composed of
    children: Optional[List["TextComponent"]] = None

    @classmethod
    def build_from_json(cls, json_data: Dict[str, Any], document: Optional[Document] = None) -> "TextComponent":
        """
        Class method to create a TextComponent instance from a JSON representation.

        Args:
            json_data (Dict[str, Any]): The JSON dictionary containing the text component data.
            all_components (Dict[str, "TextComponent"]): Dictionary mapping ids to TextComponent instances,
                                                         used for resolving parent/children relationships.

        Returns:
            TextComponent: An instance of the TextComponent class.
        """
        dict_metadata = json_data.get("metadata", {})
        if not document:
            document = Document(file=File(url=dict_metadata["document_url"]))

        # Create the BaseComponent instance without parent and children
        component = cls(
            description_for_vectorstore=json_data["text"],
            document=document,
            text=json_data["text"],
            page=dict_metadata.get("page", None),
        )

        component.id = json_data.get("_id", None)

        return component
