# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import pandas as pd


BaseComponent, BoundingBox = c3.Genai.PyUtil.importResourceFile(
    "/genAiBase/resource/code/parsing/parser_output_components/base_component.py",
    ["BaseComponent", "BoundingBox"],
)

File = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/file.py", ["File"])
Document = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/document.py", ["Document"])


@dataclass
class TableComponent(BaseComponent):
    """
    The table class.
    """

    table_content: str = ""
    bounding_box: BoundingBox = None
    header: List[str] = field(default_factory=list)
    title: str = ""
    verbalization: str = ""
    file: Optional[File] = None
    dataframe: Optional[pd.DataFrame] = None
    table_image_file: Optional[File] = None

    def __post_init__(self):
        """
        Post-initialization hook. Populates the id of the component if it is not already populated.
        """
        if self.dataframe is None:
            if self.file:
                self.dataframe = pd.read_csv(self.file.url)
        super().__post_init__()

    def populate_verbalization(self, verbalizer):
        """
        Verbalize the table using LLM.
        The LLM input can be a mixture of table_content, header and title.
        Attaches the verbalization to `self.verbalization`.
        """

        self.verbalization = verbalizer(self)

    def populate_description_for_vectorstore(self):
        """
        Populates the description for the vector store by concatenating the verbalization,
        title, header, and table content.
        """
        description_for_vectorstore = ""
        if self.verbalization != "":
            description_for_vectorstore += self.verbalization + "\n"

        title = f"\nTitle: {self.title}\n" if self.title != "" else ""
        description_for_vectorstore += title
        header = f"\nHeader: {self.header}\n" if self.header != "" else ""
        description_for_vectorstore += header

        # Set description_for_vectorstore
        self.description_for_vectorstore = description_for_vectorstore

    def get_metadata(self) -> Dict[str, Any]:
        """
        Returns the metadata of the table component.

        Returns:
            Dict[str, Any]: The metadata of the component.
        """
        document_url = ""
        if hasattr(self, "document") and self.document is not None:
            document_url = self.document.file.url
        bounding_box = ""
        if hasattr(self, "bounding_box") and self.bounding_box is not None:
            bounding_box = self.bounding_box.to_string()
        table_url = ""
        if hasattr(self, "file") and self.file is not None:
            table_url = self.file.url

        metadata = {
            "component_id": self.id,
            "document_url": document_url,
            "type": type(self).__name__,
            "page": self.page,
            "bounding_box": bounding_box,
            "table_content": self.table_content,
            "table_image_file": self.table_image_file,
            "header": self.header,
            "title": self.title,
            "verbalization": self.verbalization,
            "table_url": table_url,
        }
        return metadata

    @classmethod
    def build_from_json(cls, json_data: Dict[str, Any], document: Document = None) -> "TableComponent":
        """
        Class method to create a TableComponent instance from a JSON representation.

        Args:
            json_data (Dict[str, Any]): The JSON dictionary containing the table component data.

        Returns:
            TableComponent: An instance of the TableComponent class.
        """
        dict_metadata = json_data.get("metadata", {})
        if not document:
            document = Document(file=File(url=dict_metadata["document_url"]))
        bounding_box = BoundingBox.from_string(dict_metadata.get("bounding_box", None))

        file = None
        dataframe = None
        if "table_url" in dict_metadata and dict_metadata["table_url"]:
            file = File(url=dict_metadata["table_url"])
            dataframe = pd.read_csv(file.url)

        # Create the TableComponent instance
        component = cls(
            description_for_vectorstore=json_data["text"],
            document=document,
            page=dict_metadata.get("page", None),
            bounding_box=bounding_box,
            table_content=dict_metadata.get("table_content", None),
            table_image_file=dict_metadata.get("table_image_file", None),
            header=dict_metadata.get("header", None),
            title=dict_metadata.get("title", None),
            verbalization=dict_metadata.get("verbalization", None),
            file=file,
            dataframe=dataframe,
        )

        component.id = json_data.get("_id", None)

        return component
