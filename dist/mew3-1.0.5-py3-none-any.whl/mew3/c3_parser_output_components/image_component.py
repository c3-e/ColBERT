# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass
import numpy as np
from typing import Any, Dict, Optional
from PIL import Image as PIL_Image
import os

logger = c3.log()

BaseComponent, BoundingBox = c3.Genai.PyUtil.importResourceFile(
    "/genAiBase/resource/code/parsing/parser_output_components/base_component.py",
    ["BaseComponent", "BoundingBox"],
)

File = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/file.py", ["File"])

Document = c3.Genai.PyUtil.importResourceFile("/genAiBase/resource/code/parsing/document.py", ["Document"])


@dataclass
class ImageComponent(BaseComponent):
    """
    Represents an image component in a document, extending the BaseComponent class.
    This class encapsulates the functionality for handling images, including
    extracting insights, verbalizing content, and visualizing images.
    """

    file: File = None  # The file that stores the image.
    bounding_box: BoundingBox = None
    caption: str = ""
    verbalization: str = "None"

    def populate_verbalization(self, vision_llm):
        """
        Verbalizes the image and populates the verbalization field.

        Args:
            verbalizer (Verbalizer): The verbalizer object to use.
        """

        c3.Genai.PyUtil.loggerDebug(logger, lambda: f"populate_verbalization,{self.file.url=}")
        prompt = "Come up with a title, caption, and keywords associated with this image."
        if self.caption != "":
            prompt = f"Here is the image caption: {self.caption}\n" + prompt
        verbalization = vision_llm.process_images([self.to_image_native()], prompt)[0]
        if verbalization == "":
            logger.warn(f"populate_verbalization,verbalization is empty,{self.file.url}")
        self.verbalization = verbalization
        c3.Genai.PyUtil.loggerDebug(logger, lambda: f"populate_verbalization,{self.file.url=},{self.verbalization=}")

    def populate_description_for_vectorstore(self):
        """
        Combines the extracted caption and verbalization of the image to fill the
        description_for_vectorstore field.
        """
        description_for_vectorstore = ""
        if self.caption != "":
            description_for_vectorstore += "Image Caption: " + self.caption + "\n"
        if self.verbalization != "":
            description_for_vectorstore += "Image Description: " + self.verbalization + "\n"
        c3.Genai.PyUtil.loggerDebug(
            logger,
            lambda: f"populate_description_for_vectorstore,{self.file.url=},{self.caption=},{self.verbalization=},{description_for_vectorstore=}",
        )
        self.description_for_vectorstore = description_for_vectorstore

    def to_image_native(self) -> PIL_Image.Image:
        """
        Will return an Python image object.
        """
        with PIL_Image.open(self.file.url) as img:
            return img.copy()

    def to_array(self) -> np.array:
        """
        Return a np array of the image.
        """
        pil_image = self.get_image_object()
        return np.array(pil_image)

    def save_image(self, output_path: str):
        """
        Given an output_path (including the name and file extension),
        save the visualization to the output_path.
        """
        directory = os.path.dirname(output_path)
        if not os.path.exists(directory):
            os.makedirs(directory)

        image = self.get_image_object()
        image.save(output_path)

    def get_metadata(self) -> Dict[str, Any]:
        """
        Returns the metadata of the image component.

        Returns:
            Dict[str, Any]: The metadata of the component.
        """
        document_url = ""
        if hasattr(self, "document") and self.document is not None:
            document_url = self.document.file.url
        bounding_box = ""
        if hasattr(self, "bounding_box") and self.bounding_box is not None:
            bounding_box = self.bounding_box.to_string()

        metadata = {
            "component_id": self.id,
            "document_url": document_url,
            "type": type(self).__name__,
            "page": self.page,
            "bounding_box": bounding_box,
            "image_url": self.file.url,
            "caption": self.caption,
            "verbalization": self.verbalization,
            "additional_metadata": self.metadata,
        }
        return metadata

    @classmethod
    def build_from_json(cls, json_data: Dict[str, Any], document: Optional[Document] = None) -> "ImageComponent":
        """
        Returns the metadata of the image component.

        Returns:
            Dict[str, Any]: The metadata of the component.
        """
        dict_metadata = json_data.get("metadata", {})
        if not document:
            document = Document(file=File(url=dict_metadata["document_url"]))
        bounding_box = BoundingBox.from_string(dict_metadata.get("bounding_box", None))

        component = cls(
            description_for_vectorstore=json_data["text"],
            document=document,
            page=dict_metadata.get("page", None),
            bounding_box=bounding_box,
            file=File(url=dict_metadata["image_url"]),
            caption=dict_metadata.get("caption", None),
            verbalization=dict_metadata.get("verbalization", None),
            metadata=dict_metadata.get("additional_metadata", dict()),
        )

        component.id = json_data.get("_id", None)

        return component
