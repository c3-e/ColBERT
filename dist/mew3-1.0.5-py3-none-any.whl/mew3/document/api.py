# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

from mew3.rules import PostRule, get_tols_for_files
from mew3.specs import signature_parse

from .document import PageDoc, PageDocSpec
from .plumber_tols import cma_installed


def _get_xy_tol(spec, val):
    sig = signature_parse(val)
    kwargs = deepcopy(sig.kwargs)
    filename = spec.filename
    return get_tols_for_files(filename)


def rewrite_only_xy_tol(spec, val):
    x_tol, y_tol = _get_xy_tol(spec, val)
    parsed = signature_parse(val).dict()
    parsed["kwargs"]["extract_text_kwargs"] = {"x_tolerance": x_tol, "y_tolerance": y_tol}
    return parsed


@PostRule(
    key_path="table_crop",
    rewrite=rewrite_only_xy_tol,
    enable=lambda spec, val: (signature_parse(val).kind == "PLUMBER_TEXT") and cma_installed(),
)
@PostRule(
    key_path="text_crop",
    rewrite=rewrite_only_xy_tol,
    enable=lambda spec, val: (signature_parse(val).kind == "PLUMBER") and cma_installed(),
)
@PostRule(
    key_path="grid_gen",
    # Default if not specified.
    rewrite=lambda spec, val: "PLUMBER" if spec.filename.suffix == ".pdf" else "NULL",
    enable=lambda spec, val: val == "AUTO",
)
@PostRule(
    key_path="page_cnt",
    # Default if not specified.
    rewrite=lambda spec, val: "PLUMBER" if spec.filename.suffix == ".pdf" else "NULL",
    enable=lambda spec, val: val == "AUTO",
)
@PostRule(
    key_path="table_crop",
    # Default if not specified.
    rewrite=lambda spec, val: "PLUMBER" if spec.filename.suffix == ".pdf" else "NULL",
    enable=lambda spec, val: val == "AUTO",
)
@PostRule(
    key_path="text_crop",
    # Default if not specified.
    rewrite=lambda spec, val: "PLUMBER" if spec.filename.suffix == ".pdf" else "NULL",
    enable=lambda spec, val: val == "AUTO",
)
@PostRule(
    key_path="image_crop",
    # Default if not specified.
    rewrite=lambda spec, val: "PLUMBER(margins=5,dpi=144)" if spec.filename.suffix == ".pdf" else "NULL",
    enable=lambda spec, val: val == "AUTO",
)
@PostRule(
    key_path="filename",
    rewrite=lambda spec, val: Path(val),
    enable=lambda spec, val: isinstance(val, str),
)
def cropping_document_spec(
    filename: str | Path,
    cropping: Mapping[str, Any] | None = None,
    grid_gen: str = "AUTO",
    page_cnt: str = "AUTO",
) -> PageDocSpec:
    cropping = cropping or {}
    return PageDocSpec(
        filename=filename,
        image_crop=cropping.get("image", "AUTO"),
        text_crop=cropping.get("text", "AUTO"),
        table_crop=cropping.get("table", "AUTO"),
        page_cnt=page_cnt,
        grid_gen=grid_gen,
    )


def Document(*args, **kwargs):
    """
    A backwards-compatible version of the document class.

    Args:
        args: The arguments to pass to the document class.
        kwargs: The keyword arguments to pass to the document class.

    Returns:
        A new style `PageDoc` that acts mostly the same.
    """

    spec = cropping_document_spec(*args, **kwargs)
    return PageDoc(**spec)
