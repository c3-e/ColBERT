# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import base64
import json
import logging
import os
import uuid
from io import BytesIO
from typing import Any, Dict, List

import numpy as np

from .c3_styling import HTML_CONTENT_STRING, JS_SCRIPT_STRING

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.ERROR)


class UiDebugger:
    """

    Processing layout/component parser outputs for debugging.
    Pdf with bounding boxes overlay are stored.
    Json from either mew3 output or c3.Genai.SourcePassage are stored.
    Should work both in Jupyter notebook and in console.

    Serve an UI to view the stored images and bounding boxes in a webpage.
    """

    def __init__(
        self,
        doc_parser,
        document,
        input_components: List[Dict[str, Any]],
        bbox_class_to_overlay: str = "markdown_class",
        output_dir: str = "ui_debugger_output",
        use_dpi: int = None,
    ):
        self.doc_parser = doc_parser
        self.document = document
        self.input_components = input_components
        self.document_info = self.doc_parser.get_document_info_from_doc(self.document)
        self.orig_img_dpi = use_dpi if use_dpi else self.document_info["file_info"]["dpi"]
        self.components_json = None
        self.image_obj_list = []
        self.box_class_to_overlay = bbox_class_to_overlay
        self.output_dir = output_dir
        self.output_html_content = None
        self.output_html_path = None
        self.display_links = None

        if not isinstance(self.input_components, list):
            raise ValueError(
                "Input_components must be a list of dict. Don't forget .to_records() on the parser output!"
            )

        os.makedirs(f"{self.output_dir}/images", exist_ok=True)
        os.makedirs(f"{self.output_dir}/bboxes", exist_ok=True)

        self.run()

    def run(self):
        """
        Generate bboxes, images; render html using these data; save to local folder.
        """

        self.page_to_dimension, self.page_images = self._process_pdf_pages()
        self.components_json = self._bboxes_to_json()
        self._save_img_with_bbox()
        self.output_html_content, self.output_html_path = self._create_html_file()
        self.display_links = self._render_html_url()

        return self.display_links

    def _render_html_url(self):
        """
        Render links in jupyter:
        1. click to open dashboard in new jupyter window.
        2. click to download html to local s.t. user can open in browser.
        """

        from IPython.display import HTML

        open_link = f'<a href="{self.output_html_path}" target="_blank">Click to open Debugger Dashboard</a>'
        download_link = f'<a href="{self.output_html_path}" download>Download dashboard here</a>'

        output_link = HTML(f"{open_link}<br><br>{download_link}")

        return output_link

    def _create_html_file(self) -> None:
        """
        Display the PDF debugger interface in a Jupyter notebook cell.

        Parameters:
        -----------
        image_dir : str
            Directory containing the image files (PNG format)
        bbox_json_path : str
            Path to the JSON file containing bounding box data
        output_path : str, optional
            Path to save the HTML file for external viewing

        Returns:
        --------
        IPython.display.HTML
            HTML display object for rendering in the notebook
        """

        js_string = JS_SCRIPT_STRING.replace("{BBOX_DATA}", json.dumps(self.components_json))
        js_string = js_string.replace("{IMAGE_DATA}", json.dumps(self.image_obj_list))
        js_string = js_string.replace("{DOCUMENT_INFO}", json.dumps(self.document_info))
        js_string = js_string.replace("{DEBUGGER}", "jupyter")
        output_html_content = HTML_CONTENT_STRING.replace("{JS_SCRIPT}", js_string)

        os.makedirs(f"{self.output_dir}/html", exist_ok=True)

        output_html_path = f"{self.output_dir}/html/dashboard_{str(uuid.uuid4())}.html"
        with open(output_html_path, "w") as f:
            f.write(output_html_content)

        return output_html_content, output_html_path

    def _process_pdf_pages(self):
        """
        Process PDF pages to get both resolution info and page images in a single pass.
        Returns a tuple of (page_resolution_dict, page_images)
        """
        import pdfplumber

        page_to_dimension = {}
        page_images = []

        with pdfplumber.open(self.document.fname) as pdf:
            for page_num, curr_page in enumerate(pdf.pages):
                img = curr_page.to_image(resolution=self.orig_img_dpi).original
                img_height, img_width, _ = np.shape(img)
                page_to_dimension[page_num] = (img_width, img_height)
                page_images.append(img)

        return page_to_dimension, page_images

    def _bboxes_to_json(self) -> List[dict]:
        """
        Clean the input bbox json and sort.
        """

        components = []

        if self.input_components:
            tmp_components = self.input_components
            for compo in tmp_components:
                if "image" in compo:
                    compo.pop("image")
                if "table_image" in compo:
                    compo.pop("table_image")

                rel_scale = self.orig_img_dpi / 72
                compo["scaled_x_1"] = rel_scale * compo["x_1"]
                compo["scaled_y_1"] = rel_scale * compo["y_1"]
                compo["scaled_x_2"] = rel_scale * compo["x_2"]
                compo["scaled_y_2"] = rel_scale * compo["y_2"]

                compo["doc_width_px"] = self.page_to_dimension[compo["page"]][0]
                compo["doc_height_px"] = self.page_to_dimension[compo["page"]][1]

            components.extend(self.input_components)

        components = sorted(components, key=lambda x: (x["page"], x["global_idx"], x["y_1"], x["x_1"]))

        return components

    def _save_img_with_bbox(self) -> None:
        """
        Save images of each page with bounding boxes overlay.
        """

        import matplotlib.pyplot as plt
        import seaborn as sns
        from matplotlib.patches import Patch, Rectangle

        sns.set_theme()

        palette = sns.color_palette("husl", 8)

        color_map = {
            "PLAIN": palette[0],
            "Text": palette[0],
            "HEADER": palette[1],
            "Header": palette[1],
            "LIST": palette[3],
            "List-item": palette[3],
            "FIGURE": palette[5],
            "Figure": palette[5],
            "Picture": palette[5],
            "Formula": palette[5],
            "TABLE": palette[6],
            "Table": palette[6],
            "CAPTION": palette[7],
            "Caption": palette[7],
            "IDK": "gray",
            "Page-footer": "gray",
            "Page-header": "gray",
        }

        def _save_page_img(bboxes_on_page: List[dict], img: Any) -> None:
            figure_dpi = 250  # DO NOT CHANGE
            img_height, img_width, _ = np.shape(img)

            # Create figure with exact size. DO NOT CHANGE.
            fig = plt.figure(figsize=(img_width / 100, img_height / 100), dpi=figure_dpi)

            # Add axis that takes up entire figure. DO NO CHANGE.
            ax = fig.add_axes((0, 0, 1, 1))
            ax.imshow(img)

            seen_klass = set()

            for bbox in bboxes_on_page:
                x0, y0, x1, y1 = (
                    bbox["scaled_x_1"],
                    bbox["scaled_y_1"],
                    bbox["scaled_x_2"],
                    bbox["scaled_y_2"],
                )

                curr_class = bbox[self.box_class_to_overlay]
                if curr_class not in color_map:
                    color_map[curr_class] = "gray"

                color = color_map[curr_class]
                seen_klass.add(curr_class)
                rect = Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color, lw=3, alpha=0.7)
                ax.add_patch(rect)

                if not (x0 == 0 and y0 == 0 and x1 == 0 and y1 == 0):
                    ax.text(
                        x0,
                        y0,
                        str(np.round(bbox["score"], 3)),
                        color=color,
                        fontsize=16,
                    )

            plt.axis("off")
            plt.legend(
                handles=[Patch(facecolor=color_map[klass], label=klass) for klass in seen_klass],
                prop={"size": 12},
            )

            img_buffer = BytesIO()
            plt.savefig(img_buffer, format="png", dpi=figure_dpi, pad_inches=0)
            plt.close(fig)

            img_buffer.seek(0)
            img_data = base64.b64encode(img_buffer.read()).decode()
            self.image_obj_list.append(f"data:image/png;base64,{img_data}")

        for page_num, page_img in enumerate(self.page_images):
            bboxes_on_page = [i for i in self.components_json if i["page"] == page_num]
            _save_page_img(bboxes_on_page, page_img)
