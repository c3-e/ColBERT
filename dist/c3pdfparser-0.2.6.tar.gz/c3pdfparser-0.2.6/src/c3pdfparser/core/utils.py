# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import abstractmethod
from typing import Generic, Mapping, Protocol, Sequence, Tuple, TypeVar

T = TypeVar("T")


class HasIloc(Protocol[T]):
    @property
    @abstractmethod
    def iloc(self) -> Sequence[T]:
        ...


@dc.dataclass(frozen=True)
class Locator(Generic[T]):
    data: Mapping[str, HasIloc[T]]

    def __getitem__(self, query: Tuple[str, int]) -> T:
        key, idx = query
        return self.data[key].iloc[idx]
