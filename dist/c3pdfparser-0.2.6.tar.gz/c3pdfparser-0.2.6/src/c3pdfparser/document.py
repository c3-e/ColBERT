# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import contextlib
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Any, List, Tuple

import numpy as np
from numpy.typing import NDArray
from PIL import Image


def _img_pad(left: float, right: float, top: float, bottom: float) -> Tuple[float, float, float, float]:
    PAD = 5
    return left - PAD, right + PAD, top - PAD, bottom + PAD


@dataclass(frozen=True)
class Img:
    document: Document
    image: Image.Image

    @property
    def width(self) -> int:
        return self.image.width

    @property
    def height(self) -> int:
        return self.image.height

    @property
    def size(self) -> Tuple[int, int]:
        return self.width, self.height

    def __post_init__(self):
        assert np.array(self).ndim == 3, "Image must be 3D."
        assert np.array(self).shape[2] == 3, "Image must have 3 channels."

    def __array__(self) -> NDArray:
        return np.array(self.image)

    def crop(self, x_1: float, y_1: float, x_2: float, y_2: float) -> "Img":
        sc = self.document.rel_scale
        return type(self)(
            document=self.document,
            image=self.image.crop(
                _img_pad(*map(lambda f: f * sc, [x_1, y_1, x_2, y_2])),
            ),
        )


STANDARD_DPI: float = 72.0
"""
The standard DPI for PDFs.
"""


@dataclass(frozen=True)
class Document:
    """
    The document class. A document is simply a file URL with some metadata.

    It provides some convenience methods to load the document as images,
    and to get the name and type of the document.

    Represents a document that is stored in a file.

    """

    filename: "str | Path"
    """
    The location of the documents.
    """

    dpi: float = STANDARD_DPI
    """
    The DPI of the document.
    """

    def __post_init__(self):
        if not Path(self.filename).exists():
            raise FileNotFoundError(f"File {self.filename} does not exist.")

        if self.dpi <= 0:
            raise ValueError(f"DPI must be positive, got {self.dpi}.")

    @cache
    def __len__(self):
        with self.read_pages() as pages:
            return len(pages)

    @property
    def rel_scale(self) -> float:
        """
        The relative scale of the document.

        Returns:
            float: The relative scale of the document.
        """

        return self.dpi / STANDARD_DPI

    @property
    def fname(self) -> str:
        """
        Returns the filename as a string.
        """

        return str(self.filename)

    @property
    def name(self) -> str:
        """
        Returns the name of the document

        Args:
            document (Document): The document.

        Returns:
            str: The name of the document.
        """
        return Path(self.fname).stem

    @property
    def type(self) -> str:
        """
        Returns the type of the document

        Args:
            document: The document.

        Returns:
            str: The type of the document.
        """
        return self.fname.split(".")[-1]

    @property
    def is_pdf(self):
        return self.type == "pdf"

    def __array__(self):
        return np.array(self._to_numpy_list())

    def _to_numpy_list(self) -> List[NDArray]:
        return [np.array(page) for page in self.pillows()]

    @contextlib.contextmanager
    def read_pages(self, **pdf_plumber_kwargs: Any):
        """
        Open the PDF file and return the pages.

        Internally, this uses the `pdfplumber` library, and must be used in a `with` statement.

        Args:
            **pdf_plumber_kwargs: Additional keyword arguments to pass to `pdfplumber.open`.

        Example:
            >>> with document.read_pages() as pages:
            ...     for page in pages:
            ...         print(page)
        """
        import pdfplumber

        with pdfplumber.open(self.fname, **pdf_plumber_kwargs) as pdf:
            yield pdf.pages

    @cache
    def pillows(self, **pdf_plumber_kwargs: Any) -> List[Img]:
        """
        Loads a single pages as a list of PIL images.

        Args:
            **pdf_plumber_kwargs: Additional keyword arguments to pass to `pdfplumber.open`.

        Returns:
            The pages of the document as PIL images.
        """

        if not self.is_pdf:
            raise NotImplementedError("`load_pages_as_images` is only implemented for PDF documents.")

        with self.read_pages(**pdf_plumber_kwargs) as pages:
            return [Img(document=self, image=page.to_image(resolution=self.dpi).original) for page in pages]

    def view(self, page_chunk: int) -> List[DocumentView]:
        """
        Splits the document into chunks of size `page_chunk_size`.

        Args:
            page_chunk: The number of pages per chunks.

        Returns:
            The document views.
        """

        return [
            DocumentView(**vars(self), page_idxs=range(i, min(i + page_chunk, len(self))))
            for i in range(0, len(self), page_chunk)
        ]


@dataclass(frozen=True)
class _DocViewMixin:
    """
    A mixin made to ensure that keyword arguments always exist last (some dataclass mechanism).
    This should be placed after any other dataclass that has optional (keyword) arguments.
    """

    page_idxs: range
    """
    The pages to view. Must be have a start and end, with step = 1.
    Both start and end must be in the range [0, len(document)].
    """


@dataclass(frozen=True)
class DocumentView(Document, _DocViewMixin):
    """
    ``DocumentView`` is a view of a document, kind of like slices to arrays, but for documents.
    Acting like a proxy to read only a portion of the document,
    this class makes it possible to do page-level parallel processing.

    Note:
        This class inherits from ``Document``, s.t. no code changes are needed for existing code.
        However, this might not be the best decision going forward.
        It might be better to have a separate class.
    """

    def __post_init__(self):
        super().__post_init__()

        assert self.page_idxs.start >= 0, "Start must be >= 0."
        assert self.page_idxs.stop <= super().__len__(), "End must be <= len(document)."
        assert self.page_idxs.step == 1, "Step must be 1."
        assert self.page_idxs.start <= self.page_idxs.stop, "Start must be <= end."

    def __len__(self) -> int:
        return len(self.page_idxs)

    @property
    def start(self) -> int:
        return self.page_idxs.start

    @property
    def end(self) -> int:
        return self.page_idxs.stop

    @contextlib.contextmanager
    def read_pages(self, **pdf_plumber_kwargs: Any):
        with super().read_pages(**pdf_plumber_kwargs) as pages:
            yield [pages[i] for i in self.page_idxs]

    def pillows(self, **pdf_plumber_kwargs: Any) -> List[Img]:
        """
        Loads a single pages as a list of PIL images.

        Args:
            **pdf_plumber_kwargs: Additional keyword arguments to pass to `pdfplumber.open`.

        Returns:
            The pages of the document as PIL images.
        """

        super_pillows = super().pillows(**pdf_plumber_kwargs)
        return [super_pillows[i] for i in self.page_idxs]
