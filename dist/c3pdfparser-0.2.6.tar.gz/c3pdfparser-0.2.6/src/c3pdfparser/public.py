# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import os
from types import FunctionType
from typing import Callable, TypeVar

_T = TypeVar("_T")


def stable() -> Callable[[_T], _T]:
    """
    Decorator for marking a function as stable.
    This only works on functions and classes.

    Todo:
        Automatically document functions marked as stable.

    Todo:
        Versioning and deprecation for stable functions.
    """

    module = __name__

    def _stable_marker(func_or_class: _T) -> _T:
        assert isinstance(func_or_class, (type, FunctionType))
        name = func_or_class.__name__

        if os.environ.get("DOCUMENT_STABLE_API", False):
            print(f"::: {module}.{name}")

        return func_or_class

    return _stable_marker
