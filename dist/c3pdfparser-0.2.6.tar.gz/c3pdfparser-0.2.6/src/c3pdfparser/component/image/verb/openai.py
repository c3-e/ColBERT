# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc

from c3pdfparser.providers import OpenaiVLM, OpenaiVLMSpec

from ..api import RawImageComponent
from .api import ImageVerbal, ImageVerbalSpec


@dc.dataclass(frozen=True)
class OpenaiSpec(ImageVerbalSpec):
    """
    Spec for verbaliser that does nothing and returns an empty string.

    Note:
        Team lego might have some LLM model that can be used.
    """

    api_key: str
    """
    The API key to use.
    """

    endpoint: str
    """
    The endpoint to use.
    For example, "https://genai.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-05-01-preview"
    """

    max_tokens: int = 100
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a good image recognizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = "Given the image and its caption: '{caption}', come up with titles and keywords."


class Openai(ImageVerbal, spec_class=OpenaiSpec):
    def __init__(self, spec: OpenaiSpec):
        super().__init__(spec)

    def __call__(self, image: RawImageComponent) -> str:
        img = image.img
        text = self.spec.user_text_prompt.format(caption=image.text)

        return self.vlm(text, img)

    @property
    def vlm(self):
        return OpenaiVLM(
            OpenaiVLMSpec(
                api_key=self.spec.api_key,
                endpoint=self.spec.endpoint,
                max_tokens=self.spec.max_tokens,
                system_prompt=self.spec.system_prompt,
            )
        )
