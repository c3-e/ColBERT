# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import inspect
from abc import ABC, abstractmethod
from dataclasses import dataclass, fields
from types import FunctionType
from typing import Any, ClassVar, Generic, List, Sequence, TypeVar

from c3pdfparser.core import BoundingBox, DocBboxes, Graphrame, UniqueIds
from c3pdfparser.decltype import LayoutExec
from c3pdfparser.layout import LayoutParserOutput, MarkdownClass
from c3pdfparser.specs import Spec, specify


@dataclass(frozen=True)
class Component:
    """
    The base component class represents a document component. This contains the common attributes for all
    document components.
    """

    page: int
    """The document page this bounding box is in."""

    global_idx: int
    """
    The index of the bounding box within the page.
    """

    bbox: BoundingBox
    """The bounding box of the component."""


@dataclass(frozen=True)
class ComponentParserOutputItem(Component, ABC):
    """
    The base component parser output class.
    """

    @property
    def x_1(self) -> float:
        return self.bbox.x_1

    @property
    def x_2(self) -> float:
        return self.bbox.x_2

    @property
    def y_1(self) -> float:
        return self.bbox.y_1

    @property
    def y_2(self) -> float:
        return self.bbox.y_2

    @property
    @abstractmethod
    def description_for_vectorstore(self) -> str:
        """
        A description of the component for the vector store.

        Returns:
            The description of the component for the vector store.
        """

    @property
    @abstractmethod
    def parser(self) -> str:
        """
        The parser that parsed this component.
        """


@dataclass(frozen=True)
class ComponentParserSpec(Spec, ABC):
    """
    The base parser specification class.
    """


_S = TypeVar("_S", bound=ComponentParserSpec)
_C = TypeVar("_C", bound=ComponentParserOutputItem)


@dataclass
class ComponentParserOutput(DocBboxes):
    """
    The output of a component parser.
    This class provides some simple uilities to convert data stored in the output to a graphrame,
    and to convert it back.
    """


@specify(ComponentParserSpec)
class ComponentParser(
    Generic[_S, _C], LayoutExec[LayoutParserOutput, DocBboxes], ABC
):  # interface for all parsing workstreams
    """
    The interface for all component-wise parsing workstreams.

    Parsers are responsible for both choosing which components to parse and parsing the content of the document.

    To choose which components to parse, the parser should define `CONTEXTUAL` and `PARSE` classvars,
    where it should return a list of component classes that the parser can parse.

    To parse the content of the document, the parser should implement the `parse` method,
    where it should return the parsed content, based on a given document and bounding boxes that contains only classes in the list returned by `PARSE`.
    """

    CONTEXTUAL: ClassVar[Sequence[MarkdownClass] | MarkdownClass]
    """
    The component classes that would be fed into the parser.
    """

    PARSE: ClassVar[Sequence[MarkdownClass] | MarkdownClass]
    """
    The component class that the parser would parse.
    """

    def execute(self, bboxes: LayoutParserOutput, /) -> DocBboxes:
        """
        Parses the content of the document.

        Parameters:
            bboxes: The bounding boxes of the document.

        Returns:
            The parsed content stored in a `Graphrame`.
        """

        if not isinstance(bboxes, LayoutParserOutput):
            raise TypeError(f"bounding_boxes must be of type LayoutParserOutput, not {type(bboxes)}")

        filtered_bboxes = bboxes.filter_class(*_wrap_as_tuple(self.CONTEXTUAL))
        output = self.parse(filtered_bboxes, bboxes)

        return self._component_output_to_doc_bboxes(bboxes, output)

    @abstractmethod
    def parse(self, bounding_boxes: LayoutParserOutput, unfiltered: LayoutParserOutput, /) -> List[_C]:
        """
        Parses the content of the document.

        Parameters:
            bounding_boxes: The bounding boxes of the document.
            unfiltered: The bounding boxes of the document that contains all classes.

        Returns:
            The parsed content.
        """

    def _component_output_to_doc_bboxes(
        self, bboxes: DocBboxes, output: List[ComponentParserOutputItem]
    ) -> ComponentParserOutput:
        """
        Converts a list of component parser output items to a graphrame.

        NOTE:
            Maybe convert this into a classmethod of `ComponentParserOutput`?

        Parameters:
            output: The component parser output items.

        Returns:
            The result of component parser output.
        """

        frame = self._component_output_to_graphrame(bboxes, output)
        cpo = ComponentParserOutput(frame, document=bboxes.document)

        # Retain the typing information s.t. they can be reconstructed.
        # This works because only when the graphrame is not empty, the `_type` information is used.
        # FIXME: I don't like this. It's a bit hacky. Is there a better way?
        if len(output):
            [cpo._type] = {type(out) for out in output}

        return cpo

    def _component_output_to_graphrame(
        self, bboxes: LayoutParserOutput, output: List[ComponentParserOutputItem]
    ) -> Graphrame:
        # ComponentParser only parses the components that it handles.
        parse_bboxes = bboxes.filter_class(*_wrap_as_tuple(self.PARSE))
        unique_ids = parse_bboxes.unique_ids

        _check_unique_ids_of_filtered(parse_bboxes, unique_ids)
        _check_output_matches_unique_ids(output, unique_ids)

        # Output is empty, return an empty frame.
        if len(output) == 0:
            return Graphrame.empty([f.name for f in fields(ComponentParserOutputItem)])

        # Note: This operation is quite expensive.
        return Graphrame.from_records([_get_members_and_properties(out) for out in output], ids=unique_ids)


def _get_members_and_properties(obj: Any):
    return {
        name: member
        for name, member in inspect.getmembers(obj)
        if not name.startswith("_") and not isinstance(member, FunctionType)
    }


def _check_unique_ids_of_filtered(bboxes: LayoutParserOutput, unique_ids: UniqueIds):
    # The parsed bounding boxes retain the unique ids of the original bounding boxes, or else there is a bug.
    if not bboxes.unique_ids.issuperset(unique_ids):
        raise AssertionError("The unique ids of the bounding boxes must be a subset of the unique ids of the document.")


def _check_output_matches_unique_ids(output: List[ComponentParserOutputItem], unique_ids: UniqueIds):
    # The length must match or there is a bug.
    if len(output) != len(unique_ids):
        raise AssertionError(
            "The number of output items must be equal to the number of unique ids."
            f"Got {len(output)} output items and {len(unique_ids)} unique ids."
        )


def _wrap_as_tuple(x):
    return x if isinstance(x, tuple) else (x,)
