# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import logging
from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from c3pdfparser.core import BoundingBox, ParsedMetadata
from c3pdfparser.document import Document
from c3pdfparser.layout import LayoutParserOutput

from .api import CaptionFinder, CaptionFinderSpec

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class LocalitySpec(CaptionFinderSpec):
    later_first: bool = True
    """
    Later first means that the offsets are in the order of [1, -1, 2, -2, 3, -3, ...],
    meaning that the later boxes are explored first.
    Otherwise, the offsets are in the order of [-1, 1, -2, 2, -3, 3, ...],
    and the earlier boxes are explored first.
    """


class Locality(CaptionFinder, spec_class=LocalitySpec):
    """
    Given a document and their parsed layout,
    return the captions for each image by locating a text bounding box near the image bounding box.
    This parser assumes that the layout parser already does a decent job of parsing the document layout,
    so it only explores nearby bounding boxes, from near to far, to find the caption.
    """

    def parse(self, document: Document, bounding_boxes: LayoutParserOutput, keywords: List[str]) -> List[List[str]]:
        bboxes = bounding_boxes.to_list_of_list()
        # Compute the offset sequence.
        offset_unit = np.array([1, -1]) if self.spec.later_first else np.array([-1, 1])
        offsets = np.concatenate([i * offset_unit for i in range(1, self.spec.nearest + 1)])
        assert offsets.shape == (2 * self.spec.nearest,)

        # For faster accessing.
        bbox_list_list = bounding_boxes.to_list_of_list()
        meta_list_list: List[List[str]] = []

        for page_idx, boxes_on_page in enumerate(bboxes):
            metadata_on_page: List[str] = []

            for fig_idx in range(len(boxes_on_page)):
                # Get the caption for the figure
                caption = get_for_box(
                    document=document,
                    page_number=page_idx,
                    box_idx=fig_idx,
                    page_bounding_boxes=bbox_list_list[page_idx],
                    keywords=keywords,
                    offsets=offsets,
                )
                metadata_on_page.append(caption)

            meta_list_list.append(metadata_on_page)

        return meta_list_list


def get_for_box(
    document: Document,
    page_number: int,
    box_idx: int,
    page_bounding_boxes: Sequence[ParsedMetadata],
    keywords: List[str],
    offsets: List[int],
) -> str:
    """
    Look for the caption of a figure in the nearby bounding boxes.

    Args:
        document: The document.
        page_number: The page number.
        figure_box_idx: The index of the figure bounding box.
        page_bounding_boxes: List of bounding boxes.
        keywords: Keywords to search for in the captions.
        top_k: Number of nearby bounding boxes to consider.
    """

    nearest_bboxes: List[ParsedMetadata] = []

    for offset in offsets:
        idx = box_idx + offset
        if idx >= 0 and idx < len(page_bounding_boxes):
            bbox = page_bounding_boxes[idx]
            nearest_bboxes.append(bbox)

    # HACK:
    # This is a hack that returns empty string if no nearby bounding boxes are found,
    # while this is a hack, it exists in previous build so I'm not responsible for it.
    if not nearest_bboxes:
        return ""

    # Only choose captions if there are any nearby.
    if any(bbox.klass == "PLAIN" for bbox in nearest_bboxes):
        nearest_bboxes = [bbox for bbox in nearest_bboxes if bbox.klass == "PLAIN"]

    # if there are nearby bounding boxes with class Caption, use only those, else, check all nearby boxes
    for bbox in nearest_bboxes:
        caption = extract_content_pdfplumber(document, page_number, bbox.norm_bbox)

        if caption.lower().startswith(tuple(keywords)):
            return caption
    return ""


def extract_content_pdfplumber(document: Document, page_number: int, text_box: BoundingBox) -> str:
    """
    Extract text within a given `boundingbox` using pdfplumber.
    If `text_box` is None, extracts text from entire page.

    Args:
        document: The document.
        page_number: The page number.
        text_box: The bounding box to extract text from.

    Returns:
        str: The extracted text.
    """

    return document.page_contents[page_number].crop_text(text_box)
