# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import List, TypeVar

from c3pdfparser.specs import Spec, factorise


@dc.dataclass(frozen=True)
class TextChunkerSpec(Spec, ABC):
    pass


_S = TypeVar("_S", bound=TextChunkerSpec)


@factorise(TextChunkerSpec)
class TextChunker(ABC):
    """
    The base class for all text chunkers.

    A text chunker is a component that takes a text and chunks it into smaller text blocks.
    """

    def __call__(self, txt: str, /) -> List[str]:
        """
        Main chunker API.
        Reads the text from the text component and chunks it into text blocks while respecting sentence boundaries.

        Args:
            txt: The text component to be chunked.

        Returns:
            A list of TextComponents from the passage component.
        """

        return self.chunk(txt)

    @abstractmethod
    def chunk(self, text: str) -> List[str]:
        pass
