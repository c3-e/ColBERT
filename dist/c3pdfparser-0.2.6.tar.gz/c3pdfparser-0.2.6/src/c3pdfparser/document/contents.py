# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray
from PIL.Image import Image

from c3pdfparser.document.grids.api import CropWithBbox

from .croppers import ImageCropper, TableCropper, TextCropper

if TYPE_CHECKING:
    from c3pdfparser import BoundingBox, Document


@dataclass(frozen=True)
class Content:
    """
    A central location for accessing what's inside of a document.
    It handles scaling and cropping of images and text extraction,
    s.t. externally, the bounding boxes can be kept normalised.

    The content would utilise the cropping strategy specified in the document to perform cropping,
    allowing the underlying medium to be platform and document type agnostic.
    """

    document: Document
    page: int

    @property
    def dpi(self) -> int:
        """
        The DPI of the image.
        """

        return self.image_cropper.dpi

    @property
    def image_cropper(self) -> ImageCropper:
        """
        The image cropper to use (on this page).
        This is directly retrieved from the document.
        """
        return self.document.image_cropper(self.page)

    @property
    def text_cropper(self) -> TextCropper:
        """
        The text cropper to use (on this page).
        This is directly retrieved from the document.
        """
        return self.document.text_cropper(self.page)

    @property
    def table_cropper(self) -> TableCropper:
        """
        The table cropper to use (on this page).
        This is directly retrieved from the document.
        """
        return self.document.table_cropper(self.page)

    @property
    def image(self) -> Image:
        return self.image_cropper.crop_bbox(self)

    def __post_init__(self):
        assert np.array(self).ndim == 3, "Image must be 3D."
        assert np.array(self).shape[2] == 3, "Image must have 3 channels."

    def __array__(self) -> NDArray:
        """
        Allowing the content to be treated as an array.
        """

        return np.array(self.image)

    def find_and_gen_grid(self) -> CropWithBbox:
        return self.document.grid_generator.gen(self)

    def crop_image(self, bbox: BoundingBox | None = None) -> Image:
        """
        Crop the image to the given bounding box region.

        Parameters:
            bbox: The (normalised) bounding box region.

        Returns:
            The cropped image.
        """

        return self.image_cropper.crop_bbox(self, bbox)

    def crop_text(self, bbox: BoundingBox | None = None) -> str:
        """
        Extract text from the given bounding box region.

        Parameters:
            bbox: The (normalised) bounding box region.

        Returns:
            The extracted text.
        """

        return self.text_cropper.crop_bbox(self, bbox)

    def crop_table(self, bbox: BoundingBox | None = None) -> str:
        """
        Crop the table to the given bounding box region

        Args:
            bbox: The (normalised) bounding box region.

        Returns:
            The cropped table in string representation.
        """

        return self.table_cropper.crop_bbox(self, bbox)

    @property
    def strategy(self):
        """
        The cropping strategy to use.
        """

        cropping = self.document.cropping

        if callable(cropping):
            return cropping(self.page)

        return cropping
