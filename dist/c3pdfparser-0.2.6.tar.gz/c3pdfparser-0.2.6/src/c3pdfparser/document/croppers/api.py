# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Generic, TypeVar

from PIL.Image import Image

from c3pdfparser.specs import factorise

if TYPE_CHECKING:
    from c3pdfparser import BoundingBox
    from c3pdfparser.document.contents import Content

T = TypeVar("T")


@dc.dataclass
class CropperSpec(ABC):
    pass


class Cropper(Generic[T], ABC):
    @abstractmethod
    def crop_bbox(self, content: Content, bbox: BoundingBox) -> T:
        pass


@dc.dataclass
class TableCropperSpec(CropperSpec):
    pass


@factorise(TableCropperSpec)
class TableCropper(Cropper[str]):
    pass


@dc.dataclass
class ImageCropperSpec(CropperSpec):
    dpi: int = 72
    """
    The DPI to use for VGT model.

    Note that the higher DPI will lead to higher latency, but not neccessarily better performance.
    """

    margins: float = 5
    """
    The padding to add to the bounding box before cropping the image,
    s.t there are some margins around the text.
    """


@factorise(ImageCropperSpec)
class ImageCropper(Cropper[Image]):
    @property
    def dpi(self) -> int:
        return self.spec.dpi


@dc.dataclass
class TextCropperSpec(CropperSpec):
    pass


@factorise(TextCropperSpec)
class TextCropper(Cropper[str]):
    pass
