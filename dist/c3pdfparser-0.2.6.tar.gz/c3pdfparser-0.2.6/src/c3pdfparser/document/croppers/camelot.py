# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any, List

from pandas import DataFrame

from .api import TableCropper, TableCropperSpec

if TYPE_CHECKING:
    from c3pdfparser import BoundingBox, Document
    from c3pdfparser.document import Content

LOGGER = logging.getLogger(__name__)


class Camelot(TableCropper, spec_class=TableCropperSpec):
    """
    Camelot is a table content extractor that uses the camelot library to extract tables from PDFs.

    Since this is more or less a "traditional" table extractor,
    it is not as flexible as the other table extractors,
    and can fail on more complex tables.
    """

    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> str:
        if bbox is not None:
            warnings.warn(
                "Bounding box cropping has been disabled with Camelot, "
                "due to having issues. Ignoring the bounding box."
            )

        dfs = camelot_read_pdf(document=content.document, page_number=content.page)

        chosen_df = dfs[0]
        return self._table_to_text(chosen_df)

    def _table_to_text(self, df_table: DataFrame):
        """
        Returns a string representation of a pandas dataframe.
        """
        table_rows = []
        for _, row in df_table.iterrows():
            table_rows.append("\t| ".join([x.replace("\n", " ") for x in list(row)]))
        return "\n".join(table_rows)


def camelot_read_pdf(document: Document, page_number: int, **camelot_kwargs: Any) -> List[DataFrame]:
    """
    Attempts to read a PDF using camelot on page ``page_number``.
    This function is cached to avoid re-reading the same page multiple times,
    since this is called whenever a table is parsed.

    TODO:
        Ensure that each page is read only once, which gets rid of the ``lru_cache``.

    Warning:
        Sometimes camelot parsing would fail with the ``table_regions`` or ``table_area``.
        Therefore, it was removed alltogether (might affect parsing quality).
    """

    import camelot

    tables = camelot.read_pdf(document.fname, pages=str(page_number + 1), flavor="stream", **camelot_kwargs)
    return [table.df for table in tables]
