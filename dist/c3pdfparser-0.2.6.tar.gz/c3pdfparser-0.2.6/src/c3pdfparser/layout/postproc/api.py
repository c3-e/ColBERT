# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from types import FunctionType
from typing import Any, Callable, List, Mapping, Tuple

from c3pdfparser.decltype import LayoutExec
from c3pdfparser.specs import InlineEval, Spec, UnparsableError, factorise

from ..api import LayoutParserOutput

CAMEL_CASE_REGEX = re.compile(r"[a-zA-Z]+(?:_[a-zA-Z]+)*")


def is_camel_case(s: str) -> bool:
    return CAMEL_CASE_REGEX.fullmatch(s) is not None


@dataclass(frozen=True)
class LayoutPostProcSpec(Spec):
    """
    A specification for a post-processing step.
    """


LayoutOutputExec = LayoutExec[LayoutParserOutput, LayoutParserOutput]


@factorise(LayoutPostProcSpec)
class LayoutPostProc(LayoutOutputExec, ABC):
    """
    This is an abstract class that defines the interface for post-processing steps,
    which are functions used in the post-processing pipeline.
    """

    @abstractmethod
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        """
        The post-processing step.

        Args:
            output: The output of the layout parser.

        Returns:
            The post-processed output.
        """

    @classmethod
    def register(cls, post_proc: Callable[[LayoutOutputExec], LayoutOutputExec]) -> LayoutOutputExec:
        """
        Register a pure post-processing function (of type types.FunctionType) into the factory.

        Example:
            >>> @LayoutPostProc.register
            ... def my_post_proc(output):
            ...     return output

            >>> @LayoutPostProc.register
            ... def my_other_post_proc(output):
            ...     return output

            >>> # Note that the function name must be in camel case.
            ... # After register, it would be available in the registry.

            >>> # After registering the post-processing functions, you can use them as follows:
            ... output = LayoutPostProc.factory("MY_POST_PROC")(output)
            ... output = LayoutPostProc.factory("MY_OTHER_POST_PROC")(output)
        """

        if not isinstance(post_proc, FunctionType):
            raise ValueError(f"Can only register functions!")

        if not is_camel_case(func_name := post_proc.__name__):
            raise ValueError(f"Function name must be in camel case!")

        # Dynamically create a subclass of LayoutPostProc.
        # This has the effect of automatially registering the post-processing function.
        class _SubType(cls, spec_class=LayoutPostProcSpec, class_name=func_name.upper()):
            def execute(self, output):
                return post_proc(output)

        _SubType.__doc__ = post_proc.__doc__
        _ = _SubType

        return post_proc


@dataclass(frozen=True)
class LayoutPostProcPipe(LayoutOutputExec):
    """
    The pipeline for post-processing functions.

    Examples:
        >>> # If both post-processing functions are registered functions (not objects)...
        ... # Calls `LayoutPostProc.factory("MY_POST_PROC")` and `LayoutPostProc.factory("MY_OTHER_POST_PROC")`
        ... post_proc = LayoutPostProcPipe(["MY_POST_PROC", "MY_OTHER_POST_PROC"])

        >>> # If one of the post-processing functions is an object...
        ... # Calls `LayoutPostProc.factory("MY_OTHER_POST_PROC", arg1=1, arg2=2)` for the second function.
        ... post_proc = LayoutPostProcPipe([
        ...     {"kind": "MY_POST_PROC", "kwargs": {}},
        ...     ("MY_OTHER_POST_PROC", {"arg1": 1, "arg2": 2}),
        ... ])
    """

    post_procs: List[str | Tuple[str, Mapping[str, Any]]] = field(default_factory=list)
    """
    The sequence of post-processing functions.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        pipeline = self._pipeline()

        for func in pipeline:
            output = func(output)

        return output

    def _pipeline(self) -> List[LayoutPostProc]:
        """
        Construct the post-processing pipeline.
        """

        pipeline: List[LayoutPostProc] = []
        evaluator = InlineEval()

        for pp in self.post_procs:
            try:
                result = evaluator(pp)
                step = LayoutPostProc.factory(result.kind, **result.kwargs)
                pipeline.append(step)
            except UnparsableError as upe:
                raise ValueError(f"Invalid post-processing step {pp}.") from upe

        return pipeline
