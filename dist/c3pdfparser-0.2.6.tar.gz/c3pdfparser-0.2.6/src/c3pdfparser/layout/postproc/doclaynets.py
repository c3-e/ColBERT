# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
import itertools
import logging
from collections import defaultdict
from functools import reduce
from typing import Callable, Dict, Hashable, List, Mapping, Sequence, Set, Tuple, TypeVar, no_type_check

import numpy as np
from numpy.typing import NDArray
from PIL.Image import Image

from c3pdfparser.core import BoundingBox, ParsedMetadata

from .api import LayoutParserOutput, LayoutPostProc, LayoutPostProcSpec

LOGGER = logging.getLogger(__name__)
_T = TypeVar("_T", bound=Hashable)
_E = TypeVar("_E")


def _bbox_class_threshold() -> Dict[str, float]:
    # Dictionary returned by this function is required to be order preserving.
    # This is only the case since python 3.7
    # However I'm not too worried because I'm using many 3.8+ features.

    return {
        "Caption": 0.2,
        "Footnote": 0.2,
        "Formula": 0.2,
        "List-item": 0.2,
        "Page-footer": 0.2,
        "Page-header": 0.2,
        "Picture": 0.6,
        "Section-header": 0.2,
        "Table": 0.2,
        "Text": 0.2,
        "Title": 0.2,
    }


def _inter_class_consol() -> Dict[str, List[str]]:
    return {
        "Header": ["Title", "Section-header"],
        "Table": ["Table"],
        "Figure": ["Figure", "Picture"],
        "Text": ["Caption", "Footnote", "Text"],
        "Caption": ["Caption"],
        "Formula": ["Formula"],
        "Page-footer": ["Page-footer"],
        "Page-header": ["Page-header"],
    }


def _intra_class_consol() -> Dict[str, List[str]]:
    return {
        "Figure": ["Picture"],
        "Table": [],
        "Header": ["Page-footer", "Page-header"],
        "Caption": ["Text"],
    }


@dc.dataclass(frozen=True)
class FilterDocSpec(LayoutPostProcSpec):
    """
    A specification for a filter document layout post-processor.
    """

    bbox_class_threshold: Dict[str, float] = dc.field(default_factory=_bbox_class_threshold)
    """
    The bounding box class threshold.
    """


class FilterDoc(LayoutPostProc, spec_class=FilterDocSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        filtered = filter_doc(output, self.spec.bbox_class_threshold)
        return LayoutParserOutput.init(filtered, document=output.document)


@dc.dataclass(frozen=True)
class UnionBoxSpec(LayoutPostProcSpec):
    """
    A specification for a union consolidation post-processor.
    """

    inter_consol_dict: Dict[str, List[str]] = dc.field(default_factory=_inter_class_consol)
    """
    The interclass consolidation dictionary.
    """


class UnionBox(LayoutPostProc, spec_class=UnionBoxSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        unioned = consolidate_by_union(output.to_list_of_list(), self.spec.inter_consol_dict)
        return LayoutParserOutput.init(unioned, document=output.document)


@dc.dataclass(frozen=True)
class NoOverlapSpec(LayoutPostProcSpec):
    """
    A specification for a non-overlapping bounding box post-processor.
    """

    intra_consol_dict: Dict[str, List[str]] = dc.field(default_factory=_intra_class_consol)
    """
    The intraclass consolidation dictionary.
    """

    threshold: float = 0.95
    """
    The threshold for the non-overlapping bounding boxes.
    """


class NoOverlap(LayoutPostProc, spec_class=NoOverlapSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        no_overlap = consolidate_by_remove_overlaps(output, self.spec.intra_consol_dict, self.spec.threshold)
        return LayoutParserOutput.init(no_overlap, document=output.document)


@dc.dataclass(frozen=True)
class OrderByGridSpec(LayoutPostProcSpec):
    """
    A specification for a order by grid post-processor.
    """

    grid_step: int = 32
    """
    The size of the grid.
    """

    def __post_init__(self):
        if self.grid_step <= 0:
            raise ValueError("Grid size should be greater than 0.")


class OrderByGrid(LayoutPostProc, spec_class=OrderByGridSpec):
    """
    Order bounding boxes by grid.

    TODO:
        Add testing for this function.
    """

    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        ordered = []

        for page_bboxes in output:
            boxes = [box.detach() for box in page_bboxes]
            ordered.append(
                sorted(
                    boxes,
                    key=lambda bbox: (
                        bbox.x_1 // self.spec.grid_step,
                        bbox.y_1 // self.spec.grid_step,
                        bbox.y_2 // self.spec.grid_step,
                    ),
                )
            )

        return LayoutParserOutput.init(ordered, document=output.document)


@dc.dataclass(frozen=True)
class OrderByColumnSpec(LayoutPostProcSpec):
    """
    A specification for a order by column post-processor.
    """

    find_page_sep: bool = False
    """
    Whether to find page separators to support multi-column documents.
    """

    grid_step: int = 32
    """
    The step (in pixels) to which the process of fingind page separators creates grids for bounding box "hits".
    """

    low_pass_filter: float = 0.1
    """
    The low pass threshold to determine whether a position is a separator. This needs
    to work with grid_step and may need to change if grid_step is changed.
    """

    max_separators: int = 2
    """
    The maximum number of separators allowed on one page. If more separators than this are
    detected, we see them as unreliable and do not return any separators.
    """


class OrderByColumn(LayoutPostProc, spec_class=OrderByColumnSpec):
    """
    Order bounding boxes by column.

    TODO:
        Add testing for this function.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        ordered = order_by_column(
            doc_bboxes=output.to_list_of_list(),
            doc_imgs=[content.image for content in output.document.page_contents],
            find_page_sep=self.spec.find_page_sep,
            grid_step=self.spec.grid_step,
            low_pass_filter=self.spec.low_pass_filter,
            max_separators=self.spec.max_separators,
        )
        return LayoutParserOutput.init(ordered, document=output.document)


@dc.dataclass(frozen=True)
class ToMarkdownClassSpec(LayoutPostProcSpec):
    """
    A specification for a markdown class post-processor.
    """

    class_map: Dict[str, str] = dc.field(
        default_factory=lambda: {
            "Header": "HEADER",
            "Figure": "FIGURE",
            "Picture": "FIGURE",
            "Formula": "FIGURE",
            "Table": "TABLE",
            "Text": "PLAIN",
            "Caption": "PLAIN",
            "List-item": "LIST",
            "Page-footer": "IDK",
            "Page-header": "IDK",
        }
    )
    """
    The class maping to use.
    """


class ToMarkdownClass(LayoutPostProc, spec_class=ToMarkdownClassSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        class_group = self.spec.class_map
        return LayoutParserOutput.init_with_mapping(output, class_group)


AddMarkdownClassSpec = ToMarkdownClassSpec


class AddMarkdownClass(LayoutPostProc, spec_class=AddMarkdownClassSpec):
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:
        class_group = self.spec.class_map
        md_cls = output.skeleton.df["klass"].map(lambda cls: class_group[cls])
        return output.with_column("markdown", md_cls)


def filter_doc(doc_bboxes: LayoutParserOutput, bbox_filter_dict: Mapping[str, float]) -> List[List[ParsedMetadata]]:
    """
    Filter bounding boxes based on the bbox_filter_dict.

    Args:
        doc_bboxes: The bounding boxes.
        bbox_filter_dict: The bounding box class filter dictionary.

    Returns:
        The filtered bounding boxes.
    """

    filtered_boxes: List[List[ParsedMetadata]] = []
    for page_num, bounding_box_list in enumerate(doc_bboxes):
        # Get all the bounding boxes that have a score higher than the threshold.
        boxes = filter_page(bounding_box_list, bbox_filter_dict)

        if not boxes:
            LOGGER.warning("No bounding boxes found for page=%s. This can be a bug.", page_num)

        filtered_boxes.append(boxes)

    return filtered_boxes


def filter_page(page_bboxes: List[ParsedMetadata], filt_dict: Mapping[str, float]) -> List[ParsedMetadata]:
    """
    Filter bounding boxes based on the bbox_filter_dict.

    Args:
        page_bboxes: The bounding boxes.
        filt_dict: The bounding box class filter dictionary.

    Returns:
        The filtered bounding boxes.
    """

    return [bbox for bbox in page_bboxes if bbox.score >= filt_dict.get(bbox.klass, float("inf"))]  # type: ignore


def consolidate_by_union(
    doc_bboxes: List[List[ParsedMetadata]], inter_consol_dict: Dict[str, List[str]]
) -> List[List[ParsedMetadata]]:
    unioned_bboxes: List[List[ParsedMetadata]] = []
    for page_bboxes in doc_bboxes:
        page_bboxes = unioning_dict(page_bboxes, inter_consol_dict, 0.1)
        unioned_bboxes.append(page_bboxes)
    return unioned_bboxes


@dc.dataclass
class _UnionNode:
    """
    A dataclass for the union node for the union find algo.
    """

    idx: int
    head: int

    def find(self, nodes: List["_UnionNode"]) -> int:
        """
        Find the head of the union node.
        """

        if self.head == self.idx:
            return self.head

        self.head = nodes[self.head].find(nodes)
        return self.head


def unioning_dict(
    bboxes: List[ParsedMetadata], consolidation: Mapping[str, Sequence[str]], threshold: float
) -> List[ParsedMetadata]:
    """
    Consolidate bounding boxes by unioning the bounding boxes of the same class,
    according to the intraclass consolidation dictionary.

    Args:
        bboxes: The list of bounding boxes.
        consolidation: The intraclass consolidation dictionary.

    Returns:
        The consolidated bounding boxes.
    """

    # Map bounding box class names to the consolidated class names.
    consol_value2key = {}
    for class_key, class_val in consolidation.items():
        for meta_class in class_val:
            consol_value2key[meta_class] = class_key

    bboxes = [
        ParsedMetadata.flat_init(
            x_1=parsed.bbox.x_1,
            y_1=parsed.bbox.y_1,
            x_2=parsed.bbox.x_2,
            y_2=parsed.bbox.y_2,
            klass=consol_value2key.get(parsed.klass, parsed.klass),  # type: ignore
            score=parsed.score,
        )
        for parsed in bboxes
    ]

    # Group bounding boxes by class to perform unioning.
    grouped_bboxes = group_list_by(bboxes, key=lambda i: bboxes[i].klass)

    # Union bounding boxes of the same class.
    unioned_bboxes: List[ParsedMetadata] = []
    for parsed in grouped_bboxes.values():
        # Union find the bounding boxes.
        union_nodes = union_find_bounding_box([bbox.bbox for bbox in parsed], threshold=threshold)

        # Group the union nodes by the head of the union node.
        grouped_union_nodes = group_list_by(parsed, key=lambda idx: union_nodes[idx].find(union_nodes))

        # Union if the boxes are joined during union find.
        for val in grouped_union_nodes.values():
            merged_bbox = reduce(
                lambda a, b: a.merge(b, strategy="union"), [bbox.bbox for bbox in val[1:]], val[0].bbox
            )
            merged_score = max(bbox.score for bbox in val)

            assert all(bbox.klass == val[0].klass for bbox in val), "All bounding boxes should have the same class."

            merged_klass = val[0].klass

            unioned_bboxes.append(
                ParsedMetadata.flat_init(
                    x_1=merged_bbox.x_1,
                    y_1=merged_bbox.y_1,
                    x_2=merged_bbox.x_2,
                    y_2=merged_bbox.y_2,
                    klass=merged_klass,
                    score=merged_score,
                )
            )

    return unioned_bboxes


def group_list_by(parsed_list: List[_E], *, key: Callable[[int], _T]) -> Dict[_T, List[_E]]:
    """
    Group bounding boxes by class name.

    Args:
        parsed_list: The list of bounding boxes.
        key:
            The key function to group the bounding boxes.
            Takes in the index of the bounding box.
            The rationale to take in the index is to allow for the key function to be stateful,
            e.g. to keep track of the previous bounding box.
            This is in line with how go implements their sorting function, so definitely not unheard of.

    Returns:
        The grouped bounding boxes by class name.
    """

    result: Dict[_T, List[_E]] = defaultdict(list)

    for i, parsed in enumerate(parsed_list):
        result[key(i)].append(parsed)

    return result


def union_find_bounding_box(bounding_boxes: List[BoundingBox], threshold: float) -> List[_UnionNode]:
    """
    Union bounding boxes of the same class, with union-find algorithm.

    Args:
        bounding_boxes: The list of bounding boxes.

    Returns:
        The unioned bounding box.

    Raises:
        AssertionError: If the bounding boxes are empty.
    """

    assert len(bounding_boxes) > 0, "Bounding boxes should not be empty."

    # The union-find algorithm.
    to_merge: List[Tuple[int, int]] = []

    # Filtering edges by the threshold.
    for i, j in itertools.combinations(range(len(bounding_boxes)), 2):
        assert i < j, "i should be less than j."

        overlaps = bounding_boxes[i].intersection_over(bounding_boxes[j], strategy="union")

        # Only union when needed.
        if overlaps > threshold:
            to_merge.append((i, j))

    # Kruskal's algorithm to merge the bounding boxes.
    unioned: List[_UnionNode] = [_UnionNode(idx=i, head=i) for i in range(len(bounding_boxes))]

    for i, j in to_merge:
        head_i = unioned[i].find(unioned)
        head_j = unioned[j].find(unioned)

        if head_i != head_j:
            unioned[head_i].head = head_j

    return unioned


def consolidate_by_remove_overlaps(
    unioned_bboxes: List[List[ParsedMetadata]], intra_consol_dict: Dict[str, List[str]], threshold: float = 0.95
) -> List[List[ParsedMetadata]]:
    """
    Consolidate bounding boxes by removing the overlapping bounding boxes of the same class,
    according to the interclass consolidation dictionary.
    """

    non_overlap_bboxes: List[List[ParsedMetadata]] = []
    for page_bboxes in unioned_bboxes:
        page_bboxes = removing_overlapping_dict(page_bboxes, intra_consol_dict, threshold=threshold)
        non_overlap_bboxes.append(page_bboxes)
    return non_overlap_bboxes


def removing_overlapping_dict(
    bboxes: List[ParsedMetadata], consolidation: Mapping[str, Sequence[str]], threshold: float
) -> List[ParsedMetadata]:
    """
    Consolidate bounding boxes by removing the overlapping bounding boxes of the same class,
    according to the interclass consolidation dictionary.

    Args:
        bboxes: The list of bounding boxes.
        consolidation: The interclass consolidation dictionary.
        threshold: The threshold for merging the bounding boxes.

    Returns:
        The consolidated bounding boxes.
    """

    reverse_mapping = {}

    def set_if_not_exists(key: Hashable, value: str) -> None:
        if key not in reverse_mapping:
            reverse_mapping[key] = value

    for class_key, class_val in consolidation.items():
        for meta_class in class_val:
            set_if_not_exists(meta_class, meta_class)
            set_if_not_exists(meta_class, class_key)

    mapped_bboxes: List[ParsedMetadata] = []
    for parsed in bboxes:
        klass = parsed.klass
        mapped_bboxes.append(
            ParsedMetadata.flat_init(
                x_1=parsed.bbox.x_1,
                y_1=parsed.bbox.y_1,
                x_2=parsed.bbox.x_2,
                y_2=parsed.bbox.y_2,
                klass=reverse_mapping.get(klass, klass),
                score=parsed.score,
            )
        )

    # Group bounding boxes by class to perform merging.
    grouped = group_list_by(mapped_bboxes, key=lambda i: mapped_bboxes[i].klass)

    merged_bboxes: List[ParsedMetadata] = []
    for parsed in grouped.values():
        # Ensure that the bounding boxes are sorted by area, to remove the smaller ones first.
        parsed = sorted(parsed, key=lambda x: x.bbox.area)
        indices = dumb_merge([bbox.bbox for bbox in parsed], threshold=threshold)
        merged_bboxes.extend(parsed[i] for i in indices)

    return merged_bboxes


def dumb_merge(bbs: List[BoundingBox], threshold: float) -> Set[int]:
    """
    Merge bounding boxes by overlapping in a very dumb way,
    where every bounding box is of the same class.

    Args:
        bbs: The list of bounding boxes.
        threshold: The threshold for merging the bounding boxes.

    Returns:
        The indices of the bounding boxes to keep.
    """

    remove_idx = set()

    for i, j in itertools.combinations(range(len(bbs)), 2):
        assert i < j, "i should be less than j."

        smaller = bbs[i]
        larger = bbs[j]

        if smaller.intersection_over(larger, strategy="left") > threshold:
            remove_idx.add(i)

    return set(range(len(bbs))) - remove_idx


def order_by_column(
    doc_bboxes: List[List[ParsedMetadata]],
    doc_imgs: List[Image],
    find_page_sep: bool,
    grid_step: int,
    low_pass_filter: float,
    max_separators: int,
) -> List[List[ParsedMetadata]]:
    """
    Order bounding boxes by columns and their position, based on the page separators.

    Page separators are found by finding the vertical lines that separate the columns,
    then, the bounding boxes are sorted by columns, and then top to bottom.

    Parameters:
        doc_bboxes: The bounding boxes.
        doc_imgs: The images of the document.

    Returns:
        The ordered bounding boxes.
    """

    ordered_doc_bboxes: List[List[ParsedMetadata]] = []
    for parsed_list, document_image in zip(doc_bboxes, doc_imgs):
        # Bounding boxes that are important for the grid generation.
        bbox_list = [
            parsed.bbox for parsed in parsed_list if parsed.klass in ["Header", "Table", "Picture", "Text", "Formula"]
        ]

        page_separator_list = (
            page_sep_locs(
                bboxes=bbox_list,
                page_image_size=document_image.size,
                grid_step=grid_step,
                low_pass_filter=low_pass_filter,
                max_separators=max_separators,
            )
            if find_page_sep
            else []
        )

        page_separator_list = sorted(page_separator_list)
        pl_order_idx: List[Tuple[int, float, float, ParsedMetadata]] = []

        LOGGER.info("Page separators: %s (total=%d)", page_separator_list, len(page_separator_list))

        # Order blocks by their column index and then y position.
        for pl_idx in range(len(parsed_list)):
            parsed_item = parsed_list[pl_idx]

            idx = np.searchsorted(page_separator_list, parsed_item.x_1).item()
            top = parsed_item.y_1
            bottom = parsed_item.y_2

            pl_order_idx.append((idx, top, bottom, pl_idx))

        sorted_parsed_list = [parsed_list[pl_idx] for _, _, _, pl_idx in sorted(pl_order_idx)]
        ordered_doc_bboxes.append(sorted_parsed_list)

    return ordered_doc_bboxes


def page_sep_locs(
    bboxes: List[BoundingBox],
    page_image_size: Tuple[int, int],
    grid_step: int,
    low_pass_filter: float,
    max_separators: int,
) -> list[float]:
    """
    Find page separators locations based on the bounding boxes.

    Parameters:
        bboxes: List of bounding boxes.
        page_image_size: The size of the page image.

    Returns:
        List of page separators locations, in percentage of the page width.
    """

    page_width, _ = page_image_size

    # Get the bounding boxes that fall within the page boundaries.
    centre_boxes = [bbox for bbox in bboxes if bbox.x_1 < page_width and bbox.x_2 > 0]

    # Generate numpy grids for bounding box grid for easier locating of separators.
    box_grid = boxes_to_grid(
        bboxes=centre_boxes,
        page_image_size=page_image_size,
        grid_step=grid_step,
    )
    total_grid = box_grid.sum(1).astype(float)

    min_value, max_value = min(total_grid), max(total_grid)

    # No separators found.
    if max_value == 0:
        return []

    # Normalize the grid values and remove starting / ending zeros.
    grid_value_norm = (total_grid - min_value) / (max_value - min_value)

    if len(total_grid) <= 0.3 * page_width / grid_step:  # TODO: Expose as config
        LOGGER.warning("early stop")
        return []

    detected_separators = find_seperator_of_groups(grid_value_norm, low_pass_filter, grid_step, max_separators)
    return detected_separators


def boxes_to_grid(
    bboxes: List[BoundingBox],
    page_image_size: Tuple[int, int],
    grid_step: int,
    boundary_skips: Tuple[float, float] = (0, 0),
) -> NDArray:
    """
    Compute the grid

    Original [here](https://github.com/c3-e/c3generativeAi/blob/0d9b81a5b62a33db2edc065fe692acc388d42e38/genai/genAiBase/resource/code/parsing/parsers/layout_parser.py#L305-L316)

    Consider the following bounding boxes.
    The original source code is simply looping over all grid points, all boxes,
    and +1 whenever a point is in box (on the x axis).
    This can be seen in the following picture.

    However, since box 1 = box 2 + box 3,
    The summarization can be achieved with numpy arrays and .sum(1), which is way faster.


    ```
    Box 1:
    +--------------------------+
    |                          |
    |        0                 |
    |    +-------------+       |
    |    |             |       |
    |    |   1         |       |
    |    |             |       |
    |    |     +-------+----+  |
    |    |     |       |    |  |
    |    |     |    2  |    |  |
    |    |     |       |    |  |
    |    |     |       |    |  |
    |    +-----+-------+    |  |
    |          |            |  |
    |          |    1       |  |
    |          |            |  |
    |          +------------+  |
    |                          |
    +--------------------------+
    Box 2:
    +--------------------------+
    |                          |
    |        0                 |
    |    +-------------+       |
    |    |             |       |
    |    |   1         |       |
    |    |             |       |
    |    |             |       |
    |    |             |       |
    |    |             |       |
    |    |             |       |
    |    |             |       |
    |    +-------------+       |
    |                          |
    |                          |
    |                          |
    |                          |
    |                          |
    +--------------------------+
    Box 3:
    +--------------------------+
    |                          |
    |        0                 |
    |                          |
    |                          |
    |                          |
    |                          |
    |          +------------+  |
    |          |            |  |
    |          |            |  |
    |          |            |  |
    |          |            |  |
    |          |            |  |
    |          |            |  |
    |          |    1       |  |
    |          |            |  |
    |          +------------+  |
    |                          |
    +--------------------------+
    ```
    """

    # Generate all grids in a numpy array of the same size.
    horiz_skip, vert_skip = boundary_skips
    page_width, page_height = page_image_size

    page_width_start = (page_width * horiz_skip // grid_step) * grid_step
    page_width_end = (page_width * (1 - horiz_skip) // grid_step) * grid_step
    page_height_start = (page_height * vert_skip // grid_step) * grid_step
    page_height_end = (page_height * (1 - vert_skip) // grid_step) * grid_step
    world = BoundingBox(x_1=page_width_start, x_2=page_width_end, y_1=page_height_start, y_2=page_height_end)

    grids = [bbox.numpy_grid(world, grid_step) for bbox in bboxes]
    return np.stack(grids).sum(axis=0)


def find_seperator_of_groups(
    grid_value_norm: List[float], lp_filter: float, grid_step: int, max_seps_allowed: int
) -> List[float]:
    """
    Find separators of groups based on the low pass filter (valleys) of the grid values.

    Parameters:
        grid_value_norm: The normalized grid values.
        lp_filter: The low pass filter threshold.
        grid_step: The step of the grid.
        max_seps_allowed: The maximum number of separators allowed.

    Returns:
        List of separators.
    """

    LOGGER.debug("Aggregated grid information accross axis=1: %s", grid_value_norm)

    # Find separators based on low pass filter.
    grid_tuple_low_freq = np.array([v < lp_filter for v in grid_value_norm]).astype("int").tolist()

    # Ensure that the first and last elements are 0.
    grid_tuple_low_freq = [0] + grid_tuple_low_freq + [0]

    # Find the boundaries of the low pass filters by indices.
    # Diff left indicates left boundary and would be 0 if the current value is 1 and the previous value is 0.
    # Diff right indicates right boundary and would be 0 if the current value is 1 and the next value is 0.
    diff_left = (np.diff(grid_tuple_low_freq) == 1).astype("int")
    diff_right = (np.diff(grid_tuple_low_freq) == -1).astype("int")

    # Find location of the boundary points.
    [grid_tuple_bnd_left] = np.where((np.array(diff_left.tolist() + [0]) == 1).astype("int"))
    [grid_tuple_bnd_right] = np.where((np.array([0] + diff_right.tolist()) == 1).astype("int"))

    assert len(grid_tuple_bnd_left) == len(grid_tuple_bnd_right)

    detected_separators: List[float] = []
    for l, r in zip(grid_tuple_bnd_left, grid_tuple_bnd_right):
        detected_separators.append((l + r).item() * grid_step / 2)

    if len(detected_separators) > max_seps_allowed:
        LOGGER.warning(f"Separator reached limit: {len(detected_separators)} > {max_seps_allowed}")
        return []

    return detected_separators
