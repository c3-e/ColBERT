# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import re
from dataclasses import dataclass
from typing import Dict, Generic, Iterable, Iterator, List, Sequence, TypeVar

import pandas as pd

from c3pdfparser.document import Document

from .bbox import BoundingBox


@dataclass(frozen=True)
class DocumentContext:
    """
    The document mixin class for the bounding box on a document.
    """

    ctx: "Document | None" = None
    """
    The document the bounding box belongs to, acting as a context for the bounding box.
    The document can be accessed through the `document` property.

    When context is not used, it can be set to `None` (not set).
    However, it must be set before use.

    The reason it was designed as this is because I don't want to touch the test cases as of now,
    therefore, a `None` default value is used.
    """

    @property
    def document(self) -> Document:
        if self.ctx is None:
            raise ValueError("Document context is not set.")
        return self.ctx


_T = TypeVar("_T", pd.Series, pd.DataFrame)


@dataclass(frozen=True)
class PandasData(Generic[_T]):
    """
    The data mixin class for the bounding box on a document.
    """

    data: _T
    """
    The underlying data of the bounding box on a document.
    """


@dataclass(frozen=True)
class ParsedMetadata(DocumentContext, PandasData[pd.Series]):
    """
    Represents a bounding box as well as other metadata.
    This is the output of the layout parser,
    and supports various operations used on bounding boxes.

    TODO:
        Allow cropping to be performed on this object.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    """

    def __post_init__(self):
        if not isinstance(self.data, pd.Series):
            raise ValueError(f"Expected a Series, got {self.data}")

        if list(self.data.index) != ["x_1", "y_1", "x_2", "y_2", "klass", "score"]:
            raise ValueError(f"Expected Series to have index 'x_1', 'y_1', 'x_2', 'y_2', 'klass', 'score'")

    def __str__(self) -> str:
        return f"({self.bbox.x_1}, {self.bbox.y_1}, {self.bbox.x_2}, {self.bbox.y_2}, {self.klass}, {self.score})"

    def __iter__(self) -> Iterator[float]:
        return iter(self.bbox)

    def __len__(self):
        return 4

    def __getitem__(self, index: int):
        return self.data.iloc[index]

    @property
    def bbox(self) -> BoundingBox:
        """
        Bounding box of the parsed metadata.
        This is in the raw scale of the document.

        NOTE:
            This should be done in a batch to leverage pandas' vectorised operations.

        Returns:
            The bounding box.
        """

        return BoundingBox(x_1=self.data["x_1"], y_1=self.data["y_1"], x_2=self.data["x_2"], y_2=self.data["y_2"])

    @property
    def klass(self) -> str:
        return self.data["klass"]

    @property
    def score(self) -> float:
        return self.data["score"]

    @property
    def document(self) -> Document:
        if self.ctx is None:
            raise ValueError("Document context is not set.")
        return self.ctx

    @classmethod
    def canon_init(
        cls, bbox: BoundingBox, klass: str = "", score: float = 0.0, document: "Document | None" = None
    ) -> ParsedMetadata:
        """
        The most common way to create a ParsedMetadata instance (for testing purposes).
        """

        return cls(
            data=pd.Series(
                [bbox.x_1, bbox.y_1, bbox.x_2, bbox.y_2, klass, score],
                index=["x_1", "y_1", "x_2", "y_2", "klass", "score"],
            ),
            ctx=document,
        )

    @classmethod
    def flat_init(
        cls,
        x_1: float,
        y_1: float,
        x_2: float,
        y_2: float,
        klass: str = "",
        score: float = 0.0,
        document: Document | None = None,
    ) -> ParsedMetadata:
        """
        An alternative way to create a ParsedMetadata instance (for testing purposes).
        """

        return cls.canon_init(
            bbox=BoundingBox(x_1=x_1, y_1=y_1, x_2=x_2, y_2=y_2), klass=klass, score=score, document=document
        )


@dc.dataclass(frozen=True, eq=False)
class PageBboxes(DocumentContext, PandasData[pd.DataFrame]):
    """
    Represents the bounding boxes on a page.
    Conceptually, this is just a list of bounding boxes.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    """

    def __len__(self):
        return len(self.data.index)

    def filter_class(self, tag: List[str]):
        """
        Filters the bounding boxes by class.

        Args:
            tag: The class to filter by.

        Returns:
            The filtered bounding boxes.
        """

        return _filter_class(self, tag, self.ctx)

    def __post_init__(self):
        if not isinstance(self.data, pd.DataFrame):
            raise ValueError(f"Expected a DataFrame, got {type(self.data)=}")

        if list(self.data.columns) != ["x_1", "y_1", "x_2", "y_2", "klass", "score"]:
            raise ValueError(f"Expected DataFrame to have columns 'x_1', 'y_1', 'x_2', 'y_2', 'klass', 'score'")

    def __iter__(self) -> Iterator[ParsedMetadata]:
        for _, row in self.data.iterrows():
            yield ParsedMetadata(row, ctx=self.document)

    def __len__(self) -> int:
        return len(self.data.index)

    def __getitem__(self, index: int) -> ParsedMetadata:
        return ParsedMetadata(self.data.iloc[index], ctx=self.document)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PageBboxes):
            return self.data.equals(other.data)

        if isinstance(other, Sequence):
            return tuple(self) == tuple(other)

        return NotImplemented

    @classmethod
    def init(cls, sequence: List[ParsedMetadata], document: Document) -> PageBboxes:
        """
        Wraps a list of bounding boxes into a ListBoundingBox.

        Args:
            sequence: The list of bounding boxes.

        Returns:
            The wrapped list of bounding boxes.
        """

        return cls(data=pd.DataFrame([p.data for p in sequence]), ctx=document)


@dc.dataclass(frozen=True, eq=False)
class DocBboxes(DocumentContext, PandasData[pd.DataFrame]):
    """
    Represents the bounding boxes on a document. This class can be thought of as a `List[List[ParsedMetadata]]`.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    - page: The page number of the bounding box.

    Raises:
        ValueError: The document attribute must be provided, or this is raised.

    NOTE:
        Although this class is iterable, and can be thought of a list of list of bounding boxes,
        it is backed by a `pd.DataFrame`. This means that the underlying data is stored in a tabular format,
        and iteration is done by filtering the data by page number, and converting them to the respective objects.
        This is very slow compared to a list of list of bounding boxes, and should be avoided if possible.

        It is designed this way to ensure compatibility with the layout parser, which outputs data in this format,
        but would be changed in a future version to be more efficient.
    """

    def __len__(self) -> int:
        return len(self.document)

    def __getitem__(self, idx: int):
        return PageBboxes(self.data[self.data["page"] == idx].drop(columns="page"), ctx=self.document)

    def __post_init__(self):
        if not isinstance(self.data, pd.DataFrame):
            raise ValueError(f"Expected a DataFrame, got {type(self.data)=}")

        if list(self.data.columns) != ["x_1", "y_1", "x_2", "y_2", "klass", "score", "page"]:
            raise ValueError(f"Expected DataFrame to have columns 'x_1', 'y_1', 'x_2', 'y_2', 'klass', 'score', 'page'")

    def __eq__(self, other: object) -> bool:
        if isinstance(other, DocBboxes):
            return self.data.equals(other.data)

        if isinstance(other, Sequence):
            return list(self) == list(other)

        return NotImplemented

    def __iter__(self) -> Iterator[PageBboxes]:
        for idx in range(len(self)):
            yield self[idx]

    def to_list_of_list(self) -> List[List[ParsedMetadata]]:
        """
        Converts the bounding boxes into a list of list of bounding boxes.

        Returns:
            The list of list of bounding boxes.
        """

        return [[*p] for p in self]

    @property
    def classes(self) -> List[str]:
        """
        Returns the unique classes in the bounding boxes.

        Returns:
            The unique classes in the bounding boxes.
        """

        return self.data["klass"].unique().tolist()

    def map_class(self, mapping: Dict[str, str], /) -> DocBboxes:
        """
        Maps the classes in the bounding boxes.

        Args:
            mapping: The mapping of classes.

        Returns:
            The mapped bounding boxes.
        """

        if any(k not in mapping for k in self.classes):
            raise KeyError(f"Mapping does not contain all classes. Got {mapping.keys()}, expected {self.classes}")

        return type(self)(data=self.data.assign(klass=self.data["klass"].map(mapping)), ctx=self.ctx)

    def filter_class(self, tag: List[str], /) -> DocBboxes:
        """
        Filters the bounding boxes by class.

        Args:
            tag: The class to filter by.

        Returns:
            The filtered bounding boxes.
        """

        return _filter_class(self, tag, self.document)

    @classmethod
    def init(cls, sequence: Iterable[Iterable[ParsedMetadata]], document: Document) -> DocBboxes:
        """
        Wraps a list of bounding boxes into a ListBoundingBox.

        Args:
            sequence: The list of bounding boxes.
            document: The document the bounding boxes belong to.

        Raises:
            ValueError: If the number of pages does not match the document.

        Returns:
            The wrapped list of bounding boxes.
        """

        seq = [[*p] for p in sequence]

        if len(seq) != len(document):
            raise ValueError(
                f"Number of pages does not match the document. Got {len(seq)} pages, expected {len(document)}"
            )

        # Page number as a new column.
        list_of_pages = [PageBboxes.init(s, document) for s in seq]
        df = pd.concat([page.data.assign(page=page_num) for page_num, page in enumerate(list_of_pages)])

        return cls(df, document)


_C = TypeVar("_C", PageBboxes, DocBboxes)


def _filter_class(self: _C, tag: List[str], document: "Document | None") -> _C:
    series = [self.data["klass"].str.match(t, re.IGNORECASE) for t in tag]
    mask = pd.concat(series, axis=1).any(axis=1)
    return type(self)(self.data[mask], document)
