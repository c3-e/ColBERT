# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import collections
import itertools
from typing import List, Literal, TypedDict

from c3pdfparser.document import Document
from c3pdfparser.layout.parsed import DocBboxes, PageBboxes, ParsedMetadata

DEBUG: bool = False
"""
Whether to debug the layout. This is always False unless someone sets it to True.
"""


def lets_debug() -> None:
    """
    Set the debug flag to True.
    """

    global DEBUG
    DEBUG = True


class LayoutDebugInfo(TypedDict):
    document: Document
    """
    The document to debug.
    """

    bounding_boxes: List[List[ParsedMetadata]]
    """
    The bounding boxes to debug.
    """


def type_of_script() -> Literal["jupyter", "ipython", "terminal"]:
    """
    Code adapted from [here](https://stackoverflow.com/questions/47211324/check-if-module-is-running-in-jupyter-or-not)
    """

    try:
        ipy_str = str(type(get_ipython()))  # type: ignore
        if "zmqshell" in ipy_str:
            return "jupyter"
        if "terminal" in ipy_str:
            return "ipython"
    except NameError:
        return "terminal"


def debug_layout(document: Document, bounding_boxes: "List[List[ParsedMetadata]] | DocBboxes", title: str) -> None:
    """
    Debug the layout of the document.

    Args:
        debugger: The debugger object.
        title: The title of the document.
    """

    if not DEBUG:
        return

    if type_of_script() != "jupyter":
        return

    import matplotlib.pyplot as plt
    import seaborn as sns
    from matplotlib.patches import Patch

    sns.set_theme()

    palette = sns.color_palette("Paired", 8)

    counter = itertools.count()
    color_map = collections.defaultdict(lambda: palette[next(counter) % len(palette)])

    # Plot the bounding boxes on the page, overlayed on the image, with the label, subtle.
    def plot_page(bboxes: PageBboxes, img):
        _, ax = plt.subplots()
        ax.imshow(img)

        for bbox in bboxes:
            # Detectron's output is normalised, but we need to scale it back to the original image size.
            x0, y0, x1, y1 = bbox.bbox * document.rel_scale
            color = color_map[bbox.klass]  # Get color based on class
            rect = plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color)
            ax.add_patch(rect)
            ax.text(x0, y0, str(float(bbox.score)), color=color, fontsize=12)  # Set fontsize to 8 for smaller labels

        plt.axis("off")  # Optional: Turn off axis
        plt.title(title)
        plt.legend(
            handles=[Patch(facecolor=color_map[klass], label=klass) for klass in color_map.keys()], prop={"size": 12}
        )
        plt.show()

    def plot_multi_page(bboxes_list: DocBboxes, imgs):
        for bboxes, img in zip(bboxes_list, imgs):
            plot_page(bboxes, img)

    plot_multi_page(bounding_boxes, document.pillows())
