# Ditod package

This entire package is copied over from [this location](https://github.com/AlibabaResearch/AdvancedLiterateMachinery/tree/main/DocumentUnderstanding/VGT/object_detection/ditod) with minor changes because the original was a little bit bug prone.
