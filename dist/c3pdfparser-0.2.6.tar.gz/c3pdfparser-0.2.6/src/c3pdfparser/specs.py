# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# Confidential and Proprietary C3 Materials.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import inspect
import re
from abc import ABC, ABCMeta
from functools import cache
from typing import Callable, Dict, Generic, Tuple, Type, TypeVar

from c3pdfparser.public import stable


@cache
def _pascal_case_regex():
    return re.compile(r"^[A-Z]+[a-z]*(?:\d*(?:[A-Z]+[a-z]*)?)*$")


@cache
def _camel_boundary_regex():
    # Copied from https://stackoverflow.com/a/1176023/1332401
    return re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def pascal_to_upper_snake(name: str) -> str:
    """
    Convert a camel case string to an upper snake case string.

    Parameters:
        name: The camel case string to convert.

    Returns:
        The upper snake case string.

    Raises:
        ValueError: If the name is not in PascalCase format
    """

    if not _pascal_case_regex().match(name):
        raise ValueError(f"{name} is not in PascalCase format!")

    name = _camel_boundary_regex().sub("_", name)
    return name.upper()


@stable()
class Spec(ABC):
    """
    The base class for all specifications.
    """

    def __init__(self) -> None:
        super().__init__()

        if not dc.is_dataclass(self):
            raise ValueError("Spec classes must be dataclasses.")


_Spec = TypeVar("_Spec", bound=Spec, covariant=True)


@stable()
class WithSpec(Generic[_Spec], ABC):
    """
    A mixin class that provides a spec attribute to objects that subclass it.

    Instantiate the object that subclasses this mixin with a spec attribute.
    The spec attribute is readonly (private and property).
    """

    def __init__(self, spec: _Spec, /, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        self.__spec = spec

    @property
    def spec(self) -> _Spec:
        """
        The getter for spec attribute.
        This is used as a readonly attribute for all the subclasses.

        Subclasses must inherit `WithSpec` to have this attribute with the proper type hints.
        """
        return self.__spec


@stable()
def specify(base_spec_class: Type[_Spec], /):
    """
    A decorator that automatically modifies a class to accept a specification in its constructor,
    along with a factory method for creating instances of the class with the specified name.
    This decorator is intended solely for use with abstract classes.

    Every specified class accompanies a `Spec` dataclass that defines the specification for the class.

    After `specify` is applied to a class, the class will have a `spec` attribute that is initialized with the given specification.

    Subclasses should inherit from the decorated class and put a `spec_class` attribute in the class definition,
    which should be a subclass of the `base_spec_class` given in the decorator.

    See examples below for more details.

    Examples:
        >>> @dc.dataclass
        ... class FooSpec:
        ...     a: int = 10

        >>> @specify(FooSpec)
        ... class Foo:
        ...     pass

        >>> Foo(FooSpec()).spec
        FooSpec(a=10)

        Subclasses of the decorated class (`Foo` in the example above) should put a `spec_class` attribute
        in the class definition, which should be a subclass of the `base_spec_class`
        given in the decorator. The decorator ensures that the spec class is a subclass of the base spec class.

        >>> @dc.dataclass
        ... class BarSpec(FooSpec):
        ...     b: float = 666.666

        >>> class Bar(Foo, spec_class=BarSpec):
        ...     pass

        >>> Bar(BarSpec(a=20, b=30.0)).spec
        BarSpec(a=20, b=30.0)

        After decorating the class, the class will have a `factory` method
        that can be used to create instances of the class,
        and a `registered_classes` method that returns a list of available class names.

        >>> Foo.factory("BAR", a=20, b=22.2).spec
        BarSpec(a=20, b=22.2)

        >>> Foo.registered_classes()
        ['BAR']

        If we want to register more classes, we can do so by subclassing the `Foo` class in the same way.

        >>> @dc.dataclass
        ... class BazSpec(BarSpec):
        ...     c: str = "baz"

        >>> class Baz(Foo, spec_class=BazSpec):
        ...     pass

        >>> Foo.registered_classes()
        ['BAR', 'BAZ']

        >>> Foo.factory("BAZ", a=20, b=22.2, c="hello").spec
        BazSpec(a=20, b=22.2, c='hello')

    Parameters:
        base_spec_class: The base specification class for the class to decorate.

    Returns:
        A decorator that decorates the class with its specification class.

    Raises:
        TypeError: If the class is not abstract.
        KeyError: If the class with the same name is already registered.

    Todo:
        Perhaps allow use of ``specify`` on objects, not just classes.
    """

    # The states for this decorator are stored in the closure.
    registry_for_class: Dict[str, Tuple[Type[_Spec], Type[WithSpec[_Spec]]]] = {}

    def decorator(base_class: Type[_Spec], /):
        # The base class must be abstract to use the `specify` method.
        if not isinstance(base_class, ABCMeta):
            raise TypeError(
                f"{base_class} is not abstract! "
                "You cannot use the `specify` method on a class that does not define subclasses."
            )

        # NOTE:
        # Mix `WithSpec` last in case `base_class` has a `spec` attribute.
        class _SubClass(base_class, WithSpec[_Spec]):
            @classmethod
            def __init_subclass__(
                cls, spec_class: type[_Spec], name_rewrite: Callable[[str], str] = pascal_to_upper_snake
            ) -> None:
                """
                The `__init_subclass__` method is called when the class is subclassed.
                Here, it registers the subclass with the factory method,
                with keys being computed from the class name.

                Parameters:
                    spec_class: The specification class for the subclass.
                    name_rewrite:
                        The function to rewrite the name of the subclass.
                        By default, it converts the name from PascalCase to UPPER_SNAKE_CASE.
                """

                # The given spec class should be a subclass of the base spec class.
                if not issubclass(spec_class, base_spec_class):
                    raise TypeError(f"{spec_class} should be a subclass of {base_spec_class}")

                # The spec class should be a dataclass.
                if not dc.is_dataclass(spec_class):
                    raise ValueError("Spec classes must be dataclasses.")

                if not callable(name_rewrite):
                    raise TypeError(f"{name_rewrite} should be a callable function.")

                # If the class has name `PascalCase`, the registered name would be `PASCAL_CASE`.
                # If the same name already exists in the registry, raise a `KeyError`.
                if (reg_name := name_rewrite(cls.__name__)) in registry_for_class:
                    spec, klass = registry_for_class[reg_name]
                    raise KeyError(
                        " ".join(
                            [
                                f"Class with name {reg_name} already registered!",
                                f"Existing spec found at {inspect.getfile(spec)}.",
                                f"Existing class found at {inspect.getfile(klass)}.",
                            ]
                        )
                    )

                registry_for_class[reg_name] = spec_class, cls

            @staticmethod
            def factory(name: "str | None" = None, **kwargs) -> Type:
                """
                Factory method to create instances of the class with the given name.
                The name always would be in UPPER_SNAKE_CASE format, corresponding to the class name `UpperSnakeCase` originally.

                Parameters:
                    name: The name of the class to create an instance of.
                    **kwargs: The keyword arguments to pass to the class constructor

                Returns:
                    An instance of the class with the given name.
                """

                spec, klass = registry_for_class[name]
                return klass(spec(**kwargs))

            @staticmethod
            def registered_classes():
                """
                Examples:
                    >>> Foo.registered_classes()
                    ['BAR', 'BAZ']

                Returns:
                    A list of available class names registered with the factory method.
                """

                return list(registry_for_class.keys())

        # Copy the docstring from the base class to the subclass.
        _SubClass.__name__ = base_class.__name__
        _SubClass.__doc__ = base_class.__doc__
        return _SubClass

    return decorator
