# Copyright 2009-2023 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from io import StringIO
from typing import List

from c3pdfparser import ComponentParserOutputItem


class LinearTextVisual:
    def __init__(self) -> None:
        pass

    def render(self, output: List[ComponentParserOutputItem]) -> None:
        output = sorted(output, key=lambda x: (x["page"], x["x_1"], x["y_1"]), reverse=True)

        string_builder = StringIO()
        for out in output:
            print(out["description_for_vectorstore"], file=string_builder)
        value = string_builder.getvalue()

        return _Renderer(value)


@dc.dataclass(repr=False)
class _Renderer:
    value: str

    def __repr__(self):
        return self.value

    def _repr_html_(self) -> str:
        return f"""
<script src="https://google.github.io/typograms/typograms.js"></script>
<script type="text/typogram">
{self.value}
</script>
"""
