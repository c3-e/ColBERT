# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import warnings
from abc import ABC
from typing import Dict, Generic, Iterable, Sequence, Sized, TypeVar, no_type_check

import pandas as pd

from pdfparser.document import Document

from .bbox import BoundingBox, ParsedMetadata
from .graphrame import Graphrame
from .unique_ids import NotUniqueError, UniqueIds

CTX = TypeVar("CTX", bound=Sized)
T = TypeVar("T")

__all__ = ["DocBboxes", "PageBboxesView", "ParsedView"]


def _get_col(name: str):
    def _get(self: DocBboxes):
        return self.data.df[name]

    return _get


def _set_col(name: str):
    def _set(self: DocBboxes, value):
        self.data.df[name] = value

    return _set


@dc.dataclass(frozen=True)
class Context(Generic[CTX], ABC):
    """
    The document mixin class for the bounding box on a document.

    Note:
        This class is made mutable because I'm lazy.

        A better, read-only design is to use 2 separate classes (e.g. for parsed metadata),
        one for initialization, and one for viewing.

        With a mutable context, the parsed metadata class acts as 2 classes in one.
    """

    def __post_init__(self):
        if self.idx_in_ctx >= len(self.ctx):
            raise ValueError(
                f"The idx_in_ctx ({self.idx_in_ctx}) attribute must be less than the length of the context ({len(self.ctx)})."
            )

    ctx: CTX
    """
    The document the document bounding box belongs to,
    the document bounding box the page bounding box belongs to,
    or the page bounding box the parsed metadata belongs to.

    In short, the context of the current object.
    """

    idx_in_ctx: int
    """
    The index of the current object in the context.

    ``self.ctx[self.idx_in_ctx] == self``
    """


@dc.dataclass(frozen=True)
class ParsedView(Context["PageBboxesView"]):
    """
    A view object that is compatible with ``ParsedMetadata``.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    - page: The page number of the bounding box.
    """

    def __post_init__(self):
        super().__post_init__()

        if not isinstance(self.ctx, PageBboxesView):
            raise ValueError("The ctx attribute must be a PageBboxesView object.")

        for name in ["x_1", "y_1", "x_2", "y_2", "klass", "score"]:
            if name not in self._core.columns:
                raise ValueError(f"The data must have a '{name}' column. Got: {self._core.columns}")

        if self.width < 0 or self.height < 0:
            raise ValueError("The bounding box cannot have negative width or height.")

        if self.x_1 < 0 or self.y_1 < 0:
            warnings.warn("The bounding box cannot have negative x or y coordinates.", UserWarning)

    @property
    def x_1(self) -> float:
        return float(self._core.loc["x_1", self.idx_in_ctx])

    @property
    def y_1(self) -> float:
        return float(self._core.loc["y_1", self.idx_in_ctx])

    @property
    def x_2(self) -> float:
        return float(self._core.loc["x_2", self.idx_in_ctx])

    @property
    def y_2(self) -> float:
        return float(self._core.loc["y_2", self.idx_in_ctx])

    @property
    def width(self) -> float:
        return self.x_2 - self.x_1

    @property
    def height(self) -> float:
        return self.y_2 - self.y_1

    @property
    def font_size(self):
        warnings.warn("The font_size attribute is not available for bounding boxes.", FutureWarning)
        return self._core["font_size"]

    @property
    def klass(self) -> str:
        return str(self._core.loc["klass", self.idx_in_ctx])

    @property
    def score(self) -> float:
        return float(self._core.loc["score", self.idx_in_ctx])

    @property
    def bbox(self):
        return BoundingBox(self.x_1, self.y_1, self.x_2, self.y_2)

    norm_bbox = bbox

    @property
    def scaled_bbox(self):
        return self.bbox * self.document.rel_scale

    @property
    def unique_id(self):
        return self.ctx.unique_ids[self.idx_in_ctx]

    @property
    def page(self):
        return self.ctx.idx_in_ctx

    @property
    def _core(self):
        return self.ctx.get()

    @property
    def uid(self):
        return self.unique_id

    @property
    def document(self):
        return self.ctx.ctx.document

    @no_type_check
    def __eq__(self, other: object) -> bool:
        if hasattr(other, "unique_id"):
            return self.unique_id == other.unique_id

        try:
            return (
                True
                and self.x_1 == other.x_1
                and self.y_1 == other.y_1
                and self.x_2 == other.x_2
                and self.y_2 == other.y_2
                and self.klass == other.klass
                and self.score == other.score
                and self.page == other.page
            )
        except AttributeError:
            return NotImplemented

    def detach(self):
        return ParsedMetadata.flat_init(
            x_1=self.x_1, y_1=self.y_1, x_2=self.x_2, y_2=self.y_2, klass=self.klass, score=self.score
        )


@dc.dataclass(frozen=True)
class PageBboxesView(Context["DocBboxes"]):
    """
    Represents the bounding boxes on a page.
    Conceptually, this is just a list of bounding boxes.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    - parent: The parent id (union head) of the bounding box.
    """

    def __len__(self):
        return len(self.on_page())

    def __getitem__(self, idx: int) -> ParsedView:
        return ParsedView(ctx=self, idx_in_ctx=idx)

    def __iter__(self):
        for idx in range(len(self)):
            yield self[idx]

    @property
    def unique_ids(self):
        page_matches = self.on_page()
        return UniqueIds(self.ctx.skeleton.ids[page_matches])

    def on_page(self):
        return self.ctx.data.idx_where("page", lambda page: page == self.idx_in_ctx)

    def get(self):
        page_matches = self.on_page()
        return self.ctx.skeleton.query(page_matches)


@dc.dataclass
class DocBboxes:
    """
    Represents the bounding boxes on a document. This class can be thought of as a `List[List[ParsedView]]`.

    Data must have the following keys:

    - x_1: The minimum x-coordinate of the bounding box.
    - y_1: The minimum y-coordinate of the bounding box.
    - x_2: The maximum x-coordinate of the bounding box.
    - y_2: The maximum y-coordinate of the bounding box.
    - klass: The class of the bounding box.
    - score: The score of the bounding box.
    - page: The page number of the bounding box. Note that this is indexed from 0.

    NOTE:
        Although this class is iterable, and can be thought of a list of list of bounding boxes,
        it is backed by a `pd.DataFrame` (now `Graphrame`).
        This means that the underlying data is stored in a tabular format,
        and iteration is done by filtering the data by page number,
        and converting them to the respective objects.

        This is very slow compared to a list of list of bounding boxes, and should be avoided if possible.

        It is designed this way to ensure compatibility with the layout parser, which outputs data in this format.

        If list access is accessed commonly, consider converting the data to a list of lists using the `to_list_of_list` method.
    """

    skeleton: Graphrame
    """
    The underlying data of the bounding box on a document.
    """

    document: Document
    """
    The document the bounding boxes belong to.
    """

    @property
    def data(self):
        return self.skeleton

    @property
    def unique_ids(self) -> UniqueIds:
        return self.skeleton.ids

    x_1 = property(_get_col("x_1"), _set_col("x_1"))
    y_1 = property(_get_col("y_1"), _set_col("y_1"))
    x_2 = property(_get_col("x_2"), _set_col("x_2"))
    y_2 = property(_get_col("y_2"), _set_col("y_2"))
    klasses = property(_get_col("klass"))

    @property
    def width(self):
        return self.x_2 - self.x_1

    @property
    def height(self):
        return self.y_2 - self.y_1

    @property
    def font_size(self):
        warnings.warn("The font_size attribute is not available for bounding boxes.", FutureWarning)
        return self.height

    def __getitem__(self, idx: int) -> PageBboxesView:
        return PageBboxesView(ctx=self, idx_in_ctx=idx)

    def __len__(self):
        return len(self.document)

    def __post_init__(self):
        if not isinstance(self.document, Document):
            raise ValueError("The document attribute must be provided.")

        if not isinstance(self.skeleton, Graphrame):
            raise ValueError("The attrs attribute must be provided.")

        unique_pages = self.data["page"].unique().tolist()

        if set(unique_pages).difference(range(len(self.document))):
            raise ValueError("The page numbers must be in the range of the document.")

    def __eq__(self, other: object) -> bool:
        if isinstance(other, DocBboxes):
            return self.document == other.document and self.skeleton == other.skeleton

        return NotImplemented

    def __iter__(self):
        for idx in range(len(self)):
            yield self[idx]

    @property
    def num_bboxes(self):
        return len(self.data)

    @property
    def pages(self):
        return self.data["page"]

    def filter_class(self, *tags: str):
        select = self.data.idx_where("klass", lambda klass: klass in tags)
        return dc.replace(self, skeleton=self.skeleton.query(select))

    def map_class(self, **mapping: str):
        skeleton = self.skeleton.clone()

        if set(self.classes).difference(mapping.keys()):
            raise KeyError("The classes must be in the mapping.")

        skeleton["klass"] = skeleton["klass"].map(mapping)
        return dc.replace(self, skeleton=skeleton)

    def validate_classes(self, valid_classes: Sequence[str]):
        assert "klass" in self.data.columns, "The data must have a 'klass' column."
        return self.data["klass"].isin(valid_classes).all()

    def to_list_of_list(self):
        return tuple(tuple(bbox.detach() for bbox in page) for page in self)

    @property
    def classes(self):
        return sorted(self.data["klass"].unique().tolist())

    def columns(self, *columns: str):
        cols = list(columns)
        df = self.skeleton.df[cols]
        return type(self)(skeleton=Graphrame.from_pandas(df, ids=self.unique_ids), document=self.document)

    def with_column(self, name: str, value: Sequence[T]):
        if len(value) != len(self.skeleton.df):
            raise ValueError("The length of the value must match the length of the bounding boxes.")

        df = self.skeleton.df.copy()
        df[name] = value
        return type(self)(skeleton=Graphrame.from_pandas(df, ids=self.unique_ids), document=self.document)

    @classmethod
    def init(cls, sequence: Iterable[Iterable[ParsedMetadata]], document: Document) -> DocBboxes:
        """
        Initialize a ``LayoutParserOutput`` with the given sequence.

        Args:
            sequence: The sequence of bounding boxes.
            document: The document the bounding boxes belong to.

        Returns:
            A ``LayoutParserOutput`` object.

        Raises:
            ValueError: If the document is invalid (not a ``Document``).
        """

        if not isinstance(document, Document):
            raise ValueError("The document attribute must be provided.")

        seq_of_seq = [list(seq) for seq in sequence]

        # Convert the sequence to the standardised format.
        df_seq = []
        for page_num, page_bboxes in enumerate(seq_of_seq):
            df = pd.DataFrame.from_records(
                [
                    {
                        "x_1": box.x_1,
                        "y_1": box.y_1,
                        "x_2": box.x_2,
                        "y_2": box.y_2,
                        "klass": box.klass,
                        "score": box.score,
                        "page": page_num,
                    }
                    for box in page_bboxes
                ]
            )

            df_seq.append(df)

        # Concatenate the dataframes to form a single graph.
        dfs = pd.concat(df_seq)
        try:
            skeleton = Graphrame.from_pandas(dfs)
        except NotUniqueError as ue:
            raise NotUniqueError("The sequence cannot contain identical bounding boxes.") from ue

        return cls(skeleton=skeleton, document=document)

    @classmethod
    def init_with_mapping(cls, bbox: DocBboxes, mapping: Dict[str, str] | None = None) -> DocBboxes:
        """
        Initialize a ``LayoutParserOutput`` with the given mapping.

        Args:
            bbox: The bounding boxes.
            mapping: The mapping of class names to class types.

        Returns:
            A ``LayoutParserOutput`` object.

        Raises:
            ValueError: If the classes are invalid (not in the mapping).
        """

        if not mapping:
            return cls(skeleton=bbox.skeleton, document=bbox.document)

        # Convert the class names to the standardised class types.
        bbox = bbox.map_class(**mapping)
        result = cls(skeleton=bbox.skeleton, document=bbox.document)
        valid_classes = list(set(mapping.values()))
        result.validate_classes(valid_classes)
        return result

    @property
    def rels(self):
        return self.data.rels

    def to_records(self):
        return self.data.to_records()

    @classmethod
    def union(cls, *dbb: DocBboxes) -> DocBboxes:
        """
        Union the bounding boxes of multiple documents.

        Args:
            *dbb: The documents to union.

        Returns:
            A ``DocBboxes`` object.
        """

        if not dbb:
            raise ValueError("At least one document must be provided.")

        if len(set(d.document for d in dbb)) > 1:
            raise ValueError("All documents must be the same.")

        ids = UniqueIds([uid for d in dbb for uid in d.unique_ids])

        dfs = [d.skeleton.df for d in dbb]
        skeleton = Graphrame.from_pandas(pd.concat(dfs), ids=ids)
        return cls(skeleton=skeleton, document=dbb[0].document)

    def clone(self):
        return dc.replace(self, skeleton=self.skeleton.clone())

    def _repr_html_(self):
        # For jupyter viewing
        return self.data._repr_html_()
