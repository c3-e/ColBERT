# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


from __future__ import annotations

import math
import operator
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Literal, Tuple

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class BoundingBox:
    """
    Represents a bounding box with page coordinates.
    This is the output of the layout parser,
    and supports various operations used on bounding boxes.

    NOTE:
        Bounding boxes are always normalised to the scale of the document.

    NOTE:
        While `x_1` and `x_2` are intuitive, the y-axis is flipped in the document.

            (x_1, y_1)-----------------------------+
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                |                                  |
                +-----------------------------(x_2, y_2)
    """

    x_1: float
    """The minimum x-coordinate of the bounding box."""

    y_1: float
    """The minimum y-coordinate of the bounding box."""

    x_2: float
    """The maximum x-coordinate of the bounding box."""

    y_2: float
    """The maximum y-coordinate of the bounding box."""

    def __post_init__(self):
        if not self.valid():
            raise ValueError(f"Invalid bounding box: {self}")

        if self.x_1 < 0 or self.y_1 < 0 or self.x_2 < 0 or self.y_2 < 0:
            raise ValueError(f"Negative coordinates: {self}")

        if self.x_1 > self.x_2 or self.y_1 > self.y_2:
            raise ValueError(f"Invalid bounding box: {self}")

    def __contains__(self, point: Tuple[float, float]) -> bool:  # type: ignore
        return self.contains_point(point)

    def __iter__(self) -> Iterable[float]:
        return iter((self.x_1, self.y_1, self.x_2, self.y_2))

    def __mul__(self, factor: float) -> BoundingBox:
        return self.__arith(factor, operator.mul)

    def __truediv__(self, factor: float) -> BoundingBox:
        return self.__arith(factor, operator.truediv)

    def __arith(self, factor: float, __op: Callable[[float], float], /) -> BoundingBox:
        return BoundingBox(
            x_1=__op(self.x_1, factor),
            y_1=__op(self.y_1, factor),
            x_2=__op(self.x_2, factor),
            y_2=__op(self.y_2, factor),
        )

    def grow(self, pixels: float) -> BoundingBox:
        x_1 = max(0, self.x_1 - pixels)
        y_1 = max(0, self.y_1 - pixels)
        x_2 = self.x_2 + pixels
        y_2 = self.y_2 + pixels

        return BoundingBox(x_1=x_1, y_1=y_1, x_2=x_2, y_2=y_2)

    def rescale(self, rel_scale: float) -> BoundingBox:
        """
        Rescale the bounding box to the document size.

        Args:
            rel_scale: The relative scale to rescale the bounding box.

        Returns:
            The rescaled bounding box.
        """

        return self / rel_scale

    def overlaps(self, other: BoundingBox) -> bool:
        """
        Check if two bounding boxes overlap.

        Args:
            other: The other bounding box.

        Returns:
            True if the bounding boxes overlap, False otherwise.
        """

        return self.intersection_over(other, strategy="union") > 0

    def merge(self, other: BoundingBox, /, *, strategy: Literal["union", "intersection"]) -> BoundingBox:
        """
        Merge two bounding boxes and create a new bounding box, based on the strategy.

        Args:
            other: The other bounding box.
            strategy:
                The strategy to use for the merging.
                Supported strategies are "union" and "intersection".

        Returns:
            The merged bounding box.
        """

        if strategy == "union":
            l = min(self.x_1, other.x_1)
            b = min(self.y_1, other.y_1)
            r = max(self.x_2, other.x_2)
            t = max(self.y_2, other.y_2)
            return BoundingBox(x_1=l, y_1=b, x_2=r, y_2=t)

        if strategy == "intersection":
            l = max(self.x_1, other.x_1)
            b = max(self.y_1, other.y_1)
            r = min(self.x_2, other.x_2)
            t = min(self.y_2, other.y_2)
            return BoundingBox(x_1=l, y_1=b, x_2=r, y_2=t)

        raise ValueError(f"Invalid strategy: {strategy}")

    def intersection_over(self, other: BoundingBox, /, *, strategy: Literal["union", "left", "right"]) -> float:
        """
        Calculate the intersection over union or left side of two bounding boxes.

        Args:
            other: The other bounding box.
            strategy:
                The strategy to use for the calculation.
                Supported strategies are "union", "left", "right".
                If strategy is "union", the intersection over union (IoU) is calculated.
                If strategy is "left", the intersection over self (IoS) is calculated.
                If strategy is "right", the intersection over self (IoS) is calculated with bbox2 as the denominator.

        Returns:
            The intersection over union or intersection over self value.
        """

        if strategy == "right":
            return other.intersection_over(self, strategy="left")

        assert strategy in ["union", "left"]

        try:
            inter_bbox = self.merge(other, strategy="intersection")
        except ValueError:
            # Since intersection is empty, always return 0.
            return 0

        assert inter_bbox.area <= self.area, f"Invalid intersection area: {inter_bbox.area}, {self.area}"

        if strategy == "union":
            # Compute the area of intersection rectangle as well as the ground truth.
            # Compute the area of both the prediction and ground-truth rectangles
            inter_area = inter_bbox.area
            box_1_area = self.area
            box_2_area = other.area if strategy == "union" else 0

            # Compute the intersection over union by taking the intersection
            # area and dividing it by the sum of prediction + ground-truth
            # areas - the interesection area
            result = inter_area / (box_1_area + box_2_area - inter_area)
            assert 0 <= result <= 1, f"Invalid IoU value: {result}"
            return result

        if strategy == "left":
            inter_area = inter_bbox.area
            box_1_area = self.area
            result = inter_area / box_1_area
            assert 0 <= result <= 1, f"Invalid IoS value: {result}"
            return result

        raise ValueError(f"Invalid strategy: {strategy}")

    def within(self, other: BoundingBox, threshold: float = 0.95) -> bool:  # bbox1 within bbox2
        """
        Class method to determine if one bounding box (bbox1) is within another bounding box (bbox2)
        based on a threshold.
        Args:
            other: The other bounding box.
            threshold: The threshold for the intersection over self (IoS) value. Default is 0.95.

        Returns:
            True if bbox1 is within bbox2 based on the threshold, False otherwise.
        """

        return self.intersection_over(other, strategy="left") > threshold

    def contains_point(self, point: Tuple[float, float]) -> bool:
        """
        Class method to determine if a point is within a bounding box.

        Args:
            point: The point to check.

        Returns:
            True if the point is within the bounding box, False otherwise.
        """
        x, y = point

        return (self.x_1 <= x <= self.x_2) and (self.y_1 <= y <= self.y_2)

    def numpy_grid(self, world: BoundingBox, grid_step: int) -> NDArray:
        """
        Create a numpy grid of the bounding box, with the given world and grid step.
        Inside the grid, points falling within the bounding box are marked as 1, and points outside are marked as 0.

        The grid lines are aligned with the world boundaries, with endpoints at the grid points.
        Therefore, there would be (world.width // grid_step + 1) grid lines in the x-direction,
        and (world.height // grid_step + 1) grid lines in the y-direction.

        Args:
            world: The world bounding box.
            grid_step: The grid step.

        Returns:
            The grid of size (world.width // grid_step + 1, world.height // grid_step +) with the bounding box marked.
        """

        x_grids = np.linspace(world.x_1, world.x_2, int(world.width // grid_step) + 1)
        y_grids = np.linspace(world.y_1, world.y_2, int(world.height // grid_step) + 1)

        x_grids_include = np.logical_and(x_grids >= self.x_1, x_grids <= self.x_2)
        y_grids_include = np.logical_and(y_grids >= self.y_1, y_grids <= self.y_2)

        # Only choose the intersection.
        grid = x_grids_include[:, None] * y_grids_include[None, :]
        return grid.astype("int")

    @property
    def corners(self) -> Tuple[float, float, float, float]:
        return self.x_1, self.y_1, self.x_2, self.y_2

    @property
    def xywh(self) -> Tuple[float, float, float, float]:
        return self.x_1, self.y_1, self.width, self.height

    @property
    def area(self) -> float:
        return self.width * self.height

    @property
    def width(self):
        return self.x_2 - self.x_1

    @property
    def height(self):
        return self.y_2 - self.y_1

    def valid(self) -> bool:
        return (
            True
            and not math.isnan(self.x_1)
            and not math.isnan(self.y_1)
            and not math.isnan(self.x_2)
            and not math.isnan(self.y_2)
            and self.x_1 < self.x_2
            and self.y_1 < self.y_2
            and 0 <= self.x_1
            and 0 <= self.y_1
        )

    @classmethod
    def from_bbox_like(cls, bbox_like: Any) -> BoundingBox:
        """
        Create a bounding box from a bounding box-like object.

        Args:
            bbox_like: The bounding box-like object.

        Returns:
            The bounding box.
        """

        try:
            return cls(
                x_1=bbox_like.x_1,
                y_1=bbox_like.y_1,
                x_2=bbox_like.x_2,
                y_2=bbox_like.y_2,
            )
        except AttributeError:
            pass

        try:
            if len(bbox_like) == 4:
                return cls(
                    x_1=bbox_like[0],
                    y_1=bbox_like[1],
                    x_2=bbox_like[2],
                    y_2=bbox_like[3],
                )
        except TypeError:
            pass

        raise ValueError(f"Invalid bounding box-like object: {bbox_like}")


@dataclass(frozen=True)
class ParsedMetadata:
    """
    Represents a bounding box as well as other metadata.
    This is the output of the layout parser,
    and supports various operations used on bounding boxes.
    """

    x_1: float
    """
    The minimum x-coordinate of the bounding box.
    """

    y_1: float
    """
    The minimum y-coordinate of the bounding box.
    """

    x_2: float
    """
    The maximum x-coordinate of the bounding box.
    """

    y_2: float
    """
    The maximum y-coordinate of the bounding box.
    """

    klass: str = ""
    """
    The class of the bounding box.
    """

    score: float = 0.0
    """
    The score of the bounding box.
    """

    def __iter__(self):
        return iter([self.x_1, self.y_1, self.x_2, self.y_2])

    @property
    def bbox(self) -> BoundingBox:
        """
        Bounding box of the parsed metadata.
        This is in the raw scale of the document.

        Returns:
            The bounding box.
        """

        return BoundingBox(x_1=self.x_1, y_1=self.y_1, x_2=self.x_2, y_2=self.y_2)

    norm_bbox = bbox

    @classmethod
    def canon_init(
        cls,
        bbox: BoundingBox,
        klass: str = "",
        score: float = 0.0,
    ) -> ParsedMetadata:
        """
        The most common way to create a ParsedMetadata instance (for testing purposes).
        """

        return cls(bbox.x_1, bbox.y_1, bbox.x_2, bbox.y_2, klass, score)

    @classmethod
    def flat_init(
        cls,
        x_1: float,
        y_1: float,
        x_2: float,
        y_2: float,
        klass: str = "",
        score: float = 0.0,
    ) -> ParsedMetadata:
        """
        An alternative way to create a ParsedMetadata instance (for testing purposes).
        """

        return cls(x_1, y_1, x_2, y_2, klass, score)
