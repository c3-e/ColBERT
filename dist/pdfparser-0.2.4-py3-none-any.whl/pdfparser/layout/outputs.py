# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from typing import Literal, get_args

DocLayNetClass = Literal[
    "Caption",
    "Footnote",
    "Formula",
    "List-item",
    "Page-footer",
    "Page-header",
    "Picture",
    "Section-header",
    "Table",
    "Text",
    "Title",
]
"""
The output classes of the doclaynet dataset, and all the models trained on it.

These classes are used to classify the bounding boxes in the layout of a document.

The ordering is quite important as it is used to map the output of the model to the labels.
"""

DOCLAYNET_LABELS = get_args(DocLayNetClass)
assert len(DOCLAYNET_LABELS) == 11, "DocLayNetClass should have 11 classes"

MarkdownClass = Literal["HEADER", "PLAIN", "LIST", "TABLE", "FIGURE", "IDK"]
"""
Type alias for the enum class for bounding box classes.

The goal of the pdf parser is to be able to strip out unnecessary information,
and reconstruct the document in a clean format.

As of now, we would like to support classes supported by markdown format,
such as headers, plain text, lists, tables, figures, etc.
"""
MARKDOWN_LABELS = get_args(MarkdownClass)
