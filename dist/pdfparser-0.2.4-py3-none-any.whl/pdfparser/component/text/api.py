# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from functools import cached_property
from typing import Any, Dict, List, Sequence

from pdfparser.layout import LayoutParserOutput

from ..api import Component, ComponentParser, ComponentParserOutputItem, ComponentParserSpec


@dc.dataclass(frozen=True)
class TextParserSpec(ComponentParserSpec):
    ext_typ: str = "DEFAULT"
    chunk_typ: str = "LONG_CHAIN"
    ext_kwargs: Dict[str, Any] = dc.field(default_factory=dict)
    chunk_kwargs: Dict[str, Any] = dc.field(default_factory=dict)


@dc.dataclass(frozen=True)
class RawTextComponent(Component):
    """
    The base text component class.
    """

    text: str
    """
    The text content of the component.
    """

    @property
    def description_for_vectorstore(self) -> str:
        """
        Currently, the text itself is used as the description for the vectorstore.
        However, this is by no means a good solution, but this is the one base uses.

        TODO:
            Break the chunked texts into different components and use them as descriptions.
        """
        return self.text


@dc.dataclass(frozen=True)
class ChunkedTextComponent(RawTextComponent, ComponentParserOutputItem):
    """
    The class for a text passage in a document, chunked into smaller pieces.
    """

    chunked: Sequence[str] = ()
    """
    The text of the passage, chunked into smaller pieces.
    This is useful for chunking text into smaller pieces for different purposes.
    """


class TextParser(ComponentParser[TextParserSpec, ChunkedTextComponent], spec_class=TextParserSpec):
    """
    The overall flow for parsing text components is as follows:

    1. Extract text from the document using the extractor.
    2. Chunk the extracted text using the chunker.

    The extractor and chunker are specified in the spec.
    """

    CONTEXTUAL = "HEADER", "PLAIN", "LIST"
    PARSE = CONTEXTUAL

    def __init__(self, spec: TextParserSpec):
        super().__init__(spec)

    def parse(self, bounding_boxes: LayoutParserOutput) -> List[ChunkedTextComponent]:
        extracted = self.extractor(bounding_boxes)
        return [ChunkedTextComponent(**vars(e), chunked=self.chunker(e.text)) for e in extracted]

    @cached_property
    def extractor(self):
        """
        Lazy initialization of the extractor.
        """

        from .extract import TextExtractor

        return TextExtractor.factory(self.spec.ext_typ, **self.spec.ext_kwargs)

    @cached_property
    def chunker(self):
        """
        Lazy initialization of the chunker.
        """

        from ..chunker import TextChunker

        return TextChunker.factory(self.spec.chunk_typ, **self.spec.chunk_kwargs)
