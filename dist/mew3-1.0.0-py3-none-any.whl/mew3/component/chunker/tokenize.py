# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from dataclasses import dataclass
from functools import cached_property
from typing import List

from .api import TextChunker, TextChunkerSpec


@dataclass(frozen=True)
class TokenizerSpec(TextChunkerSpec):
    """
    The text chunker spec class.
    """

    tokenizer_name: str = "bert-base-uncased"


class Tokenizer(TextChunker, spec_class=TokenizerSpec):
    """
    Text chunker written by Long Chen.
    This chunker uses the NLTK sentence tokenizer to split text into chunks while respecting sentence boundaries.
    """

    def chunk(self, text: str) -> List[str]:
        """
        Chunks text while respecting sentence boundaries.
        Args:
            text: text to chunk.
        Returns:
            Split text chunks.
        """

        tokenized = self.pretrained_tokenizer.tokenize(text)

        length = self.spec.split_length

        return [" ".join(tokenized[i : i + length]) for i in range(0, len(tokenized), length)]

    @cached_property
    def pretrained_tokenizer(self):
        from transformers import AutoTokenizer

        return AutoTokenizer.from_pretrained(self.spec.tokenizer_name)
