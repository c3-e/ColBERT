# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import io
import json
from typing import List

import numpy as np
from numpy.typing import NDArray
import pandas as pd
import pdfplumber
from PIL import Image

from mew3.core import BoundingBox, DocBboxes
from mew3.ctx import c3_ctx, c3_not_set
from mew3.decltype import LayoutExec


@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", "+csv"])
def csv_extract(bboxes: DocBboxes) -> DocBboxes:
    """
    Extract the CSV data from the tables in the PDF.

    Warning:
        The document must be a PDF for this to work.
        In the future, use `csv_extract_default` instead.
    """

    import camelot

    doc = bboxes.document

    records = bboxes.to_records(with_ids=True)
    bbxs: List[BoundingBox] = [BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in records]
    pages: List[int] = bboxes["page"].to_numpy().tolist()
    box_types = [b["markdown_class"] for b in records]

    all_csv = []
    for idx, (b, p) in enumerate(zip(bbxs, pages)):
        if box_types[idx] == "TABLE":
            with pdfplumber.open(doc.filename) as pdf:
                curr_page = pdf.pages[p]  # zero-based index
                page_width = curr_page.width
                page_height = curr_page.height

            margin = 5
            converted_bbox = [  # x1, y1 (top-left), x2, y2 (bottom-right)
                max(0, b.x_1 - margin),  # x1 (Left boundary)
                min(page_height, page_height - b.y_1 + margin),  # y1 (Top boundary)
                min(page_width, b.x_2 + margin),  # x2 (Right boundary)
                max(0, page_height - b.y_2 - margin),  # y2 (Bottom boundary)
            ]

            area = ",".join([str(int(i)) for i in converted_bbox])

            try:
                tmp = camelot.read_pdf(
                    doc.filename, pages=str(p + 1), table_areas=[area], flavor="stream", row_tol=10  # 1-based index
                )

                _get_df_from_camelot(tmp, all_csv)

            except:
                all_csv.append("[]")
        else:
            all_csv.append("[]")

    bboxes["csv"] = all_csv
    return bboxes


@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", "+csv"])
def csv_extract_default(bboxes: DocBboxes) -> DocBboxes:
    """
    An improved version of `csv_extract` that uses the default table extraction method.
    Does not require the document to be a PDF (depends on croppers on `PageDoc`).
    """

    records = bboxes.to_records(with_ids=True)
    bbxs: List[BoundingBox] = [BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in records]
    pages: List[int] = bboxes["page"].to_numpy().tolist()
    box_types = [b["markdown_class"] for b in records]

    all_csv = []
    for idx, (b, p) in enumerate(zip(bbxs, pages)):
        if box_types[idx] == "TABLE":
            result = bboxes.document.pages[p].crop_text(b)
            all_csv.append(result)
        else:
            all_csv.append("[]")

    bboxes["csv"] = all_csv
    return bboxes


def _get_df_from_camelot(tmp, all_csv):
    if tmp.n > 0:
        curr_df = tmp[0].df
        curr_df = curr_df.fillna("")
        json_data = json.dumps(curr_df.to_dict(orient="records"))
        all_csv.append(json_data)
    else:
        all_csv.append("[]")


@LayoutExec.register(delta_columns=[".csv"])
def save_csv_c3(bboxes: DocBboxes) -> DocBboxes:
    """
    Save the CSV data to C3 FileSystem, and save the handle to the file in the `csv_url_c3` column.

    Note:
        If not running under a C3 environment, this function does nothing.
    """

    if c3_not_set():
        return bboxes

    records = bboxes.to_records()
    ids = [r["__id__"] for r in bboxes.to_records(with_ids=True)]
    fname = bboxes.document.filename.split("/")[-1].split(".pdf")[0]

    all_urls = []
    for i, r in enumerate(records):
        if "csv" in r.keys() and r["csv"] != "[]":
            retrieved_json = json.loads(r["csv"])
            df_recovered = pd.DataFrame(retrieved_json)
            buffer = io.StringIO()
            df_recovered.to_csv(buffer, index=False, encoding="utf-8") # NOTE: fix encoding
            buffer.seek(0)

            remote_csv_path = f"mew3_parsed/csv/{fname}/page_{r['page']}_gidx_{r['global_idx']}_id_{ids[i]}.csv"
            c3_ctx().FileSystem.uploadFile(srcFile=buffer, dstPath=remote_csv_path)
            buffer.close()

            all_urls.append(remote_csv_path)
        else:
            all_urls.append("")

    bboxes["csv_url_c3"] = all_urls

    return bboxes


@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", "+table_image"])
def table_image_extract(bboxes: DocBboxes) -> DocBboxes:
    """
    Ensure bboxes are filtered to ONLY contain TABLE class!
    """
    doc = bboxes.document

    bbxs: List[BoundingBox] = [
        BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in bboxes.to_records()
    ]
    pages: List[int] = bboxes["page"].to_numpy().tolist()
    imgs: List[NDArray] = [np.array(doc.pages[p].crop_image(b)) for b, p in zip(bbxs, pages)]

    bboxes["table_image"] = imgs
    return bboxes


@LayoutExec.register(delta_columns=[".x_1", ".x_2", ".y_1", ".y_2", ".page", ".table_image"])
def save_table_image_c3(bboxes: DocBboxes) -> DocBboxes:
    """
    Save the table images to C3 FileSystem, and save the handle to the file in the `table_image_url_c3` column.

    Note:
        If not running under a C3 environment, this function does nothing.
    """

    if c3_not_set():
        return bboxes

    doc = bboxes.document

    records = bboxes.to_records(with_ids=True)
    ids = [r["__id__"] for r in records]

    bbxs: List[BoundingBox] = [BoundingBox(x_1=b["x_1"], x_2=b["x_2"], y_1=b["y_1"], y_2=b["y_2"]) for b in records]
    pages: List[int] = bboxes["page"].to_numpy().tolist()

    table_image_urls = []
    for idx, (b, p) in enumerate(zip(bbxs, pages)):
        if records[idx]["markdown_class"] == "TABLE": # no need if Filter has been applied before in pipeline
            image = Image.fromarray(bboxes["table_image"][idx])
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            buffer.seek(0)

            remote_img_path = (
                f"mew3_parsed/table_images/{doc.fname.split('.')[0]}/"
                f"page_{p}_gidx_{records[idx]['global_idx']}_id_{ids[idx]}.png"
            )
            c3_ctx().FileSystem.uploadFile(srcFile=buffer, dstPath=remote_img_path)
            buffer.close()

            table_image_urls.append(remote_img_path)
        else:
            table_image_urls.append("")

    bboxes["table_image_url_c3"] = table_image_urls
    return bboxes
