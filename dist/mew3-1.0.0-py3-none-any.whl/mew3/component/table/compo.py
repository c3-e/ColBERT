# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import re
from dataclasses import dataclass

from ..api import Component

INLINE_MARKDONW_REGEX = re.compile("```(.+?)```", re.DOTALL)


@dataclass(frozen=True)
class TableTitledComponent(Component):
    title: str
    """
    The title of the table.
    """


@dataclass(frozen=True)
class TableContentComponent(TableTitledComponent):
    text: str
    """
    The verbalization of the table.
    """

    @property
    def description_for_vectorstore(self) -> str:
        return self.text

    @property
    def parser(self) -> str:
        return "TABLE"
