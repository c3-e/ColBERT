# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import dataclasses as dc
from typing import List, no_type_check

from mew3.providers import OpenaiProvider, vlm
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.layout import LayoutParserOutput

@dc.dataclass(frozen=True)
class TableVerbalSpec(LayoutExecSpec):

    max_tokens: int = 4096
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a good table verbalizer."
    """
    The system prompt to use for the API.
    """

    user_text_prompt: str = """
    Given the image of table, its title, and its parsed content (e.g. from pdfplumber or camelot), 
    come up with a brief descriptions of the table.
    Also give important values and keywords.

    Title: "{title}"

    Parsed content:

    "{text}"
    """

    """
    The user prompt to use for the table verbalization.
    """

    def delta_columns(self):
        return (".table_image", ".title", ".text", "+verbalization")


class TableVerbal(LayoutExec, spec_class=TableVerbalSpec):
    """
    A debug post-processor that plots the bounding boxes on the page.

    Note:
        Only works in Jupyter notebooks, and does nothing if not in a Jupyter notebook.
    """

    @no_type_check
    def execute(self, output: LayoutParserOutput) -> LayoutParserOutput:

        all_verbalization = []
        for box in output.to_records():
            curr_verbalization = self.verbalize_box(box)
            all_verbalization.append(curr_verbalization)

        output["verbalization"] = all_verbalization

        return output

    def verbalize_box(self, box: dict):

        img = box["table_image"]
        prompt = self.spec.user_text_prompt.format(
            title=box["title"],
            text=box["text"],
        )

        return self.vlm(prompt, img)

    @property
    def vlm(self):
        return vlm(
            OpenaiProvider(
                max_tokens=self.spec.max_tokens, system_prompt=self.spec.system_prompt
            )
        )
