# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod

from mew3.core import BoundingBox, DocBboxes
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.specs import factorize

from ..compo import RawImageComponent


@dc.dataclass(frozen=True)
class ImageVerbalSpec(LayoutExecSpec, ABC):
    def delta_columns(self):
        return ("+verbalization", ".image", ".caption", ".x_1", ".y_1", ".x_2", ".y_2")


@factorize(ImageVerbalSpec)
class ImageVerbal(LayoutExec, ABC, spec_class=ImageVerbalSpec):
    def execute(self, dbb: DocBboxes) -> DocBboxes:
        verbalized = [self._call(_pack_as_component(item)) for item in dbb.to_records()]
        dbb["verbalization"] = verbalized
        return dbb

    @abstractmethod
    def _call(self, image: dict) -> str:
        """
        Verbalize the image component.

        Args:
            image: The raw image component.

        Returns:
            The verbalization of the image.
        """


def _pack_as_component(item: dict):
    return RawImageComponent(
        page=item["page"],
        global_idx=item["global_idx"],
        bbox=BoundingBox(
            x_1=item["x_1"],
            y_1=item["y_1"],
            x_2=item["x_2"],
            y_2=item["y_2"],
        ),
        img=item["image"],
        text=item["caption"],
    )
