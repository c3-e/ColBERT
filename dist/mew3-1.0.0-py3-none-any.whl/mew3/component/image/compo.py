# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..api import Component, ComponentParserOutputItem


@dataclass(frozen=True)
class RawImageComponent(Component):
    """
    The class for an image in a document.
    This component is used as an intermediate result of the image parser,
    where captions are found but verbalization is not yet performed.
    """

    img: np.ndarray
    """
    The image array. Must be a 3D array.
    """

    text: str
    """
    The caption of the image.
    """

    def __post_init__(self):
        assert isinstance(self.img, np.ndarray), f"Image must be an numpy array, got {type(self.img)}"

    @property
    def parser(self) -> str:
        return "IMAGE"


@dataclass(frozen=True)
class VerbalImageComponent(RawImageComponent, ComponentParserOutputItem):
    verbalization: str
    """
    The verbalization of the image.
    """

    @property
    def description_for_vectorstore(self) -> str:
        return self.verbalization
