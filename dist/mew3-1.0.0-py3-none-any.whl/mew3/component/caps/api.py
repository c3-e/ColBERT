# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Sequence, get_args

from pandas import DataFrame

from mew3.core import DocBboxes
from mew3.decltype import LayoutExec, LayoutExecSpec
from mew3.document import PageDoc
from mew3.layout import MarkdownClass
from mew3.specs import factorize


@dataclass(frozen=True)
class CaptionFinderSpec(LayoutExecSpec, ABC):
    current_bbox_typ: Sequence[str] = get_args(MarkdownClass)
    """
    Type of the target bbox to perform caption/title search.
    For example, use ['TABLE'] if want to search for titles for tables.
    """


@factorize(CaptionFinderSpec)
class CaptionFinder(LayoutExec, ABC, spec_class=CaptionFinderSpec):
    """
    Given a document and their parsed layout,
    a CaptionFinder finds the captions for each image / table
    by locating a text bounding box near the image bounding box.
    I.E. recover the relationship between the image and its caption after being squashed into a linear array.
    """

    def execute(self, bounding_boxes: DocBboxes) -> DocBboxes:
        parsed = self._parse(
            document=bounding_boxes.document,
            bounding_boxes=bounding_boxes,
            current_bbox_typ=self.spec.current_bbox_typ,
        )
        df = collect_list_of_list(parsed)
        if not bounding_boxes["page"].tolist() == df["page"].tolist():
            raise ValueError(
                "The page numbers in the parsed data do not match the page numbers in the DataFrame. "
                f"Parsed data: {parsed}, DataFrame: {df}"
            )

        bounding_boxes["caption"] = list(df["caption"])
        return bounding_boxes

    @abstractmethod
    def _parse(self, document: PageDoc, bounding_boxes: DocBboxes, current_bbox_typ: Sequence[str]) -> List[List[str]]:
        """

        Parameters:
            document: The document.
            bounding_boxes: The parsed layout of the document.
            current_bbox_typ: The types of the current bounding box to search caption/titles for. Typically just one item.

        Returns:
            A list of lists of captions for each image, organised by page and then by image on each page.
        """


def collect_list_of_list(lol: List[List[str]]) -> DataFrame:
    """
    Collect a list of lists into a single list.
    """

    records = []

    for i, l in enumerate(lol):
        for j, item in enumerate(l):
            records.append({"page": i, "idx_on_page": j, "caption": item})

    return DataFrame.from_records(records, columns=["page", "idx_on_page", "caption"])
