# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Dict, List

from ..document import PageDoc

LOGGER = logging.getLogger(__name__)


@dataclass
class DocumentParserOutput:
    """
    The parser output class.

    This class represents the output of a parser. It contains the parsed document,
    a list of extracted components, and a parsing log.
    """

    document: PageDoc
    """
    The parsed document.
    """

    components: List[Dict[str, Any]]
    """
    The list of components extracted from the document.
    """


@dataclass(frozen=False)
class DocumentParser:
    """
    This class represents the main parser for enterprise search. It handles the parsing
    of documents using various parsing specifications and workflows. The parser supports
    different components such as image parsing and verbalization, and can be extended
    for additional parsing capabilities.

    Examples:
        ```python
        parser = DocumentParser(
            layout_parser_spec={},
            text_parser_spec={},
            text_chunker_spec={},
            image_parser_spec={},
        )
        ```
    """

    layout_parser_spec: Dict[str, Any]
    text_parser_spec: Dict[str, Any] | None = field(default_factory=dict)
    table_parser_spec: Dict[str, Any] | None = field(default_factory=dict)
    image_parser_spec: Dict[str, Any] | None = field(default_factory=dict)

    @cached_property
    def pipeline(self):
        from mew3.decltype import Chain, DuplicateAndMerge, Range

        parsers = {
            "text": self.text_parser,
            "table": self.table_parser,
            "image": self.image_parser,
        }

        parsers = {k: par for k, par in parsers.items() if par is not None}
        return Chain.initialize(
            [
                self.layout_parser,
                Range.initialize("global_idx"),
                DuplicateAndMerge.initialize(parsers),
            ]
        )

    @cached_property
    def layout_parser(self):
        from mew3.prelude import LayoutParserCfg, layout_parser_pipeline

        return layout_parser_pipeline(LayoutParserCfg(**self.layout_parser_spec))

    @cached_property
    def text_parser(self):
        from mew3.prelude import TextParserCfg, text_parser_pipeline

        if self.text_parser_spec is None:
            return None

        return text_parser_pipeline(TextParserCfg(**self.text_parser_spec))

    @cached_property
    def table_parser(self):
        from mew3.prelude import TableParserCfg, table_parser_pipeline

        if self.table_parser_spec is None:
            return None

        return table_parser_pipeline(TableParserCfg(**self.table_parser_spec))

    @cached_property
    def image_parser(self):
        from mew3.prelude import ImageParserCfg, image_parser_pipeline

        if self.image_parser_spec is None:
            return None

        return image_parser_pipeline(ImageParserCfg(**self.image_parser_spec))

    def __call__(self, document: PageDoc) -> DocumentParserOutput:
        """
        Parse the document using the specified parser inference settings.

        Args:
            document: The document to be parsed.
            page_chunks: The number of chunks to split the document into.
            do_table: Whether to perform table parsing.
            do_image: Whether to perform image parsing.
            do_text: Whether to perform text parsing.

        Returns:
            The result of parsing the document, including parsed components
                and any relevant logs generated during the parsing process.
        """

        return self.pipeline(document)
