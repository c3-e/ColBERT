# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import Any, Dict, List

import requests

from mew3 import settings


@dc.dataclass(frozen=True)
class OpenaiLikeLLM(ABC):
    """
    Spec for verbalizer that does nothing and returns an empty string.
    """

    max_tokens: int = 100
    """
    The maximum number of tokens to generate for the remote model.
    """

    system_prompt: str = "You are a table assistant."
    """
    The system prompt to use for the API.
    """

    @abstractmethod
    def call(self, message: List[Dict[str, Any]], /, **options):
        pass

    def __call__(self, messages: List[Dict[str, str | Dict]], /) -> str:
        """
        Call the OpenAI API with the given messages and return the response.

        Parameters:
            messages: The messages to send to the API.

        Returns:
            The response from the API.
        """

        for msg in messages:
            if not isinstance(msg, dict):
                raise TypeError(f"Message must be a dictionary. Got: {msg}")

            if "type" not in msg:
                raise ValueError("Message must have a 'type' field.")

        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": messages},
        ]

        return self.call(messages, max_tokens=self.max_tokens)["choices"][0]["message"]["content"]


@dc.dataclass(frozen=True)
class OpenaiProvider(OpenaiLikeLLM):
    """
    Spec for verbalizer that does nothing and returns an empty string.
    """

    @property
    def api_key(self) -> str:
        return settings.api_key

    @property
    def endpoint(self) -> str:
        return settings.endpoint

    def call(self, message: List[Dict[str, Any]], **options):
        headers = {"Content-Type": "application/json", "api-key": self.api_key}
        resp = requests.post(self.endpoint, headers=headers, json={"messages": message, **options})
        resp.raise_for_status()
        return resp.json()
