# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import os

from mew3.ctx import c3_ctx

from .litellm import ModelMixin
from .openai import OpenaiLikeLLM


@dc.dataclass(frozen=True)
class C3GenaiCoreLLM(OpenaiLikeLLM, ModelMixin):
    def __post_init__(self):
        openai_auth_dict = {
            "apiKey": os.environ["OPENAI_API_KEY"],
            "azureEndpoint": os.environ["OPENAI_ENDPOINT"],
        }

        openai_auth = c3_ctx().GenaiCore.Llm.AzureOpenAi.Auth(name="azure", **openai_auth_dict)
        openai_auth.setConfig()
        openai_auth.setSecret()

    def call(self, messages, **options):
        CompletionClient = c3_ctx().GenaiCore.Llm.Completion.Client
        AzureOpenAiModel = c3_ctx().GenaiCore.Llm.AzureOpenAi.Model
        client = CompletionClient(
            model=AzureOpenAiModel(
                model=self.model,
                auth=c3_ctx().GenaiCore.Llm.AzureOpenAi.Auth(name="azure"),
                defaultOptions={"temperature": 0},
            )
        )

        openai_response = client.completion(messages=messages, options=options)

        return openai_response
