# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
import logging
from abc import ABC
from typing import Any, Dict

from typing_extensions import Self

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.WARNING)


class Spec(ABC):
    """
    The base class for all specifications.
    """

    def __init__(self) -> None:
        super().__init__()

        if not dc.is_dataclass(self):
            raise ValueError("Spec classes must be dataclasses.")

    @classmethod
    def load_from_dict(cls, cfg: Dict[str, Any]) -> Self:
        result: Dict[str, Any] = {}
        for key in dc.fields(cls):
            try:
                result[key.name] = cfg[key.name]
            except KeyError as ke:
                raise ValueError(f"Missing key {key.name} in config") from ke
        return cls(**result)
