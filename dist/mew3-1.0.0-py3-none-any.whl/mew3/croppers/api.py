# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Generic, TypeVar

from PIL.Image import Image

from mew3.specs import Spec, factorize

if TYPE_CHECKING:
    from mew3.core import BoundingBox
    from mew3.decltype import LayoutProc
    from mew3.document import Content

T = TypeVar("T")


@dc.dataclass
class CropperSpec(Spec, ABC):
    pass


class Cropper(Generic[T], ABC):
    def as_proc(self, bbox: BoundingBox | None = None) -> LayoutProc:
        """
        Adaptor to convert the cropper API to the content processor API,
        to take advantage of the content processor API's `supports` method.

        Args:
            bbox:
                The bounding box to crop the content to.
                This is the same as in the `crop_bbox` method.

        Returns:
            The content processor.
        """
        from .proc import CropperAsProc

        return CropperAsProc.initialize(bbox=bbox, cropper=self)

    @abstractmethod
    def crop_bbox(self, content: Content, bbox: BoundingBox | None = None) -> T:
        """
        Crop the content to the bounding box.

        Args:
            content: The content to crop.
            bbox:
                The bounding box to crop the content to.
                If None, the entire content is cropped.
        """

    def supports(self):
        return NotImplemented


@dc.dataclass
class TableCropperSpec(CropperSpec):
    pass


@factorize(TableCropperSpec)
class TableCropper(Cropper[str]):
    pass


@dc.dataclass
class ImageCropperSpec(CropperSpec):
    dpi: int = 72
    """
    The DPI to use for VGT model.

    Note that the higher DPI will lead to higher latency, but not neccessarily better performance.
    """

    margins: float = 5
    """
    The padding to add to the bounding box before cropping the image,
    s.t there are some margins around the text.
    """


@factorize(ImageCropperSpec)
class ImageCropper(Cropper[Image]):
    @property
    def dpi(self) -> int:
        return self.spec.dpi


@dc.dataclass
class TextCropperSpec(CropperSpec):
    pass


@factorize(TextCropperSpec)
class TextCropper(Cropper[str]):
    pass
