# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

import base64
from io import BytesIO

from PIL import Image

from mew3.core import DocBboxes
from mew3.decltype import LayoutProd
from mew3.document import PageDoc


class _DoclingExtractor:
    def __init__(self, json_content):
        self.json_content = json_content
        self.texts = json_content["texts"]
        self.pictures = json_content["pictures"]
        self.tables = json_content["tables"]
        self.body = json_content["body"]
        self.combined_content = []

    def extract_texts(self):
        """Extract valid text content (non-empty)."""
        text_dict = {}
        for text_ref in self.body["children"]:
            if "$ref" in text_ref and text_ref["$ref"].startswith("#/texts/"):
                index = int(text_ref["$ref"].split("/")[2])  # Extract index of text
                text_item = self.texts[index]
                if text_item["text"].strip():  # Skip empty texts
                    text_dict[text_ref["$ref"]] = text_item["text"].strip()
        return text_dict

    def extract_pictures(self):
        """Extract picture objects and store them as Pillow images."""
        picture_dict = {}
        for pic_ref in self.body["children"]:
            if "$ref" in pic_ref and pic_ref["$ref"].startswith("#/pictures/"):
                index = int(pic_ref["$ref"].split("/")[2])  # Extract index of picture
                picture_item = self.pictures[index]
                image_data = picture_item["image"]["uri"]

                # Decode base64 image string
                image_data = image_data.split(",")[1]  # Remove the 'data:image/png;base64,' part
                image_bytes = base64.b64decode(image_data)
                image = Image.open(BytesIO(image_bytes))
                picture_dict[pic_ref["$ref"]] = image
        return picture_dict

    def extract_tables(self):
        """Extract table content dynamically for any table size."""
        table_dict = {}
        for table_ref in self.body["children"]:
            if "$ref" in table_ref and table_ref["$ref"].startswith("#/tables/"):
                index = int(table_ref["$ref"].split("/")[2])
                table_item = self.tables[index]
                table_data = table_item["data"]["table_cells"]

                # Dynamically organize table cells by row
                rows = {}
                for cell in table_data:
                    row_idx = cell["start_row_offset_idx"]  # Get the row index for this cell
                    col_idx = cell["start_col_offset_idx"]  # Get the column index for this cell

                    if row_idx not in rows:
                        rows[row_idx] = {}

                    rows[row_idx][col_idx] = cell["text"]  # Place the text content in the appropriate cell

                sorted_rows = []
                max_cols = max(len(row) for row in rows.values())
                for row_idx in sorted(rows.keys()):
                    row = [rows[row_idx].get(col_idx, "") for col_idx in range(max_cols)]
                    sorted_rows.append(row)

                table_dict[table_ref["$ref"]] = sorted_rows
        return table_dict

    def extract_content(self):
        """Run the extraction of texts, pictures, and tables."""
        text_dict = self.extract_texts()
        picture_dict = self.extract_pictures()
        table_dict = self.extract_tables()

        # Combine texts, pictures, and tables into the final list following the 'body' order
        for item in self.body["children"]:
            if "$ref" in item:
                ref = item["$ref"]
                if ref in text_dict:
                    self.combined_content.append({"type": "text", "content": text_dict[ref]})
                elif ref in picture_dict:
                    self.combined_content.append({"type": "picture", "content": picture_dict[ref]})
                elif ref in table_dict:
                    self.combined_content.append({"type": "table", "content": table_dict[ref]})

    def get_combined_content(self):
        """Return the final combined list with texts, pictures, and tables."""
        return self.combined_content


@LayoutProd.make(supports=["docx", "html"])
def docling(document: PageDoc) -> DocBboxes:
    try:
        from docling.document_converter import DocumentConverter
    except ImportError:
        raise ImportError("Please install the 'docling' package to use this layout.")

    source = document.fname

    converter = DocumentConverter()
    result = converter.convert(source)

    json_content = result.document.export_to_dict()

    extractor = _DoclingExtractor(json_content)
    extractor.extract_content()

    combined_content = extractor.get_combined_content()

    list_of_dicts = [{"type": item["type"], "content": item["content"]} for item in combined_content]

    return DocBboxes.dict_init([list_of_dicts], document=document)
