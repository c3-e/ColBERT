# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import dataclasses as dc
from functools import cached_property
from typing import TYPE_CHECKING, Any, Callable, TypeVar

from .api import LayoutExec, LayoutExecSpec

if TYPE_CHECKING:
    from mew3.core import DocBboxes

    D = TypeVar("D", bound=DocBboxes)


@dc.dataclass(frozen=True)
class AliasSpec(LayoutExecSpec):
    source: str
    target: str

    def delta_columns(self):
        return f"+{self.target}", f".{self.source}"


class Alias(LayoutExec, spec_class=AliasSpec):
    """
    Alias a column in the document bounding boxes.
    """

    def execute(self, dbb: D) -> D:
        dbb[self.spec.target] = dbb[self.spec.source]
        return dbb


@dc.dataclass(frozen=True)
class RenameSpec(LayoutExecSpec):
    source: str
    target: str

    def delta_columns(self):
        return f"-{self.source}", f"+{self.target}"


class Rename(LayoutExec, spec_class=RenameSpec):
    """
    Rename a column in the document bounding boxes.
    """

    def execute(self, dbb: D) -> D:
        dbb = self.alias(dbb)
        dbb = self.remove(dbb)
        return dbb

    @cached_property
    def alias(self):
        return Alias.initialize(source=self.spec.source, target=self.spec.target)

    @cached_property
    def remove(self):
        return Remove.initialize(column=self.spec.source)


@dc.dataclass(frozen=True)
class RemoveSpec(LayoutExecSpec):
    column: str

    def delta_columns(self):
        return (f"-{self.column}",)


class Remove(LayoutExec, spec_class=RemoveSpec):
    """
    Remove a column from the document bounding boxes.
    """

    def execute(self, dbb: D) -> D:
        del dbb[self.spec.column]
        return dbb


@dc.dataclass(frozen=True)
class FilterSpec(LayoutExecSpec):
    column: str
    function: Callable[[Any], bool]

    def delta_columns(self):
        return (f".{self.column}",)


class Filter(LayoutExec, spec_class=FilterSpec):
    """
    Filter the document bounding boxes based on the function applied to the column.
    """

    def execute(self, dbb: D) -> D:
        return dbb.filter(column=self.spec.column, func=self.spec.function)


@dc.dataclass(frozen=True)
class MarkSpec(LayoutExecSpec):
    column: str
    target: str
    function: Callable[[Any], bool]

    def delta_columns(self):
        return f".{self.column}", f"+{self.target}"


class Mark(LayoutExec, spec_class=MarkSpec):
    """
    Mark the target column based on the function applied to the source column.
    """

    def execute(self, dbb: D) -> D:
        return dbb.apply_to_column(source=self.spec.column, target=self.spec.target, mapping=self.spec.function)


@dc.dataclass(frozen=True)
class TagSpec(LayoutExecSpec):
    column: str
    tag: str

    def delta_columns(self):
        return (f"+{self.column}",)


class Tag(LayoutExec, spec_class=TagSpec):
    """
    Tag the column with a constant value
    """

    def execute(self, dbb: D) -> D:
        dbb[self.spec.column] = [self.spec.tag] * dbb.num_rows
        return dbb


@dc.dataclass(frozen=True)
class RangeSpec(LayoutExecSpec):
    column: str
    start: int = 0

    def delta_columns(self):
        return (f"+{self.column}",)


class Range(LayoutExec, spec_class=RangeSpec):
    """
    Add a column to the document bounding boxes with values from start to start+num_rows.
    """

    def execute(self, dbb: D) -> D:
        dbb[self.spec.column] = list(range(self.spec.start, dbb.num_rows + self.spec.start))
        return dbb
