# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.


HTML_CONTENT_STRING = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF Debugger</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            height: 100vh;
            width: 100vw;
        }
        body {
            display: flex;
            font-family: Arial, sans-serif;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
        }
        html, body {
            font-size: 14px !important;
        }

        #image-container, #json-container {
            height: 100%;
            overflow-y: auto;
            overflow-x: hidden;
        }
        #image-container {
            width: 60%;
            padding: 10px;
            background-color: #f5f5f5;
            transform-origin: top center;
        }
        .image-wrapper {
            position: relative;
            margin-bottom: 20px;
            transition: transform 0.2s ease;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .bounding-box {
            position: absolute;
            border: 2px solid transparent;
            background-color: transparent;
            cursor: pointer;
            z-index: 10;
        }
        .active-box {
            border: 2px solid red !important;
            background-color: rgba(255, 0, 0, 0.2) !important;
        }
        .image-content {
            position: relative;
            width: 100%;
            transition: transform 0.2s ease, margin-bottom 0.2s ease;
            display: flex;
            justify-content: center;
        }
        img {
            max-width: 100%;
            border: 1px solid #ddd;
            display: block;
            transform-origin: top center;
        }
        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .error {
            color: red;
            padding: 10px;
            border: 1px solid red;
            margin: 10px;
            background-color: #fff;
        }
        .loading {
            padding: 20px;
            text-align: center;
            color: #666;
        }
        .separator {
            color: #444444;
            font-weight: bold;
        }
        #json-container {
            width: 40%;
            padding: 10px;
            background-color: #ffffff;
            border-left: 2px solid #dddddd;
            font-family: monospace;
        }
        .json-entry {
            margin-bottom: 15px;
            padding: 5px;
            border: 2px solid transparent;
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .json-entry:hover:not(.highlighted-json) {
            background-color: #f9f9f9;
            border-color: #ddd;
        }
        .highlighted-json {
            border: 2px solid #FF8C00 !important;
            background-color: rgba(255, 140, 0, 0) !important;
        }
        #page-indicator {
            position: fixed;
            top: 10px;
            left: 10px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            z-index: 1000;
            font-family: monospace;
        }
        #sync-button {
            position: fixed;
            top: 10px;
            right: calc(40% + 25px);
            z-index: 1000;
            padding: 8px 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
        }
        #sync-button:hover {
            background-color: #0056b3;
        }
        #sync-button.active {
            background-color: #28a745;
        }
        #key-toggle-container {
            position: fixed;
            top: 90px;
            right: calc(40% + 25px);
            z-index: 1000;
            width: 220px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            max-height: 350px;
            overflow-y: auto;
            display: none;
        }
        #toggle-button {
            position: fixed;
            top: 50px;
            right: calc(40% + 25px);
            z-index: 1000;
            padding: 8px 12px;
            background-color:rgb(204, 159, 55);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
        }
        #toggle-button:hover {
            background-color: #5a6268;
        }
        #toggle-button.active {
            background-color: #5a6268;
        }
        .key-toggle-row {
            display: flex;
            align-items: center;
            margin: 4px 0;
        }
        .key-toggle-row label {
            margin-left: 8px;
            cursor: pointer;
            font-family: monospace;
            font-size: 12px;
        }
        .key-toggle-title {
            font-weight: bold;
            margin-bottom: 8px;
            border-bottom: 1px solid #eee;
            padding-bottom: 4px;
        }
        #feedback-button {
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1000;
            padding: 8px 12px;
            background-color: #6c757d;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
        }

        #feedback-button:hover {
            background-color: #5a6268;
        }

        #info-button {
            position: fixed;
            bottom: 60px;
            left: 20px;
            z-index: 1000;
            padding: 8px 12px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
        }

        #info-button:hover {
            background-color: #138496;
        }

        #info-button.active {
            background-color: #138496;
        }

        #download-button {
            position: fixed;
            bottom: 100px;
            left: 20px;
            z-index: 1000;
            padding: 8px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: all 0.2s ease;
            width: 38px;
            height: 38px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #download-button:hover {
            background-color: #218838;
        }
        
        #download-button svg {
            width: 22px;
            height: 22px;
        }

        #document-info-container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 2000;
            width: 70%;
            max-height: 80%;
            overflow-y: auto;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
            display: none;
        }

        #document-info-container pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            max-height: 500px;
            overflow-y: auto;
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
        }

        #document-info-container .close-button {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            background: none;
            border: none;
            font-size: 20px;
            color: #666666;
        }

        #document-info-container .close-button:hover {
            color: #333333;
        }

        pre {
            background: #ffffff;
            color: #222222;
            padding: 12px;
            border-radius: 6px;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: Consolas, Monaco, monospace;
            border: 1px transpranet;
            font-size: 14px;
            line-height: 1.5;
        }
        .json-key {
            font-family: Consolas, Menlo, Monaco, monospace !important;
            color: #0056b3;
            font-weight: 700 !important;
        }
        .json-string {
            color:rgb(51, 128, 0);
        }
        .json-number {
            color:rgb(230, 135, 20);
        }
        .json-boolean {
            color:rgb(233, 20, 105);
        }
        .json-null {
            color: #666666;
            font-style: italic;
        }

        #json-data, #document-info-container pre {
            font-size: 14px !important;
            line-height: 1.5 !important;
        }
        .json-key, .json-string, .json-number, .json-boolean, .json-null {
            font-size: 14px !important; 
        }
        #sync-button, #toggle-button, #feedback-button, #info-button, #download-button {
            font-size: 14px !important;
            padding: 8px 12px !important;
            height: auto !important;
            width: auto !important;
        }
        #page-indicator {
            font-size: 14px !important;
            padding: 5px 10px !important;
        }
        button, div, pre, span, label, .json-entry, #page-indicator, #json-data {
            font-size: 14px !important;
        }

    </style>
</head>
<body>
    <div id="image-container">
        <div class="loading">Loading PDF images...</div>
    </div>
    <div id="json-container">
        <h3>Bounding Boxes</h3>
        <pre id="json-data">Loading Genai.SourcePassages as JSON...</pre>
    </div>
    <button id="sync-button">Sync Scroll</button>
    <button id="toggle-button">Toggle Fields</button>
    <button id="feedback-button">Submit Feedback</button>
    <button id="info-button">Parsing Configs</button>
    <button id="download-button" title="Download HTML">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
    </button>
    <div id="key-toggle-container">
        <div class="key-toggle-title">Display Fields</div>
        <div id="key-toggles"></div>
    </div>
    <div id="document-info-container"></div>
    <script>
        {JS_SCRIPT}
    </script>
</body>
</html>
"""


JS_SCRIPT_STRING = """     
const bbox_data = {BBOX_DATA};
const image_base64 = {IMAGE_DATA};
const document_info = {DOCUMENT_INFO};
const display_url_prefix = "{DISPLAY_URL_PREFIX}";
const debugger_type = "{DEBUGGER}"

// Global state for sync scrolling
let syncScrollEnabled = false;
let currentHighlightedBoxIndex = -1;
let scrollTimeout = null;
let hiddenKeys = new Set();

// Main functionality
function initializeViewer(bboxData, imageBase64Array) {
    console.log("Initializing viewer with", bboxData.length, "bbox entries and", 
                imageBase64Array.length, "images");
    
    const imageContainer = document.getElementById('image-container');
    const jsonContainer = document.getElementById('json-data');
    
    // Ensure page indicator exists with proper styling
    updatePageIndicator(0);
    
    // Rest of the initialization code remains the same
    initializeKeyToggle(bboxData);
    jsonContainer.innerHTML = formatJSON(bboxData);
    setupJsonEntryListeners(bboxData);
    
    imageContainer.innerHTML = '';
    imageBase64Array.forEach((base64Str, fileIndex) => {
        const wrapper = createImageWrapper(base64Str, fileIndex, bboxData);
        imageContainer.appendChild(wrapper);
    });
    
    setupScrollHandler(imageContainer, imageContainer.getElementsByClassName('image-wrapper'));
    setupSyncScroll();
    setupToggleButton();
    
    if (bboxData.length > 0) {
        setTimeout(() => {
            highlightBox(0, true);
        }, 200);
    }
}

function initializeKeyToggle(bboxData) {
    if (bboxData.length === 0) return;
    
    // Get all unique keys from the data with SP keys first
    const keySet = new Set();
    const spKeys = [];
    const otherKeys = [];
    
    // Process all objects in a single loop
    bboxData.forEach(item => {
        Object.keys(item).forEach(key => {
            if (!keySet.has(key)) {
                keySet.add(key);
                if (key.startsWith("SP.")) {
                    spKeys.push(key);
                } else {
                    otherKeys.push(key);
                }
            }
        });
    });

    // Final key order: SP keys first, then other keys
    const allKeys = [...spKeys, ...otherKeys];

    // Define coordinate-related keys that should be hidden by default
    let defaultHiddenKeys = [];

    if (debugger_type === "c3") {
        defaultHiddenKeys = [
            '__id__', 'page', 'x_1', 'y_1', 'x_2', 'y_2',
            'scaled_x_1', 'scaled_y_1', 'scaled_x_2', 'scaled_y_2',
            'doc_width_px', 'doc_height_px',
            'global_idx', 'klass', 'score', 'to_parse',
            'verbalization', 'caption', 'title', 'header', 'text', 'chunked'
        ];
    } else if (debugger_type === "jupyter") {
        defaultHiddenKeys = [
            "csv",
            'x_1', 'y_1', 'x_2', 'y_2',
            'scaled_x_1', 'scaled_y_1', 'scaled_x_2', 'scaled_y_2',
            'doc_width_px', 'doc_height_px',
        ];
    }


    // Initialize hiddenKeys with the default hidden keys
    defaultHiddenKeys.forEach(key => {
        if (keySet.has(key)) {
            hiddenKeys.add(key);
        }
    });

    // Create toggle UI
    const toggleContainer = document.getElementById('key-toggles');
    toggleContainer.innerHTML = '';
    
    // Create checkbox for each key
    allKeys.forEach(key => {
        const row = document.createElement('div');
        row.className = 'key-toggle-row';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `toggle-${key}`;
        checkbox.checked = !hiddenKeys.has(key);
        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                hiddenKeys.delete(key);
            } else {
                hiddenKeys.add(key);
            }
            // Update JSON display
            document.getElementById('json-data').innerHTML = formatJSON(bboxData);
            setupJsonEntryListeners(bboxData);

            // Maintain the highlighted box
            if (currentHighlightedBoxIndex >= 0) {
                const jsonEntry = document.getElementById(`json-entry-${currentHighlightedBoxIndex}`);
                if (jsonEntry) {
                    jsonEntry.classList.add('highlighted-json');
                }
            }
        });
        
        const label = document.createElement('label');
        label.htmlFor = `toggle-${key}`;
        label.textContent = key;
        
        row.appendChild(checkbox);
        row.appendChild(label);
        toggleContainer.appendChild(row);
    });
}

function setupToggleButton() {
    const toggleButton = document.getElementById('toggle-button');
    const toggleContainer = document.getElementById('key-toggle-container');
    
    toggleButton.addEventListener('click', () => {
        if (toggleContainer.style.display === 'block') {
            toggleContainer.style.display = 'none';
            toggleButton.classList.remove('active');
        } else {
            toggleContainer.style.display = 'block';
            toggleButton.classList.add('active');
        }
    });
    
    // Close the toggle container when clicking outside of it
    document.addEventListener('click', (event) => {
        if (!toggleContainer.contains(event.target) && 
            event.target !== toggleButton) {
            toggleContainer.style.display = 'none';
            toggleButton.classList.remove('active');
        }
    });
}

function createImageWrapper(base64Str, fileIndex, data) {
    const wrapper = document.createElement('div');
    wrapper.classList.add('image-wrapper');
    
    const img = document.createElement('img');
    img.src = base64Str;
    img.alt = `Page ${fileIndex}`;
    img.style.width = "70%";
    
    img.onerror = () => {
        console.error(`Failed to load image for page ${fileIndex}`);
        img.alt = `Failed to load page ${fileIndex}`;
    };
    
    img.onload = () => {
        createOverlayBoxes(img, wrapper, data, fileIndex)();
    };
    
    wrapper.appendChild(img);
    return wrapper;
}

// UI styling
const styleElement = document.createElement('style');
styleElement.textContent = `
    /* All bounding boxes are invisible by default */
    .bounding-box {
        position: absolute;
        border: 2px solid transparent;
        background-color: transparent;
        cursor: pointer;
        z-index: 10;
    }
    
    /* Only active box is visible */
    .active-box {
        // border: 2px solid red !important;
        border: none !important;
        background-color: rgba(255, 0, 0, 0.2) !important;
        transition: all 0.2s ease;
    }
    
    /* Ensure json entries are properly positioned */
    .json-entry {
        position: relative;
        padding: 4px;
        border-radius: 3px;
        border: 2px solid transparent;
        margin-bottom: 8px;
        transition: all 0.2s ease;
    }
    
    /* Don't change orange highlight on hover */
    .highlighted-json {
        border: 2px solid #FF8C00 !important;
        background-color: rgba(255, 140, 0, 0) !important;
    }
    
    .json-entry:hover:not(.highlighted-json) {
        background-color: #f9f9f9;
        border-color: #ddd;
    }
`;
document.head.appendChild(styleElement);

function highlightBox(boxIndex, forceHighlight = false) {
    if (boxIndex === currentHighlightedBoxIndex && !forceHighlight) {
        return;
    }
    
    // Remove highlight from previously active box
    if (currentHighlightedBoxIndex >= 0) {
        const prevBox = document.querySelector(`[data-indices*="${currentHighlightedBoxIndex}"]`);
        if (prevBox) {
            prevBox.classList.remove('active-box');
        }
        
        const prevJsonEntry = document.getElementById(`json-entry-${currentHighlightedBoxIndex}`);
        if (prevJsonEntry) {
            prevJsonEntry.classList.remove('highlighted-json');
        }
    }
    
    // Highlight new active box
    const box = document.querySelector(`[data-indices*="${boxIndex}"]`);
    if (box) {
        box.classList.add('active-box');
        const jsonEntry = document.getElementById(`json-entry-${boxIndex}`);
        if (jsonEntry) {
            jsonEntry.classList.add('highlighted-json');
        }
        currentHighlightedBoxIndex = boxIndex;
    } else {
        console.log(`Box containing index ${boxIndex} not found yet`);
        if (forceHighlight) {
            setTimeout(() => {
                highlightBox(boxIndex, true);
            }, 100);
        }
    }
}

function ensureBoxVisible(boxId) {
    const box = document.getElementById(boxId);
    if (!box) return;
    
    const imageContainer = document.getElementById('image-container');
    const boxRect = box.getBoundingClientRect();
    const containerRect = imageContainer.getBoundingClientRect();
    
    // Check if box is fully visible in the container
    if (boxRect.top < containerRect.top || 
        boxRect.bottom > containerRect.bottom) {
        
        // Calculate how much additional scrolling is needed
        const centerOffset = boxRect.top - containerRect.top - 
                        (containerRect.height / 2) + (boxRect.height / 2);
        
        // Apply scrolling in a single smooth movement
        imageContainer.scrollBy({
            top: centerOffset,
            behavior: 'smooth'
        });
    }
}

function scrollToImage(pageIndex, boxId) {
    const imageContainer = document.getElementById('image-container');
    const imageWrappers = imageContainer.getElementsByClassName('image-wrapper');
    
    if (imageWrappers[pageIndex]) {
        const box = document.getElementById(boxId);
        if (!box) {
            // If there's no box, just scroll to the page
            imageWrappers[pageIndex].scrollIntoView({
                behavior: 'smooth', 
                block: 'start'
            });
            updatePageIndicator(pageIndex);
            return;
        }
        
        // Get the current page
        const currentPageIndicator = document.getElementById('page-indicator');
        const currentPage = parseInt(currentPageIndicator.textContent.replace('Page: ', ''));
        
        if (currentPage !== pageIndex) {
            // Need to switch pages - do this first
            imageWrappers[pageIndex].scrollIntoView({
                behavior: 'smooth', 
                block: 'start'
            });
            
            // After page change, ensure box is visible
            setTimeout(() => {
                ensureBoxVisible(boxId);
            }, 300);
        } else {
            // On the same page, just ensure the box is visible
            ensureBoxVisible(boxId);
        }
        
        updatePageIndicator(pageIndex);
    }
}

function setupJsonEntryListeners(data) {
    data.forEach((item, index) => {
        const jsonEntry = document.getElementById(`json-entry-${index}`);
        if (jsonEntry) {
            jsonEntry.addEventListener('click', () => {
                const pageIndex = parseInt(item.page);
                if (!isNaN(pageIndex)) {
                    scrollToImage(pageIndex, `box-${index}`);
                    highlightBox(index);
                }
            });
        }
    });
}

function updatePageIndicator(pageIndex) {
    let indicator = document.getElementById('page-indicator');
    if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'page-indicator';
        indicator.style.position = 'fixed';
        indicator.style.top = '10px';
        indicator.style.left = '10px';
        indicator.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        indicator.style.color = 'white';
        indicator.style.padding = '5px 10px';
        indicator.style.borderRadius = '4px';
        indicator.style.zIndex = '1000';
        indicator.style.fontFamily = 'monospace';
        document.body.appendChild(indicator);
    }
    indicator.textContent = `Page: ${pageIndex}`;
}


function setupScrollHandler(imageContainer, imageWrappers) {
    let ticking = false;

    imageContainer.addEventListener('scroll', () => {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                let maxVisibleArea = 0;
                let currentPageIndex = 0;

                Array.from(imageWrappers).forEach((wrapper, index) => {
                    const rect = wrapper.getBoundingClientRect();
                    const containerRect = imageContainer.getBoundingClientRect();
                    
                    // Calculate visible area more precisely
                    const visibleTop = Math.max(rect.top, containerRect.top);
                    const visibleBottom = Math.min(rect.bottom, containerRect.bottom);
                    const visibleHeight = Math.max(0, visibleBottom - visibleTop);

                    if (visibleHeight > maxVisibleArea) {
                        maxVisibleArea = visibleHeight;
                        currentPageIndex = index;
                    }
                });

                updatePageIndicator(currentPageIndex);
                ticking = false;
            });

            ticking = true;
        }
    });
}


// JSON formatting
const colorMapping = {
    "SP.pageNumber": ["rgba(0, 83, 140, 1)", "rgba(0, 83, 140, 1)"], 
    "SP.contentStr": ["rgba(0, 100, 0, 1)", "rgba(0, 100, 0, 1)"],
    "SP.caption": ["rgba(205, 133, 63, 1)", "rgba(205, 133, 63, 1)"],
    "SP.imageVerbalization": ["rgba(0, 139, 139, 1)", "rgba(0, 139, 139, 1)"],
    "SP.title": ["rgba(255, 140, 0, 1)", "rgba(255, 140, 0, 1)"],
    "SP.tableVerbalization": ["rgba(0, 139, 139, 1)", "rgba(0, 139, 139, 1)"],

    "page": ["rgba(0, 139, 139, 1)", "rgba(0, 139, 139, 1)"], 
    "klass": ["rgba(178, 34, 34, 1)", "rgba(178, 34, 34, 1)"],
    "markdown_class": ["rgba(178, 34, 34, 1)", "rgba(178, 34, 34, 1)"],
    "text": ["rgba(0, 100, 0, 1)", "rgba(0, 100, 0, 1)"],
    "verbalization": ["rgba(0, 100, 0, 1)", "rgba(0, 100, 0, 1)"],
    "title": ["rgba(255, 140, 0, 1)", "rgba(255, 140, 0, 1)"],
    "caption": ["rgba(205, 133, 63, 1)", "rgba(205, 133, 63, 1)"],
};

const defaultKeyColor = "rgba(128, 128, 128, 1)";  // gray
const defaultValueColor = "rgba(128, 128, 128, 1)"; // gray

function formatJSON(data) {
    let html = '';
    data.forEach((component, index) => {
        if (index > 0) {
            html += '<span class="separator">' + '-'.repeat(40) + '</span><br><br>';
        }
        html += `<div id="json-entry-${index}" class="json-entry" data-page="${component.page}">`;
        
        Object.entries(component).forEach(([key, value]) => {
            if (hiddenKeys.has(key)) {
                return;
            }
            
            const [keyColor, valueColor] = colorMapping[key] || [defaultKeyColor, defaultValueColor];
            let valueStr = String(value).replace(/\\n/g, '<br>');
            
            // Make specific URL fields clickable
            const urlFields = ["SP.dataFrameFile", "SP.imageFile", "SP.tableImageFile"];
            if (urlFields.includes(key) && value) {
                const fullUrl = `${display_url_prefix}${value}`;
                valueStr = `<a href="${fullUrl}" target="_blank" style="color: ${valueColor}; text-decoration: underline;">${valueStr}</a>`;
            }
            
            // Add both class and inline style for the key
            html += `<span class="json-key" style="font-family: Consolas, Menlo, Monaco, monospace !important; color: ${keyColor}; font-weight: 700 !important;">${key}</span>: ` +
                   `<span style="color: ${valueColor}">${valueStr}</span><br>`;
        });
        
        html += '</div>';
    });
    return html;
}

function scrollToJsonEntry(index) {
    const entry = document.getElementById(`json-entry-${index}`);
    if (entry) {
        const container = document.getElementById('json-container');
        
        // Scroll the JSON entry into view
        entry.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        // Highlight corresponding box
        highlightBox(index);
    }
}

function createOverlayBoxes(img, wrapper, data, fileIndex) {
    return function() {
        const imgRect = img.getBoundingClientRect();
        const wrapperRect = wrapper.getBoundingClientRect();
        
        const displayImageWidth = img.clientWidth;
        const displayImageHeight = img.clientHeight;
        const displayOffsetX = (imgRect.left - wrapperRect.left);
        const displayOffsetY = (imgRect.top - wrapperRect.top);
        
        // Create a map to track ALL indices for each coordinate
        const coordMap = new Map();
        
        // First pass: record ALL indices for each coordinate
        data.forEach((bbox, bboxIndex) => {
            if (bbox.page === fileIndex) {
                const x1 = bbox.scaled_x_1 !== undefined ? bbox.scaled_x_1 : bbox.x1;
                const y1 = bbox.scaled_y_1 !== undefined ? bbox.scaled_y_1 : bbox.y1;
                const x2 = bbox.scaled_x_2 !== undefined ? bbox.scaled_x_2 : bbox.x2;
                const y2 = bbox.scaled_y_2 !== undefined ? bbox.scaled_y_2 : bbox.y2;
                
                const coordKey = `${x1},${y1},${x2},${y2}`;
                if (!coordMap.has(coordKey)) {
                    coordMap.set(coordKey, [bboxIndex]);
                } else {
                    coordMap.get(coordKey).push(bboxIndex);
                }
            }
        });
        
        // Create overlay boxes using the coordinate map
        coordMap.forEach((indices, coordKey) => {
            const [x1, y1, x2, y2] = coordKey.split(',').map(Number);
            const firstBbox = data[indices[0]]; // Use first bbox for dimensions
            
            const overlay_box = document.createElement('div');
            overlay_box.classList.add('bounding-box');
            // Store all related indices as a data attribute
            overlay_box.dataset.indices = indices.join(',');
            overlay_box.id = `box-${indices[0]}`; // Use first index as ID
            
            const docWidth = firstBbox.doc_width_px !== undefined ? firstBbox.doc_width_px : 1000;
            const docHeight = firstBbox.doc_height_px !== undefined ? firstBbox.doc_height_px : 1000;
            
            const relOffsetX = x1 / docWidth * displayImageWidth;
            const relOffsetY = y1 / docHeight * displayImageHeight;
            const scaleWidth = (x2 - x1) / docWidth;
            const scaleHeight = (y2 - y1) / docHeight;
            
            overlay_box.style.left = `${displayOffsetX + relOffsetX}px`;
            overlay_box.style.top = `${displayOffsetY + relOffsetY}px`;
            overlay_box.style.width = `${displayImageWidth * scaleWidth}px`;
            overlay_box.style.height = `${displayImageHeight * scaleHeight}px`;
            
            overlay_box.addEventListener('click', () => {
                // When clicked, always go to the first index for this coordinate
                scrollToJsonEntry(indices[0]);
            });
            
            wrapper.appendChild(overlay_box);
            
            if (indices.includes(0) && fileIndex === 0 && currentHighlightedBoxIndex === 0) {
                overlay_box.classList.add('active-box');
            }
        });
    };
}

// Sync Scroll Functionality
function setupSyncScroll() {
    const syncButton = document.getElementById('sync-button');
    const jsonContainer = document.getElementById('json-container');
    
    syncButton.addEventListener('click', () => {
        syncScrollEnabled = !syncScrollEnabled;
        syncButton.classList.toggle('active', syncScrollEnabled);
        
        if (syncScrollEnabled) {
            syncButton.textContent = 'Sync On';
            // Start monitoring JSON scroll
            startJsonScrollMonitoring();
        } else {
            syncButton.textContent = 'Sync Scroll';
            // Stop monitoring
            stopJsonScrollMonitoring();
        }
    });
}

function startJsonScrollMonitoring() {
    const jsonContainer = document.getElementById('json-container');
    
    // Initial sync based on current JSON position
    updateFromJsonPosition();
    
    // Add scroll listener
    jsonContainer.addEventListener('scroll', handleJsonScroll);
}

function stopJsonScrollMonitoring() {
    const jsonContainer = document.getElementById('json-container');
    jsonContainer.removeEventListener('scroll', handleJsonScroll);
}

function handleJsonScroll() {
    // Clear any existing timeout to debounce scroll events
    if (scrollTimeout) {
        clearTimeout(scrollTimeout);
    }
    
    // Set a new timeout
    scrollTimeout = setTimeout(() => {
        updateFromJsonPosition();
    }, 100);
}

function updateFromJsonPosition() {
    const jsonContainer = document.getElementById('json-container');
    const containerRect = jsonContainer.getBoundingClientRect();
    const jsonEntries = document.getElementsByClassName('json-entry');
    
    let topVisibleEntry = null;
    let minDistance = Infinity;
    
    // Find the entry closest to the top of the viewport
    Array.from(jsonEntries).forEach(entry => {
        const entryIndex = parseInt(entry.id.replace('json-entry-', ''));
        const entryRect = entry.getBoundingClientRect();
        const distance = entryRect.top - containerRect.top;
        
        // Find the first visible entry (or the one closest to being visible from the top)
        // ALERT: -20 magically accounts for ending json top position in sync mode when click image
        if ((distance >= -20 && distance < minDistance) || 
            (topVisibleEntry === null && distance < 0)) {
            minDistance = Math.abs(distance);
            topVisibleEntry = entryIndex;
        }
    });
    
    if (topVisibleEntry !== null) {
        const bbox = bbox_data[topVisibleEntry];
        const pageIndex = bbox.page;
        
        // Highlight the box and scroll to its page
        highlightBox(topVisibleEntry);
        
        // Only scroll the image if we need to change pages
        const currentPageIndicator = document.getElementById('page-indicator');
        const currentPage = parseInt(currentPageIndicator.textContent.replace('Page: ', ''));
        
        if (currentPage !== pageIndex) {
            const imageContainer = document.getElementById('image-container');
            const imageWrappers = imageContainer.getElementsByClassName('image-wrapper');
            
            // Change page
            if (imageWrappers[pageIndex]) {
                imageWrappers[pageIndex].scrollIntoView({
                    behavior: 'smooth', 
                    block: 'start'
                });
                updatePageIndicator(pageIndex);
                
                // After page is visible, ensure the box is visible
                setTimeout(() => {
                    ensureBoxVisible(`box-${topVisibleEntry}`);
                }, 300);
            }
        } else {
            // On the same page, make sure the box is visible
            ensureBoxVisible(`box-${topVisibleEntry}`);
        }
    }
}

// Setup new buttons
function setupFeedbackButton() {
    const feedbackButton = document.getElementById('feedback-button');
    feedbackButton.addEventListener('click', () => {
        window.open('https://c3energy.atlassian.net/wiki/spaces/GENAI/pages/9373516443/Mew3+pilot+feedback+new+multimodal+pdf+parser', '_blank');
    });
}

function syntaxHighlight(json) {
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|true|false|null|-?\d+(\.\d+)?([eE][+-]?\d+)?)/g, function (match) {
        let cls = '';
        
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'json-key';
                // Add inline style for bold
                return `<span class="${cls}" style="font-weight: 700;">${match}</span>`;
            } else {
                cls = 'json-string';
            }
        } else if (/^(true|false)$/.test(match)) {
            cls = 'json-boolean';
        } else if (/^null$/.test(match)) {
            cls = 'json-null';
        } else if (/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(match.trim())) {
            cls = 'json-number';
        }

        return `<span class="${cls}">${match}</span>`;
    });
}


function setupInfoButton() {
    const infoButton = document.getElementById('info-button');
    const infoContainer = document.getElementById('document-info-container');
    
    // Create the info container content if it doesn't exist
    if (!infoContainer.innerHTML) {
        // Add close button
        const closeButton = document.createElement('button');
        closeButton.className = 'close-button';
        closeButton.innerHTML = '&times;';
        closeButton.addEventListener('click', () => {
            infoContainer.style.display = 'none';
            infoButton.classList.remove('active');
        });
        
        // Add title
        const title = document.createElement('h3');
        title.textContent = 'Document Information';
        
        // Add content
        const content = document.createElement('pre');
        content.innerHTML = syntaxHighlight(JSON.stringify(document_info, null, 4));
        
        // Append everything
        infoContainer.appendChild(closeButton);
        infoContainer.appendChild(title);
        infoContainer.appendChild(content);
    }
    
    infoButton.addEventListener('click', () => {
        if (infoContainer.style.display === 'block') {
            infoContainer.style.display = 'none';
            infoButton.classList.remove('active');
        } else {
            infoContainer.style.display = 'block';
            infoButton.classList.add('active');
        }
    });
    
    // Close when clicking outside
    document.addEventListener('click', (event) => {
        if (!infoContainer.contains(event.target) && 
            event.target !== infoButton) {
            infoContainer.style.display = 'none';
            infoButton.classList.remove('active');
        }
    });
}

function setupDownloadButton() {
    const downloadButton = document.getElementById('download-button');
    
    downloadButton.addEventListener('click', () => {
        // Get the current HTML content
        const htmlContent = document.documentElement.outerHTML;
        
        // Create a blob with the HTML content
        const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        const url = window.URL.createObjectURL(blob);
        
        // Create a download link
        const downloadLink = document.createElement('a');
        downloadLink.href = url;
        downloadLink.download = 'dashboard.html';
        
        // Trigger download
        document.body.appendChild(downloadLink);
        downloadLink.click();
        
        // Cleanup
        document.body.removeChild(downloadLink);
        window.URL.revokeObjectURL(url);
    });
}


// Initialize on page load
document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM loaded, initializing viewer");
    initializeViewer(bbox_data, image_base64);
    setupFeedbackButton();
    setupInfoButton();
    setupDownloadButton();
});

// Also try immediate initialization if DOM is already loaded
if (document.readyState === "complete" || document.readyState === "interactive") {
    console.log("DOM already ready, initializing immediately");
    setTimeout(function() {
        initializeViewer(bbox_data, image_base64);
        setupFeedbackButton();
        setupInfoButton();
        setupDownloadButton();
    }, 1);
}
"""
