# Copyright 2009-2024 C3 AI (www.c3.ai). All Rights Reserved.
# This material, including without limitation any software, is the confidential trade secret and proprietary
# information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
# strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
# This material may be covered by one or more patents or pending patent applications.

from __future__ import annotations

import base64
import glob
import json
import logging
import os
from typing import List

import numpy as np

from mew3.document import Content
from mew3.layout import LayoutParserOutput

from .c3_styling import HTML_CONTENT_STRING, JS_SCRIPT_STRING

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.ERROR)


class UiDebugger:
    """

    Processing layout/component parser outputs for debugging.
    Pdf with bounding boxes overlay are stored.
    Json from either mew3 output or c3.Genai.SourcePassage are stored.
    Should work both in Jupyter notebook and in console.

    Serve an UI to view the stored images and bounding boxes in a webpage.
    """

    def __init__(
        self,
        doc_parser,
        bounding_boxes: LayoutParserOutput,
        text_components: LayoutParserOutput | None = None,
        image_components: LayoutParserOutput | None = None,
        table_components: LayoutParserOutput | None = None,
        bbox_class_to_overlay: str = "markdown_class",
        output_dir: str = "ui_debugger_output",
    ):
        self.doc_parser = doc_parser
        self.bounding_boxes = bounding_boxes
        self.document = self.bounding_boxes.document
        self.document_info = self._get_document_info()
        self.text_components = text_components
        self.image_components = image_components
        self.table_components = table_components
        self.box_class_to_overlay = bbox_class_to_overlay
        self.output_dir = output_dir

        os.makedirs(f"{self.output_dir}/images", exist_ok=True)
        os.makedirs(f"{self.output_dir}/bboxes", exist_ok=True)

        self.run()

    def run(self):
        """
        Generate bboxes, images; render html using these data; save to local folder.
        """

        self._save_img_with_bbox()
        self._save_bboxes_as_json()
        self._create_html_file()
        out_html = self._render_html_url()
        self.output_html = out_html

        return out_html

    def _render_html_url(self):
        """
        Render links in jupyter:
        1. click to open dashboard in new jupyter window.
        2. click to download html to local s.t. user can open in browser.
        """

        from IPython.display import HTML

        file_path = f"{self.output_dir}/html/dashboard.html"

        open_link = f'<a href="{file_path}" target="_blank">Click to open Debugger Dashboard</a>'
        download_link = f'<a href="{file_path}" download>Download dashboard here</a>'

        out = HTML(f"{open_link}<br><br>{download_link}")

        return out

    def _create_html_file(self) -> None:
        """
        Display the PDF debugger interface in a Jupyter notebook cell.

        Parameters:
        -----------
        image_dir : str
            Directory containing the image files (PNG format)
        bbox_json_path : str
            Path to the JSON file containing bounding box data
        output_path : str, optional
            Path to save the HTML file for external viewing

        Returns:
        --------
        IPython.display.HTML
            HTML display object for rendering in the notebook
        """

        with open(f"{self.output_dir}/bboxes/bounding_boxes.json") as f:
            bbox_data = json.load(f)

        # Find all image files and sort them naturally
        image_base64 = []
        all_images = glob.glob(f"{self.output_dir}/images/*.png")
        image_files = sorted(all_images, key=lambda x: int(x.split("_")[-1].split(".")[0]))

        for img_path in image_files:
            with open(img_path, "rb") as f:
                img_data = base64.b64encode(f.read()).decode()
                image_base64.append(f"data:image/png;base64,{img_data}")

        js_string = JS_SCRIPT_STRING.replace("{BBOX_DATA}", json.dumps(bbox_data))
        js_string = js_string.replace("{IMAGE_DATA}", json.dumps(image_base64))
        js_string = js_string.replace("{DOCUMENT_INFO}", json.dumps(self.document_info))
        js_string = js_string.replace("{DEBUGGER}", "jupyter")
        output_html = HTML_CONTENT_STRING.replace("{JS_SCRIPT}", js_string)

        os.makedirs(f"{self.output_dir}/html", exist_ok=True)
        with open(f"{self.output_dir}/html/dashboard.html", "w") as f:
            f.write(output_html)

    def _get_document_info(self):
        info = {
            "file_info": {
                "filename": self.document.filename,
                "fname": self.document.name,
                "filetype": self.document.type,
                "rel_scale": self.document.rel_scale,
                "dpi": self.document.dpi,
            },
            "full_specs": self.doc_parser.to_dict(),
            "cropping_strategy": {
                "text_crop": self.document.text_crop,
                "image_crop": self.document.image_crop,
                "table_crop": self.document.table_crop,
                "page_cnt": self.document.page_cnt,
                "grid_gen": self.document.grid_gen,
            },
        }

        return info

    def _bboxes_to_json(self) -> List[dict]:
        """
        Convert bboxes obtained from
            DocumentParser.text_parser()
            DocumentParser.image_parser()
            DocumentParser.table_parser()
        into json format. Remove stored image objects.
        """

        components = []

        if self.text_components:
            components.extend(self.text_components.to_records())

        if self.image_components:
            tmp_image_components = self.image_components.to_records()
            # remove np.ndarray from the image components
            for img_obj in tmp_image_components:
                img_obj.pop("image")
            components.extend(tmp_image_components)

        if self.table_components:

            tmp_table_components = self.table_components.to_records()
            # remove np.ndarray from the table components
            for img_obj in tmp_table_components:
                img_obj.pop("table_image")
            components.extend(tmp_table_components)

        components = sorted(components, key=lambda x: x["page"])

        return components

    def _save_bboxes_as_json(self) -> None:
        """
        Save list of parsed components to json file.
        """

        list_components = self._bboxes_to_json()

        output_json = list_components.copy()

        for item in output_json:
            pc = self.bounding_boxes.document.page_contents[item["page"]]
            pc_height, pc_width, _ = np.shape(pc)

            item["score"] = float(item["score"])
            item["doc_height_px"] = pc_height
            item["doc_width_px"] = pc_width

            item["scaled_x_1"] = item["x_1"] * self.bounding_boxes.document.rel_scale
            item["scaled_y_1"] = item["y_1"] * self.bounding_boxes.document.rel_scale
            item["scaled_x_2"] = item["x_2"] * self.bounding_boxes.document.rel_scale
            item["scaled_y_2"] = item["y_2"] * self.bounding_boxes.document.rel_scale

        output_json = sorted(output_json, key=lambda x: (x["page"], x["scaled_y_1"], x["scaled_x_1"]))

        with open(f"{self.output_dir}/bboxes/bounding_boxes.json", "w", encoding="utf-8") as f:
            json.dump(output_json, f, indent=4)

    def _save_img_with_bbox(self) -> None:
        """
        Save images of each page with bounding boxes overlay.
        """

        import matplotlib.pyplot as plt
        import seaborn as sns
        from matplotlib.patches import Patch, Rectangle

        sns.set_theme()

        palette = sns.color_palette("husl", 8)

        color_map = {
            "PLAIN": palette[0],
            "Text": palette[0],
            "HEADER": palette[1],
            "Header": palette[1],
            "LIST": palette[3],
            "List-item": palette[3],
            "FIGURE": palette[5],
            "Figure": palette[5],
            "Picture": palette[5],
            "Formula": palette[5],
            "TABLE": palette[6],
            "Table": palette[6],
            "CAPTION": palette[7],
            "Caption": palette[7],
            "IDK": "gray",
            "Page-footer": "gray",
            "Page-header": "gray",
        }

        def _save_page_img(bboxes_on_page, img: Content, idx: int) -> None:
            img_dpi = 250  # DO NOT CHANGE
            img_height, img_width, _ = np.shape(img)

            # Create figure with exact size. DO NOT CHANGE.
            fig = plt.figure(figsize=(img_width / 100, img_height / 100), dpi=img_dpi)

            # Add axis that takes up entire figure. DO NO CHANGE.
            ax = fig.add_axes((0, 0, 1, 1))
            ax.imshow(img)

            seen_klass = set()
            for bbox in bboxes_on_page:
                x0, y0, x1, y1 = bbox.scaled_bbox

                curr_class = bbox[self.box_class_to_overlay]
                if curr_class not in color_map:
                    color_map[curr_class] = "gray"

                color = color_map[curr_class]
                seen_klass.add(curr_class)
                rect = Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, color=color, lw=3, alpha=0.7)
                ax.add_patch(rect)
                ax.text(
                    x0,
                    y0,
                    str(np.round(float(bbox.score), 3)),
                    color=color,
                    fontsize=16,
                )

            plt.axis("off")
            plt.legend(
                handles=[Patch(facecolor=color_map[klass], label=klass) for klass in seen_klass],
                prop={"size": 12},
            )

            plt.savefig(f"{self.output_dir}/images/page_{idx}.png", dpi=img_dpi, pad_inches=0)
            plt.close(fig)

        for idx, (bboxes_on_page, img) in enumerate(zip(self.bounding_boxes, self.document.page_contents)):
            _save_page_img(bboxes_on_page, img, idx)
